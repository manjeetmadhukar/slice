/*!
 * Slice Browse Recovery Tracker (v1.3.0)

 *
 * Add to your Shopify/WooCommerce storefront to capture product views and
 * trigger WhatsApp reminders for identified visitors who don't purchase.
 *
 * Setup:
 *   <script>window.SliceBrowseRecovery = { token: "brt_xxx" };</script>
 *   <script src="https://slice.dotscube.com/slice-browse-tracker.js" defer></script>
 *
 * Optional identification (call whenever you know the visitor):
 *   SliceBrowseRecovery.identify({ phone: "+919812345678", name: "Ali", email: "a@b.com" });
 *
 * Manual product view (if auto-detect misses a page):
 *   SliceBrowseRecovery.track({ product_id, product_title, product_url, price, currency, product_image_url, category });
 */
(function () {
  var API_BASE = "https://slice.dotscube.com/api/public/browse-track";
  var STORAGE_KEY = "slice_br_visitor";

  function getConfig() {
    return (window.SliceBrowseRecovery && window.SliceBrowseRecovery.config) || window.SliceBrowseRecovery || {};
  }

  function loadVisitor() {
    try {
      var raw = localStorage.getItem(STORAGE_KEY);
      var v = raw ? JSON.parse(raw) : {};
      if (!v.visitor_key) {
        v.visitor_key = "v_" + Date.now().toString(36) + "_" + Math.random().toString(36).slice(2, 12);
        saveVisitor(v);
      }
      return v;
    } catch (_e) { return {}; }
  }
  function saveVisitor(v) {
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(v)); } catch (_e) {}
  }

  function sessionKey() {
    try {
      var k = sessionStorage.getItem("slice_br_session");
      if (!k) {
        k = "s_" + Date.now().toString(36) + "_" + Math.random().toString(36).slice(2, 10);
        sessionStorage.setItem("slice_br_session", k);
      }
      return k;
    } catch (_e) { return null; }
  }

  function post(payload) {
    var cfg = getConfig();
    if (!cfg.token) { console.warn("[Slice] Browse tracker missing token"); return; }
    var visitor = loadVisitor();
    var body = JSON.stringify(Object.assign({ token: cfg.token, session_key: sessionKey(), visitor_key: visitor.visitor_key || null }, payload));
    // NOTE: use text/plain so the request stays a CORS "simple request".
    // sendBeacon cannot perform preflight, so application/json would fail.
    try {
      if (navigator.sendBeacon) {
        var blob = new Blob([body], { type: "text/plain;charset=UTF-8" });
        if (navigator.sendBeacon(API_BASE, blob)) return;
      }
    } catch (_e) {}
    try {
      fetch(API_BASE, { method: "POST", headers: { "Content-Type": "text/plain;charset=UTF-8" }, body: body, keepalive: true });
    } catch (_e) {}
  }

  function detectShopifyProduct() {
    if (!window.ShopifyAnalytics || !ShopifyAnalytics.meta || !ShopifyAnalytics.meta.product) return null;
    var p = ShopifyAnalytics.meta.product;
    var variant = (p.variants && p.variants[0]) || {};
    return {
      product_id: String(p.id || variant.product_id || ""),
      product_title: p.title || document.title,
      product_url: location.origin + location.pathname,
      product_image_url: (window.ShopifyAnalytics.meta && window.ShopifyAnalytics.meta.selectedVariantId) ? null : (p.featured_image || null),
      price: variant.price ? Number(variant.price) / 100 : null,
      currency: (window.Shopify && Shopify.currency && Shopify.currency.active) || null,
      category: p.type || null,
      source: "shopify",
    };
  }

  function detectWooProduct() {
    // WooCommerce product pages carry a body class 'single-product' and a
    // <div class="product" id="product-{id}"> or postid-{id} body class.
    if (document.body.className.indexOf("single-product") === -1) return null;
    var idMatch = document.body.className.match(/postid-(\d+)/);
    var el = document.querySelector('meta[property="og:image"]');
    var priceEl = document.querySelector(".woocommerce-Price-amount");
    return {
      product_id: idMatch ? idMatch[1] : (document.querySelector(".product")?.id?.replace(/^product-/, "") || location.pathname),
      product_title: document.querySelector(".product_title,.entry-title,h1")?.textContent?.trim() || document.title,
      product_url: location.origin + location.pathname,
      product_image_url: el?.getAttribute("content") || null,
      price: priceEl ? Number((priceEl.textContent || "").replace(/[^\d.]/g, "")) : null,
      currency: (document.querySelector('meta[property="product:price:currency"]')?.getAttribute("content")) || null,
      category: document.querySelector(".posted_in a")?.textContent || null,
      source: "woocommerce",
    };
  }

  function autoTrack() {
    var product = detectShopifyProduct() || detectWooProduct();
    if (!product || !product.product_id) return;
      var v = loadVisitor();
      post(Object.assign({}, product, v));
  }

  function sendIdentify(v) {
    if (!v || !v.phone) return;
    post({ type: "identify", phone: v.phone, name: v.name || null, email: v.email || null });
  }

  function asObjectFromBody(body) {
    try {
      if (!body) return null;
      if (typeof FormData !== "undefined" && body instanceof FormData) {
        var out = {};
        body.forEach(function (value, key) { out[key] = value; });
        return out;
      }
      if (typeof URLSearchParams !== "undefined" && body instanceof URLSearchParams) {
        var paramsOut = {};
        body.forEach(function (value, key) { paramsOut[key] = value; });
        return paramsOut;
      }
      if (typeof body === "string") {
        var txt = body.trim();
        if (!txt) return null;
        if (txt.charAt(0) === "{" || txt.charAt(0) === "[") return JSON.parse(txt);
        if (txt.indexOf("=") !== -1) {
          var usp = new URLSearchParams(txt);
          var qsOut = {};
          usp.forEach(function (value, key) { qsOut[key] = value; });
          return qsOut;
        }
      }
      if (typeof body === "object" && body.constructor === Object) return body;
    } catch (_e) {}
    return null;
  }

  function isObject(v) { return v && typeof v === "object"; }
  function pickDeep(obj, tests, depth) {
    if (!isObject(obj) || depth > 5) return null;
    var keys = Object.keys(obj);
    for (var i = 0; i < keys.length; i++) {
      var key = keys[i];
      var val = obj[key];
      for (var t = 0; t < tests.length; t++) {
        if (tests[t].test(key) && val != null && typeof val !== "object" && String(val).trim()) return String(val).trim();
      }
    }
    for (var j = 0; j < keys.length; j++) {
      var child = obj[keys[j]];
      var found = pickDeep(child, tests, depth + 1);
      if (found) return found;
    }
    return null;
  }

  function identifyFromObject(obj) {
    try {
      if (!isObject(obj)) return;
      var phone = pickDeep(obj, [/^billing[_-]?phone$/i, /^shipping[_-]?phone$/i, /^phone$/i, /mobile/i, /telephone/i, /^tel$/i], 0);
      if (!phone || digits(phone).length < 8) return;
      var email = pickDeep(obj, [/^billing[_-]?email$/i, /^email$/i, /email/i], 0);
      var first = pickDeep(obj, [/^billing[_-]?first[_-]?name$/i, /^first[_-]?name$/i, /^given[_-]?name$/i], 0);
      var last = pickDeep(obj, [/^billing[_-]?last[_-]?name$/i, /^last[_-]?name$/i, /^family[_-]?name$/i], 0);
      var name = [first, last].filter(Boolean).join(" ") || pickDeep(obj, [/^billing[_-]?name$/i, /^customer[_-]?name$/i, /^name$/i], 0);
      api.identify({ phone: phone, email: email || null, name: name || null });
    } catch (_e) {}
  }

  var api = {
    identify: function (info) {
      var v = loadVisitor();
      var changed = false;
      if (info && info.phone && v.phone !== String(info.phone)) { v.phone = String(info.phone); changed = true; }
      if (info && info.name && v.name !== String(info.name)) { v.name = String(info.name); changed = true; }
      if (info && info.email && v.email !== String(info.email)) { v.email = String(info.email); changed = true; }
      if (!changed) return;
      saveVisitor(v);
      // Backfill any earlier anonymous views from this session/visitor.
      sendIdentify(v);
    },
    track: function (payload) {
      var v = loadVisitor();
      post(Object.assign({}, payload, v));
    },
    reset: function () { try { localStorage.removeItem(STORAGE_KEY); } catch (_e) {} },
  };

  // Preserve any inline config
  var existing = window.SliceBrowseRecovery || {};
  window.SliceBrowseRecovery = Object.assign(api, existing, { config: existing });

  // ---- Automatic visitor identification -------------------------------
  function digits(s) { return String(s || "").replace(/\D/g, ""); }

  function identifyFromUrl() {
    try {
      var q = new URLSearchParams(location.search);
      var p = q.get("phone") || q.get("ph") || q.get("billing_phone") || q.get("tel");
      var n = q.get("name") || q.get("billing_first_name");
      var e = q.get("email") || q.get("billing_email");
      if (p && digits(p).length >= 8) api.identify({ phone: p, name: n, email: e });
    } catch (_e) {}
  }

  function identifyFromConfig() {
    var cfg = getConfig();
    var c = cfg.customer || cfg.identity;
    if (c && c.phone) api.identify(c);
    identifyFromObject(c);
  }

  var PHONE_SELECTOR = [
    "#billing_phone", "input[name='billing_phone']", "input[name='billing[phone]']",
    "input[name='phone']", "input[name='checkout[billing_address][phone]']",
    "input[type='tel']", "input[autocomplete='tel']", "input[autocomplete='tel-national']",
    "input[id*='phone' i]", "input[name*='phone' i]", "input[aria-label*='phone' i]", "input[placeholder*='phone' i]",
    "input[id*='mobile' i]", "input[name*='mobile' i]", "input[aria-label*='mobile' i]", "input[placeholder*='mobile' i]",
  ].join(",");
  var EMAIL_SELECTOR = "#billing_email,input[name='billing_email'],input[name='email'],input[type='email'],input[id*='email' i],input[name*='email' i],input[aria-label*='email' i],input[placeholder*='email' i]";
  var NAME_SELECTOR = "#billing_first_name,input[name='billing_first_name'],input[name='first_name'],input[name='name'],input[autocomplete='given-name'],input[id*='first' i],input[name*='first' i],input[aria-label*='first' i],input[placeholder*='first' i]";

  function scanForms() {
    try {
      var phones = Array.prototype.slice.call(document.querySelectorAll(PHONE_SELECTOR));
      var phoneEl = null;
      for (var i = 0; i < phones.length; i++) {
        if (digits(phones[i].value).length >= 8) { phoneEl = phones[i]; break; }
      }
      if (!phoneEl) return;
      var scope = phoneEl.closest && phoneEl.closest("form,.wc-block-components-checkout-step,.woocommerce-checkout,.checkout,.cart,.entry-content");
      var emailEl = (scope && scope.querySelector(EMAIL_SELECTOR)) || document.querySelector(EMAIL_SELECTOR);
      var nameEl = (scope && scope.querySelector(NAME_SELECTOR)) || document.querySelector(NAME_SELECTOR);
      api.identify({
        phone: phoneEl.value,
        email: emailEl && emailEl.value ? emailEl.value : null,
        name: nameEl && nameEl.value ? nameEl.value : null,
      });
    } catch (_e) {}
  }

  function scanStorageForIdentity() {
    try {
      [localStorage, sessionStorage].forEach(function (store) {
        for (var i = 0; i < store.length; i++) {
          var key = store.key(i) || "";
          if (!/(wc|woo|cart|checkout|customer|billing|shipping)/i.test(key)) continue;
          var raw = store.getItem(key);
          if (!raw || raw.length > 50000) continue;
          identifyFromObject(JSON.parse(raw));
        }
      });
    } catch (_e) {}
  }

  function watchWooCommerceRequests() {
    function relevant(url) { return /\/wc\/store\/|wc-ajax|admin-ajax|checkout|cart|woocommerce/i.test(String(url || "")); }
    function inspect(url, body) {
      try {
        if (!relevant(url)) return;
        var obj = asObjectFromBody(body);
        if (obj) identifyFromObject(obj);
      } catch (_e) {}
    }

    try {
      if (window.fetch && !window.fetch.__sliceBrowseRecoveryWrapped) {
        var originalFetch = window.fetch;
        var wrappedFetch = function (input, init) {
          try {
            var url = typeof input === "string" ? input : (input && input.url);
            if (init && init.body) inspect(url, init.body);
            else if (input && typeof input.clone === "function" && relevant(url)) {
              input.clone().text().then(function (txt) { inspect(url, txt); }).catch(function () {});
            }
          } catch (_e) {}
          return originalFetch.apply(this, arguments);
        };
        wrappedFetch.__sliceBrowseRecoveryWrapped = true;
        window.fetch = wrappedFetch;
      }
    } catch (_e) {}

    try {
      if (window.XMLHttpRequest && !window.XMLHttpRequest.prototype.__sliceBrowseRecoveryWrapped) {
        var originalOpen = window.XMLHttpRequest.prototype.open;
        var originalSend = window.XMLHttpRequest.prototype.send;
        window.XMLHttpRequest.prototype.open = function (method, url) {
          this.__sliceBrowseRecoveryUrl = url;
          return originalOpen.apply(this, arguments);
        };
        window.XMLHttpRequest.prototype.send = function (body) {
          inspect(this.__sliceBrowseRecoveryUrl, body);
          return originalSend.apply(this, arguments);
        };
        window.XMLHttpRequest.prototype.__sliceBrowseRecoveryWrapped = true;
      }
    } catch (_e) {}
  }

  function bindFormWatchers() {
    ["input", "change", "blur", "focusout", "submit"].forEach(function (ev) {
      document.addEventListener(ev, scanForms, true);
    });
    // Periodic sweep catches JS-driven (block) checkouts that don't fire change.
    var ticks = 0;
    var iv = setInterval(function () {
      ticks++;
      scanForms();
      if (ticks > 60) clearInterval(iv);
    }, 3000);
    window.addEventListener("beforeunload", scanForms);
  }

  function boot() {
    identifyFromConfig();
    identifyFromUrl();
    autoTrack();
    watchWooCommerceRequests();
    scanStorageForIdentity();
    bindFormWatchers();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", boot);
  } else {
    boot();
  }
})();

