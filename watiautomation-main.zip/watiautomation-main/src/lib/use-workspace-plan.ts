import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useWorkspace } from "@/lib/workspace-context";

export interface WorkspacePlan {
  plan_name: string;
  features: Record<string, boolean>;
  limits: Record<string, number>;
  notes: string | null;
}

export function useWorkspacePlan() {
  const { currentWorkspaceId } = useWorkspace();
  const query = useQuery({
    queryKey: ["workspace-plan", currentWorkspaceId],
    enabled: !!currentWorkspaceId,
    queryFn: async (): Promise<WorkspacePlan | null> => {
      const { data, error } = await supabase
        .from("workspace_plans")
        .select("plan_name, features, limits, notes")
        .eq("workspace_id", currentWorkspaceId!)
        .maybeSingle();
      if (error) throw error;
      if (!data) return null;
      return {
        plan_name: data.plan_name,
        features: (data.features ?? {}) as Record<string, boolean>,
        limits: (data.limits ?? {}) as Record<string, number>,
        notes: data.notes,
      };
    },
  });

  const plan = query.data ?? null;
  // If no plan assigned -> allow everything (backwards compatible)
  // If plan assigned -> only features explicitly true are allowed
  const hasFeature = (key: string): boolean => {
    if (!plan) return true;
    return plan.features?.[key] === true;
  };

  return { plan, hasFeature, isLoading: query.isLoading };
}
