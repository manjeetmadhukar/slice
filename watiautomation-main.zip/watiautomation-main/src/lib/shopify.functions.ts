// Client-callable server functions for the Shopify integration.
import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import {
  normalizeShopDomain, getAppBaseUrl, backfillStore,
  registerWebhooks, persistWebhookMeta, deleteAllWebhooks, logEvent,
} from "@/lib/shopify.server";
import { supabaseAdmin } from "@/integrations/supabase/client.server";

export const getShopifyInstallUrl = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((i) =>
    z.object({
      workspace_id: z.string().uuid(),
      shop: z.string().min(3).max(120),
    }).parse(i),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const shop = normalizeShopDomain(data.shop);
    if (!shop) throw new Error("Enter a valid Shopify domain like my-store.myshopify.com");

    const { data: member } = await supabase
      .from("workspace_members").select("role")
      .eq("workspace_id", data.workspace_id).eq("user_id", userId).maybeSingle();
    if (!member || !["owner", "admin"].includes((member as any).role)) {
      throw new Error("Admin permission required to connect Shopify");
    }

    const base = getAppBaseUrl();
    const url = `${base}/api/public/shopify/install?shop=${encodeURIComponent(shop)}&workspace_id=${encodeURIComponent(data.workspace_id)}`;
    return { url, shop };
  });

async function loadShopifyIntegration(supabase: any, workspaceId: string, userId: string) {
  const { data: member } = await supabase
    .from("workspace_members").select("role")
    .eq("workspace_id", workspaceId).eq("user_id", userId).maybeSingle();
  if (!member || !["owner", "admin"].includes((member as any).role)) {
    throw new Error("Admin permission required");
  }
  const { data: integ } = await supabase
    .from("store_integrations").select("*")
    .eq("workspace_id", workspaceId).eq("provider", "shopify").maybeSingle();
  if (!integ) throw new Error("Shopify is not connected for this workspace");
  const token = (integ as any).access_token;
  const shop = ((integ as any).meta?.shop) || String((integ as any).store_url || "").replace(/^https?:\/\//, "");
  if (!token || !shop) throw new Error("Missing Shopify access token — reconnect the store");
  return { integ, token, shop };
}

export const syncShopify = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((i) => z.object({ workspace_id: z.string().uuid() }).parse(i))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { integ, token, shop } = await loadShopifyIntegration(supabase, data.workspace_id, userId);

    // Re-register any missing webhooks before sync so future orders flow in
    try {
      const base = getAppBaseUrl();
      const cbUrl = `${base}/api/public/shopify/webhook?shop=${encodeURIComponent(shop)}`;
      const results = await registerWebhooks(shop, token, cbUrl);
      await persistWebhookMeta((integ as any).id, results);
      await logEvent({
        workspace_id: data.workspace_id, integration_id: (integ as any).id,
        direction: "out", event: "webhooks.reregistered",
        ok: results.every((r) => r.ok), response: results,
      });
    } catch (e: any) {
      await logEvent({
        workspace_id: data.workspace_id, integration_id: (integ as any).id,
        direction: "out", event: "webhooks.reregistered", ok: false,
        message: String(e?.message || e),
      });
    }

    const stats = await backfillStore(data.workspace_id, (integ as any).id, shop, token);
    return { ok: true, ...stats };
  });

export const reregisterShopifyWebhooks = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((i) => z.object({ workspace_id: z.string().uuid() }).parse(i))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { integ, token, shop } = await loadShopifyIntegration(supabase, data.workspace_id, userId);
    const base = getAppBaseUrl();
    const cbUrl = `${base}/api/public/shopify/webhook?shop=${encodeURIComponent(shop)}`;
    const results = await registerWebhooks(shop, token, cbUrl);
    await persistWebhookMeta((integ as any).id, results);
    await logEvent({
      workspace_id: data.workspace_id, integration_id: (integ as any).id,
      direction: "out", event: "webhooks.reregistered",
      ok: results.every((r) => r.ok), response: results,
    });
    return { ok: true, webhooks: results };
  });

export const disconnectShopify = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((i) => z.object({ workspace_id: z.string().uuid() }).parse(i))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { integ, token, shop } = await loadShopifyIntegration(supabase, data.workspace_id, userId).catch(() => ({ integ: null as any, token: "", shop: "" }));
    if (integ && token && shop) {
      try {
        const removed = await deleteAllWebhooks(shop, token);
        await logEvent({
          workspace_id: data.workspace_id, integration_id: (integ as any).id,
          direction: "out", event: "webhooks.removed",
          ok: removed.every((r) => r.ok), response: removed,
        });
      } catch (e: any) {
        await logEvent({
          workspace_id: data.workspace_id, integration_id: (integ as any).id,
          direction: "out", event: "webhooks.removed", ok: false,
          message: String(e?.message || e),
        });
      }
    }
    if (integ) {
      await supabaseAdmin.from("store_integrations").delete().eq("id", (integ as any).id);
    }
    return { ok: true };
  });
