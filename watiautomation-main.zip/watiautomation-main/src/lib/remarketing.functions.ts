import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const FilterSchema = z.object({
  workspace_id: z.string().uuid(),
  type: z.enum([
    "no_reply_days",
    "inactive_days",
    "campaign_status",
    "has_tags",
    "no_conversation",
    "engaged_days",
  ]),
  days: z.number().int().min(1).max(365).optional(),
  campaign_id: z.string().uuid().optional(),
  recipient_status: z.enum(["sent", "delivered", "failed", "read", "pending", "suppressed"]).optional(),
  tags: z.array(z.string().max(50)).max(20).optional(),
});

async function assertMember(supabase: any, workspaceId: string, userId: string) {
  const { data, error } = await supabase
    .from("workspace_members")
    .select("role")
    .eq("workspace_id", workspaceId)
    .eq("user_id", userId)
    .maybeSingle();
  if (error || !data) throw new Error("Not a member of this workspace");
}

export const buildRemarketingAudience = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) => FilterSchema.parse(input))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    await assertMember(supabase, data.workspace_id, userId);

    const { data: contacts } = await supabase
      .from("contacts")
      .select("id,name,phone,tags,created_at")
      .eq("workspace_id", data.workspace_id)
      .limit(5000);
    if (!contacts) return { contacts: [] };

    const cutoff = data.days
      ? new Date(Date.now() - data.days * 86400_000).toISOString()
      : null;

    // Preload phones -> contact map
    const byPhone = new Map<string, any>();
    for (const c of contacts) byPhone.set(c.phone.replace(/[^\d]/g, ""), c);

    let resultIds = new Set<string>();

    if (data.type === "has_tags") {
      const tags = (data.tags || []).map((t) => t.toLowerCase());
      if (!tags.length) return { contacts: [] };
      for (const c of contacts) {
        if ((c.tags || []).some((t: string) => tags.includes(t.toLowerCase()))) {
          resultIds.add(c.id);
        }
      }
    } else if (data.type === "no_conversation") {
      const { data: convos } = await supabase
        .from("conversations")
        .select("contact_phone")
        .eq("workspace_id", data.workspace_id);
      const hasConvo = new Set((convos || []).map((c: any) => c.contact_phone.replace(/[^\d]/g, "")));
      for (const c of contacts) {
        if (!hasConvo.has(c.phone.replace(/[^\d]/g, ""))) resultIds.add(c.id);
      }
    } else if (data.type === "campaign_status") {
      if (!data.campaign_id) throw new Error("Pick a campaign");
      const wantSuppressed = data.recipient_status === "suppressed";
      let q = supabase
        .from("campaign_recipients")
        .select("contact_id,status,error")
        .eq("workspace_id", data.workspace_id)
        .eq("campaign_id", data.campaign_id);
      if (data.recipient_status && !wantSuppressed) q = q.eq("status", data.recipient_status);
      const { data: recs } = await q;
      const suppressedRe = /131049|130472|131050|ecosystem engagement|part of an experiment|stop receiving marketing|opted out/i;
      for (const r of recs || []) {
        if (!r.contact_id) continue;
        if (wantSuppressed) {
          const isSup = r.status === "suppressed" || (r.error && suppressedRe.test(String(r.error)));
          if (!isSup) continue;
        }
        resultIds.add(r.contact_id);
      }
    } else if (data.type === "inactive_days") {
      // No conversation activity since cutoff
      const { data: convos } = await supabase
        .from("conversations")
        .select("contact_phone,last_message_at")
        .eq("workspace_id", data.workspace_id)
        .gte("last_message_at", cutoff!);
      const recent = new Set((convos || []).map((c: any) => c.contact_phone.replace(/[^\d]/g, "")));
      for (const c of contacts) {
        if (!recent.has(c.phone.replace(/[^\d]/g, ""))) resultIds.add(c.id);
      }
    } else if (data.type === "no_reply_days") {
      // Contacts whose last inbound message is older than cutoff (or none)
      const { data: convos } = await supabase
        .from("conversations")
        .select("id,contact_phone")
        .eq("workspace_id", data.workspace_id);
      const convoIds = (convos || []).map((c: any) => c.id);
      let lastInboundByConvo = new Map<string, string>();
      if (convoIds.length) {
        const { data: msgs } = await supabase
          .from("messages")
          .select("conversation_id,created_at")
          .eq("workspace_id", data.workspace_id)
          .eq("direction", "in")
          .in("conversation_id", convoIds)
          .order("created_at", { ascending: false })
          .limit(5000);
        for (const m of msgs || []) {
          if (!lastInboundByConvo.has(m.conversation_id)) {
            lastInboundByConvo.set(m.conversation_id, m.created_at);
          }
        }
      }
      const phoneToLastReply = new Map<string, string | null>();
      for (const c of convos || []) {
        const last = lastInboundByConvo.get(c.id) || null;
        const key = c.contact_phone.replace(/[^\d]/g, "");
        const prev = phoneToLastReply.get(key);
        if (!prev || (last && last > prev)) phoneToLastReply.set(key, last);
      }
      for (const c of contacts) {
        const key = c.phone.replace(/[^\d]/g, "");
        const last = phoneToLastReply.get(key);
        if (!last || last < cutoff!) resultIds.add(c.id);
      }
    } else if (data.type === "engaged_days") {
      // Contacts who DID reply (inbound message) within cutoff
      const { data: msgs } = await supabase
        .from("messages")
        .select("conversation_id")
        .eq("workspace_id", data.workspace_id)
        .eq("direction", "in")
        .gte("created_at", cutoff!);
      const convoIds = Array.from(new Set((msgs || []).map((m: any) => m.conversation_id)));
      if (convoIds.length) {
        const { data: convos } = await supabase
          .from("conversations")
          .select("contact_phone")
          .in("id", convoIds);
        const phones = new Set((convos || []).map((c: any) => c.contact_phone.replace(/[^\d]/g, "")));
        for (const c of contacts) {
          if (phones.has(c.phone.replace(/[^\d]/g, ""))) resultIds.add(c.id);
        }
      }
    }

    const matched = contacts.filter((c) => resultIds.has(c.id));
    return { contacts: matched };
  });
