// Client-callable server functions for Meta Lead Ads integration.
import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";

const SCOPES = [
  "pages_show_list",
  "pages_manage_metadata",
  "pages_read_engagement",
  "pages_manage_ads",
  "leads_retrieval",
  "business_management",
].join(",");

/** Build the Facebook OAuth URL for the current workspace. The user opens it in a popup or new tab. */
export const getMetaLeadConnectUrl = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { workspaceId: string; redirectUri: string }) =>
    z.object({ workspaceId: z.string().uuid(), redirectUri: z.string().url() }).parse(d),
  )
  .handler(async ({ data, context }) => {
    const { signState } = await import("@/lib/meta-leads.server");
    const appId = process.env.META_APP_ID;
    if (!appId) throw new Error("META_APP_ID not configured");
    const state = signState({
      w: data.workspaceId,
      u: context.userId,
      r: data.redirectUri,
      n: Math.random().toString(36).slice(2),
      t: String(Date.now()),
    });
    const url = new URL("https://www.facebook.com/v20.0/dialog/oauth");
    url.searchParams.set("client_id", appId);
    url.searchParams.set("redirect_uri", data.redirectUri);
    url.searchParams.set("state", state);
    url.searchParams.set("scope", SCOPES);
    url.searchParams.set("response_type", "code");
    return { url: url.toString() };
  });

/** List connections for current workspace. */
export const listMetaConnections = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { workspaceId: string }) => z.object({ workspaceId: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    const { data: conns, error } = await context.supabase
      .from("meta_lead_connections")
      .select("id, fb_user_id, fb_user_name, token_expires_at, created_at")
      .eq("workspace_id", data.workspaceId)
      .order("created_at", { ascending: false });
    if (error) throw error;
    return conns ?? [];
  });

/** Pull pages from Facebook for a connection and upsert. */
export const syncMetaPages = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { connectionId: string }) => z.object({ connectionId: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    const { graphGet } = await import("@/lib/meta-leads.server");
    const { data: conn, error } = await context.supabase
      .from("meta_lead_connections")
      .select("id, workspace_id, long_lived_token")
      .eq("id", data.connectionId)
      .single();
    if (error || !conn) throw new Error("Connection not found");

    const res = await graphGet("/me/accounts", conn.long_lived_token, {
      fields: "id,name,access_token,category,tasks",
      limit: "100",
    });
    const rows = (res.data ?? []).map((p: any) => ({
      connection_id: conn.id,
      workspace_id: conn.workspace_id,
      page_id: p.id,
      page_name: p.name,
      page_access_token: p.access_token,
      category: p.category ?? null,
    }));
    if (rows.length) {
      const { error: upErr } = await context.supabase
        .from("meta_lead_pages")
        .upsert(rows, { onConflict: "workspace_id,page_id" });
      if (upErr) throw upErr;
    }
    return { count: rows.length };
  });

/** List pages for a workspace (db read). */
export const listMetaPages = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { workspaceId: string }) => z.object({ workspaceId: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    const { data: pages, error } = await context.supabase
      .from("meta_lead_pages")
      .select("id, page_id, page_name, subscribed, category, connection_id")
      .eq("workspace_id", data.workspaceId)
      .order("page_name");
    if (error) throw error;
    return pages ?? [];
  });

/** Subscribe / unsubscribe a page to the leadgen webhook. */
export const toggleMetaPageSubscription = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { pageRowId: string; subscribed: boolean }) =>
    z.object({ pageRowId: z.string().uuid(), subscribed: z.boolean() }).parse(d),
  )
  .handler(async ({ data, context }) => {
    const { graphPost } = await import("@/lib/meta-leads.server");
    const { data: page, error } = await context.supabase
      .from("meta_lead_pages")
      .select("page_id, page_access_token")
      .eq("id", data.pageRowId)
      .single();
    if (error || !page) throw new Error("Page not found");

    if (data.subscribed) {
      await graphPost(`/${page.page_id}/subscribed_apps`, page.page_access_token, {
        subscribed_fields: "leadgen",
      });
    } else {
      // DELETE via POST with method override
      const url = new URL(
        `https://graph.facebook.com/v20.0/${page.page_id}/subscribed_apps`,
      );
      url.searchParams.set("access_token", page.page_access_token);
      await fetch(url.toString(), { method: "DELETE" });
    }
    await context.supabase
      .from("meta_lead_pages")
      .update({ subscribed: data.subscribed })
      .eq("id", data.pageRowId);
    return { ok: true };
  });

/** Pull all lead forms for a page and upsert (preserving routing). */
export const syncPageForms = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { pageRowId: string }) => z.object({ pageRowId: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    const { graphGet } = await import("@/lib/meta-leads.server");
    const { data: page, error } = await context.supabase
      .from("meta_lead_pages")
      .select("workspace_id, page_id, page_access_token")
      .eq("id", data.pageRowId)
      .single();
    if (error || !page) throw new Error("Page not found");

    const res = await graphGet(`/${page.page_id}/leadgen_forms`, page.page_access_token, {
      fields: "id,name,status,created_time,leads_count",
      limit: "200",
    });
    const rows = (res.data ?? []).map((f: any) => ({
      workspace_id: page.workspace_id,
      page_id: page.page_id,
      form_id: f.id,
      form_name: f.name,
      status: f.status,
    }));
    if (rows.length) {
      // upsert only base fields; do NOT clobber routing
      const { error: upErr } = await context.supabase
        .from("meta_lead_forms")
        .upsert(rows, { onConflict: "workspace_id,form_id", ignoreDuplicates: false });
      if (upErr) throw upErr;
    }
    return { count: rows.length };
  });

/** List lead forms for a workspace (optionally filtered by page). */
export const listMetaForms = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { workspaceId: string; pageId?: string }) =>
    z.object({ workspaceId: z.string().uuid(), pageId: z.string().optional() }).parse(d),
  )
  .handler(async ({ data, context }) => {
    let q = context.supabase
      .from("meta_lead_forms")
      .select(
        "id, form_id, form_name, status, page_id, assigned_user_id, assigned_agent_id, assigned_agent_label, default_stage_id, default_tags, enabled, last_lead_at",
      )
      .eq("workspace_id", data.workspaceId)
      .order("form_name");
    if (data.pageId) q = q.eq("page_id", data.pageId);
    const { data: forms, error } = await q;
    if (error) throw error;
    return forms ?? [];
  });

/** Update routing on a form. */
export const updateFormRouting = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: {
    formRowId: string;
    assigned_user_id?: string | null;
    assigned_agent_id?: string | null;
    assigned_agent_label?: string | null;
    default_stage_id?: string | null;
    default_tags?: string[];
    enabled?: boolean;
  }) =>
    z
      .object({
        formRowId: z.string().uuid(),
        assigned_user_id: z.string().uuid().nullable().optional(),
        assigned_agent_id: z.string().uuid().nullable().optional(),
        assigned_agent_label: z.string().nullable().optional(),
        default_stage_id: z.string().uuid().nullable().optional(),
        default_tags: z.array(z.string()).optional(),
        enabled: z.boolean().optional(),
      })
      .parse(d),
  )
  .handler(async ({ data, context }) => {
    const { formRowId, ...patch } = data;
    const { error } = await context.supabase
      .from("meta_lead_forms")
      .update(patch)
      .eq("id", formRowId);
    if (error) throw error;
    return { ok: true };
  });

/** Disconnect a Facebook account (cascades pages + forms). */
export const disconnectMeta = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { connectionId: string }) => z.object({ connectionId: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase
      .from("meta_lead_connections")
      .delete()
      .eq("id", data.connectionId);
    if (error) throw error;
    return { ok: true };
  });

// ---------- Lead Agents CRUD ---------- //
export const listLeadAgents = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { workspaceId: string }) => z.object({ workspaceId: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    const { data: agents, error } = await context.supabase
      .from("lead_agents")
      .select("id, name, email, phone, active")
      .eq("workspace_id", data.workspaceId)
      .order("name");
    if (error) throw error;
    return agents ?? [];
  });

export const upsertLeadAgent = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { id?: string; workspaceId: string; name: string; email?: string; phone?: string; active?: boolean }) =>
    z
      .object({
        id: z.string().uuid().optional(),
        workspaceId: z.string().uuid(),
        name: z.string().min(1),
        email: z.string().email().optional().or(z.literal("")),
        phone: z.string().optional(),
        active: z.boolean().optional(),
      })
      .parse(d),
  )
  .handler(async ({ data, context }) => {
    const row = {
      id: data.id,
      workspace_id: data.workspaceId,
      name: data.name,
      email: data.email || null,
      phone: data.phone || null,
      active: data.active ?? true,
    };
    const { error } = await context.supabase.from("lead_agents").upsert(row);
    if (error) throw error;
    return { ok: true };
  });

export const deleteLeadAgent = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { id: string }) => z.object({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase.from("lead_agents").delete().eq("id", data.id);
    if (error) throw error;
    return { ok: true };
  });
