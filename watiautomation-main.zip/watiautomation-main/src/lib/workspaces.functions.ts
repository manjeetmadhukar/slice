import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

async function assertAdmin(supabase: any, workspaceId: string, userId: string) {
  const { data, error } = await supabase
    .from("workspace_members")
    .select("role")
    .eq("workspace_id", workspaceId)
    .eq("user_id", userId)
    .maybeSingle();
  if (error || !data) throw new Error("Not a member of this workspace");
  if (data.role !== "owner" && data.role !== "admin") {
    throw new Error("Only owners and admins can do this");
  }
  return data.role as "owner" | "admin";
}

export const createWorkspace = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z.object({ name: z.string().trim().min(1).max(80) }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { userId } = context;
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    // Gate: additional workspaces require Super Admin permission on the user's profile.
    // The first workspace is always allowed (initial onboarding).
    const { count: existingCount } = await supabaseAdmin
      .from("workspace_members")
      .select("workspace_id", { count: "exact", head: true })
      .eq("user_id", userId);
    if ((existingCount ?? 0) >= 1) {
      const { data: profile } = await supabaseAdmin
        .from("profiles")
        .select("allow_multi_workspace, is_super_admin")
        .eq("id", userId)
        .maybeSingle();
      if (!profile?.allow_multi_workspace && !profile?.is_super_admin) {
        throw new Error(
          "Multi-workspace access is disabled for your account. Please contact your administrator to enable it.",
        );
      }
    }

    const slug =
      data.name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") +
      "-" + Math.random().toString(36).slice(2, 8);
    const { data: ws, error } = await supabaseAdmin
      .from("workspaces")
      .insert({ name: data.name, slug, owner_id: userId })
      .select()
      .single();
    if (error || !ws) throw new Error(error?.message || "Failed to create workspace");
    const { error: mErr } = await supabaseAdmin
      .from("workspace_members")
      .insert({ workspace_id: ws.id, user_id: userId, role: "owner" });
    if (mErr) throw new Error(mErr.message);
    await supabaseAdmin.from("whatsapp_settings").insert({
      user_id: userId,
      workspace_id: ws.id,
    });
    return { workspace: ws };
  });

export const createInvitation = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z.object({
      workspace_id: z.string().uuid(),
      email: z.string().trim().toLowerCase().email().max(255),
      role: z.enum(["admin", "agent", "viewer"]),
    }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    await assertAdmin(supabase, data.workspace_id, userId);
    const { data: wsRow, error: wsErr } = await supabase
      .from("workspaces")
      .select("allow_team_user_creation")
      .eq("id", data.workspace_id)
      .maybeSingle();
    if (wsErr) throw new Error(wsErr.message);
    if (!wsRow?.allow_team_user_creation) {
      throw new Error("Inviting team members is disabled for this workspace. Please contact support to enable it.");
    }

    const { data: inv, error } = await supabase
      .from("workspace_invitations")
      .insert({
        workspace_id: data.workspace_id,
        email: data.email,
        role: data.role,
        invited_by: userId,
      })
      .select()
      .single();
    if (error || !inv) throw new Error(error?.message || "Failed to create invite");
    const origin = process.env.PUBLIC_SITE_URL || "";
    return { invitation: inv, link: `${origin}/invite/${inv.token}` };
  });

export const revokeInvitation = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { data: inv } = await supabase
      .from("workspace_invitations")
      .select("workspace_id")
      .eq("id", data.id)
      .maybeSingle();
    if (!inv) throw new Error("Invitation not found");
    await assertAdmin(supabase, inv.workspace_id, userId);
    const { error } = await supabase.from("workspace_invitations").delete().eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const acceptInvitation = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z.object({ token: z.string().min(10).max(100) }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { userId, claims } = context;
    // Use admin client to look up by token (invitee may not be a workspace member yet).
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: invite, error } = await supabaseAdmin
      .from("workspace_invitations")
      .select("*")
      .eq("token", data.token)
      .maybeSingle();
    if (error || !invite) throw new Error("Invalid invitation");
    if (invite.accepted_at) throw new Error("Invitation already used");
    if (new Date(invite.expires_at) < new Date()) throw new Error("Invitation expired");

    const email = (claims.email as string | undefined)?.toLowerCase();
    if (email && email !== invite.email.toLowerCase()) {
      throw new Error(`This invitation is for ${invite.email}`);
    }


    // Add member (idempotent on unique constraint)
    const { error: mErr } = await supabaseAdmin
      .from("workspace_members")
      .upsert(
        { workspace_id: invite.workspace_id, user_id: userId, role: invite.role },
        { onConflict: "workspace_id,user_id" },
      );
    if (mErr) throw new Error(mErr.message);

    await supabaseAdmin
      .from("workspace_invitations")
      .update({ accepted_at: new Date().toISOString() })
      .eq("id", invite.id);

    return { workspace_id: invite.workspace_id };
  });

export const updateMemberRole = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z.object({
      workspace_id: z.string().uuid(),
      user_id: z.string().uuid(),
      role: z.enum(["admin", "agent", "viewer"]),
    }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    await assertAdmin(supabase, data.workspace_id, userId);
    // Cannot change owner role
    const { data: target } = await supabase
      .from("workspace_members")
      .select("role")
      .eq("workspace_id", data.workspace_id)
      .eq("user_id", data.user_id)
      .single();
    if (target?.role === "owner") throw new Error("Cannot change the owner's role");
    const { error } = await supabase
      .from("workspace_members")
      .update({ role: data.role })
      .eq("workspace_id", data.workspace_id)
      .eq("user_id", data.user_id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const removeMember = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z.object({
      workspace_id: z.string().uuid(),
      user_id: z.string().uuid(),
    }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    await assertAdmin(supabase, data.workspace_id, userId);
    const { data: target } = await supabase
      .from("workspace_members")
      .select("role")
      .eq("workspace_id", data.workspace_id)
      .eq("user_id", data.user_id)
      .single();
    if (target?.role === "owner") throw new Error("Cannot remove the owner");
    const { error } = await supabase
      .from("workspace_members")
      .delete()
      .eq("workspace_id", data.workspace_id)
      .eq("user_id", data.user_id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });
