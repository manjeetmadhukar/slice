// Server-only helper to send emails via the connected Gmail account
// (manjeetmadhukar@gmail.com). Uses the Lovable connector gateway so OAuth
// token refresh is handled automatically.

const GATEWAY_URL = "https://connector-gateway.lovable.dev/google_mail/gmail/v1";

function toBase64Url(input: string): string {
  // btoa works on Workers runtime; encode UTF-8 safely first
  const utf8 = unescape(encodeURIComponent(input));
  return btoa(utf8).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

function buildRawEmail(opts: {
  to: string;
  subject: string;
  html?: string;
  text?: string;
  fromName?: string;
}): string {
  const { to, subject, html, text, fromName } = opts;
  const headers = [
    fromName ? `From: ${fromName} <manjeetmadhukar@gmail.com>` : `From: manjeetmadhukar@gmail.com`,
    `To: ${to}`,
    `Subject: ${subject}`,
    "MIME-Version: 1.0",
  ];

  let body: string;
  if (html) {
    headers.push('Content-Type: text/html; charset="UTF-8"');
    body = html;
  } else {
    headers.push('Content-Type: text/plain; charset="UTF-8"');
    body = text ?? "";
  }

  return toBase64Url(headers.join("\r\n") + "\r\n\r\n" + body);
}

export interface SendGmailParams {
  to: string;
  subject: string;
  html?: string;
  text?: string;
  fromName?: string;
}

export async function sendGmail(params: SendGmailParams): Promise<{ id: string; threadId: string }> {
  const lovableKey = process.env.LOVABLE_API_KEY;
  const gmailKey = process.env.GOOGLE_MAIL_API_KEY;
  if (!lovableKey) throw new Error("LOVABLE_API_KEY is not configured");
  if (!gmailKey) throw new Error("GOOGLE_MAIL_API_KEY is not configured (Gmail connector not linked)");

  const raw = buildRawEmail(params);

  const res = await fetch(`${GATEWAY_URL}/users/me/messages/send`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${lovableKey}`,
      "X-Connection-Api-Key": gmailKey,
    },
    body: JSON.stringify({ raw }),
  });

  if (!res.ok) {
    const errBody = await res.text();
    throw new Error(`Gmail send failed (${res.status}): ${errBody}`);
  }

  return res.json();
}
