import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { supabaseAdmin } from "@/integrations/supabase/client.server";

async function assertSuperAdmin(supabase: any, userId: string) {
  const { data, error } = await supabase
    .from("profiles")
    .select("is_super_admin")
    .eq("id", userId)
    .maybeSingle();
  if (error) throw new Error(error.message);
  if (!data?.is_super_admin) throw new Error("Forbidden: super admin only");
}

function computePlanExpiry(interval: string): string {
  const days = interval === "yearly" ? 365 : 30;
  return new Date(Date.now() + days * 86_400_000).toISOString();
}

export const adminListUsers = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase, userId } = context;
    await assertSuperAdmin(supabase, userId);
    const { data, error } = await supabase
      .from("profiles")
      .select("id, email, full_name, is_super_admin, is_suspended, is_archived, allow_multi_workspace, trial_started_at, trial_ends_at, created_at")
      .order("created_at", { ascending: false });
    if (error) throw new Error(error.message);

    // Enrich with auth.users metadata (phone, company captured at signup)
    const metaById = new Map<string, { phone: string | null; company: string | null; signup_full_name: string | null; last_sign_in_at: string | null; email_confirmed_at: string | null }>();
    try {
      let page = 1;
      // Up to 5 pages (5000 users) — sufficient for most installs
      while (page <= 5) {
        const { data: list, error: lerr } = await supabaseAdmin.auth.admin.listUsers({ page, perPage: 1000 });
        if (lerr) break;
        for (const u of list.users ?? []) {
          const md: any = u.user_metadata ?? {};
          metaById.set(u.id, {
            phone: (md.phone as string) || (u as any).phone || null,
            company: (md.company as string) || null,
            signup_full_name: (md.full_name as string) || null,
            last_sign_in_at: (u as any).last_sign_in_at ?? null,
            email_confirmed_at: (u as any).email_confirmed_at ?? null,
          });
        }
        if (!list.users || list.users.length < 1000) break;
        page += 1;
      }
    } catch {
      // ignore enrichment failures, fall back to profile fields
    }

    const users = (data ?? []).map((p: any) => {
      const m = metaById.get(p.id);
      return {
        ...p,
        phone: m?.phone ?? null,
        company: m?.company ?? null,
        full_name: p.full_name || m?.signup_full_name || null,
        last_sign_in_at: m?.last_sign_in_at ?? null,
        email_confirmed_at: m?.email_confirmed_at ?? null,
      };
    });
    return { users };
  });

export const adminSetUserArchived = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z.object({ user_id: z.string().uuid(), archived: z.boolean() }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    await assertSuperAdmin(supabase, userId);
    if (data.user_id === userId) throw new Error("You cannot archive yourself");
    const { error } = await supabase
      .from("profiles")
      .update({ is_archived: data.archived })
      .eq("id", data.user_id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });


export const adminListDemoRequests = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase, userId } = context;
    await assertSuperAdmin(supabase, userId);
    const { data, error } = await supabaseAdmin
      .from("demo_requests")
      .select("*")
      .order("created_at", { ascending: false });
    if (error) throw new Error(error.message);
    return { requests: data ?? [] };
  });


export const adminListWorkspaces = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase, userId } = context;
    await assertSuperAdmin(supabase, userId);
    const { data: workspaces, error } = await supabase
      .from("workspaces")
      .select("id, name, slug, owner_id, allow_team_user_creation, created_at")
      .order("created_at", { ascending: false });
    if (error) throw new Error(error.message);

    const ids = (workspaces ?? []).map((w: any) => w.id);
    const { data: plans } = await supabase
      .from("workspace_plans")
      .select("workspace_id, plan_name, features, limits, notes, updated_at, starts_at, expires_at, billing_interval, price_monthly, price_yearly, currency")
      .in("workspace_id", ids.length ? ids : ["00000000-0000-0000-0000-000000000000"]);
    const { data: members } = await supabase
      .from("workspace_members")
      .select("workspace_id, user_id, role")
      .in("workspace_id", ids.length ? ids : ["00000000-0000-0000-0000-000000000000"]);

    const planMap = new Map((plans ?? []).map((p: any) => [p.workspace_id, p]));
    const countMap = new Map<string, number>();
    (members ?? []).forEach((m: any) => {
      countMap.set(m.workspace_id, (countMap.get(m.workspace_id) ?? 0) + 1);
    });

    return {
      workspaces: (workspaces ?? []).map((w: any) => ({
        ...w,
        member_count: countMap.get(w.id) ?? 0,
        plan: planMap.get(w.id) ?? null,
      })),
    };
  });

export const adminSetWorkspaceTeamCreation = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z.object({ workspace_id: z.string().uuid(), allowed: z.boolean() }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    await assertSuperAdmin(supabase, userId);
    const { error } = await supabaseAdmin
      .from("workspaces")
      .update({ allow_team_user_creation: data.allowed })
      .eq("id", data.workspace_id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });



export const adminUpsertPlan = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z.object({
      workspace_id: z.string().uuid(),
      plan_name: z.string().trim().min(1).max(80),
      features: z.record(z.string().min(1).max(64), z.boolean()).default({}),
      limits: z.record(z.string().min(1).max(64), z.number().int().min(-1).max(10_000_000)).default({}),
      notes: z.string().max(1000).nullable().optional(),
      price_monthly: z.number().min(0).max(10_000_000).default(0),
      price_yearly: z.number().min(0).max(10_000_000).default(0),
      currency: z.enum(["INR", "USD", "AED"]).default("INR"),
      billing_interval: z.enum(["monthly", "yearly"]).default("monthly"),
      starts_at: z.string().datetime().nullable().optional(),
      expires_at: z.string().datetime().nullable().optional(),
    }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    await assertSuperAdmin(supabase, userId);
    const startsAt = data.starts_at ?? new Date().toISOString();
    const expiresAt = data.expires_at ?? new Date(new Date(startsAt).getTime() + (data.billing_interval === "yearly" ? 365 : 30) * 86_400_000).toISOString();
    const { error } = await supabase
      .from("workspace_plans")
      .upsert(
        {
          workspace_id: data.workspace_id,
          plan_name: data.plan_name,
          features: data.features,
          limits: data.limits,
          notes: data.notes ?? null,
          price_monthly: data.price_monthly,
          price_yearly: data.price_yearly,
          currency: data.currency,
          billing_interval: data.billing_interval,
          assigned_by: userId,
          starts_at: startsAt,
          expires_at: expiresAt,
        },
        { onConflict: "workspace_id" },
      );
    if (error) throw new Error(error.message);
    return { ok: true };
  });



export const adminSetUserSuspended = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z.object({ user_id: z.string().uuid(), suspended: z.boolean() }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    await assertSuperAdmin(supabase, userId);
    if (data.user_id === userId) throw new Error("You cannot suspend yourself");
    const { error } = await supabase
      .from("profiles")
      .update({ is_suspended: data.suspended })
      .eq("id", data.user_id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const adminSetSuperAdmin = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z.object({ user_id: z.string().uuid(), is_super_admin: z.boolean() }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    await assertSuperAdmin(supabase, userId);
    if (data.user_id === userId && !data.is_super_admin) {
      throw new Error("You cannot demote yourself");
    }
    const { error } = await supabase
      .from("profiles")
      .update({ is_super_admin: data.is_super_admin })
      .eq("id", data.user_id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const getMyAdminStatus = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase, userId } = context;
    const { data } = await supabase
      .from("profiles")
      .select("is_super_admin, allow_multi_workspace")
      .eq("id", userId)
      .maybeSingle();
    return {
      is_super_admin: !!data?.is_super_admin,
      allow_multi_workspace: !!data?.allow_multi_workspace,
    };
  });

export const adminSetUserMultiWorkspace = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z.object({ user_id: z.string().uuid(), allowed: z.boolean() }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    await assertSuperAdmin(supabase, userId);
    const { error } = await supabaseAdmin
      .from("profiles")
      .update({ allow_multi_workspace: data.allowed })
      .eq("id", data.user_id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const adminImpersonateUser = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z.object({
      user_id: z.string().uuid(),
      redirect_to: z.string().url().optional(),
    }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    await assertSuperAdmin(supabase, userId);
    if (data.user_id === userId) {
      throw new Error("You're already signed in as this user");
    }

    const { data: profile, error: pErr } = await supabase
      .from("profiles")
      .select("email, is_suspended")
      .eq("id", data.user_id)
      .maybeSingle();
    if (pErr) throw new Error(pErr.message);
    if (!profile?.email) throw new Error("Target user has no email");
    if (profile.is_suspended) throw new Error("Cannot impersonate a suspended user");

    const { data: link, error: linkErr } = await supabaseAdmin.auth.admin.generateLink({
      type: "magiclink",
      email: profile.email,
      options: data.redirect_to ? { redirectTo: data.redirect_to } : undefined,
    });
    if (linkErr) throw new Error(linkErr.message);

    const action_link = (link as any)?.properties?.action_link ?? (link as any)?.action_link;
    if (!action_link) throw new Error("Failed to generate sign-in link");

    // Audit trail
    console.log(`[impersonation] super_admin=${userId} -> user=${data.user_id} email=${profile.email}`);

    return { ok: true as const, action_link, email: profile.email };
  });

export const adminListPlanRequests = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase, userId } = context;
    await assertSuperAdmin(supabase, userId);
    const { data: requests, error } = await supabase
      .from("plan_requests")
      .select("*")
      .order("created_at", { ascending: false });
    if (error) throw new Error(error.message);

    const wsIds = Array.from(new Set((requests ?? []).map((r: any) => r.workspace_id)));
    const userIds = Array.from(new Set((requests ?? []).map((r: any) => r.requested_by)));
    const [{ data: workspaces }, { data: profiles }] = await Promise.all([
      supabase.from("workspaces").select("id, name, slug").in("id", wsIds.length ? wsIds : ["00000000-0000-0000-0000-000000000000"]),
      supabase.from("profiles").select("id, email, full_name").in("id", userIds.length ? userIds : ["00000000-0000-0000-0000-000000000000"]),
    ]);
    const wsMap = new Map((workspaces ?? []).map((w: any) => [w.id, w]));
    const userMap = new Map((profiles ?? []).map((p: any) => [p.id, p]));

    return {
      requests: (requests ?? []).map((r: any) => ({
        ...r,
        workspace: wsMap.get(r.workspace_id) ?? null,
        requester: userMap.get(r.requested_by) ?? null,
      })),
    };
  });

export const adminReviewPlanRequest = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z.object({
      request_id: z.string().uuid(),
      action: z.enum(["approved", "rejected"]),
      admin_notes: z.string().max(1000).nullable().optional(),
    }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    await assertSuperAdmin(supabase, userId);

    const { data: req, error: rErr } = await supabase
      .from("plan_requests")
      .select("*")
      .eq("id", data.request_id)
      .maybeSingle();
    if (rErr) throw new Error(rErr.message);
    if (!req) throw new Error("Request not found");
    if (req.status !== "pending") throw new Error("This request has already been reviewed");

    if (data.action === "approved") {
      const { error: planErr } = await supabase
        .from("workspace_plans")
        .upsert(
          {
            workspace_id: req.workspace_id,
            plan_name: req.plan_name,
            features: req.features,
            limits: req.limits,
            notes: req.notes ?? null,
            price_monthly: req.price_monthly ?? 0,
            price_yearly: req.price_yearly ?? 0,
            currency: req.currency ?? "INR",
            billing_interval: req.billing_interval ?? "monthly",
            assigned_by: userId,
            expires_at: computePlanExpiry(req.billing_interval ?? "monthly"),
          },
          { onConflict: "workspace_id" },
        );
      if (planErr) throw new Error(planErr.message);
    }

    const { error: uErr } = await supabase
      .from("plan_requests")
      .update({
        status: data.action,
        admin_notes: data.admin_notes ?? null,
        reviewed_by: userId,
        reviewed_at: new Date().toISOString(),
      })
      .eq("id", data.request_id);
    if (uErr) throw new Error(uErr.message);

    return { ok: true as const };
  });

// ============ Plan Templates (reusable plan library) ============

export const adminListPlanTemplates = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase, userId } = context;
    await assertSuperAdmin(supabase, userId);
    const { data, error } = await supabase
      .from("plan_templates")
      .select("*")
      .order("position", { ascending: true })
      .order("created_at", { ascending: false });
    if (error) throw new Error(error.message);
    return { templates: data ?? [] };
  });

const TemplateInput = z.object({
  name: z.string().trim().min(1).max(80),
  description: z.string().max(500).nullable().optional(),
  features: z.record(z.string().min(1).max(64), z.boolean()).default({}),
  limits: z.record(z.string().min(1).max(64), z.number().int().min(-1).max(10_000_000)).default({}),
  is_active: z.boolean().default(true),
  is_popular: z.boolean().default(false),
  badge_text: z.string().max(40).nullable().optional(),
  position: z.number().int().min(0).max(100000).default(0),
  price_monthly: z.number().min(0).max(10_000_000).default(0),
  price_yearly: z.number().min(0).max(10_000_000).default(0),
  currency: z.enum(["INR", "USD", "AED"]).default("INR"),
  gateway_ids: z.array(z.enum(["razorpay", "cashfree", "instamojo", "stripe"])).default([]),
});


export const adminCreatePlanTemplate = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) => TemplateInput.parse(input))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    await assertSuperAdmin(supabase, userId);
    const { data: row, error } = await supabase
      .from("plan_templates")
      .insert({
        ...data,
        description: data.description ?? null,
        badge_text: data.badge_text ?? null,
        created_by: userId,
      })
      .select("*")
      .single();
    if (error) throw new Error(error.message);
    return { template: row };
  });


export const adminUpdatePlanTemplate = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    TemplateInput.extend({ id: z.string().uuid() }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    await assertSuperAdmin(supabase, userId);
    const { id, ...rest } = data;
    const { error } = await supabase
      .from("plan_templates")
      .update({ ...rest, description: rest.description ?? null, badge_text: rest.badge_text ?? null })
      .eq("id", id);

    if (error) throw new Error(error.message);
    return { ok: true as const };
  });

export const adminDeletePlanTemplate = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    await assertSuperAdmin(supabase, userId);
    const { error } = await supabase.from("plan_templates").delete().eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true as const };
  });

export const adminAssignPlanTemplate = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z.object({
      template_id: z.string().uuid(),
      workspace_ids: z.array(z.string().uuid()).min(1).max(500),
    }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    await assertSuperAdmin(supabase, userId);
    const { data: tpl, error: tErr } = await supabase
      .from("plan_templates")
      .select("*")
      .eq("id", data.template_id)
      .maybeSingle();
    if (tErr) throw new Error(tErr.message);
    if (!tpl) throw new Error("Template not found");

    const rows = data.workspace_ids.map((wid) => ({
      workspace_id: wid,
      plan_name: tpl.name,
      features: tpl.features,
      limits: tpl.limits,
      notes: tpl.description ?? null,
      price_monthly: tpl.price_monthly ?? 0,
      price_yearly: tpl.price_yearly ?? 0,
      currency: tpl.currency ?? "INR",
      billing_interval: "monthly",
      assigned_by: userId,
      expires_at: computePlanExpiry("monthly"),
    }));
    const { error } = await supabase
      .from("workspace_plans")
      .upsert(rows, { onConflict: "workspace_id" });
    if (error) throw new Error(error.message);
    return { ok: true as const, count: rows.length };
  });

// ============ Payment Gateway configuration (super-admin) ============

export const adminListPaymentGateways = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase, userId } = context;
    await assertSuperAdmin(supabase, userId);
    const { data, error } = await supabase
      .from("payment_gateways")
      .select("*")
      .order("provider");
    if (error) throw new Error(error.message);
    return { gateways: data ?? [] };
  });

export const adminUpdatePaymentGateway = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z.object({
      provider: z.enum(["razorpay", "cashfree", "instamojo", "stripe"]),
      is_enabled: z.boolean(),
      key_id: z.string().max(255).nullable().optional(),
      secret_key: z.string().max(500).nullable().optional(),
      webhook_secret: z.string().max(500).nullable().optional(),
      meta: z.record(z.string(), z.any()).default({}),
    }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    await assertSuperAdmin(supabase, userId);
    const patch: Record<string, any> = {
      is_enabled: data.is_enabled,
      key_id: data.key_id ?? null,
      meta: data.meta,
    };
    // Only overwrite when a non-empty value is provided so blank field keeps the saved secret.
    if (data.secret_key) patch.secret_key = data.secret_key;
    if (data.webhook_secret) patch.webhook_secret = data.webhook_secret;
    const { error } = await supabase
      .from("payment_gateways")
      .update(patch as any)
      .eq("provider", data.provider);
    if (error) throw new Error(error.message);
    return { ok: true as const };
  });




export const adminDeleteWorkspace = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) => z.object({ workspace_id: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    await assertSuperAdmin(supabase, userId);
    const { error } = await supabaseAdmin.rpc("admin_delete_workspace", {
      _workspace_id: data.workspace_id,
    });
    if (error) throw new Error(error.message);
    return { ok: true as const };
  });

export const adminDeleteUser = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) => z.object({ user_id: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    await assertSuperAdmin(supabase, userId);
    if (data.user_id === userId) throw new Error("You cannot delete your own account");

    const { data: target } = await supabaseAdmin
      .from("profiles")
      .select("is_super_admin")
      .eq("id", data.user_id)
      .maybeSingle();
    if (target?.is_super_admin) throw new Error("Demote this super admin before deleting");

    const { error } = await supabaseAdmin.rpc("admin_delete_user_data", {
      _user_id: data.user_id,
    });
    if (error) throw new Error(error.message);

    const { error: aErr } = await supabaseAdmin.auth.admin.deleteUser(data.user_id);
    if (aErr) throw new Error(aErr.message);
    return { ok: true as const };
  });
