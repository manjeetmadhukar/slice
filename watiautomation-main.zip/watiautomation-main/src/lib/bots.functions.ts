import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const positionSchema = z.object({ x: z.number(), y: z.number() });
const nodeSchema = z.object({
  id: z.string(),
  type: z.string().min(1).max(40),
  position: positionSchema,
  data: z.record(z.string(), z.any()).default({}),
});
const edgeSchema = z.object({
  id: z.string(),
  source: z.string(),
  target: z.string(),
  sourceHandle: z.string().nullable().optional(),
});
const uuidRe = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const triggerSchema = z.object({
  type: z.enum(["keyword", "first_message", "campaign_reply", "manual"]),
  keywords: z.array(z.string()).default([]),
  match_type: z.enum(["contains", "exact", "starts_with"]).default("contains"),
  campaign_id: z.string().uuid().nullable().optional(),
});

const botSchema = z.object({
  id: z.string().uuid().optional(),
  workspace_id: z.string().uuid(),
  name: z.string().min(1).max(120),
  description: z.string().max(500).nullable().optional(),
  enabled: z.boolean().default(false),
  priority: z.number().int().min(0).max(1000).default(0),
  triggers: z.array(triggerSchema).default([]),
  nodes: z.array(nodeSchema).default([]),
  edges: z.array(edgeSchema).default([]),
});

export const listBots = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((i) => z.object({ workspace_id: z.string().uuid() }).parse(i))
  .handler(async ({ data, context }) => {
    const { supabase } = context;
    const { data: bots, error } = await supabase
      .from("bots").select("*")
      .eq("workspace_id", data.workspace_id)
      .order("created_at", { ascending: false });
    if (error) throw new Error(error.message);
    return bots || [];
  });

export const getBot = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((i) => z.object({ id: z.string().uuid() }).parse(i))
  .handler(async ({ data, context }) => {
    const { supabase } = context;
    const { data: bot, error } = await supabase.from("bots").select("*").eq("id", data.id).single();
    if (error) throw new Error(error.message);
    const { data: nodes } = await supabase.from("bot_nodes").select("*").eq("bot_id", data.id);
    const { data: edges } = await supabase.from("bot_edges").select("*").eq("bot_id", data.id);
    return { bot, nodes: nodes || [], edges: edges || [] };
  });

export const createBot = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((i) => z.object({
    workspace_id: z.string().uuid(),
    name: z.string().min(1).max(120),
  }).parse(i))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { data: bot, error } = await supabase.from("bots").insert({
      workspace_id: data.workspace_id,
      name: data.name,
      created_by: userId,
      triggers: [{ type: "keyword", keywords: [], match_type: "contains" }],
    }).select().single();
    if (error) throw new Error(error.message);

    // Seed with a Trigger node
    const triggerId = crypto.randomUUID();
    await supabase.from("bot_nodes").insert({
      id: triggerId,
      bot_id: bot.id,
      workspace_id: data.workspace_id,
      type: "trigger",
      position: { x: 100, y: 100 },
      data: { label: "When user messages" },
    });
    return { id: bot.id };
  });

export const saveBot = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((i) => botSchema.parse(i))
  .handler(async ({ data, context }) => {
    const { supabase } = context;
    if (!data.id) throw new Error("Missing bot id");

    const { error: bErr } = await supabase.from("bots").update({
      name: data.name,
      description: data.description ?? null,
      enabled: data.enabled,
      priority: data.priority,
      triggers: data.triggers,
    }).eq("id", data.id);
    if (bErr) throw new Error(bErr.message);

    // Replace nodes & edges (simple sync)
    await supabase.from("bot_edges").delete().eq("bot_id", data.id);
    await supabase.from("bot_nodes").delete().eq("bot_id", data.id);

    // Map any non-UUID client ids (e.g. "reactflow__edge-...") to fresh UUIDs
    const nodeIdMap = new Map<string, string>();
    for (const n of data.nodes) {
      nodeIdMap.set(n.id, uuidRe.test(n.id) ? n.id : crypto.randomUUID());
    }

    if (data.nodes.length) {
      const { error: nErr } = await supabase.from("bot_nodes").insert(
        data.nodes.map((n) => ({
          id: nodeIdMap.get(n.id)!,
          bot_id: data.id!,
          workspace_id: data.workspace_id,
          type: n.type,
          position: n.position,
          data: n.data,
        })),
      );
      if (nErr) throw new Error(nErr.message);
    }
    if (data.edges.length) {
      const { error: eErr } = await supabase.from("bot_edges").insert(
        data.edges.map((e) => ({
          id: uuidRe.test(e.id) ? e.id : crypto.randomUUID(),
          bot_id: data.id!,
          workspace_id: data.workspace_id,
          source_node_id: nodeIdMap.get(e.source) ?? e.source,
          target_node_id: nodeIdMap.get(e.target) ?? e.target,
          source_handle: e.sourceHandle ?? null,
        })),
      );
      if (eErr) throw new Error(eErr.message);
    }
    return { ok: true };
  });

export const toggleBot = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((i) => z.object({ id: z.string().uuid(), enabled: z.boolean() }).parse(i))
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase.from("bots").update({ enabled: data.enabled }).eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const deleteBot = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((i) => z.object({ id: z.string().uuid() }).parse(i))
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase.from("bots").delete().eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const duplicateBot = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((i) => z.object({ id: z.string().uuid() }).parse(i))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { data: src, error } = await supabase.from("bots").select("*").eq("id", data.id).single();
    if (error) throw new Error(error.message);
    const { data: nodes } = await supabase.from("bot_nodes").select("*").eq("bot_id", data.id);
    const { data: edges } = await supabase.from("bot_edges").select("*").eq("bot_id", data.id);

    const { data: newBot, error: cErr } = await supabase.from("bots").insert({
      workspace_id: src.workspace_id,
      name: `${src.name} (copy)`,
      description: src.description,
      enabled: false,
      priority: src.priority,
      triggers: src.triggers,
      created_by: userId,
    }).select().single();
    if (cErr) throw new Error(cErr.message);

    const idMap = new Map<string, string>();
    for (const n of nodes || []) idMap.set(n.id, crypto.randomUUID());

    if (nodes?.length) {
      await supabase.from("bot_nodes").insert(nodes.map((n: any) => ({
        id: idMap.get(n.id),
        bot_id: newBot.id,
        workspace_id: src.workspace_id,
        type: n.type,
        position: n.position,
        data: n.data,
      })));
    }
    if (edges?.length) {
      await supabase.from("bot_edges").insert(edges.map((e: any) => ({
        bot_id: newBot.id,
        workspace_id: src.workspace_id,
        source_node_id: idMap.get(e.source_node_id) || e.source_node_id,
        target_node_id: idMap.get(e.target_node_id) || e.target_node_id,
        source_handle: e.source_handle,
      })));
    }
    return { id: newBot.id };
  });

export const startBotForConversation = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((i) => z.object({
    bot_id: z.string().uuid(),
    conversation_id: z.string().uuid(),
  }).parse(i))
  .handler(async ({ data, context }) => {
    const { supabase } = context;
    const { data: convo, error } = await supabase.from("conversations")
      .select("id, workspace_id, contact_phone, contact_id").eq("id", data.conversation_id).single();
    if (error) throw new Error(error.message);

    // Lazy-load the runner via fetch to our own webhook? No — we expose a helper server fn
    const { runBotForMessage } = await import("@/lib/bot-runner.server");
    await runBotForMessage({
      workspace_id: convo.workspace_id,
      conversation_id: convo.id,
      contact_phone: convo.contact_phone,
      contact_id: convo.contact_id,
      message_text: "",
      is_first_message: false,
      force_bot_id: data.bot_id,
    });
    return { ok: true };
  });
