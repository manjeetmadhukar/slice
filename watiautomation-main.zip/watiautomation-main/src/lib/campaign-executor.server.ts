// Shared campaign execution logic. Used by launchCampaign (immediate) and
// the scheduled-campaign cron dispatcher.
import { sendWhatsAppMessage } from "./whatsapp-send.server";

// Worker invocations have a wall-clock limit. Stop sending after this many ms
// so the function exits cleanly; the cron dispatcher will resume any
// recipients still in "pending" on a later tick.
const TIME_BUDGET_MS = 20_000;
const SEND_CONCURRENCY = 5;

// Automatic recipient-level retries for transient upstream failures
// (rate limits, HTTP 5xx, network drops). Backoff in minutes; capped so
// the cron dispatcher can pick each retry up on a later tick.
const RETRY_BACKOFF_MINUTES = [1, 5, 15, 60, 240]; // total 5 retry attempts

export async function executeCampaign(supabase: any, campaignId: string) {
  const startedAt = Date.now();
  const { data: campaign, error: cErr } = await supabase
    .from("campaigns").select("*").eq("id", campaignId).single();
  if (cErr || !campaign) throw new Error(cErr?.message || "Campaign not found");

  const { data: settings, error: sErr } = await supabase
    .from("whatsapp_settings").select("*")
    .eq("workspace_id", campaign.workspace_id).maybeSingle();
  if (sErr || !settings?.access_token || !settings?.phone_number_id) {
    await supabase.from("campaigns").update({
      status: "failed",
      completed_at: new Date().toISOString(),
    }).eq("id", campaignId);
    throw new Error("WhatsApp credentials missing");
  }

  let { data: tpl } = await supabase
    .from("templates").select("*").eq("id", campaign.template_id).maybeSingle();
  if (!tpl && campaign.template_name) {
    // Fallback: original template row was deleted/replaced. Look up by
    // workspace + meta name + language so resume still works.
    const byName = await supabase
      .from("templates").select("*")
      .eq("workspace_id", campaign.workspace_id)
      .eq("meta_template_name", campaign.template_name)
      .eq("language", campaign.template_language || "en")
      .order("created_at", { ascending: false })
      .limit(1).maybeSingle();
    tpl = byName.data ?? null;
  }
  if (!tpl) {
    // Last-resort synthetic template: send by name/language stored on the
    // campaign. Infer header media type from the stored media URL extension.
    const url: string = campaign.header_media_url || "";
    const ext = url.split("?")[0].split(".").pop()?.toLowerCase() || "";
    const inferredFormat = ["jpg","jpeg","png","webp"].includes(ext) ? "IMAGE"
      : ["mp4","mov","3gp"].includes(ext) ? "VIDEO"
      : ["pdf"].includes(ext) ? "DOCUMENT" : "";
    tpl = {
      id: campaign.template_id,
      workspace_id: campaign.workspace_id,
      meta_template_name: campaign.template_name,
      language: campaign.template_language || "en",
      body: "",
      components: inferredFormat ? [{ type: "HEADER", format: inferredFormat }] : [],
    };
  }

  // Resume support: a previous run may have died mid-loop after claiming
  // recipients (pending -> sending) but before the Meta send completed.
  // Reset any leftover "sending" recipients back to "pending" so this run
  // can pick them up. Safe because the campaign-level status='sending'
  // claim by the caller (cron / sendNow / launch) prevents concurrent
  // executors for the same campaign.
  await supabase
    .from("campaign_recipients")
    .update({ status: "pending" })
    .eq("campaign_id", campaignId)
    .eq("status", "sending");

  const nowIso = new Date().toISOString();
  const { data: recipients = [] } = await supabase
    .from("campaign_recipients").select("*")
    .eq("campaign_id", campaignId).eq("status", "pending")
    .or(`next_retry_at.is.null,next_retry_at.lte.${nowIso}`);

  await supabase.from("campaigns").update({ status: "sending" }).eq("id", campaignId);

  const variables: string[] = Array.isArray(campaign.variables) ? campaign.variables : [];

  // Detect template header media (IMAGE/VIDEO/DOCUMENT) — Meta requires the URL at send time
  const headerComp = Array.isArray(tpl.components)
    ? (tpl.components as any[]).find((x) => String(x?.type).toUpperCase() === "HEADER")
    : null;
  const headerFormat = String(headerComp?.format || "").toUpperCase();
  const mediaFormats: Record<string, "image" | "video" | "document"> = {
    IMAGE: "image",
    VIDEO: "video",
    DOCUMENT: "document",
  };
  const headerMediaType = mediaFormats[headerFormat];
  const headerMediaUrl: string | null = campaign.header_media_url || null;

  if (headerMediaType && !headerMediaUrl) {
    await supabase.from("campaigns").update({
      status: "failed",
      completed_at: new Date().toISOString(),
    }).eq("id", campaignId);
    throw new Error(
      `Template header requires a ${headerFormat.toLowerCase()} URL. Edit the campaign and provide a public media URL.`,
    );
  }

  // Per-variable mapping locked at template creation time. When present
  // we resolve {{N}} from per-recipient context (e.g. customer_name →
  // contact.name) instead of using the same sender-typed value for everyone.
  const variableMapping: Array<{ index: number; field: string; static_value?: string }> =
    Array.isArray(tpl.variable_mapping) ? (tpl.variable_mapping as any[]) : [];
  const hasMapping = variableMapping.length > 0;

  // Batch-load contact emails for recipients that need {{customer_email}}.
  const needEmail = hasMapping && variableMapping.some((e) => e?.field === "customer_email");
  const emailByContact = new Map<string, string>();
  if (needEmail) {
    const ids = Array.from(new Set(recipients.map((r: any) => r.contact_id).filter(Boolean)));
    if (ids.length) {
      const { data: cs = [] } = await supabase
        .from("contacts").select("id,email").in("id", ids);
      for (const c of cs) if (c?.email) emailByContact.set(c.id, c.email);
    }
  }

  function resolveVarsFor(r: any): string[] {
    const contactName = String(r.name || "").trim() || "Customer";
    if (!hasMapping) {
      // No per-template mapping. {{1}} defaults to the recipient's contact
      // (WhatsApp profile) name unless the sender typed an override.
      const count = Number(tpl.variables_count || 0);
      if (count === 0) return variables;
      const out: string[] = [];
      for (let i = 1; i <= count; i++) {
        const typed = String(variables[i - 1] ?? "");
        if (i === 1 && !typed.trim()) out.push(contactName);
        else out.push(typed);
      }
      return out;
    }
    const count = Math.max(Number(tpl.variables_count || 0), variableMapping.length);
    const out: string[] = [];
    const phone = `+${String(r.phone || "").replace(/[^\d]/g, "")}`;
    for (let i = 1; i <= count; i++) {
      const entry = variableMapping.find((e) => Number(e?.index) === i);
      let v = "";
      switch (entry?.field) {
        case "customer_name":  v = contactName; break;
        case "customer_phone": v = phone; break;
        case "customer_email": v = (r.contact_id && emailByContact.get(r.contact_id)) || ""; break;
        case "static_text":    v = String(entry.static_value ?? variables[i - 1] ?? ""); break;
        default: {
          const typed = String(variables[i - 1] ?? "");
          // Unmapped {{1}} → recipient contact name when sender left it blank.
          v = i === 1 && !typed.trim() ? contactName : typed;
        }
      }
      out.push(v);
    }
    return out;
  }

  const buttonsComp = Array.isArray(tpl.components)
    ? (tpl.components as any[]).find((x) => String(x?.type).toUpperCase() === "BUTTONS")
    : null;
  const buttonLabels = (Array.isArray(buttonsComp?.buttons) ? buttonsComp.buttons : [])
    .map((b: any) => String(b?.text || b?.type || "").trim())
    .filter(Boolean);
  const bodyComp = Array.isArray(tpl.components)
    ? (tpl.components as any[]).find((x) => String(x?.type).toUpperCase() === "BODY")
    : null;
  const bodyText: string = bodyComp?.text || tpl.body || tpl.meta_template_name;

  let sent = 0, failed = 0;
  let timedOut = false;

  async function processRecipient(r: any): Promise<{ sent: number; failed: number }> {
    // Atomically claim this recipient (pending -> sending) so that a concurrent
    // dispatcher (cron + manual "Send now") cannot double-send the same row.
    const { data: claimedRecipient } = await supabase
      .from("campaign_recipients")
      .update({ status: "sending" })
      .eq("id", r.id)
      .eq("status", "pending")
      .select("id").maybeSingle();
    if (!claimedRecipient) return { sent: 0, failed: 0 };

    const phone = String(r.phone || "").replace(/[^\d]/g, "");
    if (!phone) {
      await supabase.from("campaign_recipients")
        .update({ status: "failed", error: "Missing phone number" })
        .eq("id", r.id);
      return { sent: 0, failed: 1 };
    }
    const normPhone = `+${phone}`;

    // Per-recipient variable resolution. Customer fields (name/phone/email)
    // come from the recipient row; other slots use the campaign-level value.
    const perRecipientVars = resolveVarsFor(r);
    const components: any[] = [];
    if (headerMediaType && headerMediaUrl) {
      components.push({
        type: "header",
        parameters: [{ type: headerMediaType, [headerMediaType]: { link: headerMediaUrl } }],
      });
    }
    if (perRecipientVars.length) {
      components.push({
        type: "body",
        parameters: perRecipientVars.map((v) => ({ type: "text", text: v })),
      });
    }
    const componentsPayload = components.length ? components : undefined;
    const previewText = bodyText.replace(
      /\{\{\s*(\d+)\s*\}\}/g,
      (_m: string, n: string) => perRecipientVars[Number(n) - 1] ?? "",
    );
    const inboxContent = [
      previewText,
      buttonLabels.length ? buttonLabels.map((label: string) => `Button: ${label}`).join("\n") : "",
    ].filter(Boolean).join("\n\n");

    const templateName = campaign.template_name || tpl.meta_template_name;
    const language = campaign.template_language || tpl.language;
    const sendResult = await sendWhatsAppMessage({
      settings: {
        phone_number_id: settings.phone_number_id,
        access_token: settings.access_token,
      },
      toPhone: phone,
      payload: {
        messaging_product: "whatsapp",
        type: "template",
        template: {
          name: templateName,
          language: { code: language },
          ...(componentsPayload ? { components: componentsPayload } : {}),
        },
      },
      context: {
        workspaceId: campaign.workspace_id,
        purpose: "campaign",
        campaignId: campaign.id,
        recipientId: r.id,
        contactId: r.contact_id ?? null,
        templateName,
        language,
        messageType: "template",
      },
    });

    const totalAttempts = (r.attempts || 0) + sendResult.attempts;

    if (!sendResult.ok) {
      const cls = sendResult.classification;
      const code = cls?.code;
      let msg = cls?.error || "WhatsApp delivery failed";
      let recipientStatus: "failed" | "suppressed" | "pending" =
        (cls?.status as any) || "failed";

      // Refine two very common recipient-side failure messages so the UI
      // shows a specific, actionable reason instead of a generic Meta error.
      if (code === 131026) {
        msg = "Meta #131026: Recipient cannot receive WhatsApp messages (not on WhatsApp / blocked).";
        recipientStatus = "failed";
      } else if (code === 131053 || /media upload|media download/i.test(msg)) {
        msg = `Meta #131053 Media upload error: WhatsApp could not fetch/process the ${headerMediaType || "media"} at ${headerMediaUrl}. Common causes: (1) Video must be MP4 (H.264 + AAC) under 16MB; (2) Image must be JPG/PNG under 5MB; (3) Document (PDF etc.) under 100MB; (4) URL must be publicly downloadable with the correct Content-Type header. Re-encode the file or upload a smaller/standard version and retry.`;
        recipientStatus = "failed";
      }

      // Transient failure? Schedule an automatic retry with exponential
      // backoff. After exhausting RETRY_BACKOFF_MINUTES we finally mark
      // the recipient as failed so it stops blocking campaign completion.
      const nextRetryIndex = r.retry_count || 0;
      const canRetry = cls?.retryable && nextRetryIndex < RETRY_BACKOFF_MINUTES.length;

      if (canRetry) {
        const delayMin = RETRY_BACKOFF_MINUTES[nextRetryIndex];
        const nextRetryAt = new Date(Date.now() + delayMin * 60_000).toISOString();
        await supabase.from("campaign_recipients").update({
          status: "pending",
          error: `${msg} — auto-retry in ${delayMin} min (attempt ${nextRetryIndex + 2}/${RETRY_BACKOFF_MINUTES.length + 1})`,
          attempts: totalAttempts,
          retry_count: nextRetryIndex + 1,
          next_retry_at: nextRetryAt,
          last_attempt_at: new Date().toISOString(),
          meta_code: code ?? null,
          meta_subcode: cls?.subcode ?? null,
          http_status: sendResult.http_status,
        }).eq("id", r.id);
        return { sent: 0, failed: 0 };
      }

      await supabase.from("campaign_recipients").update({
        status: recipientStatus,
        error: msg,
        attempts: totalAttempts,
        last_attempt_at: new Date().toISOString(),
        meta_code: code ?? null,
        meta_subcode: cls?.subcode ?? null,
        http_status: sendResult.http_status,
      }).eq("id", r.id);
      return { sent: 0, failed: recipientStatus === "failed" ? 1 : 0 };
    }

    const msgId = sendResult.wa_message_id;
    await supabase.from("campaign_recipients").update({
      status: "sent",
      message_id: msgId,
      sent_at: new Date().toISOString(),
      attempts: totalAttempts,
      last_attempt_at: new Date().toISOString(),
      http_status: sendResult.http_status,
      next_retry_at: null,
    }).eq("id", r.id);

    // Log into conversation thread
    try {
      let convId: string | null = null;
      const resolved = await supabase.rpc("resolve_conversation", {
        _workspace_id: campaign.workspace_id,
        _phone: normPhone || r.phone || phone,
        _name: r.name || normPhone,
        _contact_id: r.contact_id ?? null,
        _last_message_at: new Date().toISOString(),
      } as any);
      convId = (resolved.data as any) ?? null;
      if (convId) {
        const msgType = headerMediaType || "text";
        const preview = headerMediaType
          ? `[${headerMediaType}]${previewText ? ` ${previewText}` : ""}`.slice(0, 140)
          : previewText.slice(0, 140);
        await supabase.from("messages").insert({
          workspace_id: campaign.workspace_id,
          conversation_id: convId,
          direction: "out",
          type: msgType,
          content: inboxContent || previewText,
          media_url: headerMediaType ? headerMediaUrl : null,
          media_mime: headerMediaType || null,
          sender_user_id: campaign.user_id,
          wa_message_id: msgId,
          status: "sent",
        });
        await supabase.from("conversations").update({
          last_message_at: new Date().toISOString(),
          last_message_preview: preview,
        }).eq("id", convId);
      }
    } catch {}
    return { sent: 1, failed: 0 };
  }

  for (let i = 0; i < recipients.length; i += SEND_CONCURRENCY) {
    if (Date.now() - startedAt > TIME_BUDGET_MS) { timedOut = true; break; }
    const batch = recipients.slice(i, i + SEND_CONCURRENCY);
    const results = await Promise.all(batch.map((r: any) => processRecipient(r)));
    for (const r of results) {
      sent += r.sent;
      failed += r.failed;
    }
  }

  // Count remaining pending recipients to decide whether to finalize.
  const { count: stillPending } = await supabase
    .from("campaign_recipients")
    .select("id", { count: "exact", head: true })
    .eq("campaign_id", campaignId)
    .in("status", ["pending", "sending"]);

  const newSentCount = (campaign.sent_count || 0) + sent;
  const newFailedCount = (campaign.failed_count || 0) + failed;

  if ((stillPending ?? 0) > 0 || timedOut) {
    // Leave status as "sending" so the cron dispatcher resumes us on the
    // next tick. Do NOT set completed_at.
    await supabase.from("campaigns").update({
      sent_count: newSentCount,
      failed_count: newFailedCount,
      status: "sending",
    }).eq("id", campaignId);

    // Auto-chain: fire-and-forget a request to the dispatcher so the next
    // batch starts immediately instead of waiting for the cron tick. Each
    // worker invocation has a wall-clock limit, so we hop to a fresh one.
    try {
      const secret = process.env.CRON_DISPATCH_SECRET;
      if (secret) {
        let origin = "https://slice.dotscube.com";
        try {
          const { getRequest } = await import("@tanstack/react-start/server");
          const reqOrigin = new URL(getRequest().url).origin;
          const host = new URL(reqOrigin).hostname;
          if (host !== "localhost" && host !== "127.0.0.1") origin = reqOrigin;
        } catch {}
        // Don't await — let it run independently of this response.
        fetch(`${origin}/api/public/hooks/dispatch-scheduled-campaigns`, {
          method: "POST",
          headers: {
            Authorization: `Bearer ${secret}`,
            "Content-Type": "application/json",
          },
          body: "{}",
        }).catch(() => {});
      }
    } catch {}

  } else {
    await supabase.from("campaigns").update({
      sent_count: newSentCount,
      failed_count: newFailedCount,
      status: "completed",
      completed_at: new Date().toISOString(),
    }).eq("id", campaignId);
  }

  return { sent, failed };
}
