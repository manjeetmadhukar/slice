// Server functions for the Browse Abandonment Recovery feature.
import { createServerFn } from "@tanstack/react-start";
import { randomBytes } from "crypto";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import {
  assertBrowseAdmin,
  assertBrowseMember,
  browseAnalyticsSchema,
  browseEventsSchema,
  browseRevokeTokenSchema,
  browseSettingsSchema,
  browseTokenSchema,
  browseWorkspaceSchema,
} from "@/lib/browse-recovery.server";

export const getBrowseSettings = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((i) => browseWorkspaceSchema.parse(i))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    await assertBrowseMember(supabase, data.workspace_id, userId);
    const { data: row } = await supabase.from("browse_recovery_settings" as any)
      .select("*").eq("workspace_id", data.workspace_id).maybeSingle();
    const { data: tokens } = await supabase.from("browse_tracker_tokens" as any)
      .select("id, token, label, created_at, last_used_at")
      .eq("workspace_id", data.workspace_id)
      .order("created_at", { ascending: false });
    return { settings: row ?? null, tokens: tokens ?? [] };
  });

export const saveBrowseSettings = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((i) => browseSettingsSchema.parse(i))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    await assertBrowseAdmin(supabase, data.workspace_id, userId);
    const row: any = {
      workspace_id: data.workspace_id,
      enabled: data.enabled,
      delay_minutes: data.delay_minutes,
      template_id: data.template_id ?? null,
      template_language: data.template_language ?? "en",
      frequency_cap_hours: data.frequency_cap_hours,
      product_include: data.product_include,
      product_exclude: data.product_exclude,
      category_include: data.category_include,
      min_price_minor: data.min_price_minor ?? null,
      updated_at: new Date().toISOString(),
    };
    const { error } = await supabase.from("browse_recovery_settings" as any)
      .upsert(row, { onConflict: "workspace_id" });
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const createBrowseTrackerToken = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((i) => browseTokenSchema.parse(i))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    await assertBrowseAdmin(supabase, data.workspace_id, userId);
    const token = `brt_${randomBytes(18).toString("base64url")}`;
    const { data: ins, error } = await supabase.from("browse_tracker_tokens" as any)
      .insert({ workspace_id: data.workspace_id, token, label: data.label ?? null })
      .select("id, token, label, created_at").single();
    if (error) throw new Error(error.message);
    return ins;
  });

export const revokeBrowseTrackerToken = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((i) => browseRevokeTokenSchema.parse(i))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    await assertBrowseAdmin(supabase, data.workspace_id, userId);
    const { error } = await supabase.from("browse_tracker_tokens" as any)
      .delete().eq("id", data.id).eq("workspace_id", data.workspace_id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const getBrowseAnalytics = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((i) => browseAnalyticsSchema.parse(i))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    await assertBrowseMember(supabase, data.workspace_id, userId);
    const since = new Date(Date.now() - data.days * 86400_000).toISOString();
    const { data: events } = await supabase.from("browse_events" as any)
      .select("id, dispatched_at, converted_at, conversion_value_minor, currency")
      .eq("workspace_id", data.workspace_id)
      .gte("viewed_at", since);
    const list = (events as any[]) || [];
    const views = list.length;
    const sent = list.filter((e) => !!e.dispatched_at).length;
    const converted = list.filter((e) => !!e.converted_at).length;
    const revenueMinor = list.reduce((s, e) => s + Number(e.conversion_value_minor || 0), 0);
    const currency = list.find((e) => e.currency)?.currency || null;

    const { count: clicks } = await supabase.from("browse_recovery_clicks" as any)
      .select("*", { count: "exact", head: true })
      .eq("workspace_id", data.workspace_id)
      .gte("created_at", since)
      .not("clicked_at", "is", null);

    return {
      views, sent, clicks: clicks ?? 0, converted,
      revenue_minor: revenueMinor,
      currency,
    };
  });

export const getBrowseEvents = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((i) => browseEventsSchema.parse(i))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    await assertBrowseMember(supabase, data.workspace_id, userId);
    const { data: rows } = await supabase.from("browse_events" as any)
      .select("id, contact_id, session_key, visitor_key, product_id, product_title, product_url, product_image_url, price_minor, currency, category, source, phone, phone_normalized, viewed_at, dispatch_scheduled_at, dispatched_at, converted_at, skip_reason, wa_message_id, contact:contacts(id, name, email, phone)")
      .eq("workspace_id", data.workspace_id)
      .order("viewed_at", { ascending: false })
      .limit(data.limit);
    return { events: rows ?? [] };
  });
