import { createContext, useContext, useEffect, useState, type ReactNode } from "react";

export const CURRENCIES = [
  { code: "INR", symbol: "₹", label: "Indian Rupee" },
  { code: "USD", symbol: "$", label: "US Dollar" },
  { code: "AED", symbol: "د.إ", label: "UAE Dirham" },
] as const;

export type CurrencyCode = (typeof CURRENCIES)[number]["code"];

const STORAGE_KEY = "app:currency";

function isCurrency(v: string | null): v is CurrencyCode {
  return !!v && CURRENCIES.some((c) => c.code === v);
}

interface Ctx {
  currency: CurrencyCode;
  setCurrency: (c: CurrencyCode) => void;
  symbol: string;
  format: (n: number | string | null | undefined) => string;
}

const CurrencyContext = createContext<Ctx | null>(null);

export function CurrencyProvider({ children }: { children: ReactNode }) {
  const [currency, setCurrencyState] = useState<CurrencyCode>("USD");

  useEffect(() => {
    const saved = typeof window !== "undefined" ? localStorage.getItem(STORAGE_KEY) : null;
    if (isCurrency(saved)) setCurrencyState(saved);
  }, []);

  function setCurrency(c: CurrencyCode) {
    setCurrencyState(c);
    if (typeof window !== "undefined") localStorage.setItem(STORAGE_KEY, c);
  }

  const symbol = CURRENCIES.find((c) => c.code === currency)!.symbol;

  function format(n: number | string | null | undefined) {
    const num = Number(n ?? 0);
    if (!Number.isFinite(num)) return `${symbol}0`;
    try {
      return new Intl.NumberFormat(undefined, {
        style: "currency",
        currency,
        maximumFractionDigits: num % 1 === 0 ? 0 : 2,
      }).format(num);
    } catch {
      return `${symbol}${num.toLocaleString()}`;
    }
  }

  return (
    <CurrencyContext.Provider value={{ currency, setCurrency, symbol, format }}>
      {children}
    </CurrencyContext.Provider>
  );
}

export function useCurrency() {
  const ctx = useContext(CurrencyContext);
  if (!ctx) throw new Error("useCurrency must be used within CurrencyProvider");
  return ctx;
}
