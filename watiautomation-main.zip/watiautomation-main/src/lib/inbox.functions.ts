import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { syncContactsToConversations } from "./contact-conversation-sync.server";
import { getWebhookCallbackUrl } from "./whatsapp-webhook-url.server";

const META_BASE = "https://graph.facebook.com/v21.0";

type WhatsAppAccountMeta = Record<string, unknown>;

async function ensureWebhookSubscribed(supabase: any, workspaceId: string, settings?: any) {
  const s = settings ?? (await getSettings(supabase, workspaceId));
  if (!s?.waba_id || !s?.access_token) return;
  const callbackUrl = getWebhookCallbackUrl();
  const verifyToken = process.env.WHATSAPP_VERIFY_TOKEN;
  const body: Record<string, string> = {};
  if (callbackUrl && verifyToken) {
    body.override_callback_uri = callbackUrl;
    body.verify_token = verifyToken;
  }
  try {
    const baseRes = await fetch(`${META_BASE}/${s.waba_id}/subscribed_apps`, {
      method: "POST",
      headers: { Authorization: `Bearer ${s.access_token}`, "Content-Type": "application/json" },
    });
    const errors: string[] = [];
    if (!baseRes.ok) {
      errors.push(
        (await baseRes.json().catch(() => ({})))?.error?.message ||
          `Webhook subscribe failed (HTTP ${baseRes.status})`,
      );
    } else if (Object.keys(body).length) {
      const wabaRes = await fetch(`${META_BASE}/${s.waba_id}/subscribed_apps`, {
        method: "POST",
        headers: { Authorization: `Bearer ${s.access_token}`, "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      if (!wabaRes.ok) {
        errors.push(
          (await wabaRes.json().catch(() => ({})))?.error?.message ||
            `WABA webhook override failed (HTTP ${wabaRes.status})`,
        );
      }
      const phoneRes = await fetch(`${META_BASE}/${s.phone_number_id}`, {
        method: "POST",
        headers: { Authorization: `Bearer ${s.access_token}`, "Content-Type": "application/json" },
        body: JSON.stringify({ webhook_configuration: body }),
      });
      if (!phoneRes.ok) {
        errors.push(
          (await phoneRes.json().catch(() => ({})))?.error?.message ||
            `Phone webhook override failed (HTTP ${phoneRes.status})`,
        );
      }
    }
    const ok = baseRes.ok && errors.length === 0;
    const err = errors.join(" • ") || null;
    const { data: accountRow } = await supabase
      .from("whatsapp_accounts")
      .select("meta")
      .eq("workspace_id", workspaceId)
      .eq("phone_number_id", s.phone_number_id)
      .maybeSingle();
    const existingMeta = (((accountRow as { meta?: WhatsAppAccountMeta } | null)
      ?.meta as WhatsAppAccountMeta) || {});
    const smbSync = (existingMeta.smb_sync || {}) as Record<string, string | null>;
    const nextSmbSync: Record<string, string | null> = { ...smbSync };
    if (!smbSync.contacts_request_id && !smbSync.contacts_error) {
      const contactsRes = await requestSmbAppData(s, "smb_app_state_sync");
      nextSmbSync.contacts_request_id = contactsRes.request_id;
      nextSmbSync.contacts_error = contactsRes.error;
    }
    if (!smbSync.history_request_id && !smbSync.history_error) {
      const historyRes = await requestSmbAppData(s, "history");
      nextSmbSync.history_request_id = historyRes.request_id;
      nextSmbSync.history_error = historyRes.error;
    }
    await supabase
      .from("whatsapp_accounts")
      .update({
        webhook_status: ok ? "subscribed" : "error",
        last_error: err,
        meta: {
          ...existingMeta,
          webhook_callback_url: callbackUrl,
          webhook_error: err,
          smb_sync: nextSmbSync,
        },
      })
      .eq("workspace_id", workspaceId)
      .eq("phone_number_id", s.phone_number_id);
    if (!ok) {
      await supabase
        .from("integration_debug_logs")
        .insert({
          workspace_id: workspaceId,
          provider: "whatsapp",
          event: "webhook.subscribe_failed",
          direction: "out",
          ok: false,
          status_code: baseRes.status,
          message: err,
          payload: {
            phone_number_id: s.phone_number_id,
            waba_id: s.waba_id,
            webhook_callback_url: callbackUrl,
          },
        })
        .then(
          () => {},
          () => {},
        );
    }
  } catch (e: any) {
    await supabase
      .from("integration_debug_logs")
      .insert({
        workspace_id: workspaceId,
        provider: "whatsapp",
        event: "webhook.subscribe_failed",
        direction: "out",
        ok: false,
        status_code: 0,
        message: e?.message || "Webhook subscribe network error",
        payload: {
          phone_number_id: s.phone_number_id,
          waba_id: s.waba_id,
          webhook_callback_url: callbackUrl,
        },
      })
      .then(
        () => {},
        () => {},
      );
  }
}

async function requestSmbAppData(
  s: any,
  syncType: "smb_app_state_sync" | "history",
): Promise<{ request_id: string | null; error: string | null }> {
  try {
    const res = await fetch(`${META_BASE}/${s.phone_number_id}/smb_app_data`, {
      method: "POST",
      headers: { Authorization: `Bearer ${s.access_token}`, "Content-Type": "application/json" },
      body: JSON.stringify({ messaging_product: "whatsapp", sync_type: syncType }),
    });
    const json: any = await res.json().catch(() => ({}));
    if (!res.ok) {
      return { request_id: null, error: json?.error?.message || `${syncType} sync failed (HTTP ${res.status})` };
    }
    return { request_id: json?.request_id ?? null, error: null };
  } catch (e: any) {
    return { request_id: null, error: e?.message || `${syncType} sync network error` };
  }
}

async function getSettings(supabase: any, workspaceId: string) {
  const { data, error } = await supabase
    .from("whatsapp_settings")
    .select("*")
    .eq("workspace_id", workspaceId)
    .maybeSingle();
  if (error) throw new Error(error.message);
  if (!data?.access_token || !data?.phone_number_id) {
    throw new Error("WhatsApp not configured for this workspace.");
  }
  return data;
}

async function assertMember(supabase: any, workspaceId: string, userId: string) {
  const { data, error } = await supabase
    .from("workspace_members")
    .select("role")
    .eq("workspace_id", workspaceId)
    .eq("user_id", userId)
    .maybeSingle();
  if (error || !data) throw new Error("Not a member of this workspace");
  return data.role as "owner" | "admin" | "agent" | "viewer";
}

function normalizeWhatsAppPhone(phone: string) {
  const digits = phone.replace(/[^\d]/g, "");
  return digits ? `+${digits}` : phone;
}

export const syncContactConversations = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z
      .object({
        workspace_id: z.string().uuid(),
        contact_id: z.string().uuid().optional(),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    await assertMember(supabase, data.workspace_id, userId);
    await ensureWebhookSubscribed(supabase, data.workspace_id);
    const result = await syncContactsToConversations({
      supabase,
      workspaceId: data.workspace_id,
      contactIds: data.contact_id ? [data.contact_id] : undefined,
    });
    return { ok: true as const, ...result };
  });

export const sendInboxMessage = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z
      .object({
        conversation_id: z.string().uuid(),
        text: z.string().min(1).max(4096),
        reply_to_wa_message_id: z.string().optional(),
        reply_to_preview: z.string().optional(),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;

    const { data: convo, error: cErr } = await supabase
      .from("conversations")
      .select("*")
      .eq("id", data.conversation_id)
      .single();
    if (cErr || !convo) throw new Error("Conversation not found");

    const role = await assertMember(supabase, convo.workspace_id, userId);
    if (role === "viewer") throw new Error("Viewers cannot send messages");

    const s = await getSettings(supabase, convo.workspace_id);
    await ensureWebhookSubscribed(supabase, convo.workspace_id, s);
    const phone = convo.contact_phone.replace(/[^\d]/g, "");

    const body: any = {
      messaging_product: "whatsapp",
      to: phone,
      type: "text",
      text: { body: data.text },
    };
    if (data.reply_to_wa_message_id) {
      body.context = { message_id: data.reply_to_wa_message_id };
    }

    const res = await fetch(`${META_BASE}/${s.phone_number_id}/messages`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${s.access_token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(body),
    });
    const json: any = await res.json();
    if (!res.ok) {
      return { ok: false as const, error: json?.error?.message || "Meta API rejected the message" };
    }

    const wa_id = json.messages?.[0]?.id;
    await supabase.from("messages").insert({
      workspace_id: convo.workspace_id,
      conversation_id: convo.id,
      direction: "out",
      type: "text",
      content: data.text,
      sender_user_id: userId,
      wa_message_id: wa_id,
      status: "sent",
      reply_to_wa_message_id: data.reply_to_wa_message_id ?? null,
      reply_to_preview: data.reply_to_preview ?? null,
    });
    await supabase
      .from("conversations")
      .update({
        last_message_at: new Date().toISOString(),
        last_message_preview: data.text.slice(0, 140),
      })
      .eq("id", convo.id);

    return { ok: true as const, wa_message_id: wa_id };
  });

export const sendInboxReaction = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z.object({
      conversation_id: z.string().uuid(),
      wa_message_id: z.string().min(1),
      emoji: z.string().max(8),
    }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { data: convo, error: cErr } = await supabase
      .from("conversations").select("*").eq("id", data.conversation_id).single();
    if (cErr || !convo) throw new Error("Conversation not found");
    const role = await assertMember(supabase, convo.workspace_id, userId);
    if (role === "viewer") throw new Error("Viewers cannot react");
    const s = await getSettings(supabase, convo.workspace_id);
    const phone = convo.contact_phone.replace(/[^\d]/g, "");

    const res = await fetch(`${META_BASE}/${s.phone_number_id}/messages`, {
      method: "POST",
      headers: { Authorization: `Bearer ${s.access_token}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        messaging_product: "whatsapp",
        to: phone,
        type: "reaction",
        reaction: { message_id: data.wa_message_id, emoji: data.emoji },
      }),
    });
    const json: any = await res.json();
    if (!res.ok) return { ok: false as const, error: json?.error?.message || "Failed to react" };

    const { data: target } = await supabase
      .from("messages").select("id, reactions")
      .eq("workspace_id", convo.workspace_id)
      .eq("wa_message_id", data.wa_message_id).maybeSingle();
    if (target) {
      const current: Array<{ by: string; emoji: string }> = Array.isArray((target as any).reactions) ? (target as any).reactions : [];
      const filtered = current.filter((r) => r.by !== "me");
      const next = data.emoji ? [...filtered, { by: "me", emoji: data.emoji }] : filtered;
      await supabase.from("messages").update({ reactions: next }).eq("id", target.id);
    }
    return { ok: true as const };
  });

export const sendInboxTemplate = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z.object({
      conversation_id: z.string().uuid(),
      template_id: z.string().uuid(),
    }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { data: convo, error: cErr } = await supabase
      .from("conversations").select("*").eq("id", data.conversation_id).single();
    if (cErr || !convo) throw new Error("Conversation not found");
    const role = await assertMember(supabase, convo.workspace_id, userId);
    if (role === "viewer") throw new Error("Viewers cannot send messages");

    const { data: tpl } = await supabase
      .from("templates").select("*")
      .eq("id", data.template_id)
      .eq("workspace_id", convo.workspace_id).maybeSingle();
    if (!tpl) return { ok: false as const, error: "Template not found" };

    const s = await getSettings(supabase, convo.workspace_id);
    const phone = convo.contact_phone.replace(/[^\d]/g, "");

    const res = await fetch(`${META_BASE}/${s.phone_number_id}/messages`, {
      method: "POST",
      headers: { Authorization: `Bearer ${s.access_token}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        messaging_product: "whatsapp",
        to: phone,
        type: "template",
        template: { name: tpl.meta_template_name, language: { code: tpl.language || "en_US" } },
      }),
    });
    const json: any = await res.json();
    if (!res.ok) return { ok: false as const, error: json?.error?.message || "Failed to send template" };

    const wa_id = json.messages?.[0]?.id;
    const bodyText = String(((tpl as any).components || []).find((c: any) => String(c?.type || "").toUpperCase() === "BODY")?.text || tpl.body || "");
    const preview = bodyText || `[template] ${tpl.meta_template_name}`;
    await supabase.from("messages").insert({
      workspace_id: convo.workspace_id,
      conversation_id: convo.id,
      direction: "out",
      type: "text",
      content: preview,
      sender_user_id: userId,
      wa_message_id: wa_id,
      status: "sent",
    });
    await supabase.from("conversations").update({
      last_message_at: new Date().toISOString(),
      last_message_preview: preview.slice(0, 140),
    }).eq("id", convo.id);
    return { ok: true as const, wa_message_id: wa_id };
  });


export const startConversations = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z
      .object({
        workspace_id: z.string().uuid(),
        contact_ids: z.array(z.string().uuid()).optional(),
        group_ids: z.array(z.string().uuid()).optional(),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    await assertMember(supabase, data.workspace_id, userId);
    if (!data.contact_ids?.length && !data.group_ids?.length) {
      return { ok: true as const, created: 0, first_conversation_id: null as string | null };
    }
    const result = await syncContactsToConversations({
      supabase,
      workspaceId: data.workspace_id,
      contactIds: data.contact_ids,
      groupIds: data.group_ids,
    });
    return { ok: true as const, ...result };
  });

export const sendInboxMedia = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z
      .object({
        conversation_id: z.string().uuid(),
        media_url: z.string().url(),
        media_type: z.enum(["image", "video", "document", "audio"]),
        media_mime: z.string().optional(),
        filename: z.string().optional(),
        caption: z.string().max(1024).optional(),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;

    const { data: convo, error: cErr } = await supabase
      .from("conversations")
      .select("*")
      .eq("id", data.conversation_id)
      .single();
    if (cErr || !convo) throw new Error("Conversation not found");

    const role = await assertMember(supabase, convo.workspace_id, userId);
    if (role === "viewer") throw new Error("Viewers cannot send messages");

    const s = await getSettings(supabase, convo.workspace_id);
    const phone = convo.contact_phone.replace(/[^\d]/g, "");

    const mediaPayload: any = { link: data.media_url };
    if (data.caption && data.media_type !== "audio") mediaPayload.caption = data.caption;
    if (data.media_type === "document" && data.filename) mediaPayload.filename = data.filename;

    const res = await fetch(`${META_BASE}/${s.phone_number_id}/messages`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${s.access_token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        messaging_product: "whatsapp",
        to: phone,
        type: data.media_type,
        [data.media_type]: mediaPayload,
      }),
    });
    const json: any = await res.json();
    if (!res.ok) {
      return { ok: false as const, error: json?.error?.message || "Meta API rejected the media" };
    }

    const wa_id = json.messages?.[0]?.id;
    await supabase.from("messages").insert({
      workspace_id: convo.workspace_id,
      conversation_id: convo.id,
      direction: "out",
      type: data.media_type,
      content: data.caption ?? null,
      media_url: data.media_url,
      media_mime: data.media_mime ?? null,
      sender_user_id: userId,
      wa_message_id: wa_id,
      status: "sent",
    });
    const preview =
      data.caption || `[${data.media_type}${data.filename ? ` · ${data.filename}` : ""}]`;
    await supabase
      .from("conversations")
      .update({
        last_message_at: new Date().toISOString(),
        last_message_preview: preview.slice(0, 140),
      })
      .eq("id", convo.id);

    return { ok: true as const, wa_message_id: wa_id };
  });
