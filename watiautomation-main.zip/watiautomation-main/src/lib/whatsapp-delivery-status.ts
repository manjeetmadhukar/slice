// Classify errors returned by Meta's Cloud API so we can:
//   * show the user a specific, actionable reason for every failure,
//   * mark a subset as "suppressed" (Meta refused delivery — retrying now
//     will not help and often hurts sender reputation),
//   * mark another subset as "retryable" (transient — rate limits, 5xx,
//     network drops) so the dispatcher can automatically try again with
//     exponential backoff.
export type CampaignRecipientDeliveryStatus = "failed" | "suppressed";

export type WhatsAppErrorClassification = {
  status: CampaignRecipientDeliveryStatus;
  code?: number;
  subcode?: number;
  title?: string;
  message?: string;
  details?: string;
  trace_id?: string;
  retryable: boolean;   // true => safe to re-attempt after a short delay
  error: string;        // human-facing summary
};

function firstError(input: any): any {
  if (Array.isArray(input)) return input[0] ?? {};
  if (Array.isArray(input?.errors)) return input.errors[0] ?? {};
  return input?.error ?? input ?? {};
}

// Meta / WhatsApp error codes that indicate a transient upstream problem.
// Retrying with backoff is appropriate — the recipient, template and
// credentials are all valid.
//   1     — API service temporarily unavailable
//   2     — Meta service temporarily unavailable
//   4     — App-level rate limit
//   17    — User-level rate limit
//   32    — Page-level rate limit
//   80007 — Business rate limit (WABA throughput)
//   130429/130472-ish transient marketing throttling handled separately
//   131016 — Service unavailable, try again
//   131048 — Spam rate limit (retryable after cool-down)
//   131056 — (Business, Consumer) pair rate limit — retryable
//   133016 — Deregistration/registration in progress
//   368    — Temporarily blocked for policies
const RETRYABLE_CODES = new Set<number>([
  1, 2, 4, 17, 32, 368,
  80007,
  131016, 131048, 131056,
  133016,
]);

export function classifyWhatsAppDeliveryError(
  input: any,
  httpStatus?: number,
): WhatsAppErrorClassification {
  const err = firstError(input);
  const rawCode = err?.code ?? err?.error_code;
  const code = Number.isFinite(Number(rawCode)) ? Number(rawCode) : undefined;
  const subcode = Number.isFinite(Number(err?.error_subcode))
    ? Number(err.error_subcode) : undefined;
  const rawMessage = String(
    err?.message
      || err?.title
      || err?.error_data?.details
      || err?.details
      || "Unknown WhatsApp delivery error",
  );
  const details = err?.error_data?.details || err?.details || undefined;
  const trace_id = err?.fbtrace_id || err?.trace_id || undefined;
  const title = err?.title;

  // ---- Meta-suppressed marketing deliveries (do NOT retry immediately) ----
  if (code === 131049 || /ecosystem engagement/i.test(rawMessage)) {
    return {
      status: "suppressed", code: 131049, subcode, title, message: rawMessage,
      details, trace_id, retryable: false,
      error:
        "Meta #131049: Delivery suppressed by WhatsApp per-user marketing limits (healthy ecosystem engagement). This is not a Slice send/API failure. Wait at least 24 hours before retrying this recipient, use warmer/opted-in audiences, and improve the marketing template quality.",
    };
  }
  if (code === 130472 || /part of an experiment/i.test(rawMessage)) {
    return {
      status: "suppressed", code: 130472, subcode, title, message: rawMessage,
      details, trace_id, retryable: false,
      error:
        "Meta #130472: Delivery suppressed because this recipient is part of WhatsApp's marketing message experiment. This is controlled by Meta and should not be retried immediately.",
    };
  }
  if (code === 131050 || /stop receiving marketing|stopped receiving marketing|opted out/i.test(rawMessage)) {
    return {
      status: "suppressed", code: 131050, subcode, title, message: rawMessage,
      details, trace_id, retryable: false,
      error:
        "Meta #131050: Recipient opted out of marketing messages from this business. Do not retry marketing templates for this recipient unless they opt back in.",
    };
  }

  // ---- Transient / retryable ----
  const isHttpRetryable =
    typeof httpStatus === "number" && (httpStatus === 429 || httpStatus >= 500);
  const isCodeRetryable = code !== undefined && RETRYABLE_CODES.has(code);
  const isTextRetryable = /temporarily unavailable|try again|timeout|timed out|rate limit|throttl/i.test(rawMessage);
  const retryable = isHttpRetryable || isCodeRetryable || isTextRetryable;

  const prefix = code ? `Meta #${code}: ` : httpStatus ? `HTTP ${httpStatus}: ` : "";
  return {
    status: "failed",
    code, subcode, title, message: rawMessage, details, trace_id,
    retryable,
    error: `${prefix}${rawMessage}`.slice(0, 500),
  };
}

export function isMetaSuppressedDelivery(rowOrError: any): boolean {
  if (rowOrError?.status === "suppressed") return true;
  const text = String(rowOrError?.error ?? rowOrError ?? "");
  return /131049|130472|131050|ecosystem engagement|part of an experiment|stop receiving marketing|opted out/i.test(text);
}
