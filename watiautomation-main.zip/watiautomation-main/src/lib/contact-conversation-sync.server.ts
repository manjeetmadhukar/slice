export type ContactConversationSyncResult = {
  total_contacts: number;
  created: number;
  updated: number;
  skipped: number;
  first_conversation_id: string | null;
};

type ContactRow = {
  id: string;
  name: string | null;
  phone: string | null;
};

export function normalizeWhatsAppPhone(phone: string | null | undefined) {
  const digits = String(phone ?? "").replace(/[^\d]/g, "");
  return digits ? `+${digits}` : "";
}

function phoneCandidates(phone: string | null | undefined) {
  const normalized = normalizeWhatsAppPhone(phone);
  const raw = String(phone ?? "").trim();
  const digits = raw.replace(/[^\d]/g, "");
  return Array.from(new Set([normalized, raw, digits].filter(Boolean)));
}

async function loadContacts(supabase: any, workspaceId: string, contactIds?: string[]) {
  if (contactIds) {
    if (contactIds.length === 0) return [] as ContactRow[];
    const { data, error } = await supabase
      .from("contacts")
      .select("id, name, phone")
      .eq("workspace_id", workspaceId)
      .in("id", contactIds);
    if (error) throw new Error(error.message);
    return (data ?? []) as ContactRow[];
  }

  const rows: ContactRow[] = [];
  const pageSize = 1000;
  for (let from = 0; ; from += pageSize) {
    const { data, error } = await supabase
      .from("contacts")
      .select("id, name, phone")
      .eq("workspace_id", workspaceId)
      .order("created_at", { ascending: true })
      .range(from, from + pageSize - 1);
    if (error) throw new Error(error.message);
    rows.push(...((data ?? []) as ContactRow[]));
    if (!data || data.length < pageSize) break;
  }
  return rows;
}

async function findExistingConversation(supabase: any, workspaceId: string, contact: ContactRow) {
  const byContact = await supabase
    .from("conversations")
    .select("id, contact_phone")
    .eq("workspace_id", workspaceId)
    .eq("contact_id", contact.id)
    .order("last_message_at", { ascending: false })
    .limit(1)
    .maybeSingle();
  if (byContact.error) throw new Error(byContact.error.message);
  if (byContact.data) return byContact.data;

  const candidates = phoneCandidates(contact.phone);
  if (!candidates.length) return null;
  const byPhone = await supabase
    .from("conversations")
    .select("id, contact_phone")
    .eq("workspace_id", workspaceId)
    .in("contact_phone", candidates)
    .order("last_message_at", { ascending: false })
    .limit(1)
    .maybeSingle();
  if (byPhone.error) throw new Error(byPhone.error.message);
  return byPhone.data ?? null;
}

export async function syncContactsToConversations(opts: {
  supabase: any;
  workspaceId: string;
  contactIds?: string[];
  groupIds?: string[];
}): Promise<ContactConversationSyncResult> {
  const selectedContactIds = opts.contactIds ? new Set(opts.contactIds) : null;

  if (opts.groupIds?.length) {
    const { data, error } = await opts.supabase
      .from("contact_group_members")
      .select("contact_id")
      .eq("workspace_id", opts.workspaceId)
      .in("group_id", opts.groupIds);
    if (error) throw new Error(error.message);
    for (const row of data ?? []) {
      if (selectedContactIds) selectedContactIds.add(row.contact_id);
    }
  }

  const contacts = await loadContacts(
    opts.supabase,
    opts.workspaceId,
    selectedContactIds ? Array.from(selectedContactIds) : undefined,
  );

  let created = 0;
  let updated = 0;
  let skipped = 0;
  let first: string | null = null;
  const seenPhones = new Set<string>();

  for (const contact of contacts) {
    const contactPhone = normalizeWhatsAppPhone(contact.phone);
    if (!contactPhone || seenPhones.has(contactPhone)) {
      skipped++;
      continue;
    }
    seenPhones.add(contactPhone);

    const contactName = contact.name || contactPhone;
    const existing = await findExistingConversation(opts.supabase, opts.workspaceId, contact);
    if (existing?.id) {
      const patch = {
        contact_id: contact.id,
        contact_name: contactName,
        contact_phone: contactPhone,
      };
      const { error } = await opts.supabase
        .from("conversations")
        .update(patch)
        .eq("id", existing.id);
      if (error) {
        await opts.supabase
          .from("conversations")
          .update({ contact_id: contact.id, contact_name: contactName })
          .eq("id", existing.id);
      }
      updated++;
      if (!first) first = existing.id;
      continue;
    }

    const { data: resolvedId, error } = await opts.supabase.rpc("resolve_conversation", {
      _workspace_id: opts.workspaceId,
      _phone: contactPhone,
      _name: contactName,
      _contact_id: contact.id,
      _last_message_at: new Date().toISOString(),
    });

    if (error || !resolvedId) {
      skipped++;
      continue;
    }
    created++;
    if (!first) first = resolvedId as string;
  }

  return {
    total_contacts: contacts.length,
    created,
    updated,
    skipped,
    first_conversation_id: first,
  };
}
