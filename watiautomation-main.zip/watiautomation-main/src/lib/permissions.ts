export type PermAction = "view" | "create" | "edit" | "delete";

export type ModuleKey =
  | "dashboard"
  | "inbox"
  | "contacts"
  | "pipeline"
  | "follow_ups"
  | "commerce"
  | "templates"
  | "campaigns"
  | "remarketing"
  | "automations"
  | "bots"
  | "ai"
  | "analytics"
  | "integrations"
  | "browse_recovery"
  | "team"
  | "settings";

export const MODULES: { key: ModuleKey; label: string }[] = [
  { key: "dashboard", label: "Dashboard" },
  { key: "inbox", label: "Inbox" },
  { key: "contacts", label: "Contacts" },
  { key: "pipeline", label: "Pipeline" },
  { key: "follow_ups", label: "Follow-ups" },
  { key: "commerce", label: "Commerce" },
  { key: "templates", label: "Templates" },
  { key: "campaigns", label: "Campaigns" },
  { key: "remarketing", label: "Remarketing" },
  { key: "automations", label: "Automations" },
  { key: "bots", label: "AI Bots" },
  { key: "ai", label: "AI Insights" },
  { key: "analytics", label: "Analytics" },
  { key: "integrations", label: "Integrations" },
  { key: "browse_recovery", label: "Browse Recovery" },
  { key: "team", label: "Team" },
  { key: "settings", label: "Settings" },
];

export const ACTIONS: PermAction[] = ["view", "create", "edit", "delete"];

export type PermissionRow = {
  module: ModuleKey | string;
  can_view: boolean;
  can_create: boolean;
  can_edit: boolean;
  can_delete: boolean;
};

export type PermissionMap = Record<string, Record<PermAction, boolean>>;

export function rowsToMap(rows: PermissionRow[]): PermissionMap {
  const m: PermissionMap = {};
  for (const r of rows) {
    m[r.module] = {
      view: !!r.can_view,
      create: !!r.can_create,
      edit: !!r.can_edit,
      delete: !!r.can_delete,
    };
  }
  return m;
}

export function defaultPermissions(role: "admin" | "agent" | "viewer"): PermissionMap {
  const m: PermissionMap = {};
  for (const mod of MODULES) {
    if (role === "viewer") {
      m[mod.key] = { view: true, create: false, edit: false, delete: false };
    } else if (role === "agent") {
      m[mod.key] = {
        view: true,
        create: mod.key !== "team" && mod.key !== "settings",
        edit: mod.key !== "team" && mod.key !== "settings",
        delete: false,
      };
    } else {
      m[mod.key] = { view: true, create: true, edit: true, delete: true };
    }
  }
  return m;
}
