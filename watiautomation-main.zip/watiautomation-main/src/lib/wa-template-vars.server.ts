// Smart WhatsApp template variable resolver.
//
// Problem: Slice / Meta templates have a positional body like:
//   "Hi {{1}}, order #{{2}} from {{3}}. Amount: {{4}}"
// but the same merchant may approve a re-ordered template such as
//   "Hi {{1}}, your order from {{2}} (#{{3}}) totals {{4}}"
// Hardcoding [name, orderNo, store, amount] then mis-maps {{2}} and {{3}}.
//
// This resolver reads the template BODY text, inspects the words around
// each {{N}} placeholder, and picks the matching field from the context
// bag (name / orderNumber / storeName / amount / trackingId / productName
// / url / custom.*). If a slot can't be matched, it falls back to a
// caller-supplied positional default so existing templates keep working.
//
// It also validates resolved values (amount must look numeric, name must
// be non-empty, etc.) and returns a list of warnings the caller can log
// to integration_debug_logs so future mapping issues are visible.

export type WaTemplateCtx = {
  name?: string | null;
  orderNumber?: string | null;
  storeName?: string | null;
  amount?: string | null;     // already formatted with currency symbol
  amountRaw?: number | null;  // numeric, for validation
  currency?: string | null;
  trackingId?: string | null;
  trackingUrl?: string | null;
  productName?: string | null;
  productPrice?: string | null;
  orderStatus?: string | null;
  orderDate?: string | null;
  customerEmail?: string | null;
  customerPhone?: string | null;
  url?: string | null;        // generic recovery / cta link
  custom?: Record<string, string | number | null | undefined>;
};

export type FieldKey =
  | "name" | "orderNumber" | "storeName" | "amount"
  | "trackingId" | "trackingUrl" | "productName" | "productPrice"
  | "orderStatus" | "orderDate" | "customerEmail" | "customerPhone"
  | "url";

// Locked mapping persisted on the template row (see `variable_mapping` column).
// When present, this OVERRIDES keyword detection so {{N}} is always resolved
// from the data source the user picked at template-creation time.
export type LockedMapping = Array<{
  index: number;
  field: string;              // FieldKey, "static_text", or any future field
  static_value?: string;      // only when field === "static_text"
}>;

// Maps the persisted UI field keys (from src/lib/wa-template-fields.ts) to
// the runtime FieldKey understood by getCtxValue below. Keeping this here so
// the server resolver stays standalone and never imports the UI module.
const UI_FIELD_TO_CTX: Record<string, FieldKey | "__static__" | null> = {
  customer_name:  "name",
  customer_phone: "customerPhone",
  customer_email: "customerEmail",
  order_id:       "orderNumber",
  order_amount:   "amount",
  order_status:   "orderStatus",
  order_date:     "orderDate",
  product_name:   "productName",
  product_price:  "productPrice",
  tracking_id:    "trackingId",
  tracking_url:   "trackingUrl",
  store_name:     "storeName",
  recovery_url:   "url",
  static_text:    "__static__",
};

// Keyword → field. Ordered by specificity (more specific first).
const KEYWORD_MAP: Array<{ field: FieldKey; patterns: RegExp[] }> = [
  { field: "trackingUrl",  patterns: [/track(ing)?\s*(link|url)/i, /track\s*your\s*order/i] },
  { field: "trackingId",   patterns: [/tracking\s*(id|number|no|#)/i, /\bawb\b/i, /\bconsignment\b/i, /\bwaybill\b/i] },
  { field: "orderNumber",  patterns: [/order\s*(id|number|no|#)/i, /\border\s*#/i, /#\s*$/i, /invoice\s*(no|#|number)/i, /reference\s*(no|#)/i] },
  { field: "amount",       patterns: [/order\s*(amount|total|value)/i, /\b(amount|total|grand\s*total|price|value)\b/i, /pay(able|ment)?\s*(amount|of)?/i, /[₹$€£]\s*$/, /(inr|usd|eur|gbp|aed|aud|cad)\s*$/i] },
  { field: "storeName",    patterns: [/\bfrom\s*$/i, /\bat\s*$/i, /\bstore\b/i, /\bshop\b/i, /\bbrand\b/i, /\bmerchant\b/i, /thanks?\s*for\s*(shopping|ordering)\s*(at|with)?\s*$/i] },
  { field: "productName",  patterns: [/\bproduct\b/i, /\bitem\b/i, /you\s*(ordered|bought|purchased)\s*$/i] },
  { field: "url",          patterns: [/\b(link|url|click\s*here|continue|complete|recover|checkout)\b/i] },
  { field: "name",         patterns: [/^(hi|hello|hey|dear)\b/i, /\bcustomer\s*name\b/i, /\bname\b/i] },
];

function classifyPlaceholder(before: string, after: string): FieldKey | null {
  // `before` is ONLY the text since the previous placeholder (so labels that
  // belong to earlier slots, e.g. "order #" before {{2}}, can never leak into
  // {{4}}'s classification). Among all keyword matches in `before`, pick the
  // one that ends CLOSEST to the placeholder — the nearest label wins.
  let best: { field: FieldKey; end: number; rank: number } | null = null;
  KEYWORD_MAP.forEach(({ field, patterns }, rank) => {
    for (const re of patterns) {
      const g = new RegExp(re.source, re.flags.includes("g") ? re.flags : re.flags + "g");
      let m: RegExpExecArray | null;
      while ((m = g.exec(before)) !== null) {
        const end = m.index + m[0].length;
        if (!best || end > best.end || (end === best.end && rank < best.rank)) {
          best = { field, end, rank };
        }
        if (m[0].length === 0) g.lastIndex++;
      }
    }
  });
  if (best) return (best as { field: FieldKey }).field;
  for (const { field, patterns } of KEYWORD_MAP) {
    if (patterns.some((re) => re.test(after))) return field;
  }
  return null;
}

function getCtxValue(ctx: WaTemplateCtx, field: FieldKey): string | null {
  switch (field) {
    case "name":           return ctx.name ?? null;
    case "orderNumber":    return ctx.orderNumber ?? null;
    case "storeName":      return ctx.storeName ?? null;
    case "amount":         return ctx.amount ?? null;
    case "trackingId":     return ctx.trackingId ?? null;
    case "trackingUrl":    return ctx.trackingUrl ?? null;
    case "productName":    return ctx.productName ?? null;
    case "productPrice":   return ctx.productPrice ?? null;
    case "orderStatus":    return ctx.orderStatus ?? null;
    case "orderDate":      return ctx.orderDate ?? null;
    case "customerEmail":  return ctx.customerEmail ?? null;
    case "customerPhone":  return ctx.customerPhone ?? null;
    case "url":            return ctx.url ?? null;
    default:               return null;
  }
}

function looksLikeMoney(s: string): boolean {
  return /\d/.test(s) && /[\d.,]/.test(s);
}

function validate(field: FieldKey, value: string): string | null {
  if (!value || !value.trim()) return `${field} is empty`;
  if (field === "amount" && !looksLikeMoney(value)) {
    return `amount slot resolved to non-numeric value "${value}"`;
  }
  if (field === "orderNumber" && value.length > 64) {
    return `orderNumber unusually long (${value.length} chars)`;
  }
  if (field === "trackingUrl" && !/^https?:\/\//i.test(value)) {
    return `trackingUrl is not a URL: "${value}"`;
  }
  return null;
}

export type ResolveResult = {
  params: string[];          // length = max(variableCount, detected placeholders)
  mapping: Array<{ index: number; field: FieldKey | "fallback"; value: string }>;
  warnings: string[];
};

/**
 * Resolve body params for a WhatsApp template.
 *
 * @param componentsSchema raw `templates.components` JSON from Meta
 * @param ctx              available data
 * @param fallbackOrder    positional default used when keyword detection fails
 *                         (legacy Slice templates: [name, orderNumber, storeName, amount])
 * @param variableCount    `templates.variables_count` from DB
 */
export function resolveTemplateParams(
  componentsSchema: unknown,
  ctx: WaTemplateCtx,
  fallbackOrder: FieldKey[],
  variableCount?: number | null,
  lockedMapping?: LockedMapping | null,
): ResolveResult {
  // Locked mapping takes priority — it's what the user explicitly chose
  // when the template was created and is the only way to guarantee that
  // {{N}} always carries the same data field across every campaign.
  if (Array.isArray(lockedMapping) && lockedMapping.length) {
    const count = Math.max(Number(variableCount || 0), ...lockedMapping.map(e => Number(e.index) || 0));
    const byIndex = new Map<number, LockedMapping[number]>();
    for (const e of lockedMapping) if (Number.isFinite(e.index)) byIndex.set(Number(e.index), e);
    const params: string[] = [];
    const mapping: ResolveResult["mapping"] = [];
    const warnings: string[] = [];
    for (let i = 1; i <= count; i++) {
      const entry = byIndex.get(i);
      if (!entry) {
        params.push("");
        mapping.push({ index: i, field: "fallback", value: "" });
        warnings.push(`{{${i}}} has no locked mapping`);
        continue;
      }
      const ctxKey = UI_FIELD_TO_CTX[entry.field];
      let value = "";
      let fieldLabel: FieldKey | "fallback" = "fallback";
      if (ctxKey === "__static__") {
        value = (entry.static_value ?? "").toString();
        fieldLabel = "fallback"; // not a runtime field, but recorded by name below
      } else if (ctxKey) {
        value = (getCtxValue(ctx, ctxKey) ?? "").toString();
        fieldLabel = ctxKey;
      } else {
        warnings.push(`{{${i}}} unknown field "${entry.field}"`);
      }
      params.push(value);
      mapping.push({ index: i, field: fieldLabel, value });
      if (ctxKey && ctxKey !== "__static__") {
        const err = validate(ctxKey, value);
        if (err) warnings.push(`{{${i}}} (${entry.field}) → ${err}`);
      } else if (ctxKey === "__static__" && !value.trim()) {
        warnings.push(`{{${i}}} static text is empty`);
      }
    }
    return { params, mapping, warnings };
  }


  const schema = Array.isArray(componentsSchema) ? (componentsSchema as any[]) : [];
  const bodyComp = schema.find((c: any) => String(c?.type || "").toUpperCase() === "BODY");
  const bodyText: string = String(bodyComp?.text || "");

  // Meta-approved example body_text. When the template has no locked mapping
  // (legacy / synced-from-Meta templates), example values are the most
  // reliable hint to what each {{N}} represents — keyword detection alone
  // misclassified e.g. "...order for {{1}}" as customer name.
  const exampleRow: string[] = (() => {
    const ex = bodyComp?.example?.body_text;
    if (Array.isArray(ex) && ex.length && Array.isArray(ex[0])) {
      return (ex[0] as any[]).map((v: any) => String(v ?? ""));
    }
    return [];
  })();
  function fieldFromExample(sample: string): FieldKey | null {
    const s = sample.trim();
    if (!s) return null;
    if (/^https?:\/\//i.test(s)) {
      return /track|awb|consign|waybill|shipment/i.test(s) ? "trackingUrl" : "url";
    }
    if (/^[A-Z]{2,4}\d{6,}$/.test(s) || /^awb/i.test(s)) return "trackingId";
    if (/^#?\d{3,}$/.test(s) || /^#/.test(s) || /order|invoice/i.test(s)) return "orderNumber";
    if (/[₹$€£]|^(inr|usd|eur|gbp|aed)\b/i.test(s) || /^\d+(\.\d{1,2})?$/.test(s)) return "amount";
    if (/@/.test(s) && /\./.test(s)) return "customerEmail";
    if (/^\+?\d[\d\s\-()]{6,}$/.test(s)) return "customerPhone";
    if (/\b(dress|shirt|kurti|saree|tee|bag|shoe|product|item)\b/i.test(s)) return "productName";
    if (/^[A-Z][a-z]+(\s+[A-Z][a-z]+){1,3}$/.test(s)) return "name";
    return null;
  }

  // Collect placeholders in body, in document order. Same {{N}} can appear
  // multiple times — first occurrence wins for classification. Each slot is
  // classified using only the text between the previous placeholder and this
  // one (before-context) and the text up to the next placeholder (after).
  const seen = new Map<number, FieldKey | null>();
  const order: number[] = [];
  const re = /\{\{\s*(\d+)\s*\}\}/g;
  let m: RegExpExecArray | null;
  let prevEnd = 0;
  while ((m = re.exec(bodyText)) !== null) {
    const n = Number(m[1]);
    const matchEnd = m.index + m[0].length;
    if (!Number.isFinite(n) || n < 1) { prevEnd = matchEnd; continue; }
    if (!seen.has(n)) {
      let before = bodyText.slice(prevEnd, m.index);
      if (before.length > 80) before = before.slice(-80);
      const nextIdx = bodyText.indexOf("{{", matchEnd);
      const afterEnd = nextIdx === -1 ? Math.min(bodyText.length, matchEnd + 40) : Math.min(nextIdx, matchEnd + 40);
      const after = bodyText.slice(matchEnd, afterEnd);
      // Example-derived field WINS over keyword guessing — it's the value
      // Meta actually approved the template against.
      const fromExample = fieldFromExample(exampleRow[n - 1] ?? "");
      seen.set(n, fromExample ?? classifyPlaceholder(before, after));
      order.push(n);
    }
    prevEnd = matchEnd;
  }

  const maxIndex = Math.max(
    Number(variableCount || 0),
    order.length ? Math.max(...order) : 0,
  );

  const params: string[] = [];
  const mapping: ResolveResult["mapping"] = [];
  const warnings: string[] = [];
  const usedFallback = new Set<FieldKey>();

  for (let i = 1; i <= maxIndex; i++) {
    let field = seen.get(i) ?? null;
    let value: string | null = field ? getCtxValue(ctx, field) : null;

    if (!field) {
      // Slot could not be classified at all — only THEN use positional fallback.
      const fb = fallbackOrder.find((f) => !usedFallback.has(f) && getCtxValue(ctx, f));
      if (fb) {
        field = fb;
        value = getCtxValue(ctx, fb);
        usedFallback.add(fb);
      }
    } else if (!value) {
      // Slot WAS classified (e.g. productName) but the data is missing.
      // NEVER substitute an unrelated field here — that's how a customer
      // name ended up in a product-name slot. Warn loudly instead.
      usedFallback.add(field);
      warnings.push(`{{${i}}} expects ${field} but no value was provided by the integration`);
    } else {
      usedFallback.add(field);
    }

    const finalValue = (value ?? "").toString();
    params.push(finalValue);
    mapping.push({ index: i, field: field ?? "fallback", value: finalValue });

    if (field) {
      const err = validate(field, finalValue);
      if (err) warnings.push(`{{${i}}} → ${err}`);
    } else if (!finalValue.trim()) {
      warnings.push(`{{${i}}} could not be resolved (no keyword match, no fallback available)`);
    }
  }

  return { params, mapping, warnings };
}
