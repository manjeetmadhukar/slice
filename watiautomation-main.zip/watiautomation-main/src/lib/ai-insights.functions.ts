import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const wsInput = z.object({ workspace_id: z.string().uuid() });

/** Aggregate stats for the AI dashboard (message analysis + lead quality). */
export const getAiDashboardStats = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) => wsInput.parse(d))
  .handler(async ({ data, context }) => {
    const { supabase } = context;
    const ws = data.workspace_id;

    const since = new Date(Date.now() - 30 * 86_400_000).toISOString();

    const [{ data: analyses }, { data: contacts }] = await Promise.all([
      supabase
        .from("ai_message_analyses")
        .select("sentiment,intent,urgency,lead_stage,conversion_probability,created_at")
        .eq("workspace_id", ws)
        .gte("created_at", since)
        .limit(5000),
      supabase
        .from("contacts")
        .select("id,name,phone,ai_lead_stage,ai_last_intent,ai_confidence,ai_updated_at,lead_stage")
        .eq("workspace_id", ws)
        .not("ai_updated_at", "is", null)
        .order("ai_updated_at", { ascending: false })
        .limit(200),
    ]);

    const rows = analyses ?? [];
    const count = (key: keyof (typeof rows)[number]) => {
      const out: Record<string, number> = {};
      for (const r of rows) {
        const v = (r[key] as string) || "unknown";
        out[v] = (out[v] || 0) + 1;
      }
      return out;
    };

    const probs = rows
      .map((r) => Number(r.conversion_probability ?? 0))
      .filter((n) => !isNaN(n));
    const avgConversion = probs.length
      ? Math.round((probs.reduce((a, b) => a + b, 0) / probs.length) * 100)
      : 0;

    // Hot/warm/cold buckets from contacts' ai_confidence + last conversion prob.
    const contactList = contacts ?? [];
    const buckets = { hot: 0, warm: 0, cold: 0 };
    for (const c of contactList) {
      const conf = Number(c.ai_confidence ?? 0);
      if (conf >= 0.7) buckets.hot++;
      else if (conf >= 0.4) buckets.warm++;
      else buckets.cold++;
    }

    return {
      total: rows.length,
      sentiment: count("sentiment"),
      intent: count("intent"),
      urgency: count("urgency"),
      stage: count("lead_stage"),
      avgConversion,
      buckets,
      contacts: contactList,
    };
  });

/** Per-lead timeline: messages with AI tags for one contact. */
export const getLeadTimeline = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) =>
    z.object({ workspace_id: z.string().uuid(), contact_id: z.string().uuid() }).parse(d),
  )
  .handler(async ({ data, context }) => {
    const { supabase } = context;

    const { data: contact } = await supabase
      .from("contacts")
      .select("id,name,phone,ai_lead_stage,ai_last_intent,ai_confidence,ai_language,ai_updated_at,lead_stage,tags")
      .eq("id", data.contact_id)
      .eq("workspace_id", data.workspace_id)
      .maybeSingle();

    if (!contact) return { contact: null, messages: [] as any[] };

    const { data: convos } = await supabase
      .from("conversations")
      .select("id")
      .eq("workspace_id", data.workspace_id)
      .eq("contact_id", data.contact_id);

    const convoIds = (convos ?? []).map((c) => c.id);
    if (convoIds.length === 0) return { contact, messages: [] as any[] };

    const [{ data: messages }, { data: analyses }] = await Promise.all([
      supabase
        .from("messages")
        .select("id,content,direction,created_at,type,status,is_automated")
        .in("conversation_id", convoIds)
        .order("created_at", { ascending: false })
        .limit(200),
      supabase
        .from("ai_message_analyses")
        .select("message_id,sentiment,intent,urgency,lead_stage,conversion_probability,reasoning,recommended_action")
        .in("conversation_id", convoIds)
        .limit(500),
    ]);

    const byMsg = new Map<string, any>();
    for (const a of analyses ?? []) {
      if (a.message_id) byMsg.set(a.message_id, a);
    }

    const enriched = (messages ?? []).map((m) => ({
      ...m,
      ai: byMsg.get(m.id) || null,
    }));

    return { contact, messages: enriched };
  });

/** Read AI assistant settings for the current workspace. */
export const getAiSettings = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) => wsInput.parse(d))
  .handler(async ({ data, context }) => {
    const { supabase } = context;
    const { data: row } = await supabase
      .from("ai_assistant_settings")
      .select("*")
      .eq("workspace_id", data.workspace_id)
      .maybeSingle();
    return row;
  });

/** Update AI assistant settings (model + prompt config). Admins/owners only via RLS. */
export const updateAiSettings = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) =>
    z.object({
      workspace_id: z.string().uuid(),
      model: z.string().min(1).max(80),
      tone: z.string().min(1).max(40),
      language_preference: z.string().min(1).max(40),
      system_prompt: z.string().max(8000),
      enabled: z.boolean(),
    }).parse(d),
  )
  .handler(async ({ data, context }) => {
    const { supabase } = context;
    const { error } = await supabase
      .from("ai_assistant_settings")
      .upsert(
        {
          workspace_id: data.workspace_id,
          model: data.model,
          tone: data.tone,
          language_preference: data.language_preference,
          system_prompt: data.system_prompt,
          enabled: data.enabled,
        },
        { onConflict: "workspace_id" },
      );
    if (error) throw new Error(error.message);
    return { ok: true };
  });
