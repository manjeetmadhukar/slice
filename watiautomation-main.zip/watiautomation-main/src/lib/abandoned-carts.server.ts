// Abandoned-cart helpers shared by Shopify + WooCommerce webhook receivers.
//
// Responsibilities:
//   * mint a unique, URL-safe recovery token per cart
//   * build a Slice short link (slice.dotscube.com/r/{token}) the user
//     pastes into the {{recovery_url}} variable of a WhatsApp template
//   * persist provider data + the resolved short link on `abandoned_carts`
//     so the redirector can 302 the customer to the real provider URL and
//     log every click for conversion analytics.
import { randomBytes } from "crypto";
import { supabaseAdmin } from "@/integrations/supabase/client.server";

const CANONICAL_RECOVERY_BASE = "https://slice.dotscube.com";

export function mintRecoveryToken(): string {
  // 18 bytes → 24 char url-safe slug. Collision probability negligible at
  // expected volumes; the DB unique index is the source of truth.
  return randomBytes(18).toString("base64url");
}

export function buildRecoveryUrl(baseUrl: string, token: string): string {
  // SHORT link: slice.dotscube.com/r/{token}. Matches the URL button users
  // set up in Meta-approved WhatsApp templates (https://slice.dotscube.com/r/{{1}}).
  // The /r/$token route handles the 302 redirect to the provider cart URL.
  const base = canonicalRecoveryBase(baseUrl);
  return `${base}/r/${encodeURIComponent(token)}`;
}

function canonicalRecoveryBase(baseUrl: string): string {
  const envBase = process.env.APP_BASE_URL;
  const raw = (envBase || baseUrl || CANONICAL_RECOVERY_BASE).replace(/\/$/, "");
  try {
    const url = new URL(raw);
    const host = url.hostname.toLowerCase();
    if (host === "localhost" || host === "127.0.0.1") return raw;
    if (host === "slice.dotscube.com") return CANONICAL_RECOVERY_BASE;
    if (host.endsWith(".lovable.app") || host.includes("lovableproject.com")) {
      return CANONICAL_RECOVERY_BASE;
    }
    return raw;
  } catch {
    return CANONICAL_RECOVERY_BASE;
  }
}

function normalizeRecoveryUrlForToken(existingUrl: string | null | undefined, appBaseUrl: string, token: string) {
  const expected = buildRecoveryUrl(appBaseUrl, token);
  if (!existingUrl) return expected;
  try {
    const current = new URL(existingUrl);
    const expectedUrl = new URL(expected);
    if (current.hostname !== expectedUrl.hostname || current.pathname !== expectedUrl.pathname) {
      return expected;
    }
    return existingUrl;
  } catch {
    return expected;
  }
}

export function normalizeWooCommerceRecoveryUrl(rawUrl: string | null | undefined, storeUrl: string | null | undefined, cartToken: string): string | null {
  const token = String(cartToken || "").trim();
  if (!token) return rawUrl || null;
  const candidates = [rawUrl, storeUrl ? `${String(storeUrl).replace(/\/$/, "")}/cart/` : null].filter(Boolean) as string[];
  for (const candidate of candidates) {
    try {
      const url = new URL(candidate);
      if (!/^https?:$/i.test(url.protocol)) continue;
      if (url.searchParams.has("slice_recover") || /\/cart/i.test(url.pathname)) {
        url.searchParams.set("slice_recover", token);
        return url.toString();
      }
    } catch {}
  }
  return rawUrl || null;
}

export type AbandonedCartUpsert = {
  workspaceId: string;
  integrationId: string;
  provider: "shopify" | "woocommerce";
  cartToken: string;            // provider-side cart/checkout token (stable per cart)
  externalId?: string | null;   // e.g. Shopify checkout id
  contactId?: string | null;
  customerName?: string | null;
  customerEmail?: string | null;
  customerPhone?: string | null; // already E.164 normalized
  total: number;
  currency: string;
  providerRecoveryUrl: string | null;  // Shopify abandoned_checkout_url OR WC checkout URL
  items: unknown[];
  delayMinutes?: number | null;  // minutes to wait before sending WhatsApp reminder (default 30)
  abandonedAt?: string | null;   // provider-reported abandonment time; countdown anchor
  expiresAt?: string | null;    // ISO; defaults to 30 days
  appBaseUrl: string;
};

/**
 * Idempotent upsert: on first sight of (integration_id, cart_token) mint a
 * recovery token and return its slice short link. Subsequent updates reuse
 * the same token so the URL printed in WhatsApp stays valid for the full
 * lifetime of the cart.
 */
export async function upsertAbandonedCart(args: AbandonedCartUpsert): Promise<{
  cartId: string;
  recoveryToken: string;
  recoveryUrl: string;
  isNew: boolean;
}> {
  const expiresAt = args.expiresAt
    || new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString();

  const { data: existing } = await supabaseAdmin
    .from("abandoned_carts")
    .select("id, recovery_token, recovery_url, send_scheduled_at, abandoned_at, status, recovered_at, contact_id, customer_name, customer_email, customer_phone, items, total")
    .eq("integration_id", args.integrationId)
    .eq("cart_token", args.cartToken)
    .maybeSingle();

  const recoveryToken = (existing as any)?.recovery_token || mintRecoveryToken();
  const recoveryUrl = normalizeRecoveryUrlForToken((existing as any)?.recovery_url, args.appBaseUrl, recoveryToken);

  // Countdown anchor = the recorded cart-abandonment timestamp, NOT webhook
  // processing time. Once a cart has an abandoned_at we keep it forever, so
  // duplicate/retried webhooks can never restart or push the timer forward.
  // Providers (WooCommerce/CartFlows) often report naive local-time strings
  // like "2026-08-16 20:24:59" with no timezone, which parse as UTC and land
  // in the future for +05:30 stores. Never trust a future timestamp.
  const sanitizeAbandonedAt = (raw: unknown): string => {
    const now = Date.now();
    if (!raw) return new Date(now).toISOString();
    const t = new Date(String(raw)).getTime();
    if (!Number.isFinite(t)) return new Date(now).toISOString();
    // allow 2 min of clock skew, otherwise clamp to now
    return new Date(t > now + 120_000 ? now : t).toISOString();
  };
  const abandonedAtIso = ((existing as any)?.abandoned_at as string | undefined)
    ? sanitizeAbandonedAt((existing as any).abandoned_at)
    : sanitizeAbandonedAt(args.abandonedAt);

  const delayMin = Number.isFinite(Number(args.delayMinutes)) && Number(args.delayMinutes) >= 0
    ? Number(args.delayMinutes)
    : 30;
  const existingScheduledAt = (existing as any)?.send_scheduled_at as string | null | undefined;
  const dueAt = new Date(new Date(abandonedAtIso).getTime() + delayMin * 60_000).toISOString();
  // Drop a stale schedule that was computed from a bad (future) anchor.
  const scheduledAt = existingScheduledAt && new Date(existingScheduledAt).getTime() <= new Date(dueAt).getTime()
    ? existingScheduledAt
    : dueAt;


  // Never overwrite existing customer identity with an empty value — a
  // later cart heartbeat from the same visitor may not include billing
  // fields (e.g. blocks checkout AJAX, cart quantity change) while an
  // earlier checkout-page ping already captured them.
  const pickString = (next: string | null | undefined, prev: unknown): string | null => {
    const n = typeof next === "string" ? next.trim() : "";
    if (n) return n;
    const p = typeof prev === "string" ? prev.trim() : "";
    return p ? p : null;
  };
  const nextItems = Array.isArray(args.items) && args.items.length ? args.items : null;
  const prevItems = Array.isArray((existing as any)?.items) ? (existing as any).items : null;
  const mergedItems = nextItems ?? prevItems ?? [];
  const mergedTotal = Number(args.total || 0) > 0
    ? Number(args.total)
    : Number((existing as any)?.total || 0);

  const row: any = {
    workspace_id: args.workspaceId,
    integration_id: args.integrationId,
    provider: args.provider,
    cart_token: args.cartToken,
    external_id: args.externalId ?? args.cartToken,
    contact_id: args.contactId ?? (existing as any)?.contact_id ?? null,
    customer_name: pickString(args.customerName, (existing as any)?.customer_name),
    customer_email: pickString(args.customerEmail, (existing as any)?.customer_email),
    customer_phone: pickString(args.customerPhone, (existing as any)?.customer_phone),
    total: mergedTotal,
    currency: args.currency || "USD",
    checkout_url: args.providerRecoveryUrl,
    provider_recovery_url: args.providerRecoveryUrl,
    recovery_token: recoveryToken,
    recovery_url: recoveryUrl,
    recovery_expires_at: expiresAt,
    items: mergedItems as any,
    status: "abandoned",
    abandoned_at: abandonedAtIso,
    send_scheduled_at: scheduledAt,
  };

  if ((existing as any)?.id) {
    // A late cart heartbeat must never resurrect a cart the shopper already
    // purchased — that would re-arm a cancelled reminder.
    const updateRow = { ...row };
    if ((existing as any).status === "recovered") delete (updateRow as any).status;
    await supabaseAdmin.from("abandoned_carts").update(updateRow).eq("id", (existing as any).id);
    console.log(`[abandoned-carts] merge cart_token=${args.cartToken} name=${row.customer_name ?? "-"} phone=${row.customer_phone ?? "-"} email=${row.customer_email ?? "-"}`);
    return { cartId: (existing as any).id, recoveryToken, recoveryUrl, isNew: false };
  }
  const { data: inserted, error } = await supabaseAdmin
    .from("abandoned_carts").insert(row).select("id").single();
  if (error) {
    // Concurrent pings for the same cart can race past the lookup above and
    // collide on uniq_abandoned_carts_integration_cart — fall back to update.
    if ((error as any).code === "23505") {
      const { data: raced } = await supabaseAdmin
        .from("abandoned_carts")
        .select("id, recovery_token, recovery_url")
        .eq("integration_id", args.integrationId)
        .eq("cart_token", args.cartToken)
        .maybeSingle();
      if ((raced as any)?.id) {
        const keepToken = (raced as any).recovery_token || recoveryToken;
        await supabaseAdmin.from("abandoned_carts").update({
          ...row,
          recovery_token: keepToken,
          recovery_url: normalizeRecoveryUrlForToken((raced as any).recovery_url, args.appBaseUrl, keepToken),
        }).eq("id", (raced as any).id);
        return {
          cartId: (raced as any).id,
          recoveryToken: keepToken,
          recoveryUrl: normalizeRecoveryUrlForToken((raced as any).recovery_url, args.appBaseUrl, keepToken),
          isNew: false,
        };
      }
    }
    throw error;
  }
  console.log(`[abandoned-carts] insert cart_token=${args.cartToken} name=${row.customer_name ?? "-"} phone=${row.customer_phone ?? "-"} email=${row.customer_email ?? "-"}`);
  return { cartId: (inserted as any).id, recoveryToken, recoveryUrl, isNew: true };
}

export async function recordRecoveryClick(args: {
  cartId: string;
  workspaceId: string;
  token: string;
  ip?: string | null;
  userAgent?: string | null;
  referer?: string | null;
}) {
  // Best-effort: never block the redirect on logging failure.
  try {
    await supabaseAdmin.from("cart_recovery_clicks").insert({
      workspace_id: args.workspaceId,
      abandoned_cart_id: args.cartId,
      recovery_token: args.token,
      ip: args.ip ?? null,
      user_agent: args.userAgent ?? null,
      referer: args.referer ?? null,
    } as any);
    const { data: cur } = await supabaseAdmin
      .from("abandoned_carts").select("click_count")
      .eq("id", args.cartId).maybeSingle();
    await supabaseAdmin.from("abandoned_carts").update({
      clicked_at: new Date().toISOString(),
      click_count: Number((cur as any)?.click_count || 0) + 1,
    } as any).eq("id", args.cartId);
  } catch (e) {
    console.error("recordRecoveryClick failed", e);
  }
}


/**
 * Purchase completed → cancel any pending abandoned-cart reminder for this
 * shopper (all carts they may have left behind, since Woo/CartFlows mints a
 * new cart token per session). Only carts that have NOT been reminded yet are
 * touched, so analytics for already-sent reminders stay intact.
 */
export async function cancelPendingCartReminders(args: {
  workspaceId: string;
  integrationId: string;
  cartToken?: string | null;
  phone?: string | null;
  email?: string | null;
  windowHours?: number;
}): Promise<number> {
  try {
    const sinceIso = new Date(Date.now() - (args.windowHours ?? 72) * 3600_000).toISOString();
    const { data: open } = await supabaseAdmin
      .from("abandoned_carts")
      .select("id, cart_token, customer_phone, customer_email")
      .eq("workspace_id", args.workspaceId)
      .eq("integration_id", args.integrationId)
      .eq("status", "abandoned")
      .gte("abandoned_at", sinceIso)
      .limit(200);
    const digits = (v: unknown) => {
      const d = String(v ?? "").replace(/[^\d]/g, "");
      return d.length > 10 ? d.slice(-10) : d;
    };
    const wantPhone = digits(args.phone);
    const wantEmail = String(args.email ?? "").trim().toLowerCase();
    const wantToken = String(args.cartToken ?? "").trim();
    const ids = (open ?? [])
      .filter((c: any) =>
        (wantToken && String(c.cart_token) === wantToken)
        || (wantPhone && digits(c.customer_phone) === wantPhone)
        || (wantEmail && String(c.customer_email ?? "").trim().toLowerCase() === wantEmail))
      .map((c: any) => c.id);
    if (!ids.length) return 0;
    await supabaseAdmin.from("abandoned_carts").update({
      status: "recovered",
      recovered_at: new Date().toISOString(),
      send_scheduled_at: null,
    } as any).in("id", ids);
    console.log(`[abandoned-carts] cancelled ${ids.length} pending reminder(s) after purchase`);
    return ids.length;
  } catch (e) {
    console.error("[abandoned-carts] cancelPendingCartReminders failed", e);
    return 0;
  }
}
