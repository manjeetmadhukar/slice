import { createContext, useContext, useMemo, type ReactNode } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useWorkspace } from "@/lib/workspace-context";
import {
  rowsToMap,
  type PermAction,
  type PermissionMap,
  type ModuleKey,
} from "@/lib/permissions";

interface Ctx {
  permissions: PermissionMap;
  isPrivileged: boolean; // owner/admin bypass
  hasPermission: (module: ModuleKey | string, action?: PermAction) => boolean;
  isLoading: boolean;
}

const PermCtx = createContext<Ctx | null>(null);

export function PermissionsProvider({ children }: { children: ReactNode }) {
  const { currentWorkspaceId, role } = useWorkspace();
  const isPrivileged = role === "owner" || role === "admin";

  const { data: rows = [], isLoading } = useQuery({
    queryKey: ["member-permissions", currentWorkspaceId],
    enabled: !!currentWorkspaceId && !isPrivileged,
    queryFn: async () => {
      const { data: userRes } = await supabase.auth.getUser();
      const uid = userRes.user?.id;
      if (!uid) return [];
      const { data, error } = await supabase
        .from("member_permissions")
        .select("module, can_view, can_create, can_edit, can_delete")
        .eq("workspace_id", currentWorkspaceId!)
        .eq("user_id", uid);
      if (error) throw error;
      return data ?? [];
    },
  });

  const permissions = useMemo(() => rowsToMap(rows as any), [rows]);

  const hasPermission = (module: ModuleKey | string, action: PermAction = "view") => {
    if (isPrivileged) return true;
    return !!permissions[module]?.[action];
  };

  return (
    <PermCtx.Provider value={{ permissions, isPrivileged, hasPermission, isLoading }}>
      {children}
    </PermCtx.Provider>
  );
}

export function usePermissions() {
  const ctx = useContext(PermCtx);
  if (!ctx) throw new Error("usePermissions must be used within PermissionsProvider");
  return ctx;
}
