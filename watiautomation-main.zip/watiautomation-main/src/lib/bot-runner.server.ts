// Bot flow execution engine. Imported only by server code.
import { supabaseAdmin } from "@/integrations/supabase/client.server";

const META_BASE = "https://graph.facebook.com/v21.0";

type Settings = { phone_number_id: string; access_token: string };
type Node = { id: string; type: string; data: any; position: any };
type Edge = { id: string; source_node_id: string; target_node_id: string; source_handle: string | null };

async function logBotDebug(args: {
  workspace_id: string;
  event: string;
  ok: boolean;
  message: string;
  payload?: Record<string, any>;
}) {
  await supabaseAdmin.from("integration_debug_logs").insert({
    workspace_id: args.workspace_id,
    provider: "whatsapp",
    direction: "in",
    event: args.event,
    ok: args.ok,
    status_code: args.ok ? 200 : 422,
    message: args.message,
    payload: args.payload || {},
  }).then(() => {}, () => {});
}

async function getSettings(workspace_id: string): Promise<Settings | null> {
  const { data } = await supabaseAdmin
    .from("whatsapp_settings").select("phone_number_id, access_token")
    .eq("workspace_id", workspace_id).maybeSingle();
  if (!data?.phone_number_id || !data.access_token) return null;
  return data as Settings;
}

async function sendText(s: Settings, to: string, body: string) {
  const res = await fetch(`${META_BASE}/${s.phone_number_id}/messages`, {
    method: "POST",
    headers: { Authorization: `Bearer ${s.access_token}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      messaging_product: "whatsapp",
      to: to.replace(/[^\d]/g, ""),
      type: "text",
      text: { body },
    }),
  });
  const j: any = await res.json().catch(() => ({}));
  return {
    ok: res.ok,
    wa_id: j?.messages?.[0]?.id as string | undefined,
    error: res.ok ? undefined : JSON.stringify(j).slice(0, 500),
  };
}

async function sendButtons(s: Settings, to: string, body: string, buttons: string[]) {
  const res = await fetch(`${META_BASE}/${s.phone_number_id}/messages`, {
    method: "POST",
    headers: { Authorization: `Bearer ${s.access_token}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      messaging_product: "whatsapp",
      to: to.replace(/[^\d]/g, ""),
      type: "interactive",
      interactive: {
        type: "button",
        body: { text: body },
        action: {
          buttons: buttons.slice(0, 3).map((b, i) => ({
            type: "reply",
            reply: { id: `btn_${i}`, title: b.slice(0, 20) },
          })),
        },
      },
    }),
  });
  const j: any = await res.json().catch(() => ({}));
  return { ok: res.ok, wa_id: j?.messages?.[0]?.id as string | undefined };
}

async function sendMedia(s: Settings, to: string, mediaType: string, url: string, caption?: string) {
  const t = ["image", "video", "audio", "document"].includes(mediaType) ? mediaType : "image";
  const body: any = {
    messaging_product: "whatsapp",
    to: to.replace(/[^\d]/g, ""),
    type: t,
    [t]: { link: url, ...(caption && t !== "audio" ? { caption } : {}) },
  };
  const res = await fetch(`${META_BASE}/${s.phone_number_id}/messages`, {
    method: "POST",
    headers: { Authorization: `Bearer ${s.access_token}`, "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  const j: any = await res.json().catch(() => ({}));
  return { ok: res.ok, wa_id: j?.messages?.[0]?.id as string | undefined };
}

async function sendTemplate(s: Settings, to: string, name: string, language: string) {
  const res = await fetch(`${META_BASE}/${s.phone_number_id}/messages`, {
    method: "POST",
    headers: { Authorization: `Bearer ${s.access_token}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      messaging_product: "whatsapp",
      to: to.replace(/[^\d]/g, ""),
      type: "template",
      template: { name, language: { code: language } },
    }),
  });
  const j: any = await res.json().catch(() => ({}));
  return { ok: res.ok, wa_id: j?.messages?.[0]?.id as string | undefined };
}

async function logOutbound(workspace_id: string, conversation_id: string, content: string, wa_id?: string) {
  await supabaseAdmin.from("messages").insert({
    workspace_id,
    conversation_id,
    direction: "out",
    type: "text",
    content,
    wa_message_id: wa_id,
    is_automated: true,
  });
  await supabaseAdmin.from("conversations").update({
    last_message_at: new Date().toISOString(),
    last_message_preview: content.slice(0, 140),
  }).eq("id", conversation_id);
}

function interpolate(tpl: string, vars: Record<string, any>, contact: any): string {
  return tpl.replace(/\{\{\s*([\w.]+)\s*\}\}/g, (_, k) => {
    if (k.startsWith("contact.")) return String(contact?.[k.slice(8)] ?? "");
    return String(vars[k] ?? "");
  });
}

function evalCondition(cond: any, vars: Record<string, any>, contact: any, lastReply: string): boolean {
  const field = cond.field || "last_reply";
  const op = cond.operator || "contains";
  const expected = String(cond.value ?? "").toLowerCase();
  let actual = "";
  if (field === "last_reply") actual = lastReply.toLowerCase();
  else if (field.startsWith("contact.")) actual = String(contact?.[field.slice(8)] ?? "").toLowerCase();
  else if (field.startsWith("var.")) actual = String(vars[field.slice(4)] ?? "").toLowerCase();
  if (op === "equals") return actual === expected;
  if (op === "contains") return actual.includes(expected);
  if (op === "starts_with") return actual.startsWith(expected);
  if (op === "not_empty") return actual.trim().length > 0;
  return false;
}

async function callAI(workspace_id: string, systemPrompt: string, knowledge: string, history: { role: string; content: string }[]): Promise<{ reply: string; ok: boolean; error?: string }> {
  const apiKey = process.env.LOVABLE_API_KEY;
  if (!apiKey) return { reply: "AI is not configured.", ok: false, error: "missing_lovable_api_key" };
  const model = "google/gemini-3-flash-preview";

  // Pre-check + reserve 1 credit before the request; we true-up after we know actual tokens.
  const { consumeAiCredits, creditsForTokens } = await import("@/lib/ai-credits.server");
  const pre = await consumeAiCredits({ workspace_id, amount: 1, feature: "bot_ai_reply", model, meta: { stage: "reserve" } });
  if (!pre.ok) {
    return {
      reply: "Your AI credits have been exhausted. Please recharge to continue using AI features.",
      ok: false,
      error: "ai_credits_exhausted",
    };
  }

  const sys = `${systemPrompt}\n\n${knowledge ? `Knowledge:\n${knowledge}` : ""}`.trim();
  const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
    method: "POST",
    headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      model,
      messages: [{ role: "system", content: sys }, ...history.slice(-10)],
    }),
  });
  if (!res.ok) return { reply: "Sorry, I can't reply right now.", ok: false, error: await res.text().catch(() => `status_${res.status}`) };
  const j: any = await res.json();
  const total = Number(j?.usage?.total_tokens ?? 0);
  const extra = Math.max(0, creditsForTokens(total) - 1);
  if (extra > 0) {
    await consumeAiCredits({ workspace_id, amount: extra, feature: "bot_ai_reply", model, meta: { stage: "true_up", total_tokens: total } }).catch(() => {});
  }
  return { reply: j?.choices?.[0]?.message?.content ?? "...", ok: true };
}

function normalizeTriggerText(value: string): string {
  return value
    .toLowerCase()
    .trim()
    .replace(/[^\p{L}\p{N}\s]/gu, " ")
    .replace(/([a-z])\1{1,}/g, "$1")
    .replace(/\s+/g, " ")
    .trim();
}

function triggerMatches(text: string, keyword: string, matchType?: string): boolean {
  const rawText = text.toLowerCase().trim();
  const rawKeyword = keyword.toLowerCase().trim();
  const normalizedText = normalizeTriggerText(text);
  const normalizedKeyword = normalizeTriggerText(keyword);
  if (!rawKeyword && !normalizedKeyword) return false;
  if (matchType === "exact") return rawText === rawKeyword || normalizedText === normalizedKeyword;
  if (matchType === "starts_with") return rawText.startsWith(rawKeyword) || normalizedText.startsWith(normalizedKeyword);
  return rawText.includes(rawKeyword) || normalizedText.includes(normalizedKeyword);
}

async function findTriggeredBot(workspace_id: string, text: string, is_first: boolean): Promise<string | null> {
  const { data: bots } = await supabaseAdmin
    .from("bots").select("id, triggers, priority")
    .eq("workspace_id", workspace_id).eq("enabled", true)
    .order("priority", { ascending: false });
  if (!bots?.length) return null;
  const t = (text || "").toLowerCase().trim();
  for (const b of bots as any[]) {
    for (const trig of b.triggers || []) {
      if (trig.type === "first_message" && is_first) return b.id;
      if (trig.type === "keyword" && t && trig.keywords?.length) {
        const matched = trig.keywords.some((k: string) => {
          return triggerMatches(t, k, trig.match_type);
        });
        if (matched) return b.id;
      }
    }
  }
  return null;
}

function findStartNode(nodes: Node[]): Node | null {
  return nodes.find((n) => n.type === "trigger") ?? nodes[0] ?? null;
}

function nextNodes(edges: Edge[], from: string, handle?: string): string[] {
  return edges
    .filter((e) => e.source_node_id === from && (handle ? e.source_handle === handle : true))
    .map((e) => e.target_node_id);
}

export async function runBotForMessage(params: {
  workspace_id: string;
  conversation_id: string;
  contact_phone: string;
  contact_id?: string | null;
  message_text: string | null;
  is_first_message: boolean;
  force_bot_id?: string;
}): Promise<{ handled: boolean }> {
  try {
    const settings = await getSettings(params.workspace_id);
    if (!settings) {
      await logBotDebug({
        workspace_id: params.workspace_id,
        event: "bot.skipped",
        ok: false,
        message: "Bot skipped because WhatsApp settings are missing for this workspace",
        payload: { conversation_id: params.conversation_id },
      });
      return { handled: false };
    }

    const text = (params.message_text || "").trim();

    // Look for existing active session
    const { data: existing } = await supabaseAdmin
      .from("bot_sessions").select("*")
      .eq("workspace_id", params.workspace_id)
      .eq("contact_phone", params.contact_phone)
      .eq("status", "active")
      .order("updated_at", { ascending: false })
      .limit(1);
    let session: any = existing?.[0] ?? null;

    // ----- Human-handover detection -----
    // If a teammate has explicitly been assigned, do not auto-reply. For
    // manual outbound messages, only pause an already-running bot when the
    // human reply happened after that bot session started. Older manual chat
    // history must not block fresh keyword triggers in existing conversations.
    const { data: convoRow } = await supabaseAdmin
      .from("conversations").select("assigned_to").eq("id", params.conversation_id).maybeSingle();
    const humanAssigned = !!convoRow?.assigned_to;
    let humanRepliedDuringSession = false;
    if (session) {
      const { data: humanMsg } = await supabaseAdmin
        .from("messages").select("id")
        .eq("conversation_id", params.conversation_id)
        .eq("direction", "out")
        .eq("is_automated", false)
        .gt("created_at", session.created_at)
        .limit(1);
      humanRepliedDuringSession = !!(humanMsg && humanMsg.length);
    }

    if (humanAssigned || humanRepliedDuringSession) {
      if (session) {
        await supabaseAdmin.from("bot_sessions")
          .update({ status: "paused_human" }).eq("id", session.id);
      }
      await logBotDebug({
        workspace_id: params.workspace_id,
        event: "bot.paused_human",
        ok: true,
        message: humanAssigned ? "Bot paused because the conversation is assigned to a teammate" : "Bot paused because a teammate replied during the bot session",
        payload: { conversation_id: params.conversation_id, session_id: session?.id ?? null },
      });
      return { handled: false };
    }

    if (!session) {
      const botId = params.force_bot_id || await findTriggeredBot(params.workspace_id, text, params.is_first_message);
      if (!botId) {
        await logBotDebug({
          workspace_id: params.workspace_id,
          event: "bot.no_trigger_match",
          ok: false,
          message: "No active bot trigger matched this inbound message",
          payload: { conversation_id: params.conversation_id, text: text.slice(0, 200), is_first_message: params.is_first_message },
        });
        return { handled: false };
      }
      const { data: created } = await supabaseAdmin.from("bot_sessions").insert({
        workspace_id: params.workspace_id,
        bot_id: botId,
        conversation_id: params.conversation_id,
        contact_id: params.contact_id || null,
        contact_phone: params.contact_phone,
        variables: {},
        status: "active",
      }).select().single();
      session = created;
    }

    // Load bot graph
    const { data: nodesData } = await supabaseAdmin.from("bot_nodes").select("*").eq("bot_id", session.bot_id);
    const { data: edgesData } = await supabaseAdmin.from("bot_edges").select("*").eq("bot_id", session.bot_id);
    const nodes: Node[] = nodesData || [];
    const edges: Edge[] = edgesData || [];

    let contact: any = null;
    if (session.contact_id) {
      const { data: c } = await supabaseAdmin.from("contacts").select("*").eq("id", session.contact_id).maybeSingle();
      contact = c;
    }

    let vars: Record<string, any> = session.variables || {};
    let currentNodeId: string | null = session.current_node_id;

    // If awaiting input, capture answer first
    if (session.awaiting_input && currentNodeId) {
      const askNode = nodes.find((n) => n.id === currentNodeId);
      if (askNode?.type === "ai_reply") {
        // ai_reply runs in continuous-chat mode — re-execute the same node
        // with the new inbound message so the AI replies again.
        // Keep currentNodeId pointing at the ai_reply node.
      } else if (askNode?.data?.variable) {
        vars[askNode.data.variable] = text;
        // Save to contact field if requested
        if (askNode.data.save_to_contact && contact) {
          const patch: any = {};
          if (askNode.data.save_to_contact === "name") patch.name = text;
          else if (askNode.data.save_to_contact === "email") patch.email = text;
          else patch.custom_fields = { ...(contact.custom_fields || {}), [askNode.data.save_to_contact]: text };
          await supabaseAdmin.from("contacts").update(patch).eq("id", contact.id);
        }
        const nxt = nextNodes(edges, currentNodeId);
        currentNodeId = nxt[0] ?? null;
      } else {
        const nxt = nextNodes(edges, currentNodeId);
        currentNodeId = nxt[0] ?? null;
      }
    } else if (!currentNodeId) {
      const start = findStartNode(nodes);
      currentNodeId = start ? nextNodes(edges, start.id)[0] ?? null : null;
    }

    // Execute until pause or end
    let steps = 0;
    const lastReply = text;
    while (currentNodeId && steps < 50) {
      steps++;
      const node = nodes.find((n) => n.id === currentNodeId);
      if (!node) break;

      await supabaseAdmin.from("bot_runs").insert({
        workspace_id: params.workspace_id,
        bot_id: session.bot_id,
        session_id: session.id,
        node_id: node.id,
        node_type: node.type,
        event: "executed",
        detail: {},
      });

      if (node.type === "send_message") {
        const body = interpolate(String(node.data?.text ?? ""), vars, contact);
        if (body) {
          const r = await sendText(settings, params.contact_phone, body);
          if (r.ok) await logOutbound(params.workspace_id, params.conversation_id, body, r.wa_id);
        }
        currentNodeId = nextNodes(edges, node.id)[0] ?? null;
      } else if (node.type === "send_buttons") {
        const body = interpolate(String(node.data?.text ?? ""), vars, contact);
        const buttons = (node.data?.buttons || []).filter(Boolean);
        if (body && buttons.length) {
          const r = await sendButtons(settings, params.contact_phone, body, buttons);
          if (r.ok) await logOutbound(params.workspace_id, params.conversation_id, body, r.wa_id);
        }
        currentNodeId = nextNodes(edges, node.id)[0] ?? null;
      } else if (node.type === "send_media") {
        const url = String(node.data?.url ?? "");
        const mt = String(node.data?.media_type ?? "image");
        const caption = node.data?.caption ? interpolate(String(node.data.caption), vars, contact) : undefined;
        if (url) {
          const r = await sendMedia(settings, params.contact_phone, mt, url, caption);
          if (r.ok) await logOutbound(params.workspace_id, params.conversation_id, caption || `[${mt}]`, r.wa_id);
        }
        currentNodeId = nextNodes(edges, node.id)[0] ?? null;
      } else if (node.type === "send_template") {
        if (node.data?.template_id) {
          const { data: tpl } = await supabaseAdmin
            .from("templates").select("meta_template_name, language")
            .eq("id", node.data.template_id).maybeSingle();
          if (tpl) {
            const r = await sendTemplate(settings, params.contact_phone, tpl.meta_template_name, tpl.language);
            if (r.ok) await logOutbound(params.workspace_id, params.conversation_id, `[template:${tpl.meta_template_name}]`, r.wa_id);
          }
        }
        currentNodeId = nextNodes(edges, node.id)[0] ?? null;
      } else if (node.type === "ask") {
        const prompt = interpolate(String(node.data?.text ?? ""), vars, contact);
        if (prompt) {
          const r = await sendText(settings, params.contact_phone, prompt);
          if (r.ok) await logOutbound(params.workspace_id, params.conversation_id, prompt, r.wa_id);
        }
        // pause for input
        await supabaseAdmin.from("bot_sessions").update({
          current_node_id: node.id,
          awaiting_input: true,
          variables: vars,
        }).eq("id", session.id);
        return { handled: true };
      } else if (node.type === "ai_reply") {
        // Pull recent convo for context
        const { data: msgs } = await supabaseAdmin.from("messages")
          .select("direction, content")
          .eq("conversation_id", params.conversation_id)
          .order("created_at", { ascending: false }).limit(20);
        const history = (msgs || []).reverse().map((m: any) => ({
          role: m.direction === "in" ? "user" : "assistant",
          content: m.content || "",
        }));
        const aiResult = await callAI(
          params.workspace_id,
          String(node.data?.system_prompt ?? "You are a helpful assistant."),
          String(node.data?.knowledge ?? ""),
          history,
        );
        if (!aiResult.ok) {
          await logBotDebug({
            workspace_id: params.workspace_id,
            event: "bot.ai_error",
            ok: false,
            message: "AI reply generation failed",
            payload: { bot_id: session.bot_id, node_id: node.id, error: aiResult.error?.slice(0, 500) },
          });
        }
        const r = await sendText(settings, params.contact_phone, aiResult.reply);
        if (r.ok) await logOutbound(params.workspace_id, params.conversation_id, aiResult.reply, r.wa_id);
        else {
          await logBotDebug({
            workspace_id: params.workspace_id,
            event: "bot.send_error",
            ok: false,
            message: "AI reply was generated but WhatsApp delivery failed",
            payload: { bot_id: session.bot_id, node_id: node.id, error: r.error },
          });
        }
        const nxt = nextNodes(edges, node.id)[0] ?? null;
        if (!nxt) {
          // Terminal ai_reply → stay on this node and wait for the next inbound
          // message so the AI keeps the conversation going until a human takes over.
          await supabaseAdmin.from("bot_sessions").update({
            current_node_id: node.id,
            awaiting_input: true,
            variables: vars,
          }).eq("id", session.id);
          return { handled: true };
        }
        currentNodeId = nxt;
      } else if (node.type === "condition") {
        const passed = evalCondition(node.data || {}, vars, contact, lastReply);
        currentNodeId = nextNodes(edges, node.id, passed ? "true" : "false")[0] ?? null;
      } else if (node.type === "delay") {
        const seconds = Number(node.data?.seconds ?? 0);
        if (seconds > 0) {
          await supabaseAdmin.from("bot_sessions").update({
            current_node_id: node.id,
            awaiting_input: false,
            variables: vars,
            resume_at: new Date(Date.now() + seconds * 1000).toISOString(),
          }).eq("id", session.id);
          return { handled: true };
        }
        currentNodeId = nextNodes(edges, node.id)[0] ?? null;
      } else if (node.type === "assign") {
        if (node.data?.user_id) {
          await supabaseAdmin.from("conversations")
            .update({ assigned_to: node.data.user_id })
            .eq("id", params.conversation_id);
        }
        currentNodeId = nextNodes(edges, node.id)[0] ?? null;
      } else if (node.type === "tag") {
        if (contact && node.data?.tag) {
          const tags = Array.from(new Set([...(contact.tags || []), node.data.tag]));
          await supabaseAdmin.from("contacts").update({ tags }).eq("id", contact.id);
        }
        currentNodeId = nextNodes(edges, node.id)[0] ?? null;
      } else if (node.type === "update_field") {
        if (contact && node.data?.field && node.data?.value !== undefined) {
          const val = interpolate(String(node.data.value), vars, contact);
          const patch: any = {};
          if (["name", "email", "city", "lead_stage", "lead_source"].includes(node.data.field)) {
            patch[node.data.field] = val;
          } else {
            patch.custom_fields = { ...(contact.custom_fields || {}), [node.data.field]: val };
          }
          await supabaseAdmin.from("contacts").update(patch).eq("id", contact.id);
        }
        currentNodeId = nextNodes(edges, node.id)[0] ?? null;
      } else if (node.type === "end") {
        await supabaseAdmin.from("bot_sessions").update({
          status: "completed",
          current_node_id: node.id,
          awaiting_input: false,
          variables: vars,
        }).eq("id", session.id);
        return { handled: true };
      } else {
        // trigger / unknown — just advance
        currentNodeId = nextNodes(edges, node.id)[0] ?? null;
      }
    }

    if (!currentNodeId) {
      await supabaseAdmin.from("bot_sessions").update({
        status: "completed",
        awaiting_input: false,
        variables: vars,
      }).eq("id", session.id);
    } else {
      await supabaseAdmin.from("bot_sessions").update({
        current_node_id: currentNodeId,
        variables: vars,
      }).eq("id", session.id);
    }
    return { handled: true };
  } catch (e) {
    console.error("bot runner error", e);
    return { handled: false };
  }
}
