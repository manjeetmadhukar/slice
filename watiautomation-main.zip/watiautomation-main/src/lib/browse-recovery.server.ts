import { z } from "zod";

export async function assertBrowseAdmin(supabase: any, workspaceId: string, userId: string) {
  const { data } = await supabase
    .from("workspace_members")
    .select("role")
    .eq("workspace_id", workspaceId)
    .eq("user_id", userId)
    .maybeSingle();
  const role = (data as any)?.role;
  if (!role || !["owner", "admin"].includes(role)) throw new Error("Admin permission required");
}

export async function assertBrowseMember(supabase: any, workspaceId: string, userId: string) {
  const { data } = await supabase
    .from("workspace_members")
    .select("role")
    .eq("workspace_id", workspaceId)
    .eq("user_id", userId)
    .maybeSingle();
  if (!data) throw new Error("Not a member of this workspace");
}

export const browseWorkspaceSchema = z.object({ workspace_id: z.string().uuid() });

export const browseSettingsSchema = z.object({
  workspace_id: z.string().uuid(),
  enabled: z.boolean(),
  delay_minutes: z.number().int().min(1).max(1440 * 7),
  template_id: z.string().uuid().nullable().optional(),
  template_language: z.string().max(20).nullable().optional(),
  frequency_cap_hours: z.number().int().min(0).max(24 * 30).default(24),
  product_include: z.array(z.string().max(200)).max(500).default([]),
  product_exclude: z.array(z.string().max(200)).max(500).default([]),
  category_include: z.array(z.string().max(200)).max(500).default([]),
  min_price_minor: z.number().int().min(0).nullable().optional(),
});

export const browseTokenSchema = z.object({
  workspace_id: z.string().uuid(),
  label: z.string().max(120).optional(),
});

export const browseRevokeTokenSchema = z.object({
  workspace_id: z.string().uuid(),
  id: z.string().uuid(),
});

export const browseAnalyticsSchema = z.object({
  workspace_id: z.string().uuid(),
  days: z.number().int().min(1).max(365).default(30),
});

export const browseEventsSchema = z.object({
  workspace_id: z.string().uuid(),
  limit: z.number().int().min(1).max(200).default(50),
});