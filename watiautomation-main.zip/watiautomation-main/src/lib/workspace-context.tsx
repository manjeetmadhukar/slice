import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

const STORAGE_KEY = "wati:current_workspace";

export type Role = "owner" | "admin" | "agent" | "viewer";

export interface WorkspaceMembership {
  workspace_id: string;
  role: Role;
  workspaces: { id: string; name: string; slug: string; owner_id: string; allow_team_user_creation?: boolean };
}

interface Ctx {
  memberships: WorkspaceMembership[];
  current: WorkspaceMembership | null;
  currentWorkspaceId: string | null;
  role: Role | null;
  setCurrent: (workspaceId: string) => void;
  isLoading: boolean;
  refetch: () => void;
}

const WorkspaceCtx = createContext<Ctx | null>(null);

export function WorkspaceProvider({ children }: { children: ReactNode }) {
  const qc = useQueryClient();
  const [currentId, setCurrentId] = useState<string | null>(() => {
    if (typeof window === "undefined") return null;
    return localStorage.getItem(STORAGE_KEY);
  });

  const { data: memberships = [], isLoading, refetch } = useQuery({
    queryKey: ["workspace-memberships"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("workspace_members")
        .select("workspace_id, role, is_active, workspaces(id, name, slug, owner_id, allow_team_user_creation)")
        .order("created_at", { ascending: true });
      if (error) throw error;
      const rows = (data ?? []) as any[];
      // Hide deactivated memberships from the switcher entirely
      return rows.filter((r) => r.is_active !== false) as unknown as WorkspaceMembership[];
    },
  });


  // Pick a valid current workspace
  useEffect(() => {
    if (!memberships.length) return;
    const exists = currentId && memberships.find((m) => m.workspace_id === currentId);
    if (!exists) {
      const first = memberships[0].workspace_id;
      setCurrentId(first);
      localStorage.setItem(STORAGE_KEY, first);
    }
  }, [memberships, currentId]);

  function setCurrent(id: string) {
    setCurrentId(id);
    localStorage.setItem(STORAGE_KEY, id);
    // Invalidate workspace-scoped queries so they refetch with the new id.
    qc.invalidateQueries();
  }

  const current = useMemo(
    () => memberships.find((m) => m.workspace_id === currentId) ?? null,
    [memberships, currentId],
  );

  return (
    <WorkspaceCtx.Provider
      value={{
        memberships,
        current,
        currentWorkspaceId: current?.workspace_id ?? null,
        role: current?.role ?? null,
        setCurrent,
        isLoading,
        refetch,
      }}
    >
      {children}
    </WorkspaceCtx.Provider>
  );
}

export function useWorkspace() {
  const ctx = useContext(WorkspaceCtx);
  if (!ctx) throw new Error("useWorkspace must be used within WorkspaceProvider");
  return ctx;
}

export function canManageWorkspace(role: Role | null) {
  return role === "owner" || role === "admin";
}

export function canSendCampaigns(role: Role | null) {
  return role === "owner" || role === "admin" || role === "agent";
}
