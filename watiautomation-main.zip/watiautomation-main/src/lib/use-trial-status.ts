import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useWorkspace } from "@/lib/workspace-context";

export interface TrialStatus {
  trialStartedAt: Date | null;
  trialEndsAt: Date | null;
  daysLeft: number;
  hoursLeft: number;
  isExpired: boolean;
  hasPaidPlan: boolean;
  planExpiresAt: Date | null;
  planExpired: boolean;
  planName: string | null;
  /** True when the user has no active paid plan and access should be blocked. */
  isLocked: boolean;
  isLoading: boolean;
}

export function useTrialStatus(): TrialStatus {
  const { currentWorkspaceId } = useWorkspace();

  const profileQ = useQuery({
    queryKey: ["my-trial-profile"],
    queryFn: async () => {
      const { data: u } = await supabase.auth.getUser();
      if (!u.user) return null;
      const { data } = await supabase
        .from("profiles")
        .select("trial_started_at, trial_ends_at")
        .eq("id", u.user.id)
        .maybeSingle();
      return data;
    },
    staleTime: 60_000,
  });

  const planQ = useQuery({
    queryKey: ["my-trial-plan", currentWorkspaceId],
    enabled: !!currentWorkspaceId,
    queryFn: async () => {
      const { data } = await supabase
        .from("workspace_plans")
        .select("plan_name, expires_at")
        .eq("workspace_id", currentWorkspaceId!)
        .maybeSingle();
      return data;
    },
    staleTime: 60_000,
  });

  const trialEndsAt = profileQ.data?.trial_ends_at ? new Date(profileQ.data.trial_ends_at) : null;
  const trialStartedAt = profileQ.data?.trial_started_at ? new Date(profileQ.data.trial_started_at) : null;
  const msLeft = trialEndsAt ? trialEndsAt.getTime() - Date.now() : 0;
  const daysLeft = trialEndsAt ? Math.ceil(msLeft / 86_400_000) : 0;
  const hoursLeft = trialEndsAt ? Math.max(0, Math.ceil(msLeft / 3_600_000)) : 0;
  const isExpired = !!trialEndsAt && msLeft <= 0;
  const planExpiresAt = planQ.data?.expires_at ? new Date(planQ.data.expires_at) : null;
  const planExpired = !!planExpiresAt && planExpiresAt.getTime() <= Date.now();
  const hasPaidPlan = !!planQ.data?.plan_name && !planExpired;

  return {
    trialStartedAt,
    trialEndsAt,
    daysLeft,
    hoursLeft,
    isExpired,
    hasPaidPlan,
    planExpiresAt,
    planExpired,
    planName: planQ.data?.plan_name ?? null,
    isLocked: (isExpired || planExpired) && !hasPaidPlan,
    isLoading: profileQ.isLoading || planQ.isLoading,
  };
}

export function formatTrialExpiry(date: Date | null): string {
  if (!date) return "—";
  return date.toLocaleString(undefined, {
    dateStyle: "medium",
    timeStyle: "short",
  });
}
