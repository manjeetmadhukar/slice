// Abandoned-cart reminder delivery reconciliation.
//
// The Cloud API accepts a template with HTTP 200 (status "sent"), but Meta can
// still refuse to deliver it afterwards — most commonly #131049 ("healthy
// ecosystem engagement" marketing cap) or #130472 (marketing experiment).
// That failure only arrives later, on the `statuses` webhook.
//
// Before this, the cart had already been stamped `last_reminder_at`, so it left
// the queue forever and the shopper never got a reminder even though nothing in
// Slice had actually failed. This module re-opens such carts so the dispatcher
// can try again after a cool-down, and records the exact Meta reason in the
// Debug Center.
import { supabaseAdmin } from "@/integrations/supabase/client.server";
import type { WhatsAppErrorClassification } from "./whatsapp-delivery-status";

const MAX_REMINDER_ATTEMPTS = 3;

// Meta-side suppression needs a long cool-down (per-user marketing cap resets
// on a ~24h window). Ordinary transient failures can be retried much sooner.
const SUPPRESSED_RETRY_MS = 24 * 60 * 60 * 1000;
const RETRYABLE_RETRY_MS = 15 * 60 * 1000;

function digitsOf(v: unknown): string {
  return String(v ?? "").replace(/[^\d]/g, "");
}

/**
 * Called when Meta reports a `failed` status for an outbound message.
 * If the message was an abandoned-cart reminder, re-queue the cart.
 * Never throws — delivery-status processing must not break on this.
 */
export async function reconcileCartReminderFailure(args: {
  workspaceId: string;
  waMessageId: string;
  recipientId?: string | null;
  classification: WhatsAppErrorClassification;
}): Promise<void> {
  try {
    const phoneDigits = digitsOf(args.recipientId);
    if (!args.workspaceId || !phoneDigits) return;

    // Reminder was dispatched moments ago; bound the lookup so we never touch
    // an unrelated older cart for the same shopper.
    const sinceIso = new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString();
    const { data: carts } = await supabaseAdmin
      .from("abandoned_carts")
      .select("id, integration_id, cart_token, customer_phone, reminders_sent, last_reminder_at, status")
      .eq("workspace_id", args.workspaceId)
      .eq("status", "abandoned")
      .not("last_reminder_at", "is", null)
      .gte("last_reminder_at", sinceIso)
      .order("last_reminder_at", { ascending: false })
      .limit(50);

    const cart = (carts ?? []).find((c: any) => {
      const d = digitsOf(c.customer_phone);
      return d && (d === phoneDigits || d.endsWith(phoneDigits) || phoneDigits.endsWith(d));
    }) as any;
    if (!cart) return;

    const attempts = Number(cart.reminders_sent || 0);
    const cls = args.classification;
    const canRetry =
      attempts < MAX_REMINDER_ATTEMPTS && (cls.status === "suppressed" || cls.retryable);
    const retryInMs = cls.status === "suppressed" ? SUPPRESSED_RETRY_MS : RETRYABLE_RETRY_MS;

    if (canRetry) {
      await supabaseAdmin
        .from("abandoned_carts")
        .update({
          last_reminder_at: null,
          send_scheduled_at: new Date(Date.now() + retryInMs).toISOString(),
        } as any)
        .eq("id", cart.id);

      // Release the duplicate-send guard, otherwise the dispatcher would treat
      // the cart as "already sent" and immediately re-stamp it.
      await supabaseAdmin
        .from("ecom_automation_runs")
        .delete()
        .eq("workspace_id", args.workspaceId)
        .eq("automation_key", "abandoned_cart")
        .eq("target_type", "cart")
        .eq("target_id", String(cart.cart_token || cart.id));
    }

    await supabaseAdmin.from("integration_debug_logs").insert({
      workspace_id: args.workspaceId,
      integration_id: cart.integration_id ?? null,
      direction: "in",
      event: "wa.cart_abandoned.not_delivered",
      ok: false,
      message: canRetry
        ? `${cls.error} — reminder re-queued for ${Math.round(retryInMs / 60000)} min from now (attempt ${attempts + 1}/${MAX_REMINDER_ATTEMPTS}).`
        : `${cls.error} — no further automatic retries for this cart (attempt ${attempts}/${MAX_REMINDER_ATTEMPTS}).`,
      payload: {
        cart_id: cart.id,
        cart_token: cart.cart_token,
        wa_message_id: args.waMessageId,
        recipient: args.recipientId ?? null,
        meta_code: cls.code ?? null,
        retry_scheduled: canRetry,
      } as any,
    } as any);
  } catch (e) {
    console.error("[cart-reminder-status] reconcile failed", e);
  }
}
