import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

async function assertAdmin(supabase: any, workspaceId: string, userId: string) {
  const { data, error } = await supabase
    .from("workspace_members")
    .select("role")
    .eq("workspace_id", workspaceId)
    .eq("user_id", userId)
    .maybeSingle();
  if (error || !data) throw new Error("Not a member of this workspace");
  if (data.role !== "owner" && data.role !== "admin") {
    throw new Error("Only owners and admins can do this");
  }
  return data.role as "owner" | "admin";
}

async function assertWorkspaceMember(supabase: any, workspaceId: string, userId: string) {
  const { data, error } = await supabase
    .from("workspace_members")
    .select("role")
    .eq("workspace_id", workspaceId)
    .eq("user_id", userId)
    .maybeSingle();
  if (error || !data) throw new Error("Not a member of this workspace");
  return data.role as "owner" | "admin" | "agent" | "viewer";
}

const permSchema = z.object({
  module: z.string().min(1).max(50),
  can_view: z.boolean(),
  can_create: z.boolean(),
  can_edit: z.boolean(),
  can_delete: z.boolean(),
});

export const createTeamUser = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z.object({
      workspace_id: z.string().uuid(),
      full_name: z.string().trim().min(1).max(100),
      email: z.string().trim().toLowerCase().email().max(255),
      username: z.string().trim().min(3).max(50).regex(/^[a-zA-Z0-9_.-]+$/),
      password: z.string().min(8).max(72),
      role: z.enum(["admin", "agent", "viewer"]),
      permissions: z.array(permSchema).max(50),
    }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    await assertAdmin(supabase, data.workspace_id, userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    // Gate: Super Admin must enable team-user creation for this workspace.
    const { data: ws, error: wsErr } = await supabaseAdmin
      .from("workspaces")
      .select("allow_team_user_creation")
      .eq("id", data.workspace_id)
      .maybeSingle();
    if (wsErr) throw new Error(wsErr.message);
    if (!ws?.allow_team_user_creation) {
      throw new Error("Adding team users is disabled for this workspace. Please contact support to enable it.");
    }


    // Check username uniqueness
    const { data: existingUsername } = await supabaseAdmin
      .from("profiles")
      .select("id")
      .eq("username", data.username)
      .maybeSingle();
    if (existingUsername) throw new Error("Username already taken");

    // Try to find existing auth user by email
    let newUserId: string | null = null;
    const { data: list } = await supabaseAdmin.auth.admin.listUsers({ page: 1, perPage: 200 });
    const existing = list?.users?.find((u: any) => u.email?.toLowerCase() === data.email);
    if (existing) {
      newUserId = existing.id;
      // Reset password to admin-provided one
      await supabaseAdmin.auth.admin.updateUserById(existing.id, { password: data.password });
    } else {
      const { data: created, error: createErr } = await supabaseAdmin.auth.admin.createUser({
        email: data.email,
        password: data.password,
        email_confirm: true,
        user_metadata: { full_name: data.full_name },
      });
      if (createErr || !created.user) throw new Error(createErr?.message || "Failed to create user");
      newUserId = created.user.id;
    }

    // Upsert profile with username
    const { error: profileErr } = await supabaseAdmin
      .from("profiles")
      .upsert(
        {
          id: newUserId!,
          email: data.email,
          full_name: data.full_name,
          username: data.username,
          created_by_admin: true,
        },
        { onConflict: "id" },
      );
    if (profileErr) throw new Error(profileErr.message);

    // Add to workspace
    const { error: memberErr } = await supabaseAdmin
      .from("workspace_members")
      .upsert(
        { workspace_id: data.workspace_id, user_id: newUserId!, role: data.role, is_active: true },
        { onConflict: "workspace_id,user_id" },
      );
    if (memberErr) throw new Error(memberErr.message);

    // Replace permissions
    await supabaseAdmin
      .from("member_permissions")
      .delete()
      .eq("workspace_id", data.workspace_id)
      .eq("user_id", newUserId!);

    if (data.permissions.length) {
      const rows = data.permissions.map((p) => ({
        workspace_id: data.workspace_id,
        user_id: newUserId!,
        ...p,
      }));
      const { error: permErr } = await supabaseAdmin.from("member_permissions").insert(rows);
      if (permErr) throw new Error(permErr.message);
    }

    return { ok: true, user_id: newUserId };
  });

export const listWorkspaceMembers = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) => z.object({ workspace_id: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    await assertWorkspaceMember(context.supabase, data.workspace_id, context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const { data: members, error: membersErr } = await supabaseAdmin
      .from("workspace_members")
      .select("workspace_id, user_id, role, is_active, created_at")
      .eq("workspace_id", data.workspace_id)
      .order("created_at", { ascending: true });
    if (membersErr) throw new Error(membersErr.message);

    const userIds = [...new Set((members ?? []).map((m) => m.user_id).filter(Boolean))];
    const profilesById = new Map<string, { email: string | null; full_name: string | null; username: string | null }>();

    if (userIds.length) {
      const { data: profiles, error: profilesErr } = await supabaseAdmin
        .from("profiles")
        .select("id, email, full_name, username")
        .in("id", userIds);
      if (profilesErr) throw new Error(profilesErr.message);
      for (const profile of profiles ?? []) {
        profilesById.set(profile.id, {
          email: profile.email ?? null,
          full_name: profile.full_name ?? null,
          username: profile.username ?? null,
        });
      }
    }

    return {
      members: (members ?? []).map((member) => ({
        workspace_id: member.workspace_id,
        user_id: member.user_id,
        role: member.role,
        is_active: member.is_active,
        profiles: profilesById.get(member.user_id) ?? {
          email: null,
          full_name: "Team member",
          username: null,
        },
      })),
    };
  });

export const updateUserPermissions = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z.object({
      workspace_id: z.string().uuid(),
      user_id: z.string().uuid(),
      permissions: z.array(permSchema).max(50),
    }).parse(input),
  )
  .handler(async ({ data, context }) => {
    await assertAdmin(context.supabase, data.workspace_id, context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    await supabaseAdmin
      .from("member_permissions")
      .delete()
      .eq("workspace_id", data.workspace_id)
      .eq("user_id", data.user_id);
    if (data.permissions.length) {
      const rows = data.permissions.map((p) => ({
        workspace_id: data.workspace_id,
        user_id: data.user_id,
        ...p,
      }));
      const { error } = await supabaseAdmin.from("member_permissions").insert(rows);
      if (error) throw new Error(error.message);
    }
    return { ok: true };
  });

export const resetUserPassword = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z.object({
      workspace_id: z.string().uuid(),
      user_id: z.string().uuid(),
      password: z.string().min(8).max(72),
    }).parse(input),
  )
  .handler(async ({ data, context }) => {
    await assertAdmin(context.supabase, data.workspace_id, context.userId);
    // Confirm target is in this workspace
    const { data: m } = await context.supabase
      .from("workspace_members")
      .select("user_id, role")
      .eq("workspace_id", data.workspace_id)
      .eq("user_id", data.user_id)
      .maybeSingle();
    if (!m) throw new Error("User is not part of this workspace");
    if (m.role === "owner") throw new Error("Cannot reset the owner's password");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin.auth.admin.updateUserById(data.user_id, {
      password: data.password,
    });
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const setUserActive = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z.object({
      workspace_id: z.string().uuid(),
      user_id: z.string().uuid(),
      is_active: z.boolean(),
    }).parse(input),
  )
  .handler(async ({ data, context }) => {
    await assertAdmin(context.supabase, data.workspace_id, context.userId);
    const { data: m } = await context.supabase
      .from("workspace_members")
      .select("role")
      .eq("workspace_id", data.workspace_id)
      .eq("user_id", data.user_id)
      .maybeSingle();
    if (m?.role === "owner") throw new Error("Cannot deactivate the owner");
    const { error } = await context.supabase
      .from("workspace_members")
      .update({ is_active: data.is_active })
      .eq("workspace_id", data.workspace_id)
      .eq("user_id", data.user_id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const getMemberPermissions = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z.object({ workspace_id: z.string().uuid(), user_id: z.string().uuid() }).parse(input),
  )
  .handler(async ({ data, context }) => {
    await assertAdmin(context.supabase, data.workspace_id, context.userId);
    const { data: rows, error } = await context.supabase
      .from("member_permissions")
      .select("module, can_view, can_create, can_edit, can_delete")
      .eq("workspace_id", data.workspace_id)
      .eq("user_id", data.user_id);
    if (error) throw new Error(error.message);
    return { permissions: rows ?? [] };
  });
