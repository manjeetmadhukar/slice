import { supabaseAdmin } from "@/integrations/supabase/client.server";

/**
 * Deduct AI credits from a workspace atomically and log the usage.
 * Returns { ok, balanceAfter }. When ok=false the caller must not
 * proceed with the AI request.
 */
export async function consumeAiCredits(params: {
  workspace_id: string;
  amount: number;
  feature: string;
  model?: string | null;
  meta?: Record<string, unknown>;
}): Promise<{ ok: boolean; balanceAfter: number }> {
  const amount = Math.max(1, Math.floor(params.amount || 1));
  const { data, error } = await supabaseAdmin.rpc("consume_ai_credits", {
    _workspace_id: params.workspace_id,
    _amount: amount,
    _feature: params.feature,
    _model: params.model ?? "",
    _meta: (params.meta ?? {}) as any,
  });
  if (error) {
    console.error("[ai-credits] consume error", error);
    return { ok: false, balanceAfter: 0 };
  }
  const row = Array.isArray(data) ? data[0] : data;
  return {
    ok: !!row?.ok,
    balanceAfter: Number(row?.balance_after ?? 0),
  };
}

/** Rough token→credit conversion (1 credit per ~1k tokens, min 1). */
export function creditsForTokens(totalTokens?: number | null): number {
  const t = Number(totalTokens || 0);
  return Math.max(1, Math.ceil(t / 1000));
}
