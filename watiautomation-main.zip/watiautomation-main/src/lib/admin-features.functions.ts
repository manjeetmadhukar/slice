import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

async function assertSuperAdmin(supabase: any, userId: string) {
  const { data, error } = await supabase
    .from("profiles")
    .select("is_super_admin")
    .eq("id", userId)
    .maybeSingle();
  if (error) throw new Error(error.message);
  if (!data?.is_super_admin) throw new Error("Forbidden: super admin only");
}

// ============ Master features (library) ============

export const adminListMasterFeatures = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase, userId } = context;
    await assertSuperAdmin(supabase, userId);
    const { data, error } = await supabase
      .from("master_features")
      .select("*")
      .order("position", { ascending: true });
    if (error) throw new Error(error.message);
    return { features: data ?? [] };
  });

const FeatureInput = z.object({
  name: z.string().trim().min(1).max(120),
  description: z.string().max(500).nullable().optional(),
  category: z.string().trim().min(1).max(80),
  icon: z.string().max(80).nullable().optional(),
  position: z.number().int().min(0).max(100000).default(0),
  is_active: z.boolean().default(true),
});

export const adminCreateMasterFeature = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) => FeatureInput.parse(input))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    await assertSuperAdmin(supabase, userId);
    const { data: row, error } = await supabase
      .from("master_features")
      .insert({ ...data, description: data.description ?? null, icon: data.icon ?? null })
      .select("*")
      .single();
    if (error) throw new Error(error.message);
    return { feature: row };
  });

export const adminUpdateMasterFeature = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) => FeatureInput.extend({ id: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    await assertSuperAdmin(supabase, userId);
    const { id, ...rest } = data;
    const { error } = await supabase
      .from("master_features")
      .update({ ...rest, description: rest.description ?? null, icon: rest.icon ?? null })
      .eq("id", id);
    if (error) throw new Error(error.message);
    return { ok: true as const };
  });

export const adminDeleteMasterFeature = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    await assertSuperAdmin(supabase, userId);
    const { error } = await supabase.from("master_features").delete().eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true as const };
  });

export const adminReorderMasterFeatures = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z.object({
      order: z.array(z.object({ id: z.string().uuid(), position: z.number().int().min(0) })).max(1000),
    }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    await assertSuperAdmin(supabase, userId);
    // Update positions one by one (small list)
    for (const row of data.order) {
      await supabase.from("master_features").update({ position: row.position }).eq("id", row.id);
    }
    return { ok: true as const };
  });

// ============ Plan template features (junction) ============

export const adminGetPlanFeatures = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) => z.object({ template_id: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    await assertSuperAdmin(supabase, userId);
    const { data: rows, error } = await supabase
      .from("plan_template_features")
      .select("*")
      .eq("template_id", data.template_id);
    if (error) throw new Error(error.message);
    return { rows: rows ?? [] };
  });

export const adminSetPlanFeatures = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z.object({
      template_id: z.string().uuid(),
      features: z.array(
        z.object({
          feature_id: z.string().uuid(),
          included: z.boolean(),
          custom_value: z.string().max(80).nullable().optional(),
        }),
      ).max(500),
    }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    await assertSuperAdmin(supabase, userId);
    // Replace strategy: delete all then insert
    const { error: delErr } = await supabase
      .from("plan_template_features")
      .delete()
      .eq("template_id", data.template_id);
    if (delErr) throw new Error(delErr.message);
    if (data.features.length > 0) {
      const rows = data.features.map((f) => ({
        template_id: data.template_id,
        feature_id: f.feature_id,
        included: f.included,
        custom_value: f.custom_value ?? null,
      }));
      const { error: insErr } = await supabase.from("plan_template_features").insert(rows);
      if (insErr) throw new Error(insErr.message);
    }
    return { ok: true as const };
  });

// ============ Plan template position / popular ============

export const adminUpdatePlanMeta = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z.object({
      id: z.string().uuid(),
      is_popular: z.boolean().optional(),
      badge_text: z.string().max(40).nullable().optional(),
      position: z.number().int().min(0).max(100000).optional(),
    }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    await assertSuperAdmin(supabase, userId);
    const { id, ...rest } = data;
    const patch: any = {};
    if (rest.is_popular !== undefined) patch.is_popular = rest.is_popular;
    if (rest.badge_text !== undefined) patch.badge_text = rest.badge_text ?? null;
    if (rest.position !== undefined) patch.position = rest.position;
    const { error } = await supabase.from("plan_templates").update(patch).eq("id", id);
    if (error) throw new Error(error.message);
    return { ok: true as const };
  });

export const adminReorderPlans = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z.object({
      order: z.array(z.object({ id: z.string().uuid(), position: z.number().int().min(0) })).max(100),
    }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    await assertSuperAdmin(supabase, userId);
    for (const row of data.order) {
      await supabase.from("plan_templates").update({ position: row.position }).eq("id", row.id);
    }
    return { ok: true as const };
  });
