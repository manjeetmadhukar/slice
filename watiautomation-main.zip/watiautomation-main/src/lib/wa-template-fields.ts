// Single source of truth for WhatsApp template variable mapping.
//
// Each entry is a predefined field a user can pick from a dropdown when
// creating a template. The `fieldKey` ties the choice to the runtime context
// bag in `wa-template-vars.server.ts` so {{N}} is ALWAYS resolved from the
// same data source — no keyword guessing, no positional drift.
//
// `static_text` is a special escape hatch: the literal value the user typed
// (e.g. brand tagline) is sent verbatim every time.

export type TemplateFieldKey =
  | "customer_name"
  | "customer_phone"
  | "customer_email"
  | "order_id"
  | "order_amount"
  | "order_status"
  | "order_date"
  | "product_name"
  | "product_price"
  | "tracking_id"
  | "tracking_url"
  | "store_name"
  | "recovery_url"
  | "static_text";

export type TemplateField = {
  key: TemplateFieldKey;
  label: string;
  group: "Customer" | "Order" | "Product" | "Shipping" | "Store" | "Other";
  sample: string;            // realistic example sent to Meta for approval
  description?: string;
};

export const TEMPLATE_FIELDS: TemplateField[] = [
  { key: "customer_name",  label: "Customer Name",   group: "Customer", sample: "Priya Sharma" },
  { key: "customer_phone", label: "Customer Phone",  group: "Customer", sample: "+91 98765 43210" },
  { key: "customer_email", label: "Customer Email",  group: "Customer", sample: "priya@example.com" },
  { key: "order_id",       label: "Order ID",        group: "Order",    sample: "#10245" },
  { key: "order_amount",   label: "Order Amount",    group: "Order",    sample: "₹1,499.00" },
  { key: "order_status",   label: "Order Status",    group: "Order",    sample: "Shipped" },
  { key: "order_date",     label: "Order Date",      group: "Order",    sample: "12 Jun 2026" },
  { key: "product_name",   label: "Product Name",    group: "Product",  sample: "Floral Maxi Dress" },
  { key: "product_price",  label: "Product Price",   group: "Product",  sample: "₹999.00" },
  { key: "tracking_id",    label: "Tracking ID",     group: "Shipping", sample: "AWB1234567890" },
  { key: "tracking_url",   label: "Tracking URL",    group: "Shipping", sample: "https://track.example.com/AWB123" },
  { key: "store_name",     label: "Store Name",      group: "Store",    sample: "Gulabik" },
  { key: "recovery_url",   label: "Recovery / CTA Link", group: "Other", sample: "https://shop.example.com/cart" },
  { key: "static_text",    label: "Custom static text", group: "Other", sample: "", description: "Same value sent to every customer." },
];

// Maps a UI field key to the runtime FieldKey understood by
// resolveTemplateParams in wa-template-vars.server.ts.
export const FIELD_TO_CTX: Record<TemplateFieldKey, string | null> = {
  customer_name:  "name",
  customer_phone: "customerPhone",
  customer_email: "customerEmail",
  order_id:       "orderNumber",
  order_amount:   "amount",
  order_status:   "orderStatus",
  order_date:     "orderDate",
  product_name:   "productName",
  product_price:  "productPrice",
  tracking_id:    "trackingId",
  tracking_url:   "trackingUrl",
  store_name:     "storeName",
  recovery_url:   "url",
  static_text:    null,
};

export function fieldByKey(key: string | null | undefined): TemplateField | null {
  if (!key) return null;
  return TEMPLATE_FIELDS.find((f) => f.key === key) ?? null;
}

export type VariableMappingEntry = {
  index: number;             // 1-based, matches {{N}}
  field: TemplateFieldKey;
  static_value?: string;     // only when field === "static_text"
};

// --- Auto-detection -------------------------------------------------------
// Guesses a field for each {{N}} in a template by inspecting:
//   1. Meta-approved example values (most reliable signal)
//   2. Surrounding body text keywords (e.g. "order #{{2}}" → order_id)
// Returns one entry per placeholder up to variables_count. Falls back to
// `customer_name` when nothing matches so the dropdown still has a value.
type GuessTemplate = {
  variables_count?: number | null;
  body?: string | null;
  components?: any;
};

function fieldFromExample(sample: string): TemplateFieldKey | null {
  const s = (sample || "").trim();
  if (!s) return null;
  if (/^https?:\/\//i.test(s)) {
    if (/track|awb|consign|waybill|shipment/i.test(s)) return "tracking_url";
    return "recovery_url";
  }
  if (/^[A-Z]{2,4}\d{6,}$/.test(s) || /^awb/i.test(s)) return "tracking_id";
  if (/[₹$€£]/.test(s) || /^(inr|usd|eur|gbp|aed)\b/i.test(s) || /^\d+(\.\d{1,2})?$/.test(s)) return "order_amount";
  if (/^#?\d{3,}$/.test(s) || /^#/.test(s) || /order|invoice/i.test(s)) return "order_id";
  if (/@/.test(s) && /\./.test(s)) return "customer_email";
  if (/^\+?\d[\d\s\-()]{6,}$/.test(s)) return "customer_phone";
  if (/\b(dress|shirt|kurti|saree|tee|bag|shoe|product|item|outfit)\b/i.test(s)) return "product_name";
  if (/^[A-Z][a-z]+(\s+[A-Z][a-z]+){1,3}$/.test(s)) return "customer_name";
  return null;
}

const KEYWORD_RULES: Array<{ field: TemplateFieldKey; re: RegExp }> = [
  { field: "tracking_url",  re: /track(ing)?\s*(link|url)|track\s*your\s*order/i },
  { field: "tracking_id",   re: /tracking\s*(id|number|no|#)|\bawb\b|\bconsignment\b|\bwaybill\b/i },
  { field: "order_id",      re: /order\s*(id|number|no|#)|\border\s*#|invoice\s*(no|#|number)|reference\s*(no|#)/i },
  { field: "order_amount",  re: /order\s*(amount|total|value)|\b(amount|total|grand\s*total|price|value)\b|pay(able|ment)|[₹$€£]\s*$|(inr|usd|eur|gbp|aed|aud|cad)\s*$/i },
  { field: "store_name",    re: /\bfrom\s*$|\bat\s*$|\bstore\b|\bshop\b|\bbrand\b|\bmerchant\b|thanks?\s*for\s*(shopping|ordering)/i },
  { field: "product_name",  re: /\bproduct\b|\bitem\b|you\s*(ordered|bought|purchased)|outfit\s*you\s*loved/i },
  { field: "recovery_url",  re: /\b(link|url|click\s*here|continue|complete|recover|checkout|cart)\b/i },
  { field: "customer_name", re: /^(hi|hello|hey|dear)\b|\bcustomer\s*name\b|\bname\b/i },
];

function fieldFromContext(before: string, after: string): TemplateFieldKey | null {
  for (const { field, re } of KEYWORD_RULES) {
    if (re.test(before)) return field;
  }
  for (const { field, re } of KEYWORD_RULES) {
    if (re.test(after)) return field;
  }
  return null;
}

export function guessTemplateMapping(template: GuessTemplate): VariableMappingEntry[] {
  const count = Number(template.variables_count || 0);
  if (count <= 0) return [];

  const components: any[] = Array.isArray(template.components) ? template.components : [];
  const bodyComp = components.find((c: any) => String(c?.type || "").toUpperCase() === "BODY");
  const bodyText: string = String(bodyComp?.text || template.body || "");
  const exampleRow: string[] = (() => {
    const ex = bodyComp?.example?.body_text;
    if (Array.isArray(ex) && ex.length && Array.isArray(ex[0])) {
      return (ex[0] as any[]).map((v: any) => String(v ?? ""));
    }
    return [];
  })();

  // Walk placeholders in order to capture before/after context per slot.
  const ctxByIndex = new Map<number, { before: string; after: string }>();
  const re = /\{\{\s*(\d+)\s*\}\}/g;
  let m: RegExpExecArray | null;
  let prevEnd = 0;
  while ((m = re.exec(bodyText)) !== null) {
    const n = Number(m[1]);
    const matchEnd = m.index + m[0].length;
    if (Number.isFinite(n) && n >= 1 && !ctxByIndex.has(n)) {
      let before = bodyText.slice(prevEnd, m.index);
      if (before.length > 80) before = before.slice(-80);
      const nextIdx = bodyText.indexOf("{{", matchEnd);
      const afterEnd = nextIdx === -1 ? Math.min(bodyText.length, matchEnd + 40) : Math.min(nextIdx, matchEnd + 40);
      const after = bodyText.slice(matchEnd, afterEnd);
      ctxByIndex.set(n, { before, after });
    }
    prevEnd = matchEnd;
  }

  const out: VariableMappingEntry[] = [];
  for (let i = 1; i <= count; i++) {
    const fromExample = fieldFromExample(exampleRow[i - 1] ?? "");
    const ctx = ctxByIndex.get(i);
    const fromCtx = ctx ? fieldFromContext(ctx.before, ctx.after) : null;
    const field: TemplateFieldKey = fromExample ?? fromCtx ?? "customer_name";
    out.push({ index: i, field });
  }
  return out;
}

