// Server-only helpers for Meta (Facebook) Lead Ads integration.
// Wraps Graph API + state-token signing. Never import in client bundles.

import { createHmac, timingSafeEqual } from "crypto";

const GRAPH = "https://graph.facebook.com/v20.0";

function appSecret() {
  const s = process.env.META_APP_SECRET;
  if (!s) throw new Error("META_APP_SECRET is not configured");
  return s;
}
function appId() {
  const s = process.env.META_APP_ID;
  if (!s) throw new Error("META_APP_ID is not configured");
  return s;
}
export function verifyToken() {
  const s = process.env.META_LEAD_VERIFY_TOKEN;
  if (!s) throw new Error("META_LEAD_VERIFY_TOKEN is not configured");
  return s;
}

/** appsecret_proof for Graph calls — Meta requires this when using a token outside the browser. */
function appsecretProof(token: string) {
  return createHmac("sha256", appSecret()).update(token).digest("hex");
}

export async function graphGet(path: string, token: string, params: Record<string, string> = {}) {
  const url = new URL(`${GRAPH}${path.startsWith("/") ? path : `/${path}`}`);
  url.searchParams.set("access_token", token);
  url.searchParams.set("appsecret_proof", appsecretProof(token));
  for (const [k, v] of Object.entries(params)) url.searchParams.set(k, v);
  const res = await fetch(url.toString());
  const json = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(`Graph GET ${path} failed: ${res.status} ${JSON.stringify(json)}`);
  return json;
}

export async function graphPost(path: string, token: string, body: Record<string, string> = {}) {
  const url = new URL(`${GRAPH}${path.startsWith("/") ? path : `/${path}`}`);
  url.searchParams.set("access_token", token);
  url.searchParams.set("appsecret_proof", appsecretProof(token));
  const form = new URLSearchParams(body);
  const res = await fetch(url.toString(), { method: "POST", body: form });
  const json = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(`Graph POST ${path} failed: ${res.status} ${JSON.stringify(json)}`);
  return json;
}

/** Exchange a short-lived OAuth code for a long-lived user token. */
export async function exchangeCodeForToken(code: string, redirectUri: string) {
  const u1 = new URL(`${GRAPH}/oauth/access_token`);
  u1.searchParams.set("client_id", appId());
  u1.searchParams.set("client_secret", appSecret());
  u1.searchParams.set("redirect_uri", redirectUri);
  u1.searchParams.set("code", code);
  const r1 = await fetch(u1.toString());
  const j1 = await r1.json();
  if (!r1.ok) throw new Error(`OAuth exchange failed: ${JSON.stringify(j1)}`);
  const shortToken: string = j1.access_token;

  // Upgrade to long-lived (~60 days).
  const u2 = new URL(`${GRAPH}/oauth/access_token`);
  u2.searchParams.set("grant_type", "fb_exchange_token");
  u2.searchParams.set("client_id", appId());
  u2.searchParams.set("client_secret", appSecret());
  u2.searchParams.set("fb_exchange_token", shortToken);
  const r2 = await fetch(u2.toString());
  const j2 = await r2.json();
  if (!r2.ok) throw new Error(`Long-lived exchange failed: ${JSON.stringify(j2)}`);
  return {
    access_token: j2.access_token as string,
    expires_in: (j2.expires_in as number | undefined) ?? null,
  };
}

// ---------- State token signing ---------- //
export function signState(payload: Record<string, string>) {
  const data = Buffer.from(JSON.stringify(payload)).toString("base64url");
  const sig = createHmac("sha256", appSecret()).update(data).digest("base64url");
  return `${data}.${sig}`;
}
export function verifyState(state: string): Record<string, string> | null {
  const [data, sig] = state.split(".");
  if (!data || !sig) return null;
  const expected = createHmac("sha256", appSecret()).update(data).digest("base64url");
  const a = Buffer.from(sig);
  const b = Buffer.from(expected);
  if (a.length !== b.length || !timingSafeEqual(a, b)) return null;
  try {
    return JSON.parse(Buffer.from(data, "base64url").toString("utf8"));
  } catch {
    return null;
  }
}

// ---------- Lead field normalization ---------- //
const FIELD_ALIASES: Record<string, string[]> = {
  name: ["full_name", "name", "first_name", "your_name"],
  email: ["email", "your_email", "work_email"],
  phone: ["phone_number", "phone", "mobile", "mobile_number", "whatsapp", "contact_number"],
  city: ["city"],
  message: ["message", "comments", "notes", "enquiry"],
};

export function normalizeLeadFields(fieldData: Array<{ name: string; values: string[] }>) {
  const flat: Record<string, string> = {};
  for (const f of fieldData) {
    flat[f.name.toLowerCase()] = (f.values?.[0] ?? "").toString();
  }
  function pick(key: keyof typeof FIELD_ALIASES) {
    for (const a of FIELD_ALIASES[key]) {
      if (flat[a]) return flat[a];
    }
    return undefined;
  }
  return {
    name: pick("name"),
    email: pick("email"),
    phone: pick("phone"),
    city: pick("city"),
    message: pick("message"),
    raw: flat,
  };
}
