import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

async function assertSuperAdmin(supabase: any, userId: string) {
  const { data, error } = await supabase
    .from("profiles")
    .select("is_super_admin")
    .eq("id", userId)
    .maybeSingle();
  if (error) throw new Error(error.message);
  if (!data?.is_super_admin) throw new Error("Forbidden: super admin only");
}

// List ALL reseller accounts with workspace & customer counts (super admin)
export const adminListResellers = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase, userId } = context;
    await assertSuperAdmin(supabase, userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const { data: accounts } = await supabaseAdmin
      .from("reseller_accounts")
      .select("*")
      .order("created_at", { ascending: false });
    const ids = (accounts ?? []).map((a: any) => a.workspace_id);
    const { data: workspaces } = await supabaseAdmin
      .from("workspaces")
      .select("id, name, slug, owner_id")
      .in("id", ids.length ? ids : ["00000000-0000-0000-0000-000000000000"]);
    const { data: customers } = await supabaseAdmin
      .from("reseller_customers")
      .select("reseller_workspace_id, status")
      .in("reseller_workspace_id", ids.length ? ids : ["00000000-0000-0000-0000-000000000000"]);
    const wsMap = new Map((workspaces ?? []).map((w: any) => [w.id, w]));
    const counts = new Map<string, { active: number; total: number }>();
    (customers ?? []).forEach((c: any) => {
      const cur = counts.get(c.reseller_workspace_id) ?? { active: 0, total: 0 };
      cur.total += 1;
      if (c.status === "active") cur.active += 1;
      counts.set(c.reseller_workspace_id, cur);
    });
    return {
      accounts: (accounts ?? []).map((a: any) => ({
        ...a,
        workspace: wsMap.get(a.workspace_id),
        customer_count: counts.get(a.workspace_id) ?? { active: 0, total: 0 },
      })),
    };
  });

const UpdateResellerSchema = z.object({
  workspace_id: z.string().uuid(),
  brand_name: z.string().min(1).max(120).optional(),
  support_email: z.string().email().nullable().optional(),
  primary_color: z.string().max(20).optional(),
  logo_path: z.string().nullable().optional(),
  subdomain: z
    .string()
    .regex(/^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/i, "Invalid subdomain")
    .nullable()
    .optional(),
  custom_domain: z.string().nullable().optional(),
  plan_template_id: z.union([z.string().uuid(), z.literal(""), z.null()]).optional().transform((v) => (v ? v : null)),
  commission_pct: z.number().min(0).max(100).optional(),
  max_customers: z.number().int().min(-1).optional(),
  allow_custom_domain: z.boolean().optional(),
  white_label: z.boolean().optional(),
  status: z.enum(["active", "suspended"]).optional(),
  features: z.record(z.string(), z.boolean()).optional(),
});

export const adminUpdateReseller = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => UpdateResellerSchema.parse(data))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    await assertSuperAdmin(supabase, userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const { workspace_id, ...patch } = data;
    // Normalize empty strings to null
    if (patch.subdomain === "") patch.subdomain = null;
    if (patch.custom_domain === "") patch.custom_domain = null;
    if (patch.subdomain) patch.subdomain = patch.subdomain.toLowerCase();
    if (patch.custom_domain) patch.custom_domain = patch.custom_domain.toLowerCase();

    const { data: updated, error } = await supabaseAdmin
      .from("reseller_accounts")
      .update(patch)
      .eq("workspace_id", workspace_id)
      .select()
      .maybeSingle();
    if (error) throw new Error(error.message);
    return { account: updated };
  });

// Workspace owner/admin updates branding for their own reseller account
const SelfBrandSchema = z.object({
  workspace_id: z.string().uuid(),
  brand_name: z.string().min(1).max(120),
  support_email: z.string().email().nullable().or(z.literal("")),
  primary_color: z.string().max(20),
  logo_path: z.string().nullable().optional(),
  custom_domain: z.string().nullable().optional(),
  white_label: z.boolean(),
});

export const updateMyResellerBranding = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => SelfBrandSchema.parse(d))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    // verify owner/admin of this workspace
    const { data: mem } = await supabase
      .from("workspace_members")
      .select("role")
      .eq("workspace_id", data.workspace_id)
      .eq("user_id", userId)
      .maybeSingle();
    if (!mem || !["owner", "admin"].includes(mem.role as string)) {
      throw new Error("Forbidden: workspace admin only");
    }
    const { data: acct } = await supabase
      .from("reseller_accounts")
      .select("allow_custom_domain")
      .eq("workspace_id", data.workspace_id)
      .maybeSingle();
    const patch: any = {
      brand_name: data.brand_name,
      support_email: data.support_email || null,
      primary_color: data.primary_color,
      logo_path: data.logo_path ?? null,
      white_label: data.white_label,
    };
    if (acct?.allow_custom_domain) {
      patch.custom_domain = (data.custom_domain || "").toLowerCase() || null;
    }
    const { error } = await supabase
      .from("reseller_accounts")
      .update(patch)
      .eq("workspace_id", data.workspace_id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

// Regenerate a license key (super admin or reseller owner)
export const regenerateCustomerLicense = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ customer_id: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    const { supabase } = context;
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    // RLS-permission check via user's client first
    const { data: existing, error: e0 } = await supabase
      .from("reseller_customers")
      .select("id, reseller_workspace_id")
      .eq("id", data.customer_id)
      .maybeSingle();
    if (e0 || !existing) throw new Error("Customer not found or forbidden");
    const { data: newKey } = await supabaseAdmin.rpc("generate_license_key");
    const { error } = await supabaseAdmin
      .from("reseller_customers")
      .update({ license_key: newKey, license_status: "active" })
      .eq("id", data.customer_id);
    if (error) throw new Error(error.message);
    return { license_key: newKey as string };
  });

export const setCustomerLicenseStatus = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) =>
    z
      .object({
        customer_id: z.string().uuid(),
        status: z.enum(["active", "revoked", "expired"]),
        license_expires_at: z.string().datetime().nullable().optional(),
      })
      .parse(d),
  )
  .handler(async ({ data, context }) => {
    const { supabase } = context;
    const patch: any = { license_status: data.status };
    if (data.license_expires_at !== undefined) patch.license_expires_at = data.license_expires_at;
    const { error } = await supabase
      .from("reseller_customers")
      .update(patch)
      .eq("id", data.customer_id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

// Sign a URL for a private logo path (60 days)
export const signResellerLogoUrl = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ path: z.string().min(1) }).parse(d))
  .handler(async ({ data, context }) => {
    const { supabase } = context;
    const { data: signed, error } = await supabase.storage
      .from("reseller-logos")
      .createSignedUrl(data.path, 60 * 60 * 24 * 60);
    if (error) throw new Error(error.message);
    return { url: signed.signedUrl };
  });
