import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const wsInput = z.object({ workspace_id: z.string().uuid() });

/** Balance + today/month usage aggregates for the workspace credit widget. */
export const getAiCreditSummary = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) => wsInput.parse(d))
  .handler(async ({ data, context }) => {
    const { supabase } = context;
    const ws = data.workspace_id;

    const { data: account } = await supabase
      .from("ai_credit_accounts")
      .select("balance, low_threshold, lifetime_added, lifetime_used, updated_at")
      .eq("workspace_id", ws)
      .maybeSingle();

    const startOfDay = new Date(); startOfDay.setHours(0, 0, 0, 0);
    const startOfMonth = new Date(); startOfMonth.setDate(1); startOfMonth.setHours(0, 0, 0, 0);

    const { data: monthRows } = await supabase
      .from("ai_credit_ledger")
      .select("delta, created_at")
      .eq("workspace_id", ws)
      .eq("entry_type", "usage")
      .gte("created_at", startOfMonth.toISOString())
      .limit(10000);

    let usedToday = 0;
    let usedMonth = 0;
    for (const r of monthRows ?? []) {
      const spent = -Number(r.delta ?? 0);
      if (spent <= 0) continue;
      usedMonth += spent;
      if (new Date(r.created_at as string) >= startOfDay) usedToday += spent;
    }

    return {
      balance: Number(account?.balance ?? 0),
      lowThreshold: Number(account?.low_threshold ?? 500),
      lifetimeAdded: Number(account?.lifetime_added ?? 0),
      lifetimeUsed: Number(account?.lifetime_used ?? 0),
      usedToday,
      usedMonth,
      updatedAt: account?.updated_at ?? null,
    };
  });

/** Recent usage / adjustment history for the workspace. */
export const getAiCreditLedger = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) =>
    z.object({ workspace_id: z.string().uuid(), limit: z.number().int().min(1).max(200).optional() }).parse(d),
  )
  .handler(async ({ data, context }) => {
    const { supabase } = context;
    const { data: rows } = await supabase
      .from("ai_credit_ledger")
      .select("id, workspace_id, delta, entry_type, feature, model, meta, actor_user_id, notes, balance_after, created_at")
      .eq("workspace_id", data.workspace_id)
      .order("created_at", { ascending: false })
      .limit(data.limit ?? 50);
    return rows ?? [];
  });

/** Super-admin: list every workspace with its balance for the admin panel. */
export const adminListAiCreditAccounts = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase, userId } = context;
    const { data: me } = await supabase.from("profiles").select("is_super_admin").eq("id", userId).maybeSingle();
    if (!me?.is_super_admin) throw new Error("forbidden");

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: workspaces } = await supabaseAdmin
      .from("workspaces")
      .select("id, name, slug, owner_id")
      .order("name", { ascending: true });

    const { data: accounts } = await supabaseAdmin
      .from("ai_credit_accounts")
      .select("workspace_id, balance, low_threshold, lifetime_added, lifetime_used, updated_at");

    const byWs = new Map((accounts ?? []).map((a: any) => [a.workspace_id, a]));
    return (workspaces ?? []).map((w: any) => ({
      workspace_id: w.id,
      workspace_name: w.name,
      workspace_slug: w.slug,
      balance: Number(byWs.get(w.id)?.balance ?? 0),
      low_threshold: Number(byWs.get(w.id)?.low_threshold ?? 500),
      lifetime_added: Number(byWs.get(w.id)?.lifetime_added ?? 0),
      lifetime_used: Number(byWs.get(w.id)?.lifetime_used ?? 0),
      updated_at: byWs.get(w.id)?.updated_at ?? null,
    }));
  });

const adjustSchema = z.object({
  workspace_id: z.string().uuid(),
  amount: z.number().int().min(1).max(10_000_000),
  entry_type: z.enum(["admin_add", "admin_deduct", "admin_reset", "recharge"]),
  notes: z.string().max(500).optional(),
});

/** Super-admin: add / deduct / reset / recharge a workspace's AI credit balance. */
export const adminAdjustAiCredits = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) => adjustSchema.parse(d))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { data: me } = await supabase.from("profiles").select("is_super_admin").eq("id", userId).maybeSingle();
    if (!me?.is_super_admin) throw new Error("forbidden");

    const delta =
      data.entry_type === "admin_reset"
        ? 0
        : data.entry_type === "admin_deduct"
        ? -data.amount
        : data.amount;

    const { data: newBalance, error } = await supabase.rpc("admin_adjust_ai_credits", {
      _workspace_id: data.workspace_id,
      _delta: delta,
      _entry_type: data.entry_type,
      _notes: data.notes,
      _actor: userId,
    });
    if (error) throw new Error(error.message);
    return { balance: Number(newBalance ?? 0) };
  });

/** Super-admin: update the low-balance warning threshold for a workspace. */
export const adminSetLowThreshold = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) =>
    z.object({ workspace_id: z.string().uuid(), low_threshold: z.number().int().min(0).max(1_000_000) }).parse(d),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { data: me } = await supabase.from("profiles").select("is_super_admin").eq("id", userId).maybeSingle();
    if (!me?.is_super_admin) throw new Error("forbidden");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    await supabaseAdmin
      .from("ai_credit_accounts")
      .upsert({ workspace_id: data.workspace_id, low_threshold: data.low_threshold }, { onConflict: "workspace_id" });
    return { ok: true };
  });
