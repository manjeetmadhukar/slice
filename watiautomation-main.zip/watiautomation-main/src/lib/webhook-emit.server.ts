// Fan-out helper: delivers an event payload to every enabled workspace webhook
// endpoint subscribed to that event. Fire-and-forget, never throws.
import { supabaseAdmin } from "@/integrations/supabase/client.server";

export async function emitWorkspaceWebhook(
  workspaceId: string,
  event: string,
  data: Record<string, unknown>,
) {
  try {
    const { data: endpoints } = await supabaseAdmin
      .from("webhook_endpoints")
      .select("id, url, events, enabled, secret")
      .eq("workspace_id", workspaceId)
      .eq("enabled", true);

    const targets = (endpoints ?? []).filter((e: any) =>
      Array.isArray(e.events) && e.events.includes(event),
    );
    if (!targets.length) return;

    const body = JSON.stringify({
      event,
      workspace_id: workspaceId,
      timestamp: new Date().toISOString(),
      data,
    });

    await Promise.all(
      targets.map(async (ep: any) => {
        let status = "error";
        try {
          const res = await fetch(ep.url, {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              "X-Slice-Event": event,
              ...(ep.secret ? { "X-Slice-Signature": ep.secret } : {}),
            },
            body,
          });
          status = String(res.status);
        } catch (e: any) {
          status = `error: ${String(e?.message || e).slice(0, 80)}`;
        }
        await supabaseAdmin
          .from("webhook_endpoints")
          .update({ last_triggered_at: new Date().toISOString(), last_status: status })
          .eq("id", ep.id);
      }),
    );
  } catch {
    // never break the caller
  }
}
