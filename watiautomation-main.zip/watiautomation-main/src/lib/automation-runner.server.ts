// Runs automations on incoming WhatsApp messages.
// Imported by the webhook server route only.
import { supabaseAdmin } from "@/integrations/supabase/client.server";

const META_BASE = "https://graph.facebook.com/v21.0";

type Settings = {
  phone_number_id: string;
  access_token: string;
};

async function sendText(s: Settings, toPhone: string, body: string) {
  const res = await fetch(`${META_BASE}/${s.phone_number_id}/messages`, {
    method: "POST",
    headers: { Authorization: `Bearer ${s.access_token}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      messaging_product: "whatsapp",
      to: toPhone.replace(/[^\d]/g, ""),
      type: "text",
      text: { body },
    }),
  });
  const j: any = await res.json().catch(() => ({}));
  return { ok: res.ok, wa_id: j?.messages?.[0]?.id as string | undefined, error: j?.error?.message };
}

async function sendTemplate(s: Settings, toPhone: string, name: string, language: string) {
  const res = await fetch(`${META_BASE}/${s.phone_number_id}/messages`, {
    method: "POST",
    headers: { Authorization: `Bearer ${s.access_token}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      messaging_product: "whatsapp",
      to: toPhone.replace(/[^\d]/g, ""),
      type: "template",
      template: { name, language: { code: language } },
    }),
  });
  const j: any = await res.json().catch(() => ({}));
  return { ok: res.ok, wa_id: j?.messages?.[0]?.id as string | undefined, error: j?.error?.message };
}

function matchKeyword(text: string, keywords: string[], match_type: string) {
  const t = text.toLowerCase().trim();
  return keywords.some((k) => {
    const kw = k.toLowerCase().trim();
    if (!kw) return false;
    if (match_type === "exact") return t === kw;
    if (match_type === "starts_with") return t.startsWith(kw);
    return t.includes(kw);
  });
}

function isWithinAwayWindow(start?: string | null, end?: string | null, days?: number[] | null) {
  const now = new Date();
  const day = now.getUTCDay();
  if (days && days.length && !days.includes(day)) return false;
  if (!start || !end) return true; // no window = always away
  const mins = now.getUTCHours() * 60 + now.getUTCMinutes();
  const [sh, sm] = start.split(":").map(Number);
  const [eh, em] = end.split(":").map(Number);
  const s = sh * 60 + sm;
  const e = eh * 60 + em;
  // away = OUTSIDE business hours (start..end is business)
  if (s <= e) return mins < s || mins >= e;
  return mins < s && mins >= e;
}

export async function runAutomations(params: {
  workspace_id: string;
  conversation_id: string;
  contact_phone: string;
  message_text: string | null;
  is_first_message: boolean;
}) {
  try {
    const { data: settings } = await supabaseAdmin
      .from("whatsapp_settings").select("phone_number_id, access_token")
      .eq("workspace_id", params.workspace_id).maybeSingle();
    if (!settings?.phone_number_id || !settings.access_token) return;
    const s = settings as Settings;

    const { data: automations } = await supabaseAdmin
      .from("automations").select("*")
      .eq("workspace_id", params.workspace_id).eq("enabled", true)
      .order("priority", { ascending: false });
    if (!automations?.length) return;

    const text = (params.message_text || "").trim();
    const replies: Array<{ kind: "text" | "template"; body?: string; tpl?: any }> = [];
    let assignedTo: string | null = null;

    for (const a of automations as any[]) {
      if (a.type === "welcome") {
        if (params.is_first_message && a.reply_text) {
          replies.push({ kind: "text", body: a.reply_text });
        }
      } else if (a.type === "keyword") {
        if (text && a.keywords?.length && matchKeyword(text, a.keywords, a.match_type)) {
          if (a.template_id) {
            const { data: tpl } = await supabaseAdmin
              .from("templates").select("meta_template_name, language")
              .eq("id", a.template_id).maybeSingle();
            if (tpl) replies.push({ kind: "template", tpl });
          } else if (a.reply_text) {
            replies.push({ kind: "text", body: a.reply_text });
          }
          if (a.assign_to) assignedTo = a.assign_to;
        }
      } else if (a.type === "away") {
        if (isWithinAwayWindow(a.away_start, a.away_end, a.away_days) && a.reply_text) {
          // Avoid spamming: only send if no automated reply in last 4 hours on this convo
          const since = new Date(Date.now() - 4 * 3600 * 1000).toISOString();
          const { data: recent } = await supabaseAdmin
            .from("messages").select("id")
            .eq("conversation_id", params.conversation_id)
            .eq("is_automated", true).gte("created_at", since).limit(1);
          if (!recent?.length) replies.push({ kind: "text", body: a.reply_text });
        }
      } else if (a.type === "routing") {
        if (a.assign_to && (!a.keywords?.length || matchKeyword(text, a.keywords, a.match_type))) {
          assignedTo = a.assign_to;
        }
      }
    }

    for (const r of replies) {
      let result: { ok: boolean; wa_id?: string; error?: string };
      let content = r.body || "";
      let msgType: "text" | "template" = "text";
      if (r.kind === "template" && r.tpl) {
        result = await sendTemplate(s, params.contact_phone, r.tpl.meta_template_name, r.tpl.language);
        content = `[template:${r.tpl.meta_template_name}]`;
        msgType = "template" as any;
      } else {
        result = await sendText(s, params.contact_phone, r.body!);
      }
      if (result.ok) {
        await supabaseAdmin.from("messages").insert({
          workspace_id: params.workspace_id,
          conversation_id: params.conversation_id,
          direction: "out",
          type: msgType === "template" ? "text" : "text",
          content,
          wa_message_id: result.wa_id,
          is_automated: true,
        });
        await supabaseAdmin.from("conversations").update({
          last_message_at: new Date().toISOString(),
          last_message_preview: content.slice(0, 140),
        }).eq("id", params.conversation_id);
      }
    }

    if (assignedTo) {
      await supabaseAdmin.from("conversations")
        .update({ assigned_to: assignedTo })
        .eq("id", params.conversation_id);
    }
  } catch (e) {
    console.error("automation runner error", e);
  }
}
