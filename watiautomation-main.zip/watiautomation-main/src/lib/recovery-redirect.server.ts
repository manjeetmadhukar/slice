import { supabaseAdmin } from "@/integrations/supabase/client.server";
import { recordRecoveryClick } from "@/lib/abandoned-carts.server";

function extractTokenCandidate(raw: string): string {
  const candidates = [raw];
  try {
    const decoded = decodeURIComponent(raw);
    if (decoded !== raw) candidates.push(decoded);
  } catch {}

  for (const candidate of candidates) {
    const trimmed = candidate.trim();
    if (!trimmed || /\{\{\s*\d+\s*\}\}/.test(trimmed)) continue;

    try {
      const url = new URL(trimmed);
      const recoverToken = url.searchParams.get("slice_recover") || url.searchParams.get("recover") || url.searchParams.get("token");
      if (recoverToken && !/\{\{\s*\d+\s*\}\}/.test(recoverToken)) return recoverToken;
      const token = url.pathname.split("/").filter(Boolean).pop();
      if (token) return token;
    } catch {}

    const marker = trimmed.match(/\/(?:api\/public\/)?r\/([^?#]+)/i);
    if (marker?.[1]) {
      const token = marker[1].split("/").filter(Boolean).pop();
      if (token) return token;
    }

    const token = trimmed.split(/[?#]/)[0].split("/").filter(Boolean).pop();
    if (token) return token;
  }

  return "";
}

export async function handleRecoveryRedirect(request: Request, rawToken: string) {
  const token = extractTokenCandidate(String(rawToken || ""));
  if (!token || token.length > 200 || /[,()"]/.test(token)) {
    return new Response("Not found", { status: 404 });
  }

  const { data: cart } = await supabaseAdmin
    .from("abandoned_carts")
    .select("id, workspace_id, integration_id, provider, cart_token, customer_name, customer_email, customer_phone, provider_recovery_url, checkout_url, recovery_expires_at, status, items")
    .or(`recovery_token.eq.${token},cart_token.eq.${token}`)
    .order("abandoned_at", { ascending: false })
    .limit(1)
    .maybeSingle();
  if (!cart) return new Response("This recovery link is no longer valid.", { status: 404 });

  const expires = (cart as any).recovery_expires_at as string | null;
  if (expires && new Date(expires).getTime() < Date.now()) {
    return new Response("This recovery link has expired.", { status: 410 });
  }

  let target = (cart as any).provider_recovery_url || (cart as any).checkout_url;
  if ((cart as any).provider === "woocommerce" && target && (cart as any).cart_token) {
    try {
      const url = new URL(target);
      if (url.searchParams.has("slice_recover")) url.searchParams.set("slice_recover", (cart as any).cart_token);
      target = url.toString();
    } catch {}
  }
  if (!target) return new Response("Recovery URL is missing for this cart.", { status: 404 });

  recordRecoveryClick({
    cartId: (cart as any).id,
    workspaceId: (cart as any).workspace_id,
    token,
    ip: request.headers.get("cf-connecting-ip") || request.headers.get("x-forwarded-for"),
    userAgent: request.headers.get("user-agent"),
    referer: request.headers.get("referer"),
  }).catch(() => {});

  return new Response(null, {
    status: 302,
    headers: { Location: target, "Cache-Control": "no-store" },
  });
}