// Shared CSV parsing helpers for contact imports.
// Handles: BOM, CRLF, RFC-4180 quoted fields with embedded commas/quotes,
// curly/smart quotes wrapping fields, and phone sanitization
// (strips zero-width chars, smart quotes, spaces, dashes, parens).

const SMART_QUOTES = /[\u2018\u2019\u201A\u201B\u201C\u201D\u201E\u201F\u2039\u203A\u00AB\u00BB\u0060\u00B4]/g;
const INVISIBLE = /[\u200B-\u200D\uFEFF\u00A0]/g;

function stripBom(s: string) {
  return s.replace(/^\uFEFF/, "");
}

function cleanField(v: string) {
  let s = (v ?? "").replace(INVISIBLE, "").replace(SMART_QUOTES, '"').trim();
  // Strip surrounding straight quotes left over from smart-quote wrapping
  if (s.length >= 2 && s.startsWith('"') && s.endsWith('"')) {
    s = s.slice(1, -1).replace(/""/g, '"').trim();
  }
  return s;
}

export function sanitizePhone(v: string) {
  const s = cleanField(v).replace(INVISIBLE, "").replace(SMART_QUOTES, "");
  // Keep leading + and digits only
  const hasPlus = /^\s*\+/.test(s);
  const digits = s.replace(/\D+/g, "");
  if (!digits) return "";
  return hasPlus ? `+${digits}` : digits;
}

// Parse a single CSV line respecting quoted fields.
function parseLine(line: string): string[] {
  const out: string[] = [];
  let cur = "";
  let inQuotes = false;
  for (let i = 0; i < line.length; i++) {
    const c = line[i];
    if (inQuotes) {
      if (c === '"') {
        if (line[i + 1] === '"') { cur += '"'; i++; }
        else inQuotes = false;
      } else cur += c;
    } else {
      if (c === '"') inQuotes = true;
      else if (c === ",") { out.push(cur); cur = ""; }
      else cur += c;
    }
  }
  out.push(cur);
  return out;
}

export type ParsedContactRow = { name: string; phone: string; email: string | null };

export function parseContactsCsv(text: string): ParsedContactRow[] {
  const cleaned = stripBom(text ?? "");
  // Support quoted fields containing newlines by walking char-by-char.
  const records: string[][] = [];
  let field = "";
  let row: string[] = [];
  let inQuotes = false;
  for (let i = 0; i < cleaned.length; i++) {
    const c = cleaned[i];
    if (inQuotes) {
      if (c === '"') {
        if (cleaned[i + 1] === '"') { field += '"'; i++; }
        else inQuotes = false;
      } else field += c;
    } else {
      if (c === '"') inQuotes = true;
      else if (c === ",") { row.push(field); field = ""; }
      else if (c === "\n" || c === "\r") {
        if (c === "\r" && cleaned[i + 1] === "\n") i++;
        row.push(field); field = "";
        if (row.some((x) => x.trim() !== "")) records.push(row);
        row = [];
      } else field += c;
    }
  }
  if (field.length || row.length) {
    row.push(field);
    if (row.some((x) => x.trim() !== "")) records.push(row);
  }

  const rows: ParsedContactRow[] = [];
  for (let i = 0; i < records.length; i++) {
    const cols = records[i].map(cleanField);
    const [rawName, rawPhone, rawEmail] = cols;
    if (i === 0 && /^name$/i.test(rawName || "") && /^phone$/i.test(rawPhone || "")) continue;
    const phone = sanitizePhone(rawPhone || "");
    const name = (rawName || "").trim();
    if (!name || !phone) continue;
    const email = (rawEmail || "").trim() || null;
    rows.push({ name, phone, email });
  }
  return rows;
}
