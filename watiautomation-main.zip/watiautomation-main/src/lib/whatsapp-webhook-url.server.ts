import { getRequest } from "@tanstack/react-start/server";

const WEBHOOK_PATH = "/api/public/whatsapp-webhook";
const FALLBACK_PUBLIC_ORIGIN = "https://slice.dotscube.com";

function normalizeOrigin(value?: string | null): string | null {
  const raw = String(value || "").trim();
  if (!raw) return null;
  try {
    const url = new URL(raw.startsWith("http") ? raw : `https://${raw}`);
    return url.origin;
  } catch {
    return null;
  }
}

function isStablePublicOrigin(origin: string): boolean {
  const host = new URL(origin).hostname;
  return host !== "localhost" && host !== "127.0.0.1" && !host.includes("-preview--");
}

export function getWebhookCallbackUrl(): string | null {
  const configuredOrigin =
    normalizeOrigin(process.env.WHATSAPP_WEBHOOK_BASE_URL) ||
    normalizeOrigin(process.env.PUBLIC_SITE_URL) ||
    normalizeOrigin(process.env.APP_BASE_URL);
  if (configuredOrigin) return `${configuredOrigin}${WEBHOOK_PATH}`;

  try {
    const req = getRequest();
    const origin = new URL(req.url).origin;
    if (isStablePublicOrigin(origin)) return `${origin}${WEBHOOK_PATH}`;
  } catch {
    // fall through to production fallback
  }

  return `${FALLBACK_PUBLIC_ORIGIN}${WEBHOOK_PATH}`;
}
