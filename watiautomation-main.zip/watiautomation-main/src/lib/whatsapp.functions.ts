import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { guessTemplateMapping } from "@/lib/wa-template-fields";

const META_BASE = "https://graph.facebook.com/v21.0";


// Meta AUTHENTICATION templates require a fixed shape: no `text` on BODY,
// optional code expiration on FOOTER, and a single OTP button. Any other
// shape returns "component of type BODY has unexpected field(s) (text)".
function buildAuthComponents(footerHint?: string | null) {
  let minutes = 10;
  if (footerHint) {
    const m = String(footerHint).match(/(\d{1,3})/);
    if (m) minutes = Math.max(1, Math.min(90, parseInt(m[1], 10)));
  }
  return [
    { type: "BODY", add_security_recommendation: true },
    { type: "FOOTER", code_expiration_minutes: minutes },
    { type: "BUTTONS", buttons: [{ type: "OTP", otp_type: "COPY_CODE", text: "Copy code" }] },
  ];
}

async function getSettings(supabase: any, workspaceId: string) {
  const { data, error } = await supabase
    .from("whatsapp_settings")
    .select("*")
    .eq("workspace_id", workspaceId)
    .maybeSingle();
  if (error) throw new Error(error.message);
  if (!data) throw new Error("Settings not found for this workspace");
  if (!data.access_token || !data.phone_number_id) {
    throw new Error("WhatsApp credentials not configured. Add them in Settings.");
  }
  return data;
}

async function assertMember(
  supabase: any,
  workspaceId: string,
  userId: string,
  allowed: ("owner" | "admin" | "agent" | "viewer")[],
) {
  const { data, error } = await supabase
    .from("workspace_members")
    .select("role")
    .eq("workspace_id", workspaceId)
    .eq("user_id", userId)
    .maybeSingle();
  if (error || !data) throw new Error("Not a member of this workspace");
  if (!allowed.includes(data.role)) throw new Error("Insufficient permissions");
}

// Verify credentials with Meta + persist (admin/owner only)
export const verifyAndSaveSettings = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z.object({
      workspace_id: z.string().uuid(),
      phone_number_id: z.string().min(3).max(64),
      waba_id: z.string().min(3).max(64),
      access_token: z.string().min(20),
    }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    await assertMember(supabase, data.workspace_id, userId, ["owner", "admin"]);

    const res = await fetch(
      `${META_BASE}/${data.phone_number_id}?fields=display_phone_number,verified_name,quality_rating`,
      { headers: { Authorization: `Bearer ${data.access_token}` } },
    );
    const json: any = await res.json();
    if (!res.ok) {
      return { ok: false as const, error: json?.error?.message || "Meta API rejected the credentials" };
    }
    // Upsert (one whatsapp_settings row per workspace)
    const { error } = await supabase
      .from("whatsapp_settings")
      .upsert(
        {
          user_id: userId,
          workspace_id: data.workspace_id,
          phone_number_id: data.phone_number_id,
          waba_id: data.waba_id,
          access_token: data.access_token,
          business_phone: json.display_phone_number || null,
          display_name: json.verified_name || null,
          verified: true,
          updated_at: new Date().toISOString(),
        },
        { onConflict: "workspace_id" },
      );
    if (error) return { ok: false as const, error: error.message };
    return { ok: true as const, info: json };
  });

// Sync templates from Meta WABA
export const syncTemplates = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z.object({ workspace_id: z.string().uuid() }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    await assertMember(supabase, data.workspace_id, userId, ["owner", "admin", "agent"]);
    const s = await getSettings(supabase, data.workspace_id);
    if (!s.waba_id) throw new Error("WABA ID missing");

    const res = await fetch(
      `${META_BASE}/${s.waba_id}/message_templates?limit=200`,
      { headers: { Authorization: `Bearer ${s.access_token}` } },
    );
    const json: any = await res.json();
    if (!res.ok) throw new Error(json?.error?.message || "Failed to fetch templates");

    const rows = (json.data || []).map((t: any) => {
      const body = t.components?.find((c: any) => c.type === "BODY")?.text || "";
      const vars = (body.match(/\{\{\d+\}\}/g) || []).length;
      return {
        user_id: userId,
        workspace_id: data.workspace_id,
        meta_template_name: t.name,
        language: t.language,
        category: t.category,
        status: t.status,
        body,
        components: t.components,
        variables_count: vars,
        synced_at: new Date().toISOString(),
      };
    });

    await supabase.from("templates").delete().eq("workspace_id", data.workspace_id);
    if (rows.length) {
      const { error } = await supabase.from("templates").insert(rows);
      if (error) throw new Error(error.message);
    }
    return { count: rows.length };
  });

export const createTemplate = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z.object({
      workspace_id: z.string().uuid(),
      name: z.string().min(1).max(512).regex(/^[a-z0-9_]+$/, "Use lowercase letters, numbers and underscores only"),
      language: z.string().min(2).max(10),
      category: z.enum(["MARKETING", "UTILITY", "AUTHENTICATION"]),
      header_type: z.enum(["NONE", "TEXT", "IMAGE", "VIDEO", "DOCUMENT", "LOCATION"]),
      header_text: z.string().max(60).optional(),
      header_media_url: z.string().url().optional(),
      body: z.string().min(1).max(1024),
      body_examples: z.array(z.string().max(200)).max(20).optional(),
      footer: z.string().max(60).optional(),
      buttons: z.array(
        z.object({
          type: z.enum(["QUICK_REPLY", "PHONE_NUMBER", "URL", "COPY_CODE"]),
          text: z.string().max(25).optional(),
          phone_number: z.string().max(20).optional(),
          url: z.string().max(2000).optional(),
          example: z.string().max(2000).optional(),
          dynamic: z.boolean().optional(),
        }),
      ).max(10).optional(),
      variable_mapping: z.array(
        z.object({
          index: z.number().int().min(1).max(20),
          field: z.enum([
            "customer_name","customer_phone","customer_email",
            "order_id","order_amount","order_status","order_date",
            "product_name","product_price",
            "tracking_id","tracking_url",
            "store_name","recovery_url","static_text",
          ]),
          static_value: z.string().max(200).optional(),
        }),
      ).max(20).optional(),
    }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    await assertMember(supabase, data.workspace_id, userId, ["owner", "admin"]);
    const s = await getSettings(supabase, data.workspace_id);
    if (!s.waba_id) throw new Error("WABA ID missing");

    const components: any[] = [];

    if (data.header_type === "TEXT" && data.header_text) {
      components.push({ type: "HEADER", format: "TEXT", text: data.header_text });
    } else if (["IMAGE", "VIDEO", "DOCUMENT"].includes(data.header_type)) {
      if (!data.header_media_url) throw new Error("Header media URL required");
      const appId = process.env.META_APP_ID;
      if (!appId) throw new Error("META_APP_ID not configured on server");

      // Download the media from the provided URL
      const mediaRes = await fetch(data.header_media_url);
      if (!mediaRes.ok) throw new Error(`Failed to fetch media URL (${mediaRes.status})`);
      const contentType = mediaRes.headers.get("content-type") || "application/octet-stream";
      const buf = new Uint8Array(await mediaRes.arrayBuffer());
      const fileName = data.header_media_url.split("/").pop()?.split("?")[0] || "upload.bin";

      // Step 1: create resumable upload session
      const sessRes = await fetch(
        `${META_BASE}/${appId}/uploads?file_name=${encodeURIComponent(fileName)}&file_length=${buf.byteLength}&file_type=${encodeURIComponent(contentType)}&access_token=${encodeURIComponent(s.access_token)}`,
        { method: "POST" },
      );
      const sessJson: any = await sessRes.json();
      if (!sessRes.ok || !sessJson.id) {
        return { ok: false as const, error: sessJson?.error?.message || "Failed to start media upload" };
      }

      // Step 2: upload bytes
      const upRes = await fetch(`${META_BASE}/${sessJson.id}`, {
        method: "POST",
        headers: {
          Authorization: `OAuth ${s.access_token}`,
          file_offset: "0",
        },
        body: buf,
      });
      const upJson: any = await upRes.json();
      if (!upRes.ok || !upJson.h) {
        return { ok: false as const, error: upJson?.error?.message || "Failed to upload media to Meta" };
      }

      components.push({
        type: "HEADER",
        format: data.header_type,
        example: { header_handle: [upJson.h] },
      });
    } else if (data.header_type === "LOCATION") {
      components.push({ type: "HEADER", format: "LOCATION" });
    }

    {
      const varCount = (data.body.match(/\{\{\d+\}\}/g) || []).length;
      const bodyComp: any = { type: "BODY", text: data.body };
      if (varCount > 0) {
        const ex = (data.body_examples || []).slice(0, varCount);
        while (ex.length < varCount) ex.push("sample");
        bodyComp.example = { body_text: [ex] };
      }
      components.push(bodyComp);
    }

    if (data.footer) {
      components.push({ type: "FOOTER", text: data.footer });
    }

    if (data.buttons && data.buttons.length > 0) {
      const buttons = data.buttons.map((b) => {
        if (b.type === "QUICK_REPLY") return { type: "QUICK_REPLY", text: b.text };
        if (b.type === "PHONE_NUMBER") return { type: "PHONE_NUMBER", text: b.text, phone_number: b.phone_number };
        if (b.type === "COPY_CODE") return { type: "COPY_CODE", example: [b.example || ""] };
        if (b.type === "URL") {
          const out: any = { type: "URL", text: b.text, url: b.url };
          if (b.dynamic && b.example) out.example = [b.example];
          return out;
        }
        return b;
      });
      components.push({ type: "BUTTONS", buttons });
    }

    const finalComponents = data.category === "AUTHENTICATION"
      ? buildAuthComponents(data.footer)
      : components;

    const res = await fetch(`${META_BASE}/${s.waba_id}/message_templates`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${s.access_token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        name: data.name,
        language: data.language,
        category: data.category,
        components: finalComponents,
      }),
    });
    const json: any = await res.json();
    if (!res.ok) {
      return { ok: false as const, error: json?.error?.error_user_msg || json?.error?.message || "Meta rejected the template" };
    }

    // Save locally with PENDING status
    await supabase.from("templates").insert({
      user_id: userId,
      workspace_id: data.workspace_id,
      meta_template_name: data.name,
      language: data.language,
      category: data.category,
      status: json.status || "PENDING",
      body: data.body,
      components: finalComponents,
      variables_count: (data.body.match(/\{\{\d+\}\}/g) || []).length,
      variable_mapping: data.variable_mapping ?? null,
      synced_at: new Date().toISOString(),
    } as any);

    return { ok: true as const, id: json.id, status: json.status };
  });

// Edit a non-APPROVED template by deleting it on Meta and resubmitting.
// Meta does not allow direct content edits to PENDING/REJECTED templates.
export const editTemplate = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z.object({
      workspace_id: z.string().uuid(),
      template_id: z.string().uuid(),
      name: z.string().min(1).max(512).regex(/^[a-z0-9_]+$/, "Use lowercase letters, numbers and underscores only"),
      language: z.string().min(2).max(10),
      category: z.enum(["MARKETING", "UTILITY", "AUTHENTICATION"]),
      header_type: z.enum(["NONE", "TEXT", "IMAGE", "VIDEO", "DOCUMENT", "LOCATION"]),
      header_text: z.string().max(60).optional(),
      header_media_url: z.string().url().optional(),
      body: z.string().min(1).max(1024),
      body_examples: z.array(z.string().max(200)).max(20).optional(),
      footer: z.string().max(60).optional(),
      buttons: z.array(
        z.object({
          type: z.enum(["QUICK_REPLY", "PHONE_NUMBER", "URL", "COPY_CODE"]),
          text: z.string().max(25).optional(),
          phone_number: z.string().max(20).optional(),
          url: z.string().max(2000).optional(),
          example: z.string().max(2000).optional(),
          dynamic: z.boolean().optional(),
        }),
      ).max(10).optional(),
      variable_mapping: z.array(
        z.object({
          index: z.number().int().min(1).max(20),
          field: z.enum([
            "customer_name","customer_phone","customer_email",
            "order_id","order_amount","order_status","order_date",
            "product_name","product_price",
            "tracking_id","tracking_url",
            "store_name","recovery_url","static_text",
          ]),
          static_value: z.string().max(200).optional(),
        }),
      ).max(20).optional(),
    }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    await assertMember(supabase, data.workspace_id, userId, ["owner", "admin"]);
    const s = await getSettings(supabase, data.workspace_id);
    if (!s.waba_id) throw new Error("WABA ID missing");

    const { data: existing, error: exErr } = await supabase
      .from("templates").select("*")
      .eq("id", data.template_id)
      .eq("workspace_id", data.workspace_id)
      .single();
    if (exErr || !existing) throw new Error("Template not found");
    if (existing.status === "APPROVED") {
      return { ok: false as const, error: "Approved templates cannot be edited. Create a new template instead." };
    }

    // Delete existing template on Meta (best-effort; ignore failures so we can still resubmit)
    await fetch(
      `${META_BASE}/${s.waba_id}/message_templates?name=${encodeURIComponent(existing.meta_template_name)}`,
      { method: "DELETE", headers: { Authorization: `Bearer ${s.access_token}` } },
    ).catch(() => null);

    const components: any[] = [];
    if (data.header_type === "TEXT" && data.header_text) {
      components.push({ type: "HEADER", format: "TEXT", text: data.header_text });
    } else if (["IMAGE", "VIDEO", "DOCUMENT"].includes(data.header_type)) {
      if (!data.header_media_url) throw new Error("Header media URL required");
      const appId = process.env.META_APP_ID;
      if (!appId) throw new Error("META_APP_ID not configured on server");

      const mediaRes = await fetch(data.header_media_url);
      if (!mediaRes.ok) throw new Error(`Failed to fetch media URL (${mediaRes.status})`);
      const contentType = mediaRes.headers.get("content-type") || "application/octet-stream";
      const buf = new Uint8Array(await mediaRes.arrayBuffer());
      const fileName = data.header_media_url.split("/").pop()?.split("?")[0] || "upload.bin";

      const sessRes = await fetch(
        `${META_BASE}/${appId}/uploads?file_name=${encodeURIComponent(fileName)}&file_length=${buf.byteLength}&file_type=${encodeURIComponent(contentType)}&access_token=${encodeURIComponent(s.access_token)}`,
        { method: "POST" },
      );
      const sessJson: any = await sessRes.json();
      if (!sessRes.ok || !sessJson.id) {
        return { ok: false as const, error: sessJson?.error?.message || "Failed to start media upload" };
      }
      const upRes = await fetch(`${META_BASE}/${sessJson.id}`, {
        method: "POST",
        headers: { Authorization: `OAuth ${s.access_token}`, file_offset: "0" },
        body: buf,
      });
      const upJson: any = await upRes.json();
      if (!upRes.ok || !upJson.h) {
        return { ok: false as const, error: upJson?.error?.message || "Failed to upload media to Meta" };
      }
      components.push({ type: "HEADER", format: data.header_type, example: { header_handle: [upJson.h] } });
    } else if (data.header_type === "LOCATION") {
      components.push({ type: "HEADER", format: "LOCATION" });
    }

    {
      const varCount = (data.body.match(/\{\{\d+\}\}/g) || []).length;
      const bodyComp: any = { type: "BODY", text: data.body };
      if (varCount > 0) {
        const ex = (data.body_examples || []).slice(0, varCount);
        while (ex.length < varCount) ex.push("sample");
        bodyComp.example = { body_text: [ex] };
      }
      components.push(bodyComp);
    }
    if (data.footer) components.push({ type: "FOOTER", text: data.footer });

    if (data.buttons && data.buttons.length > 0) {
      const buttons = data.buttons.map((b) => {
        if (b.type === "QUICK_REPLY") return { type: "QUICK_REPLY", text: b.text };
        if (b.type === "PHONE_NUMBER") return { type: "PHONE_NUMBER", text: b.text, phone_number: b.phone_number };
        if (b.type === "COPY_CODE") return { type: "COPY_CODE", example: [b.example || ""] };
        if (b.type === "URL") {
          const out: any = { type: "URL", text: b.text, url: b.url };
          if (b.dynamic && b.example) out.example = [b.example];
          return out;
        }
        return b;
      });
      components.push({ type: "BUTTONS", buttons });
    }

    const finalComponents = data.category === "AUTHENTICATION"
      ? buildAuthComponents(data.footer)
      : components;

    const res = await fetch(`${META_BASE}/${s.waba_id}/message_templates`, {
      method: "POST",
      headers: { Authorization: `Bearer ${s.access_token}`, "Content-Type": "application/json" },
      body: JSON.stringify({ name: data.name, language: data.language, category: data.category, components: finalComponents }),
    });
    const json: any = await res.json();
    if (!res.ok) {
      return { ok: false as const, error: json?.error?.error_user_msg || json?.error?.message || "Meta rejected the template" };
    }

    const { error: updErr } = await supabase.from("templates").update({
      meta_template_name: data.name,
      language: data.language,
      category: data.category,
      status: json.status || "PENDING",
      body: data.body,
      components: finalComponents,
      variables_count: (data.body.match(/\{\{\d+\}\}/g) || []).length,
      variable_mapping: data.variable_mapping ?? null,
      synced_at: new Date().toISOString(),
    } as any).eq("id", data.template_id);
    if (updErr) return { ok: false as const, error: updErr.message };

    return { ok: true as const, id: json.id, status: json.status };
  });

// Locks a per-variable field mapping on an existing template WITHOUT
// resubmitting to Meta — so users can map fields on already-APPROVED
// templates (e.g. ones synced from Meta with variables but no mapping yet).
// This is the single source of truth the runtime resolver respects.
export const setTemplateMapping = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z.object({
      workspace_id: z.string().uuid(),
      template_id: z.string().uuid(),
      variable_mapping: z.array(
        z.object({
          index: z.number().int().min(1).max(20),
          field: z.enum([
            "customer_name","customer_phone","customer_email",
            "order_id","order_amount","order_status","order_date",
            "product_name","product_price",
            "tracking_id","tracking_url",
            "store_name","recovery_url","static_text",
          ]),
          static_value: z.string().max(200).optional(),
        }),
      ).min(1).max(20),
    }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    await assertMember(supabase, data.workspace_id, userId, ["owner", "admin"]);

    const { data: tpl, error: tErr } = await supabase
      .from("templates").select("variables_count")
      .eq("id", data.template_id).eq("workspace_id", data.workspace_id).maybeSingle();
    if (tErr || !tpl) return { ok: false as const, error: "Template not found" };

    const expected = Number(tpl.variables_count || 0);
    if (expected > 0) {
      const indexes = new Set(data.variable_mapping.map((e) => e.index));
      for (let i = 1; i <= expected; i++) {
        if (!indexes.has(i)) return { ok: false as const, error: `Field for {{${i}}} is missing` };
      }
      for (const e of data.variable_mapping) {
        if (e.field === "static_text" && !(e.static_value || "").trim()) {
          return { ok: false as const, error: `Static text for {{${e.index}}} is empty` };
        }
      }
    }

    const { error: updErr } = await supabase.from("templates")
      .update({ variable_mapping: data.variable_mapping } as any)
      .eq("id", data.template_id).eq("workspace_id", data.workspace_id);
    if (updErr) return { ok: false as const, error: updErr.message };
    return { ok: true as const };
  });

// Bulk auto-mapping: writes a guessed variable_mapping (from body text +
// Meta-approved example values) for every template in the workspace that
// has no mapping yet. Lets the user clear the "Fields not mapped" warning
// across all templates in one click instead of opening each dialog.
export const autoMapAllTemplates = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z.object({ workspace_id: z.string().uuid() }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    await assertMember(supabase, data.workspace_id, userId, ["owner", "admin"]);

    const { data: rows, error } = await supabase
      .from("templates")
      .select("id, variables_count, variable_mapping, body, components")
      .eq("workspace_id", data.workspace_id);
    if (error) return { ok: false as const, error: error.message, updated: 0 };

    let updated = 0;
    for (const t of (rows as any[]) || []) {
      const count = Number(t.variables_count || 0);
      if (count <= 0) continue;
      if (Array.isArray(t.variable_mapping) && t.variable_mapping.length >= count) continue;
      const mapping = guessTemplateMapping({
        variables_count: count,
        body: t.body,
        components: t.components,
      });
      if (!mapping.length) continue;
      const { error: uErr } = await supabase
        .from("templates")
        .update({ variable_mapping: mapping } as any)
        .eq("id", t.id)
        .eq("workspace_id", data.workspace_id);
      if (!uErr) updated++;
    }
    return { ok: true as const, updated };
  });



async function createCampaignWithRecipients(
  supabase: any,
  userId: string,
  data: {
    workspace_id: string;
    name: string;
    template_id: string;
    contact_ids: string[];
    group_id?: string;
    variables: string[];
    header_media_url?: string;
    scheduled_at?: string | null;
  },
) {
  const { data: tpl, error: tplErr } = await supabase
    .from("templates").select("*")
    .eq("id", data.template_id)
    .eq("workspace_id", data.workspace_id)
    .single();
  if (tplErr || !tpl) throw new Error("Template not found");

  let selectedContactIds = Array.from(new Set(data.contact_ids));
  if (data.group_id) {
    selectedContactIds = [];
    const PAGE = 1000;
    for (let from = 0; ; from += PAGE) {
      const { data: memberRows, error: mErr } = await supabase
        .from("contact_group_members")
        .select("contact_id")
        .eq("workspace_id", data.workspace_id)
        .eq("group_id", data.group_id)
        .range(from, from + PAGE - 1);
      if (mErr) {
        console.error("Campaign group member fetch failed", {
          workspace_id: data.workspace_id,
          group_id: data.group_id,
          page_from: from,
          error: mErr.message,
        });
        throw new Error(mErr.message || "Failed to fetch campaign group contacts");
      }
      const rows = memberRows ?? [];
      selectedContactIds.push(...rows.map((row: any) => row.contact_id).filter(Boolean));
      if (rows.length < PAGE) break;
    }
    selectedContactIds = Array.from(new Set(selectedContactIds));
  }
  if (selectedContactIds.length === 0) throw new Error("Select at least one contact");

  // Fetch selected contacts in chunks. Supabase/PostgREST encodes `.in(...)`
  // filters into the request URL; large campaign groups (hundreds of UUIDs)
  // can exceed URL limits and surface to the user as a generic "Bad Request".
  const contacts: { id: string; name: string; phone: string }[] = [];
  const CONTACT_ID_CHUNK_SIZE = 100;
  for (let i = 0; i < selectedContactIds.length; i += CONTACT_ID_CHUNK_SIZE) {
    const ids = selectedContactIds.slice(i, i + CONTACT_ID_CHUNK_SIZE);
    const { data: chunkContacts, error: cErr } = await supabase
      .from("contacts").select("id,name,phone")
      .in("id", ids)
      .eq("workspace_id", data.workspace_id);
    if (cErr) {
      console.error("Campaign contact fetch failed", {
        workspace_id: data.workspace_id,
        selected_count: selectedContactIds.length,
        chunk_start: i,
        chunk_size: ids.length,
        error: cErr.message,
      });
      throw new Error(cErr.message || "Failed to fetch campaign contacts");
    }
    contacts.push(...((chunkContacts ?? []) as { id: string; name: string; phone: string }[]));
  }

  const isScheduled = !!data.scheduled_at;
  const { data: campaign, error: campErr } = await supabase
    .from("campaigns").insert({
      user_id: userId,
      workspace_id: data.workspace_id,
      name: data.name,
      template_id: tpl.id,
      template_name: tpl.meta_template_name,
      template_language: tpl.language,
      variables: data.variables,
      header_media_url: data.header_media_url || null,
      status: isScheduled ? "scheduled" : "sending",
      scheduled_at: data.scheduled_at || null,
      total_count: contacts.length,
    }).select().single();
  if (campErr || !campaign) throw new Error(campErr?.message || "Failed to create campaign");

  const recipientsByPhone = new Map<string, any>();
  for (const c of contacts) {
    const phoneKey = String(c.phone || "").replace(/\D/g, "");
    if (!phoneKey || recipientsByPhone.has(phoneKey)) continue;
    recipientsByPhone.set(phoneKey, c);
  }

  const recipients = Array.from(recipientsByPhone.values()).map((c: any) => ({
      campaign_id: campaign.id,
      user_id: userId,
      workspace_id: data.workspace_id,
      contact_id: c.id,
      phone: c.phone,
      name: c.name,
      status: "pending",
    }));
  if (recipients.length) {
    const RECIPIENT_INSERT_CHUNK_SIZE = 200;
    for (let i = 0; i < recipients.length; i += RECIPIENT_INSERT_CHUNK_SIZE) {
      const rows = recipients.slice(i, i + RECIPIENT_INSERT_CHUNK_SIZE);
      const { error: rErr } = await supabase.from("campaign_recipients").insert(rows);
      if (rErr) {
        console.error("Campaign recipient insert failed", {
          workspace_id: data.workspace_id,
          campaign_id: campaign.id,
          recipient_count: recipients.length,
          chunk_start: i,
          chunk_size: rows.length,
          error: rErr.message,
        });
        throw new Error(rErr.message || "Failed to create campaign recipients");
      }
    }
  }
  if (recipients.length !== contacts.length) {
    await supabase.from("campaigns").update({ total_count: recipients.length }).eq("id", campaign.id);
  }

  return campaign;
}

export const launchCampaign = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z.object({
      workspace_id: z.string().uuid(),
      name: z.string().min(1).max(120),
      template_id: z.string().uuid(),
      contact_ids: z.array(z.string().uuid()).max(1000).default([]),
      group_id: z.string().uuid().optional(),
      variables: z.array(z.string().max(500)).default([]),
      header_media_url: z.string().url().optional(),
    }).refine((data) => data.contact_ids.length > 0 || !!data.group_id, {
      message: "Select at least one contact",
    }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    await assertMember(supabase, data.workspace_id, userId, ["owner", "admin", "agent"]);
    await getSettings(supabase, data.workspace_id);

    const campaign = await createCampaignWithRecipients(supabase, userId, data);
    const { executeCampaign } = await import("./campaign-executor.server");
    const { sent, failed } = await executeCampaign(supabase, campaign.id);
    return { campaign_id: campaign.id, sent, failed };
  });

export const scheduleCampaign = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z.object({
      workspace_id: z.string().uuid(),
      name: z.string().min(1).max(120),
      template_id: z.string().uuid(),
      contact_ids: z.array(z.string().uuid()).max(1000).default([]),
      group_id: z.string().uuid().optional(),
      variables: z.array(z.string().max(500)).default([]),
      header_media_url: z.string().url().optional(),
      scheduled_at: z.string().datetime(),
    }).refine((data) => data.contact_ids.length > 0 || !!data.group_id, {
      message: "Select at least one contact",
    }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    await assertMember(supabase, data.workspace_id, userId, ["owner", "admin", "agent"]);
    await getSettings(supabase, data.workspace_id);

    const when = new Date(data.scheduled_at).getTime();
    if (isNaN(when) || when <= Date.now()) {
      throw new Error("Scheduled time must be in the future");
    }

    const campaign = await createCampaignWithRecipients(supabase, userId, data);
    return { campaign_id: campaign.id, scheduled_at: data.scheduled_at };
  });

export const cancelScheduledCampaign = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z.object({
      workspace_id: z.string().uuid(),
      campaign_id: z.string().uuid(),
    }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    await assertMember(supabase, data.workspace_id, userId, ["owner", "admin", "agent"]);
    const { error } = await supabase
      .from("campaigns")
      .update({ status: "draft", scheduled_at: null })
      .eq("id", data.campaign_id)
      .eq("workspace_id", data.workspace_id)
      .eq("status", "scheduled");
    if (error) throw new Error(error.message);
    return { ok: true as const };
  });

export const sendScheduledCampaignNow = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z.object({
      workspace_id: z.string().uuid(),
      campaign_id: z.string().uuid(),
    }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    await assertMember(supabase, data.workspace_id, userId, ["owner", "admin", "agent"]);

    // Atomically claim the campaign so the cron can't double-send
    const { data: claimed, error: cErr } = await supabase
      .from("campaigns")
      .update({ status: "sending", scheduled_at: null })
      .eq("id", data.campaign_id)
      .eq("workspace_id", data.workspace_id)
      .in("status", ["scheduled", "draft", "failed"])
      .select("id").maybeSingle();
    if (cErr) throw new Error(cErr.message);
    if (!claimed) throw new Error("Campaign is already sending or completed");

    const { executeCampaign } = await import("./campaign-executor.server");
    const { sent, failed } = await executeCampaign(supabase, data.campaign_id);
    return { ok: true as const, sent, failed };
  });

export const resumeCampaign = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z.object({
      workspace_id: z.string().uuid(),
      campaign_id: z.string().uuid(),
    }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    await assertMember(supabase, data.workspace_id, userId, ["owner", "admin", "agent"]);

    // Allow resume from "sending" (worker timed out) or "failed" (manual retry).
    const { data: claimed, error: cErr } = await supabase
      .from("campaigns")
      .update({ status: "sending", completed_at: null })
      .eq("id", data.campaign_id)
      .eq("workspace_id", data.workspace_id)
      .in("status", ["sending", "failed"])
      .select("id").maybeSingle();
    if (cErr) throw new Error(cErr.message);
    if (!claimed) throw new Error("Campaign is not in a resumable state");

    const { executeCampaign } = await import("./campaign-executor.server");
    const { sent, failed } = await executeCampaign(supabase, data.campaign_id);
    return { ok: true as const, sent, failed };
  });

export const rescheduleCampaign = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z.object({
      workspace_id: z.string().uuid(),
      campaign_id: z.string().uuid(),
      scheduled_at: z.string().datetime(),
    }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    await assertMember(supabase, data.workspace_id, userId, ["owner", "admin", "agent"]);

    const when = new Date(data.scheduled_at).getTime();
    if (isNaN(when) || when <= Date.now()) {
      throw new Error("Scheduled time must be in the future");
    }
    const { error } = await supabase
      .from("campaigns")
      .update({ status: "scheduled", scheduled_at: data.scheduled_at })
      .eq("id", data.campaign_id)
      .eq("workspace_id", data.workspace_id)
      .in("status", ["scheduled", "draft"]);
    if (error) throw new Error(error.message);
    return { ok: true as const, scheduled_at: data.scheduled_at };
  });


