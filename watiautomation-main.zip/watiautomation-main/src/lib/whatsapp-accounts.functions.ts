import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { getWebhookCallbackUrl } from "./whatsapp-webhook-url.server";
import { syncContactsToConversations } from "./contact-conversation-sync.server";

const META_BASE = "https://graph.facebook.com/v21.0";

async function subscribeAppToWaba(opts: {
  wabaId: string;
  accessToken: string;
  phoneNumberId?: string | null;
}): Promise<{ ok: boolean; error: string | null; callback_url: string | null }> {
  const verifyToken = process.env.WHATSAPP_VERIFY_TOKEN;
  const callbackUrl = getWebhookCallbackUrl();
  const overrideBody: Record<string, string> = {};
  if (callbackUrl && verifyToken) {
    overrideBody.override_callback_uri = callbackUrl;
    overrideBody.verify_token = verifyToken;
  }
  try {
    // First subscribe the app without an override. Meta can reject a direct override
    // on existing/provider-migrated numbers until the app is already subscribed.
    const baseRes = await fetch(`${META_BASE}/${opts.wabaId}/subscribed_apps`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${opts.accessToken}`,
        "Content-Type": "application/json",
      },
    });
    if (!baseRes.ok) {
      const j: any = await baseRes.json().catch(() => ({}));
      return {
        ok: false,
        error: j?.error?.message || `subscribed_apps failed (HTTP ${baseRes.status})`,
        callback_url: callbackUrl,
      };
    }

    const errors: string[] = [];
    if (Object.keys(overrideBody).length) {
      const wabaOverrideRes = await fetch(`${META_BASE}/${opts.wabaId}/subscribed_apps`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${opts.accessToken}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify(overrideBody),
      });
      if (!wabaOverrideRes.ok) {
        const j: any = await wabaOverrideRes.json().catch(() => ({}));
        errors.push(
          j?.error?.message || `WABA webhook override failed (HTTP ${wabaOverrideRes.status})`,
        );
      }

      // Existing WhatsApp numbers migrated from another provider can retain a
      // phone-number-level alternate callback. That takes priority over the WABA
      // callback, so set the phone callback too during onboarding and sync.
      if (opts.phoneNumberId) {
        const phoneOverrideRes = await fetch(`${META_BASE}/${opts.phoneNumberId}`, {
          method: "POST",
          headers: {
            Authorization: `Bearer ${opts.accessToken}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ webhook_configuration: overrideBody }),
        });
        if (!phoneOverrideRes.ok) {
          const j: any = await phoneOverrideRes.json().catch(() => ({}));
          errors.push(
            j?.error?.message || `Phone webhook override failed (HTTP ${phoneOverrideRes.status})`,
          );
        }
      }
    }

    return {
      ok: errors.length === 0,
      error: errors.join(" • ") || null,
      callback_url: callbackUrl,
    };
  } catch (e: any) {
    return {
      ok: false,
      error: e?.message || "subscribed_apps network error",
      callback_url: callbackUrl,
    };
  }
}

async function requestSmbAppData(opts: {
  phoneNumberId?: string | null;
  accessToken: string;
  syncType: "smb_app_state_sync" | "history";
}): Promise<{ request_id: string | null; error: string | null }> {
  if (!opts.phoneNumberId) return { request_id: null, error: "Missing phone number ID" };
  try {
    const res = await fetch(`${META_BASE}/${opts.phoneNumberId}/smb_app_data`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${opts.accessToken}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ messaging_product: "whatsapp", sync_type: opts.syncType }),
    });
    const json: any = await res.json().catch(() => ({}));
    if (!res.ok) {
      return {
        request_id: null,
        error: json?.error?.message || `${opts.syncType} sync failed (HTTP ${res.status})`,
      };
    }
    return { request_id: json?.request_id ?? null, error: null };
  } catch (e: any) {
    return { request_id: null, error: e?.message || `${opts.syncType} sync network error` };
  }
}

// Lookup a phone number's display_phone_number / verified_name from the WABA's phone_numbers list.
// This is used as a fallback because GET /{phone_number_id} sometimes returns an empty
// display_phone_number for existing/pre-onboarded WABAs until the number is (re)registered.

// Meta omits `messaging_limit_tier` for numbers without an assigned tier, but
// still returns `throughput.level` (STANDARD / HIGH). Derive a displayable tier.
function resolveMessagingTier(info: any, fallback?: string | null): string {
  if (info?.messaging_limit_tier) return String(info.messaging_limit_tier);
  const level = info?.throughput?.level;
  if (level) return `TIER_${String(level)}`;
  return fallback || "TIER_NOT_SET";
}

// Meta returns name_status = NON_EXISTS when there is no *pending* display-name
// review — which is also the case for numbers whose name is already live (set via
// the WhatsApp Business app / Business Manager). If a verified_name exists, the
// display name is in use, so report it as APPROVED instead of NON_EXISTS.
function resolveNameStatus(
  info: any,
  verifiedName: string | null | undefined,
  fallback?: string | null,
): string {
  const status = info?.name_status ?? fallback ?? null;
  if (verifiedName && (!status || status === "NON_EXISTS" || status === "NONE")) {
    return "APPROVED";
  }
  return status || "APPROVED";
}

async function lookupPhoneNumberFromWaba(opts: {
  wabaId: string;
  phoneNumberId: string;
  accessToken: string;
}): Promise<{ display_phone_number: string | null; verified_name: string | null }> {
  try {
    const res = await fetch(
      `${META_BASE}/${opts.wabaId}/phone_numbers?fields=id,display_phone_number,verified_name,quality_rating,name_status,messaging_limit_tier,throughput`,
      { headers: { Authorization: `Bearer ${opts.accessToken}` } },
    );
    const json: any = await res.json();
    if (!res.ok) return { display_phone_number: null, verified_name: null };
    const list: any[] = json?.data || [];
    const match = list.find((p) => String(p.id) === String(opts.phoneNumberId)) || list[0];
    return {
      display_phone_number: match?.display_phone_number ?? null,
      verified_name: match?.verified_name ?? null,
    };
  } catch {
    return { display_phone_number: null, verified_name: null };
  }
}

// Shared helper: subscribe app to WABA + pull templates. Best-effort.
async function autoBootstrapAccount(opts: {
  supabase: any;
  userId: string;
  workspaceId: string;
  wabaId: string;
  phoneNumberId?: string | null;
  accessToken: string;
}): Promise<{
  webhook_status: string;
  webhook_error: string | null;
  webhook_callback_url: string | null;
  template_count: number;
  smb_sync: Record<string, string | null>;
}> {
  const sub = await subscribeAppToWaba({
    wabaId: opts.wabaId,
    phoneNumberId: opts.phoneNumberId,
    accessToken: opts.accessToken,
  });
  const webhook_status = sub.ok ? "subscribed" : "error";
  const contactsSync = await requestSmbAppData({
    phoneNumberId: opts.phoneNumberId,
    accessToken: opts.accessToken,
    syncType: "smb_app_state_sync",
  });
  const historySync = await requestSmbAppData({
    phoneNumberId: opts.phoneNumberId,
    accessToken: opts.accessToken,
    syncType: "history",
  });

  let template_count = 0;
  try {
    const tRes = await fetch(`${META_BASE}/${opts.wabaId}/message_templates?limit=200`, {
      headers: { Authorization: `Bearer ${opts.accessToken}` },
    });
    const tJson: any = await tRes.json();
    if (tRes.ok) {
      const rows = (tJson.data || []).map((t: any) => {
        const body = t.components?.find((c: any) => c.type === "BODY")?.text || "";
        const vars = (body.match(/\{\{\d+\}\}/g) || []).length;
        return {
          user_id: opts.userId,
          workspace_id: opts.workspaceId,
          meta_template_name: t.name,
          language: t.language,
          category: t.category,
          status: t.status,
          body,
          components: t.components,
          variables_count: vars,
          synced_at: new Date().toISOString(),
        };
      });
      if (rows.length) {
        await opts.supabase.from("templates").delete().eq("workspace_id", opts.workspaceId);
        await opts.supabase.from("templates").insert(rows);
        template_count = rows.length;
      }
    }
  } catch {}

  return {
    webhook_status,
    webhook_error: [sub.error, contactsSync.error, historySync.error].filter(Boolean).join(" • ") || null,
    webhook_callback_url: sub.callback_url,
    template_count,
    smb_sync: {
      contacts_request_id: contactsSync.request_id,
      contacts_error: contactsSync.error,
      history_request_id: historySync.request_id,
      history_error: historySync.error,
    },
  };
}

export const getEmbeddedSignupConfig = createServerFn({ method: "GET" }).handler(async () => {
  return {
    app_id: process.env.META_APP_ID || "",
    config_id: process.env.META_ES_CONFIG_ID || "",
  };
});

export const getWebhookConfig = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async () => {
    return {
      verify_token: process.env.WHATSAPP_VERIFY_TOKEN || "",
      configured: !!process.env.WHATSAPP_VERIFY_TOKEN,
    };
  });

export const finishEmbeddedSignup = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z
      .object({
        workspace_id: z.string().uuid(),
        code: z.string().min(10).max(2048),
        waba_id: z.string().max(64).optional().nullable(),
        phone_number_id: z.string().max(64).optional().nullable(),
        business_id: z.string().max(64).optional().nullable(),
        set_active: z.boolean().default(true),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    await assertAdmin(supabase, data.workspace_id, userId);

    const appId = process.env.META_APP_ID;
    const appSecret = process.env.META_APP_SECRET;
    if (!appId || !appSecret) {
      return {
        ok: false as const,
        error: "Meta app credentials are not configured on the server.",
      };
    }

    const tokenUrl = `${META_BASE}/oauth/access_token?client_id=${encodeURIComponent(appId)}&client_secret=${encodeURIComponent(appSecret)}&code=${encodeURIComponent(data.code)}`;
    const tRes = await fetch(tokenUrl);
    const tJson: any = await tRes.json();
    if (!tRes.ok || !tJson.access_token) {
      return {
        ok: false as const,
        error: tJson?.error?.message || "Failed to exchange code for access token.",
      };
    }
    const accessToken: string = tJson.access_token;

    // Discover WABA IDs from token if client didn't get them via postMessage
    let wabaId = data.waba_id || null;
    let phoneNumberId = data.phone_number_id || null;

    if (!wabaId) {
      try {
        const dbg = await fetch(
          `${META_BASE}/debug_token?input_token=${encodeURIComponent(accessToken)}&access_token=${encodeURIComponent(appId + "|" + appSecret)}`,
        );
        const dbgJson: any = await dbg.json();
        const scopes = dbgJson?.data?.granular_scopes || [];
        const wa = scopes.find(
          (s: any) =>
            s.scope === "whatsapp_business_management" || s.scope === "whatsapp_business_messaging",
        );
        if (wa?.target_ids?.length) wabaId = wa.target_ids[0];
      } catch {}
    }

    if (!wabaId) {
      // Last resort: list WABAs owned by user's businesses
      try {
        const bRes = await fetch(
          `${META_BASE}/me/businesses?fields=id,owned_whatsapp_business_accounts{id,name}`,
          {
            headers: { Authorization: `Bearer ${accessToken}` },
          },
        );
        const bJson: any = await bRes.json();
        for (const biz of bJson?.data || []) {
          const w = biz?.owned_whatsapp_business_accounts?.data?.[0];
          if (w?.id) {
            wabaId = w.id;
            break;
          }
        }
      } catch {}
    }

    if (!wabaId) {
      return {
        ok: false as const,
        error:
          "Couldn't find a WhatsApp Business Account on your Meta profile. Please complete every step of the popup.",
      };
    }

    if (!phoneNumberId) {
      try {
        const pRes = await fetch(
          `${META_BASE}/${wabaId}/phone_numbers?fields=id,display_phone_number,verified_name`,
          {
            headers: { Authorization: `Bearer ${accessToken}` },
          },
        );
        const pJson: any = await pRes.json();
        const first = pJson?.data?.[0];
        if (first?.id) phoneNumberId = first.id;
      } catch {}
    }

    if (!phoneNumberId) {
      return {
        ok: false as const,
        error:
          "No phone number was found on your WhatsApp Business Account. Please add one in Meta and retry.",
      };
    }

    await subscribeAppToWaba({ wabaId, phoneNumberId, accessToken });

    const pin = String(Math.floor(100000 + Math.random() * 900000));
    let registerError: string | null = null;
    try {
      const regRes = await fetch(`${META_BASE}/${phoneNumberId}/register`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${accessToken}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ messaging_product: "whatsapp", pin }),
      });
      if (!regRes.ok) {
        const rj: any = await regRes.json().catch(() => ({}));
        registerError = rj?.error?.message || `Cloud API register failed (HTTP ${regRes.status})`;
      }
    } catch (e: any) {
      registerError = e?.message || "Cloud API register network error";
    }

    const infoRes = await fetch(
      `${META_BASE}/${phoneNumberId}?fields=display_phone_number,verified_name,quality_rating,name_status,messaging_limit_tier,throughput`,
      { headers: { Authorization: `Bearer ${accessToken}` } },
    );
    const info: any = await infoRes.json();
    if (!infoRes.ok) {
      return {
        ok: false as const,
        error: info?.error?.message || "Could not fetch phone number info from Meta.",
      };
    }

    let business_name: string | null = null;
    try {
      const wRes = await fetch(`${META_BASE}/${wabaId}?fields=name`, {
        headers: { Authorization: `Bearer ${accessToken}` },
      });
      const wJson: any = await wRes.json();
      if (wRes.ok) business_name = wJson.name || null;
    } catch {}

    // Fallback: if Meta didn't return the display number on the phone node, grab it from the WABA list
    let displayPhone: string | null = info.display_phone_number ?? null;
    let verifiedName: string | null = info.verified_name ?? null;
    if (!displayPhone || !verifiedName) {
      const fb = await lookupPhoneNumberFromWaba({
        wabaId: wabaId!,
        phoneNumberId: phoneNumberId!,
        accessToken,
      });
      if (!displayPhone) displayPhone = fb.display_phone_number;
      if (!verifiedName) verifiedName = fb.verified_name;
    }

    if (data.set_active) {
      await supabase
        .from("whatsapp_accounts")
        .update({ is_active: false })
        .eq("workspace_id", data.workspace_id);
    }

    const boot = await autoBootstrapAccount({
      supabase,
      userId,
      workspaceId: data.workspace_id,
      wabaId,
      phoneNumberId,
      accessToken,
    });

    const combinedError = [boot.webhook_error, registerError].filter(Boolean).join(" • ") || null;

    const row = {
      workspace_id: data.workspace_id,
      connected_by: userId,
      phone_number_id: phoneNumberId,
      waba_id: wabaId,
      access_token: accessToken,
      business_name,
      display_name: verifiedName,
      phone_number: displayPhone,
      quality_rating: info.quality_rating ?? "UNKNOWN",
      messaging_tier: resolveMessagingTier(info),
      display_name_status: resolveNameStatus(info, verifiedName),
      status: registerError ? "pending" : "connected",
      webhook_status: boot.webhook_status,
      sync_status: "synced",
      is_active: data.set_active,
      last_synced_at: new Date().toISOString(),
      last_error: combinedError,
      meta: {
        connection_source: "embedded_signup",
        business_id: data.business_id ?? null,
        register_pin: pin,
        register_error: registerError,
        webhook_error: boot.webhook_error,
        webhook_callback_url: boot.webhook_callback_url,
        smb_sync: boot.smb_sync,
      },
    };

    const { data: saved, error } = await supabase
      .from("whatsapp_accounts")
      .upsert(row, { onConflict: "workspace_id,phone_number_id" })
      .select()
      .single();
    if (error) return { ok: false as const, error: error.message };

    await supabase.from("whatsapp_settings").upsert(
      {
        user_id: userId,
        workspace_id: data.workspace_id,
        phone_number_id: phoneNumberId,
        waba_id: wabaId,
        access_token: accessToken,
        business_phone: displayPhone,
        display_name: verifiedName,
        verified: true,
        updated_at: new Date().toISOString(),
      },
      { onConflict: "workspace_id" },
    );

    if (combinedError) {
      await supabase.from("integration_debug_logs").insert({
        workspace_id: data.workspace_id,
        provider: "whatsapp",
        event: "setup.warning",
        direction: "out",
        ok: false,
        status_code: 0,
        message: combinedError,
        payload: { phone_number_id: phoneNumberId, waba_id: wabaId, register_error: registerError, webhook_error: boot.webhook_error, webhook_callback_url: boot.webhook_callback_url },
      }).then(() => {}, () => {});
    }

    const contactSync = await syncContactsToConversations({
      supabase,
      workspaceId: data.workspace_id,
    });

    return {
      ok: true as const,
      account: saved,
      template_count: boot.template_count,
      contact_sync: contactSync,
      warning: combinedError,
      needs_register: !!registerError,
    };
  });

async function assertAdmin(supabase: any, workspaceId: string, userId: string) {
  const { data } = await supabase
    .from("workspace_members")
    .select("role")
    .eq("workspace_id", workspaceId)
    .eq("user_id", userId)
    .maybeSingle();
  if (!data || !["owner", "admin"].includes(data.role)) {
    throw new Error("Only owners and admins can manage WhatsApp accounts");
  }
}

export const connectWhatsAppAccount = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z
      .object({
        workspace_id: z.string().uuid(),
        phone_number_id: z.string().min(3).max(64),
        waba_id: z.string().min(3).max(64),
        access_token: z.string().min(20).max(4096),
        set_active: z.boolean().default(true),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    await assertAdmin(supabase, data.workspace_id, userId);

    // Verify with Meta Graph API
    const res = await fetch(
      `${META_BASE}/${data.phone_number_id}?fields=display_phone_number,verified_name,quality_rating,name_status,messaging_limit_tier,throughput`,
      { headers: { Authorization: `Bearer ${data.access_token}` } },
    );
    const info: any = await res.json();
    if (!res.ok) {
      return {
        ok: false as const,
        error:
          info?.error?.message ||
          "Meta rejected the credentials. Please reconnect via Embedded Signup.",
      };
    }

    // Fetch WABA business name
    let business_name: string | null = null;
    try {
      const wRes = await fetch(`${META_BASE}/${data.waba_id}?fields=name`, {
        headers: { Authorization: `Bearer ${data.access_token}` },
      });
      const wJson: any = await wRes.json();
      if (wRes.ok) business_name = wJson.name || null;
    } catch {}

    // Fallback if Meta omitted display_phone_number on the phone node (common for existing WABAs)
    let displayPhone: string | null = info.display_phone_number ?? null;
    let verifiedName: string | null = info.verified_name ?? null;
    if (!displayPhone || !verifiedName) {
      const fb = await lookupPhoneNumberFromWaba({
        wabaId: data.waba_id,
        phoneNumberId: data.phone_number_id,
        accessToken: data.access_token,
      });
      if (!displayPhone) displayPhone = fb.display_phone_number;
      if (!verifiedName) verifiedName = fb.verified_name;
    }

    if (data.set_active) {
      await supabase
        .from("whatsapp_accounts")
        .update({ is_active: false })
        .eq("workspace_id", data.workspace_id);
    }

    // Auto: subscribe webhook + pull templates
    const boot = await autoBootstrapAccount({
      supabase,
      userId,
      workspaceId: data.workspace_id,
      wabaId: data.waba_id,
      phoneNumberId: data.phone_number_id,
      accessToken: data.access_token,
    });

    const row = {
      workspace_id: data.workspace_id,
      connected_by: userId,
      phone_number_id: data.phone_number_id,
      waba_id: data.waba_id,
      access_token: data.access_token,
      business_name,
      display_name: verifiedName,
      phone_number: displayPhone,
      quality_rating: info.quality_rating ?? "UNKNOWN",
      messaging_tier: resolveMessagingTier(info),
      display_name_status: resolveNameStatus(info, verifiedName),
      status: "connected",
      webhook_status: boot.webhook_status,
      sync_status: "synced",
      is_active: data.set_active,
      last_synced_at: new Date().toISOString(),
      meta: {
        webhook_callback_url: boot.webhook_callback_url,
        webhook_error: boot.webhook_error,
        smb_sync: boot.smb_sync,
      },
    };

    const { data: saved, error } = await supabase
      .from("whatsapp_accounts")
      .upsert(row, { onConflict: "workspace_id,phone_number_id" })
      .select()
      .single();
    if (error) return { ok: false as const, error: error.message };

    // Mirror into singleton whatsapp_settings so the rest of the app keeps working
    await supabase.from("whatsapp_settings").upsert(
      {
        user_id: userId,
        workspace_id: data.workspace_id,
        phone_number_id: data.phone_number_id,
        waba_id: data.waba_id,
        access_token: data.access_token,
        business_phone: displayPhone,
        display_name: verifiedName,
        verified: true,
        updated_at: new Date().toISOString(),
      },
      { onConflict: "workspace_id" },
    );

    const contactSync = await syncContactsToConversations({
      supabase,
      workspaceId: data.workspace_id,
    });

    return {
      ok: true as const,
      account: saved,
      template_count: boot.template_count,
      contact_sync: contactSync,
    };
  });

export const connectTechProvider = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z
      .object({
        workspace_id: z.string().uuid(),
        provider: z.string().min(2).max(64),
        phone_number: z.string().min(5).max(32),
        phone_number_id: z.string().min(2).max(64),
        waba_id: z.string().min(2).max(64),
        api_key: z.string().min(8).max(4096),
        api_endpoint: z.string().max(512).optional().nullable(),
        display_name: z.string().max(128).optional().nullable(),
        business_portfolio_id: z.string().max(64).optional().nullable(),
        meta_access_token: z.string().max(4096).optional().nullable(),
        connection_source: z.string().max(64).optional().nullable(),
        set_active: z.boolean().default(true),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    await assertAdmin(supabase, data.workspace_id, userId);

    if (data.set_active) {
      await supabase
        .from("whatsapp_accounts")
        .update({ is_active: false })
        .eq("workspace_id", data.workspace_id);
    }

    const row = {
      workspace_id: data.workspace_id,
      connected_by: userId,
      phone_number_id: data.phone_number_id,
      waba_id: data.waba_id,
      access_token: data.api_key,
      business_name: `${data.provider} (Tech Provider)`,
      display_name: data.display_name ?? null,
      phone_number: data.phone_number,
      quality_rating: "UNKNOWN",
      messaging_tier: "TIER_NOT_SET",
      display_name_status: "APPROVED",
      status: "connected",
      webhook_status: "pending",
      sync_status: "idle",
      is_active: data.set_active,
      last_synced_at: new Date().toISOString(),
      meta: {
        provider: data.provider,
        api_endpoint: data.api_endpoint ?? null,
        business_portfolio_id: data.business_portfolio_id ?? null,
        meta_access_token: data.meta_access_token ?? null,
        connection_source: data.connection_source ?? "tech_provider",
      },
    };

    const { data: saved, error } = await supabase
      .from("whatsapp_accounts")
      .upsert(row, { onConflict: "workspace_id,phone_number_id" })
      .select()
      .single();
    if (error) return { ok: false as const, error: error.message };

    await supabase.from("whatsapp_settings").upsert(
      {
        user_id: userId,
        workspace_id: data.workspace_id,
        phone_number_id: data.phone_number_id,
        waba_id: data.waba_id,
        access_token: data.meta_access_token || data.api_key,
        business_phone: data.phone_number,
        display_name: data.display_name ?? null,
        verified: true,
        updated_at: new Date().toISOString(),
      },
      { onConflict: "workspace_id" },
    );

    return { ok: true as const, account: saved, provider: data.provider };
  });

export const syncWhatsAppAccount = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) => z.object({ account_id: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { data: acc } = await supabase
      .from("whatsapp_accounts")
      .select("*")
      .eq("id", data.account_id)
      .maybeSingle();
    if (!acc) throw new Error("Account not found");
    await assertAdmin(supabase, acc.workspace_id, userId);

    const res = await fetch(
      `${META_BASE}/${acc.phone_number_id}?fields=display_phone_number,verified_name,quality_rating,name_status,messaging_limit_tier,throughput`,
      { headers: { Authorization: `Bearer ${acc.access_token}` } },
    );
    const info: any = await res.json();
    if (!res.ok) {
      await supabase
        .from("whatsapp_accounts")
        .update({
          status: "error",
          last_error: info?.error?.message || "Sync failed",
          sync_status: "failed",
          last_synced_at: new Date().toISOString(),
        })
        .eq("id", acc.id);
      return { ok: false as const, error: info?.error?.message || "Sync failed" };
    }

    // Sync templates (best effort)
    let template_count = 0;
    try {
      const tRes = await fetch(`${META_BASE}/${acc.waba_id}/message_templates?limit=200`, {
        headers: { Authorization: `Bearer ${acc.access_token}` },
      });
      const tJson: any = await tRes.json();
      if (tRes.ok) {
        const rows = (tJson.data || []).map((t: any) => {
          const body = t.components?.find((c: any) => c.type === "BODY")?.text || "";
          const vars = (body.match(/\{\{\d+\}\}/g) || []).length;
          return {
            user_id: userId,
            workspace_id: acc.workspace_id,
            meta_template_name: t.name,
            language: t.language,
            category: t.category,
            status: t.status,
            body,
            components: t.components,
            variables_count: vars,
            synced_at: new Date().toISOString(),
          };
        });
        if (rows.length) {
          await supabase.from("templates").delete().eq("workspace_id", acc.workspace_id);
          await supabase.from("templates").insert(rows);
          template_count = rows.length;
        }
      }
    } catch {}

    // (Re)subscribe our app to webhook events on this WABA
    const sub = await subscribeAppToWaba({
      wabaId: acc.waba_id,
      phoneNumberId: acc.phone_number_id,
      accessToken: acc.access_token,
    });
    const webhook_status: string = sub.ok ? "subscribed" : "error";

    // Fallback fetch if Meta omitted display_phone_number on the phone node
    let displayPhone: string | null = info.display_phone_number ?? null;
    let verifiedName: string | null = info.verified_name ?? null;
    if (!displayPhone || !verifiedName) {
      const fb = await lookupPhoneNumberFromWaba({
        wabaId: acc.waba_id,
        phoneNumberId: acc.phone_number_id,
        accessToken: acc.access_token,
      });
      if (!displayPhone) displayPhone = fb.display_phone_number;
      if (!verifiedName) verifiedName = fb.verified_name;
    }

    await supabase
      .from("whatsapp_accounts")
      .update({
        status: "connected",
        sync_status: "synced",
        webhook_status,
        last_error: sub.error,
        last_synced_at: new Date().toISOString(),
        quality_rating: info.quality_rating ?? acc.quality_rating,
        messaging_tier: resolveMessagingTier(info, acc.messaging_tier),
        display_name_status: resolveNameStatus(info, verifiedName ?? acc.display_name, acc.display_name_status),
        display_name: verifiedName ?? acc.display_name,
        phone_number: displayPhone ?? acc.phone_number,
        meta: {
          ...((acc as any).meta || {}),
          webhook_callback_url: sub.callback_url,
          webhook_error: sub.error,
        },
      })
      .eq("id", acc.id);

    // Also mirror into whatsapp_settings if this is the active account
    if (acc.is_active) {
      await supabase.from("whatsapp_settings").upsert(
        {
          user_id: userId,
          workspace_id: acc.workspace_id,
          phone_number_id: acc.phone_number_id,
          waba_id: acc.waba_id,
          access_token: acc.access_token,
          business_phone: displayPhone ?? acc.phone_number,
          display_name: verifiedName ?? acc.display_name,
          verified: true,
          updated_at: new Date().toISOString(),
        },
        { onConflict: "workspace_id" },
      );
    }

    const contactSync = await syncContactsToConversations({
      supabase,
      workspaceId: acc.workspace_id,
    });

    return { ok: sub.ok as boolean, template_count, contact_sync: contactSync, error: sub.error, webhook_callback_url: sub.callback_url };
  });

export const setActiveWhatsAppAccount = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) => z.object({ account_id: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { data: acc } = await supabase
      .from("whatsapp_accounts")
      .select("*")
      .eq("id", data.account_id)
      .maybeSingle();
    if (!acc) throw new Error("Account not found");
    await assertAdmin(supabase, acc.workspace_id, userId);

    await supabase
      .from("whatsapp_accounts")
      .update({ is_active: false })
      .eq("workspace_id", acc.workspace_id);
    await supabase.from("whatsapp_accounts").update({ is_active: true }).eq("id", acc.id);

    await supabase.from("whatsapp_settings").upsert(
      {
        user_id: userId,
        workspace_id: acc.workspace_id,
        phone_number_id: acc.phone_number_id,
        waba_id: acc.waba_id,
        access_token: acc.access_token,
        business_phone: acc.phone_number,
        display_name: acc.display_name,
        verified: true,
        updated_at: new Date().toISOString(),
      },
      { onConflict: "workspace_id" },
    );

    return { ok: true as const };
  });

export const disconnectWhatsAppAccount = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) => z.object({ account_id: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { data: acc } = await supabase
      .from("whatsapp_accounts")
      .select("workspace_id")
      .eq("id", data.account_id)
      .maybeSingle();
    if (!acc) throw new Error("Account not found");
    await assertAdmin(supabase, acc.workspace_id, userId);

    const { error } = await supabase.from("whatsapp_accounts").delete().eq("id", data.account_id);
    if (error) throw new Error(error.message);
    return { ok: true as const };
  });

export const registerWhatsAppPhoneNumber = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z
      .object({
        account_id: z.string().uuid(),
        pin: z
          .string()
          .regex(/^\d{6}$/)
          .optional(),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { data: acc } = await supabase
      .from("whatsapp_accounts")
      .select("*")
      .eq("id", data.account_id)
      .maybeSingle();
    if (!acc) throw new Error("Account not found");
    await assertAdmin(supabase, acc.workspace_id, userId);

    const pin = data.pin || String(Math.floor(100000 + Math.random() * 900000));

    // 1. Subscribe app to the WABA (idempotent)
    const sub = await subscribeAppToWaba({
      wabaId: acc.waba_id,
      phoneNumberId: acc.phone_number_id,
      accessToken: acc.access_token,
    });

    // 2. Register the phone number with Cloud API
    const res = await fetch(`${META_BASE}/${acc.phone_number_id}/register`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${acc.access_token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ messaging_product: "whatsapp", pin }),
    });
    const json: any = await res.json().catch(() => ({}));
    if (!res.ok || json?.error) {
      const msg = json?.error?.message || `Meta /register failed (HTTP ${res.status})`;
      await supabase
        .from("whatsapp_accounts")
        .update({
          status: "error",
          last_error: msg,
        })
        .eq("id", acc.id);
      return { ok: false as const, error: msg };
    }

    await supabase
      .from("whatsapp_accounts")
      .update({
        status: "connected",
        webhook_status: sub.ok ? "subscribed" : "error",
        last_error: sub.error,
        meta: {
          ...((acc as any).meta || {}),
          register_pin: pin,
          registered_at: new Date().toISOString(),
          webhook_callback_url: sub.callback_url,
          webhook_error: sub.error,
        },
      })
      .eq("id", acc.id);

    return { ok: true as const, pin };
  });
