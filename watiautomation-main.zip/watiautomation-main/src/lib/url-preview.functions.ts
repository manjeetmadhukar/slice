import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

/**
 * Template-builder helper: checks whether a preview URL is reachable and,
 * for Slice short links, reports where it would redirect.
 * Read-only — never records clicks or analytics.
 */
export const checkPreviewUrl = createServerFn({ method: "POST" })
  .inputValidator((data) => z.object({ url: z.string().min(1).max(2000) }).parse(data))
  .handler(async ({ data }) => {
    let target: URL;
    try {
      target = new URL(data.url);
    } catch {
      return { ok: false, status: 0, error: "That isn't a valid URL." } as const;
    }
    if (target.protocol !== "https:" && target.protocol !== "http:") {
      return { ok: false, status: 0, error: "URL must start with http:// or https://" } as const;
    }
    if (/\{\{\s*\d+\s*\}\}/.test(data.url)) {
      return { ok: false, status: 0, error: "URL still contains a {{n}} placeholder." } as const;
    }

    try {
      const res = await fetch(target.toString(), {
        method: "GET",
        redirect: "manual",
        headers: { "User-Agent": "SliceTemplatePreview/1.0" },
      });
      const location = res.headers.get("location");
      if (res.status >= 300 && res.status < 400 && location) {
        return { ok: true, status: res.status, redirectsTo: location } as const;
      }
      if (res.status >= 400) {
        return {
          ok: false,
          status: res.status,
          error:
            res.status === 404
              ? "The link returned 404 — the token or path doesn't resolve."
              : res.status === 410
                ? "The link has expired (410)."
                : `The link returned HTTP ${res.status}.`,
        } as const;
      }
      return { ok: true, status: res.status, redirectsTo: null } as const;
    } catch (e: any) {
      return { ok: false, status: 0, error: `Could not reach the URL: ${e?.message || "network error"}` } as const;
    }
  });
