// Central feature catalog.
// RULE: Any new feature added to the app MUST be registered here so it appears
// automatically in Workspaces & Plans, Plan Library, Plan Requests, and Users
// (per-workspace feature toggles). Gate nav/routes via hasFeature(key).

export interface FeatureDef {
  key: string;
  label: string;
  description?: string;
}

export const FEATURE_CATALOG: FeatureDef[] = [
  { key: "inbox", label: "Inbox", description: "Unified WhatsApp inbox" },
  { key: "contacts", label: "Contacts", description: "Contact management & groups" },
  { key: "pipeline", label: "Pipeline", description: "Sales pipeline & deals" },
  { key: "follow_ups", label: "Follow-ups", description: "Tasks & reminders" },
  { key: "commerce", label: "Commerce", description: "Orders & abandoned carts" },
  { key: "templates", label: "Templates", description: "WhatsApp message templates" },
  { key: "campaigns", label: "Campaigns", description: "Bulk broadcast campaigns" },
  { key: "remarketing", label: "Remarketing", description: "Remarketing automations" },
  { key: "automations", label: "Automations", description: "Keyword & event triggers" },
  { key: "bots", label: "AI Bots", description: "Visual AI bot flow builder" },
  { key: "analytics", label: "Analytics", description: "Reports & insights" },
  { key: "integrations", label: "Integrations", description: "Third-party integrations" },
  { key: "ai", label: "AI Assist", description: "AI-powered assistance" },
  { key: "payments", label: "Payments & Billing", description: "Self-serve paid plans via Razorpay, Cashfree, Instamojo & Stripe" },
  { key: "reseller_program", label: "Reseller Program", description: "White-label reseller account: brand, sub-customers & commissions" },
  { key: "webhooks_zapier", label: "Webhooks & Zapier", description: "Connect Slice to 5000+ tools via webhooks and Zapier" },
  { key: "lead_intake", label: "Lead Intake", description: "Capture leads from Meta Ads & WordPress forms into the CRM pipeline" },
  { key: "meta_lead_ads", label: "Facebook Lead Ads", description: "Direct Facebook Lead Ads OAuth connection with per-form lead routing to agents, stages & tags" },
  { key: "ai_credits", label: "AI Credits", description: "Per-workspace AI credit balance, usage tracking, low-balance warnings and admin recharge" },
  { key: "interested_leads", label: "Interested Leads", description: "Track WhatsApp template Quick Reply button clicks (e.g. \"Interested\") with reports, filters and CSV/Excel exports" },
  { key: "browse_recovery", label: "Browse Recovery", description: "Track product views on Shopify/WooCommerce and auto-send WhatsApp reminders when identified visitors don't add to cart" },
];

export const FEATURE_KEYS = FEATURE_CATALOG.map((f) => f.key);

export const FEATURE_LABELS: Record<string, string> = Object.fromEntries(
  FEATURE_CATALOG.map((f) => [f.key, f.label]),
);

export interface LimitDef {
  key: string;
  label: string;
}

export const LIMIT_CATALOG: LimitDef[] = [
  { key: "whatsapp_numbers", label: "WhatsApp numbers" },
  { key: "team_members", label: "Team members" },
  { key: "contacts", label: "Contacts" },
  { key: "messages_per_month", label: "Messages / month" },
  { key: "campaigns_per_month", label: "Broadcast campaigns / month" },
  { key: "automation_flows", label: "Automation flows" },
  { key: "ai_bot_sessions", label: "AI bot sessions / month" },
  { key: "shopify_stores", label: "Shopify stores" },
  { key: "woocommerce_stores", label: "WooCommerce stores" },
  { key: "reseller_max_customers", label: "Reseller sub-customers" },
];


// Supported payment gateway providers
export const PAYMENT_PROVIDERS = [
  { key: "razorpay", label: "Razorpay", region: "India" },
  { key: "cashfree", label: "Cashfree", region: "India" },
  { key: "instamojo", label: "Instamojo", region: "India" },
  { key: "stripe", label: "Stripe", region: "Global" },
] as const;

export type PaymentProvider = (typeof PAYMENT_PROVIDERS)[number]["key"];

export const SUPPORTED_CURRENCIES = ["INR", "USD", "AED"] as const;
export type SupportedCurrency = (typeof SUPPORTED_CURRENCIES)[number];
