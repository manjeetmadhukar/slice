import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const META_BASE = "https://graph.facebook.com/v21.0";

type FieldKey = "name" | "orderNumber" | "storeName" | "amount" | "trackingId" | "trackingUrl" | "productName" | "productPrice" | "orderStatus" | "orderDate" | "customerEmail" | "customerPhone" | "url";

function sanitizeParam(v: unknown) {
  const s = String(v ?? "").replace(/[\r\n\t]+/g, " ").replace(/ {4,}/g, "   ").trim();
  return s.length ? s : "-";
}

// Builds Meta `components` array based on the template's component schema.
// Handles HEADER (TEXT/IMAGE/VIDEO/DOCUMENT) so we don't trip error #132012
// "header component parameter should not be empty".
// Emits a Meta button-component parameter for any BUTTONS entry that has a
// URL button with a dynamic `{{N}}` suffix. Without this, Meta rejects the
// send with error #132000 "Number of parameters does not match" because the
// template declares a dynamic URL but the request carries no value for it.
function appendUrlButtonParams(out: any[], schema: any[], urlButtonValue?: string | null) {
  const buttonsComp = schema.find((c: any) => String(c?.type || "").toUpperCase() === "BUTTONS");
  const buttons = Array.isArray(buttonsComp?.buttons) ? buttonsComp.buttons : [];
  for (let i = 0; i < buttons.length; i++) {
    const btn = buttons[i];
    if (String(btn?.type || "").toUpperCase() !== "URL") continue;
    const urlTmpl = String(btn?.url || "");
    const m = urlTmpl.match(/^(.*?)\{\{\s*\d+\s*\}\}/);
    if (!m) continue;
    const prefix = m[1];
    let suffix = "";
    if (urlButtonValue) {
      if (urlButtonValue.startsWith(prefix)) {
        suffix = urlButtonValue.slice(prefix.length);
      } else {
        try {
          const u = new URL(urlButtonValue);
          const segs = u.pathname.split("/").filter(Boolean);
          suffix = segs[segs.length - 1] || "";
        } catch {
          suffix = urlButtonValue;
        }
      }
    }
    if (!suffix) {
      const ex = Array.isArray(btn?.example) ? btn.example[0] : null;
      if (ex && typeof ex === "string") {
        suffix = ex.startsWith(prefix) ? ex.slice(prefix.length) : ex;
      }
    }
    if (!suffix) suffix = "recover";
    out.push({ type: "button", sub_type: "url", index: String(i), parameters: [{ type: "text", text: sanitizeParam(suffix) }] });
  }
}

function getRecoveryTokenFromUrl(urlButtonValue?: string | null) {
  if (!urlButtonValue) return "";
  try {
    const u = new URL(urlButtonValue);
    return u.pathname.split("/").filter(Boolean).pop() || "";
  } catch {
    return String(urlButtonValue).split(/[?#]/)[0].split("/").filter(Boolean).pop() || "";
  }
}

function applyInlineRecoveryTokenParams(schema: any[], bodyParams: string[], urlButtonValue?: string | null) {
  const token = getRecoveryTokenFromUrl(urlButtonValue);
  if (!token) return bodyParams;
  const bodyComp = schema.find((c: any) => String(c?.type || "").toUpperCase() === "BODY");
  const text = String(bodyComp?.text || "");
  if (!text) return bodyParams;

  const next = [...bodyParams];
  const re = /(?:https?:\/\/[^\s{}]+)?\/(?:api\/public\/)?r\/\{\{\s*(\d+)\s*\}\}/gi;
  let match: RegExpExecArray | null;
  while ((match = re.exec(text)) !== null) {
    const index = Number(match[1]) - 1;
    if (index >= 0) next[index] = token;
  }
  return next;
}

function buildComponents(templateComponentsSchema: any[] | null | undefined, bodyParams: string[], variableCount?: number | null, urlButtonValue?: string | null) {
  const out: any[] = [];
  const schema = Array.isArray(templateComponentsSchema) ? templateComponentsSchema : [];
  for (const comp of schema) {
    const type = String(comp?.type || "").toUpperCase();
    if (type === "HEADER") {
      const format = String(comp?.format || "TEXT").toUpperCase();
      if (format === "TEXT") {
        const headerVars: string[] = Array.isArray(comp?.example?.header_text) ? comp.example.header_text : [];
        const hasVar = /\{\{\d+\}\}/.test(String(comp?.text || ""));
        if (hasVar) {
          const text = sanitizeParam(headerVars[0] ?? "Update");
          out.push({ type: "header", parameters: [{ type: "text", text }] });
        }
      } else if (["IMAGE", "VIDEO", "DOCUMENT"].includes(format)) {
        const link = comp?.example?.header_handle?.[0];
        if (link) {
          const key = format.toLowerCase();
          out.push({ type: "header", parameters: [{ type: key, [key]: { link } }] });
        }
      }
    }
  }
  const count = Math.max(0, Number(variableCount || 0));
  if (count) {
    const effectiveBodyParams = applyInlineRecoveryTokenParams(schema, bodyParams, urlButtonValue);
    const values = Array.from({ length: count }, (_, i) => sanitizeParam(effectiveBodyParams[i]));
    out.push({ type: "body", parameters: values.map((text) => ({ type: "text", text })) });
  }
  appendUrlButtonParams(out, schema, urlButtonValue);
  return out.length ? out : undefined;
}

function templateComponents(params: string[], variableCount?: number | null) {
  return buildComponents(null, params, variableCount);
}

async function assertAdmin(supabase: any, workspaceId: string, userId: string) {
  const { data } = await supabase
    .from("workspace_members").select("role")
    .eq("workspace_id", workspaceId).eq("user_id", userId).maybeSingle();
  if (!data || !["owner", "admin"].includes(data.role)) {
    throw new Error("Admin permission required");
  }
}

async function upsertByIntegrationExternal(supabase: any, table: "ecom_orders" | "ecom_customers", row: Record<string, unknown>) {
  const payload = row as any;
  const { data: existing, error: findError } = await supabase
    .from(table as any)
    .select("id")
    .eq("integration_id", payload.integration_id)
    .eq("external_id", payload.external_id)
    .maybeSingle();
  if (findError) throw new Error(findError.message);
  const existingId = (existing as any)?.id;
  if (existingId) {
    const { error } = await supabase.from(table as any).update(payload).eq("id", existingId);
    if (error) throw new Error(error.message);
    return;
  }
  const { error } = await supabase.from(table as any).insert(payload);
  if (error) throw new Error(error.message);
}

export const getIntegrationDebugLogs = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((i) =>
    z.object({
      workspace_id: z.string().uuid(),
      integration_id: z.string().uuid().optional(),
      limit: z.number().int().min(1).max(200).default(50),
    }).parse(i),
  )
  .handler(async ({ data, context }) => {
    const { supabase } = context;
    let q = supabase
      .from("integration_debug_logs").select("*")
      .eq("workspace_id", data.workspace_id)
      .order("created_at", { ascending: false })
      .limit(data.limit);
    if (data.integration_id) q = q.eq("integration_id", data.integration_id);
    const { data: rows, error } = await q;
    if (error) throw new Error(error.message);
    return { logs: rows || [] };
  });

export const syncWooCommerceData = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((i) => z.object({ workspace_id: z.string().uuid(), integration_id: z.string().uuid().optional() }).parse(i))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { data: integ } = await supabase.from("store_integrations").select("*")
      .eq("workspace_id", data.workspace_id).eq("provider", "woocommerce")
      .maybeSingle();
    if (!integ) return { ok: false, error: "WooCommerce integration not found" };
    await assertAdmin(supabase, data.workspace_id, userId);
    const base = String(integ.store_url || "").replace(/\/$/, "");
    const auth = `consumer_key=${encodeURIComponent(integ.api_key || "")}&consumer_secret=${encodeURIComponent(integ.api_secret || "")}`;
    const load = async (path: string) => {
      const res = await fetch(`${base}/wp-json/wc/v3/${path}?per_page=100&${auth}`);
      const json = await res.json().catch(() => ([]));
      if (!res.ok) throw new Error(json?.message || `WooCommerce ${path} sync failed`);
      return Array.isArray(json) ? json : [];
    };
    const [orders, customers, products] = await Promise.all([load("orders"), load("customers"), load("products")]);
    for (const o of orders) {
      await upsertByIntegrationExternal(supabase, "ecom_orders", {
        workspace_id: data.workspace_id, integration_id: integ.id, external_id: String(o.id), order_number: String(o.number || o.id),
        customer_name: [o.billing?.first_name, o.billing?.last_name].filter(Boolean).join(" ") || o.billing?.email || null,
        customer_phone: o.billing?.phone ? `+${String(o.billing.phone).replace(/[^\d]/g, "")}` : null,
        total: Number(o.total || 0), currency: o.currency || "USD",
        payment_status: ["processing", "completed"].includes(o.status) ? "paid" : "pending",
        fulfillment_status: o.status === "completed" ? "fulfilled" : "unfulfilled",
        source: "woocommerce", items: o.line_items || [], placed_at: o.date_created_gmt || o.date_created || new Date().toISOString(),
      });
    }
    for (const c of customers) {
      await upsertByIntegrationExternal(supabase, "ecom_customers", {
        workspace_id: data.workspace_id, integration_id: integ.id, external_id: String(c.id),
        name: [c.first_name, c.last_name].filter(Boolean).join(" ") || c.email || null,
        email: c.email || null, phone: c.billing?.phone ? `+${String(c.billing.phone).replace(/[^\d]/g, "")}` : null,
        total_orders: Number(c.orders_count || 0), lifetime_value: Number(c.total_spent || 0),
      });
    }
    const revenue = orders.reduce((sum: number, o: any) => sum + Number(o.total || 0), 0);
    const meta: any = integ.meta || {};
    meta.stats = { ...(meta.stats || {}), customers: customers.length, orders: orders.length, products: products.length, revenue };
    await supabase.from("store_integrations").update({ meta, total_revenue: revenue, last_sync_at: new Date().toISOString(), status: "connected" }).eq("id", integ.id);
    await supabase.from("integration_debug_logs").insert({ workspace_id: data.workspace_id, integration_id: integ.id, provider: "woocommerce", direction: "in", event: "manual.sync", ok: true, status_code: 200, message: `Synced ${orders.length} orders, ${customers.length} customers, ${products.length} products` } as any);
    return { ok: true, orders: orders.length, customers: customers.length, products: products.length, revenue };
  });

export const sendTestWhatsApp = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((i) =>
    z.object({
      workspace_id: z.string().uuid(),
      integration_id: z.string().uuid().optional(),
      phone: z.string().min(6).max(20),
      template_id: z.string().uuid().optional(),
      cart_id: z.string().uuid().optional(),
    }).parse(i),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;

    async function logEvent(ok: boolean, message: string, extra: any = {}) {
      try {
        await supabase.from("integration_debug_logs").insert({
          workspace_id: data.workspace_id,
          integration_id: data.integration_id || null,
          provider: "woocommerce",
          direction: "out",
          event: "test.whatsapp",
          ok,
          status_code: extra.status_code ?? null,
          message,
          payload: extra.payload || { phone: data.phone },
          response: extra.response || null,
        } as any);
      } catch {}
    }

    // Any workspace member can run the test (not strictly admin)
    const { data: member } = await supabase
      .from("workspace_members").select("role")
      .eq("workspace_id", data.workspace_id).eq("user_id", userId).maybeSingle();
    if (!member) {
      const msg = "You are not a member of this workspace.";
      await logEvent(false, msg);
      return { ok: false, error: msg };
    }

    const { data: settings, error: settingsErr } = await supabase
      .from("whatsapp_settings").select("phone_number_id, access_token")
      .eq("workspace_id", data.workspace_id).maybeSingle();
    if (settingsErr) {
      await logEvent(false, `Failed to load WhatsApp settings: ${settingsErr.message}`);
      return { ok: false, error: settingsErr.message };
    }
    if (!settings?.phone_number_id || !settings.access_token) {
      const msg = "WhatsApp is not configured for this workspace. Open WhatsApp Setup and connect your number first.";
      await logEvent(false, msg);
      return { ok: false, error: msg };
    }

    let phone = String(data.phone).replace(/[^\d]/g, "");
    if (phone.length === 10) phone = "91" + phone; // default India country code when missing
    if (!phone || phone.length < 8) {
      const msg = `Invalid phone number: ${data.phone}`;
      await logEvent(false, msg);
      return { ok: false, error: msg };
    }
    let body: any;
    let templateNameForTracking = "";
    let templateComponentsForTracking: any = null;

    let params = ["Slice Customer", "TEST", "Slice WooCommerce"];
    let recoveryUrl: string | null = null;
    let cartContext: any = null;
    if (data.cart_id) {
      const { data: cart, error: cartErr } = await supabase
        .from("abandoned_carts")
        .select("*")
        .eq("workspace_id", data.workspace_id)
        .eq("id", data.cart_id)
        .maybeSingle();
      if (cartErr) {
        await logEvent(false, `Failed to load abandoned cart: ${cartErr.message}`);
        return { ok: false, error: cartErr.message };
      }
      if (!cart) {
        const msg = "Abandoned cart not found";
        await logEvent(false, msg);
        return { ok: false, error: msg };
      }
      cartContext = cart;
      recoveryUrl = (cart as any).recovery_url || null;
    }
    if (data.template_id) {
      const { data: tpl } = await supabase
        .from("templates").select("meta_template_name, language, variables_count, status, components, variable_mapping")
        .eq("workspace_id", data.workspace_id)
        .eq("id", data.template_id).maybeSingle();
      if (!tpl) {
        await logEvent(false, "Template not found");
        return { ok: false, error: "Template not found" };
      }
      if (cartContext) {
        const { resolveTemplateParams } = await import("@/lib/wa-template-vars.server");
        const items: any[] = Array.isArray((cartContext as any).items) ? (cartContext as any).items : [];
        const firstItem = items.find((it: any) => it && String(it.name || it.title || "").trim()) || null;
        const productName = firstItem
          ? (items.length > 1 ? `${String(firstItem.name || firstItem.title)} +${items.length - 1} more` : String(firstItem.name || firstItem.title))
          : null;
        const currency = String((cartContext as any).currency || "INR").toUpperCase();
        const symMap: Record<string, string> = { INR: "₹", USD: "$", EUR: "€", GBP: "£", AED: "AED ", AUD: "A$", CAD: "C$" };
        const amount = `${symMap[currency] || `${currency} `}${Number((cartContext as any).total || 0).toFixed(2)}`;
        const fallbackOrder: FieldKey[] = ["name", "url", "amount", "storeName"];
        const resolved = resolveTemplateParams(
          tpl.components,
          {
            name: (cartContext as any).customer_name || "Customer",
            storeName: "our store",
            amount,
            amountRaw: Number((cartContext as any).total || 0),
            currency,
            url: recoveryUrl,
            productName,
            productPrice: firstItem != null && (firstItem.price ?? firstItem.total) != null
              ? `${symMap[currency] || `${currency} `}${Number(firstItem.price ?? firstItem.total).toFixed(2)}`
              : null,
            customerEmail: (cartContext as any).customer_email || null,
            customerPhone: (cartContext as any).customer_phone || null,
          },
          fallbackOrder,
          tpl.variables_count,
          (tpl as any).variable_mapping ?? null,
        );
        params = resolved.params;
        await logEvent(resolved.warnings.length === 0, resolved.warnings.length ? `Cart template mapping warnings: ${resolved.warnings.join("; ")}` : "Cart template mapped with recovery URL", {
          payload: { cart_id: data.cart_id, template: tpl.meta_template_name, mapping: resolved.mapping, recovery_url: recoveryUrl },
        });
      }
      const components = buildComponents(tpl.components as any, params, tpl.variables_count, recoveryUrl);
      templateNameForTracking = tpl.meta_template_name;
      templateComponentsForTracking = tpl.components;
      body = {
        messaging_product: "whatsapp",
        to: phone,
        type: "template",
        template: { name: tpl.meta_template_name, language: { code: tpl.language || "en_US" }, ...(components ? { components } : {}) },
      };
    } else {
      const { data: tpl } = await supabase
        .from("templates")
        .select("meta_template_name, language, variables_count, components, variable_mapping")
        .eq("workspace_id", data.workspace_id)
        .eq("status", "APPROVED")
        .order("created_at", { ascending: false })
        .limit(1)
        .maybeSingle();
      if (!tpl?.meta_template_name) {
        const msg = "No approved WhatsApp template found. Sync or create an approved template first, then run the test again.";
        await logEvent(false, msg);
        return { ok: false, error: msg };
      }
      const components = buildComponents(tpl.components as any, params, tpl.variables_count, recoveryUrl);
      templateNameForTracking = tpl.meta_template_name;
      templateComponentsForTracking = tpl.components;
      body = {
        messaging_product: "whatsapp",
        to: phone,
        type: "template",
        template: { name: tpl.meta_template_name, language: { code: tpl.language || "en_US" }, ...(components ? { components } : {}) },
      };
    }

    try {
      const res = await fetch(`${META_BASE}/${settings.phone_number_id}/messages`, {
        method: "POST",
        headers: { Authorization: `Bearer ${settings.access_token}`, "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      const j: any = await res.json().catch(() => ({}));
      const waMessageId: string | null = j?.messages?.[0]?.id ?? null;

      await logEvent(res.ok, res.ok ? `Test sent to ${phone}` : (j?.error?.message || `HTTP ${res.status}`), {
        status_code: res.status,
        payload: body,
        response: j,
      });

      // Track outbound test message so Meta delivery webhook updates real status
      if (res.ok && waMessageId) {
        try {
          const contactPhone = `+${phone}`;
          const { data: convoId } = await supabase.rpc("resolve_conversation", {
            _workspace_id: data.workspace_id,
            _phone: contactPhone,
            _name: contactPhone,
            _last_message_at: new Date().toISOString(),
          } as any);
          const convo = convoId ? { id: convoId as string } : null;
          if (convo) {
            const bodyText = String((Array.isArray(templateComponentsForTracking) ? templateComponentsForTracking : []).find((c: any) => String(c?.type || "").toUpperCase() === "BODY")?.text || "");
            const rendered = bodyText.replace(/\{\{\s*(\d+)\s*\}\}/g, (_m, idx) => {
              const i = Math.max(0, Number(idx) - 1);
              return params[i] != null ? String(params[i]) : "";
            });
            await supabase.from("messages").insert({
              workspace_id: data.workspace_id,
              conversation_id: convo.id,
              direction: "out",
              type: "text",
              content: rendered || `[template] ${templateNameForTracking}`,
              wa_message_id: waMessageId,
              status: "sent",
            } as any);
          }
        } catch (trackErr) {
          console.error("test send tracking failed", trackErr);
        }
      }

      if (!res.ok) {
        return { ok: false, error: j?.error?.message || `HTTP ${res.status}`, status: res.status };
      }
      return { ok: true, message_id: waMessageId, status: res.status };
    } catch (e: any) {
      await logEvent(false, `Network error: ${e?.message || "unknown"}`, { payload: body });
      return { ok: false, error: e?.message || "Network error" };
    }
  });

export const getIntegrationHealth = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((i) => z.object({ integration_id: z.string().uuid() }).parse(i))
  .handler(async ({ data, context }) => {
    const { supabase } = context;
    const { data: integ } = await supabase
      .from("store_integrations").select("*")
      .eq("id", data.integration_id).maybeSingle();
    if (!integ) throw new Error("Integration not found");

    const since = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString();
    const { data: logsData } = await supabase
      .from("integration_debug_logs").select("ok, direction, event, status_code, created_at, message")
      .eq("integration_id", data.integration_id).gte("created_at", since)
      .order("created_at", { ascending: false }).limit(200);
    const logs = logsData || [];

    const messagesSent = logs.filter((l: any) => l.direction === "out" && l.ok).length;
    const messagesFailed = logs.filter((l: any) => l.direction === "out" && !l.ok).length;
    const lastInbound = logs.find((l: any) => l.direction === "in");
    const lastOutbound = logs.find((l: any) => l.direction === "out");

    return {
      integration: integ,
      health: {
        connected: integ.status === "connected",
        api_key_set: !!integ.api_key,
        workspace_linked: !!integ.workspace_id,
        last_sync_at: integ.last_sync_at,
        last_inbound: lastInbound || null,
        last_outbound: lastOutbound || null,
        messages_sent_24h: messagesSent,
        messages_failed_24h: messagesFailed,
        stats: (integ.meta as any)?.stats || {},
      },
    };
  });

export const updateIntegrationAutomation = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((i) =>
    z.object({
      integration_id: z.string().uuid(),
      event_key: z.string().min(1).max(64),
      enabled: z.boolean(),
      template_name: z.string().max(255).optional(),
      language: z.string().max(20).default("en_US"),
    }).parse(i),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { data: integ } = await supabase
      .from("store_integrations").select("workspace_id, meta")
      .eq("id", data.integration_id).maybeSingle();
    if (!integ) throw new Error("Integration not found");
    await assertAdmin(supabase, integ.workspace_id, userId);
    const meta: any = integ.meta || {};
    meta.automations = meta.automations || {};
    meta.automations[data.event_key] = {
      enabled: data.enabled,
      template_name: data.template_name || null,
      language: data.language,
    };
    const { error } = await supabase.from("store_integrations").update({ meta }).eq("id", data.integration_id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });
