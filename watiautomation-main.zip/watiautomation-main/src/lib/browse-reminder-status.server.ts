import { supabaseAdmin } from "@/integrations/supabase/client.server";
import type { WhatsAppErrorClassification } from "./whatsapp-delivery-status";

const SUPPRESSED_RETRY_MS = 24 * 60 * 60 * 1000;
const RETRYABLE_RETRY_MS = 15 * 60 * 1000;

/** Reconciles an asynchronous Meta delivery failure with its browse event. */
export async function reconcileBrowseReminderFailure(args: {
  workspaceId: string;
  waMessageId: string;
  classification: WhatsAppErrorClassification;
}): Promise<void> {
  try {
    const { data: event } = await supabaseAdmin
      .from("browse_events" as any)
      .select("id, dispatched_at")
      .eq("workspace_id", args.workspaceId)
      .eq("wa_message_id", args.waMessageId)
      .maybeSingle();

    if (!event) return;

    const canRetry = args.classification.status === "suppressed" || args.classification.retryable;
    const retryInMs = args.classification.status === "suppressed"
      ? SUPPRESSED_RETRY_MS
      : RETRYABLE_RETRY_MS;

    await supabaseAdmin
      .from("browse_events" as any)
      .update(canRetry ? {
        dispatched_at: null,
        wa_message_id: null,
        skip_reason: null,
        dispatch_scheduled_at: new Date(Date.now() + retryInMs).toISOString(),
      } : {
        dispatched_at: null,
        skip_reason: `delivery_failed:${args.classification.code ?? "unknown"}`,
      })
      .eq("id", (event as any).id)
      .eq("wa_message_id", args.waMessageId);

    await supabaseAdmin.from("integration_debug_logs").insert({
      workspace_id: args.workspaceId,
      provider: "whatsapp",
      direction: "in",
      event: "wa.browse_recovery.not_delivered",
      ok: false,
      message: canRetry
        ? `${args.classification.error} — browse reminder re-queued.`
        : `${args.classification.error} — browse reminder marked as failed.`,
      payload: {
        browse_event_id: (event as any).id,
        wa_message_id: args.waMessageId,
        meta_code: args.classification.code ?? null,
        retry_scheduled: canRetry,
      } as any,
    } as any);
  } catch (error) {
    console.error("[browse-reminder-status] reconcile failed", error);
  }
}