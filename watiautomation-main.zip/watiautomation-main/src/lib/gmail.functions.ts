import { createServerFn } from '@tanstack/react-start';
import { z } from 'zod';
import { requireSupabaseAuth } from '@/integrations/supabase/auth-middleware';

const GATEWAY_URL = 'https://connector-gateway.lovable.dev/google_mail/gmail/v1';

const SendEmailSchema = z.object({
  to: z.string().email().max(320),
  subject: z.string().min(1).max(998),
  body: z.string().min(1).max(100000),
  cc: z.string().max(2000).optional(),
  bcc: z.string().max(2000).optional(),
  isHtml: z.boolean().optional(),
});

function toBase64Url(input: string): string {
  // UTF-8 safe base64url
  const bytes = new TextEncoder().encode(input);
  let binary = '';
  for (const b of bytes) binary += String.fromCharCode(b);
  return btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

function buildRawEmail(opts: {
  to: string;
  subject: string;
  body: string;
  cc?: string;
  bcc?: string;
  isHtml?: boolean;
}): string {
  const contentType = opts.isHtml
    ? 'text/html; charset="UTF-8"'
    : 'text/plain; charset="UTF-8"';
  // Encode subject for non-ASCII safety
  const encodedSubject = `=?UTF-8?B?${btoa(unescape(encodeURIComponent(opts.subject)))}?=`;
  const headers = [
    `To: ${opts.to}`,
    opts.cc ? `Cc: ${opts.cc}` : null,
    opts.bcc ? `Bcc: ${opts.bcc}` : null,
    `Subject: ${encodedSubject}`,
    'MIME-Version: 1.0',
    `Content-Type: ${contentType}`,
    'Content-Transfer-Encoding: 8bit',
  ].filter(Boolean) as string[];
  const message = headers.join('\r\n') + '\r\n\r\n' + opts.body;
  return toBase64Url(message);
}

export const sendGmail = createServerFn({ method: 'POST' })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => SendEmailSchema.parse(data))
  .handler(async ({ data }) => {
    const lovableKey = process.env.LOVABLE_API_KEY;
    const gmailKey = process.env.GOOGLE_MAIL_API_KEY;
    if (!lovableKey) throw new Error('LOVABLE_API_KEY not configured');
    if (!gmailKey) throw new Error('GOOGLE_MAIL_API_KEY not configured (Gmail connector not linked)');

    const raw = buildRawEmail(data);

    const res = await fetch(`${GATEWAY_URL}/users/me/messages/send`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${lovableKey}`,
        'X-Connection-Api-Key': gmailKey,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ raw }),
    });

    if (!res.ok) {
      const errText = await res.text();
      throw new Error(`Gmail send failed [${res.status}]: ${errText}`);
    }

    return (await res.json()) as { id: string; threadId: string; labelIds?: string[] };
  });
