import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

export interface ButtonClickFilters {
  workspaceId?: string | null;
  search?: string | null;
  from?: string | null;
  to?: string | null;
  campaignId?: string | null;
  templateName?: string | null;
  buttonText?: string | null;
  page?: number;
  pageSize?: number;
  allWorkspaces?: boolean;
}

export interface ButtonClickRow {
  id: string;
  workspace_id: string;
  contact_id: string | null;
  contact_name: string | null;
  phone: string;
  campaign_id: string | null;
  template_name: string | null;
  button_text: string | null;
  button_payload: string | null;
  button_type: string | null;
  clicked_at: string;
}

function buildQuery(supabase: any, f: ButtonClickFilters) {
  let q = supabase
    .from("template_button_clicks")
    .select(
      "id, workspace_id, contact_id, contact_name, phone, campaign_id, template_name, button_text, button_payload, button_type, clicked_at",
      { count: "exact" },
    );
  if (!f.allWorkspaces && f.workspaceId) q = q.eq("workspace_id", f.workspaceId);
  if (f.from) q = q.gte("clicked_at", f.from);
  if (f.to) q = q.lte("clicked_at", f.to);
  if (f.campaignId) q = q.eq("campaign_id", f.campaignId);
  if (f.templateName) q = q.eq("template_name", f.templateName);
  if (f.buttonText) q = q.eq("button_text", f.buttonText);
  if (f.search) {
    const s = f.search.replace(/[%,()]/g, " ").trim();
    const digits = s.replace(/\D/g, "");
    const parts = [`contact_name.ilike.%${s}%`, `phone.ilike.%${s}%`];
    if (digits) parts.push(`phone_normalized.ilike.%${digits}%`);
    q = q.or(parts.join(","));
  }
  return q;
}

/** Paginated, filtered list of template button clicks (RLS scopes to the caller). */
export const listButtonClicks = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: ButtonClickFilters) => input ?? {})
  .handler(async ({ data, context }) => {
    const page = Math.max(1, Number(data.page || 1));
    const pageSize = Math.min(500, Math.max(1, Number(data.pageSize || 50)));
    const fromIdx = (page - 1) * pageSize;

    const { data: rows, count, error } = await buildQuery(context.supabase, data)
      .order("clicked_at", { ascending: false })
      .range(fromIdx, fromIdx + pageSize - 1);
    if (error) throw new Error(error.message);

    return {
      rows: (rows ?? []) as ButtonClickRow[],
      total: count ?? 0,
      page,
      pageSize,
    };
  });

/** Full (capped) export dataset for CSV/Excel downloads. */
export const exportButtonClicks = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: ButtonClickFilters) => input ?? {})
  .handler(async ({ data, context }) => {
    const out: ButtonClickRow[] = [];
    const CHUNK = 1000;
    for (let start = 0; start < 20000; start += CHUNK) {
      const { data: rows, error } = await buildQuery(context.supabase, data)
        .order("clicked_at", { ascending: false })
        .range(start, start + CHUNK - 1);
      if (error) throw new Error(error.message);
      const batch = (rows ?? []) as ButtonClickRow[];
      out.push(...batch);
      if (batch.length < CHUNK) break;
    }
    return { rows: out };
  });

/** Distinct campaigns / templates / button labels available for filtering. */
export const getButtonClickFacets = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { workspaceId?: string | null; allWorkspaces?: boolean }) => input ?? {})
  .handler(async ({ data, context }) => {
    let q = context.supabase
      .from("template_button_clicks")
      .select("campaign_id, template_name, button_text")
      .order("clicked_at", { ascending: false })
      .limit(5000);
    if (!data.allWorkspaces && data.workspaceId) q = q.eq("workspace_id", data.workspaceId);
    const { data: rows } = await q;

    const campaignIds = Array.from(
      new Set(((rows ?? []) as any[]).map((r) => r.campaign_id).filter(Boolean)),
    ) as string[];
    let campaigns: { id: string; name: string }[] = [];
    if (campaignIds.length) {
      const { data: cs } = await context.supabase
        .from("campaigns")
        .select("id, name")
        .in("id", campaignIds);
      campaigns = ((cs ?? []) as any[]).map((c) => ({ id: c.id, name: c.name }));
    }

    return {
      campaigns,
      templates: Array.from(
        new Set(((rows ?? []) as any[]).map((r) => r.template_name).filter(Boolean)),
      ) as string[],
      buttons: Array.from(
        new Set(((rows ?? []) as any[]).map((r) => r.button_text).filter(Boolean)),
      ) as string[],
    };
  });

/** Per-campaign button click counters for campaign analytics. */
export const getCampaignButtonStats = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { campaignId: string }) => input)
  .handler(async ({ data, context }) => {
    const { data: rows, error } = await context.supabase
      .from("template_button_clicks")
      .select("button_text, phone")
      .eq("campaign_id", data.campaignId)
      .limit(10000);
    if (error) throw new Error(error.message);
    const list = (rows ?? []) as { button_text: string | null; phone: string }[];
    const byButton = new Map<string, number>();
    for (const r of list) {
      const key = (r.button_text || "Button").trim();
      byButton.set(key, (byButton.get(key) || 0) + 1);
    }
    const interested = list.filter((r) => /interested/i.test(r.button_text || "")).length;
    return {
      total: list.length,
      uniqueContacts: new Set(list.map((r) => r.phone)).size,
      interested,
      byButton: Array.from(byButton.entries()).map(([button, count]) => ({ button, count })),
    };
  });
