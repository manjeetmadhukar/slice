// Shopify OAuth + sync helpers. Server-only.
import { createHmac, timingSafeEqual, randomBytes } from "crypto";
import { supabaseAdmin } from "@/integrations/supabase/client.server";
import { resolveTemplateParams, type FieldKey } from "@/lib/wa-template-vars.server";
import { sendWhatsAppMessage } from "@/lib/whatsapp-send.server";

export const SHOPIFY_API_VERSION = "2024-10";

// NOTE: `read_all_orders` and `read_checkouts` are Shopify "protected" scopes
// that require explicit merchant/Shopify approval. Requesting them on a custom
// or unapproved app causes Shopify to silently strip ALL order/checkout scopes
// from the granted access token — which then fails webhook registration with
// "Topics allowed: app/uninstalled" and order reads with "merchant approval
// required for read_orders scope". Keep this list to the safe defaults.
export const SHOPIFY_SCOPES = [
  "read_orders",
  "read_customers",
  "read_products",
  "read_inventory",
  "read_fulfillments",
].join(",");

export function getShopifyCreds() {
  const apiKey = process.env.SHOPIFY_API_KEY;
  const apiSecret = process.env.SHOPIFY_API_SECRET;
  if (!apiKey || !apiSecret) {
    throw new Error("Shopify app credentials are not configured. Set SHOPIFY_API_KEY and SHOPIFY_API_SECRET.");
  }
  return { apiKey, apiSecret };
}

export function getAppBaseUrl(request?: Request) {
  const envUrl = process.env.APP_BASE_URL;
  if (envUrl) return envUrl.replace(/\/$/, "");
  if (request) {
    const url = new URL(request.url);
    if (url.hostname.endsWith(".lovable.app") || url.hostname.includes("lovableproject.com")) {
      return "https://slice.dotscube.com";
    }
    return `${url.protocol}//${url.host}`;
  }
  return "https://slice.dotscube.com";
}

export function normalizeShopDomain(input: string): string | null {
  const raw = String(input || "").trim().toLowerCase().replace(/^https?:\/\//, "").replace(/\/.*$/, "");
  if (!raw) return null;
  const shop = raw.endsWith(".myshopify.com") ? raw : `${raw.replace(/\..*$/, "")}.myshopify.com`;
  if (!/^[a-z0-9][a-z0-9-]*\.myshopify\.com$/.test(shop)) return null;
  return shop;
}

export function verifyOAuthHmac(params: URLSearchParams, secret: string): boolean {
  const hmac = params.get("hmac");
  if (!hmac) return false;
  const entries: [string, string][] = [];
  params.forEach((v, k) => { if (k !== "hmac" && k !== "signature") entries.push([k, v]); });
  entries.sort(([a], [b]) => a.localeCompare(b));
  const message = entries.map(([k, v]) => `${k}=${v}`).join("&");
  const expected = createHmac("sha256", secret).update(message).digest("hex");
  try {
    return timingSafeEqual(Buffer.from(hmac, "utf8"), Buffer.from(expected, "utf8"));
  } catch { return false; }
}

export function verifyWebhookHmac(rawBody: string, headerHmac: string | null, secret: string): boolean {
  if (!headerHmac) return false;
  const expected = createHmac("sha256", secret).update(rawBody, "utf8").digest("base64");
  try {
    return timingSafeEqual(Buffer.from(headerHmac, "utf8"), Buffer.from(expected, "utf8"));
  } catch { return false; }
}

export function makeNonce() {
  return randomBytes(16).toString("hex");
}

export function buildAuthorizeUrl(shop: string, state: string, redirectUri: string) {
  const { apiKey } = getShopifyCreds();
  const u = new URL(`https://${shop}/admin/oauth/authorize`);
  u.searchParams.set("client_id", apiKey);
  u.searchParams.set("scope", SHOPIFY_SCOPES);
  u.searchParams.set("redirect_uri", redirectUri);
  u.searchParams.set("state", state);
  return u.toString();
}

function parseScopes(raw: unknown): string[] {
  if (Array.isArray(raw)) return raw.map(String).filter(Boolean);
  return String(raw || "")
    .split(/[,\s]+/)
    .map((s) => s.trim())
    .filter(Boolean);
}

export async function exchangeCodeForToken(shop: string, code: string): Promise<{ accessToken: string; scopes: string[] }> {
  const { apiKey, apiSecret } = getShopifyCreds();
  const res = await fetch(`https://${shop}/admin/oauth/access_token`, {
    method: "POST",
    headers: { "Content-Type": "application/json", Accept: "application/json" },
    body: JSON.stringify({ client_id: apiKey, client_secret: apiSecret, code }),
  });
  const j: any = await res.json().catch(() => ({}));
  if (!res.ok || !j?.access_token) {
    throw new Error(j?.error_description || j?.error || `Token exchange failed (${res.status})`);
  }
  return { accessToken: j.access_token as string, scopes: parseScopes(j?.scope) };
}

export async function getAccessScopes(shop: string, token: string): Promise<string[]> {
  const res = await fetch(`https://${shop}/admin/oauth/access_scopes.json`, {
    headers: { "X-Shopify-Access-Token": token, Accept: "application/json" },
  });
  const j: any = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(j?.errors ? JSON.stringify(j.errors) : `Shopify access scopes HTTP ${res.status}`);
  return (j?.access_scopes || []).map((s: any) => String(s?.handle || "")).filter(Boolean);
}

export async function shopifyRest<T = any>(shop: string, token: string, path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(`https://${shop}/admin/api/${SHOPIFY_API_VERSION}${path}`, {
    ...init,
    headers: {
      "X-Shopify-Access-Token": token,
      "Content-Type": "application/json",
      Accept: "application/json",
      ...(init?.headers || {}),
    },
  });
  const j = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error((j as any)?.errors ? JSON.stringify((j as any).errors) : `Shopify ${path} HTTP ${res.status}`);
  return j as T;
}

export const WEBHOOK_TOPICS = [
  "orders/create",
  "orders/updated",
  "orders/paid",
  "orders/fulfilled",
  "orders/cancelled",
  "customers/create",
  "customers/update",
  // Abandoned-cart capture. Shopify only requires `read_orders` for these
  // checkout topics — the protected `read_checkouts` scope is for live cart
  // (carts/*) events, which we don't need.
  "checkouts/create",
  "checkouts/update",
  "checkouts/delete",
  "app/uninstalled",
];

export type WebhookRegResult = { topic: string; ok: boolean; id?: number | string; error?: string };

const TOPIC_REQUIRED_SCOPES: Record<string, string[]> = {
  "orders/create": ["read_orders"],
  "orders/updated": ["read_orders"],
  "orders/paid": ["read_orders"],
  "orders/fulfilled": ["read_orders"],
  "orders/cancelled": ["read_orders"],
  "customers/create": ["read_customers"],
  "customers/update": ["read_customers"],
  "checkouts/create": ["read_orders"],
  "checkouts/update": ["read_orders"],
  "checkouts/delete": ["read_orders"],
};

export function missingShopifySyncScopes(scopes: string[]) {
  const granted = new Set(scopes);
  return ["read_orders", "read_customers"].filter((scope) => !granted.has(scope));
}

export function shopifyPermissionMessage(missing: string[]) {
  return `Shopify permissions missing: ${missing.join(", ")}. Enable/approve these Admin API scopes in your Shopify app, then disconnect and reconnect the store.`;
}

export async function registerWebhooks(shop: string, token: string, callbackUrl: string, grantedScopes?: string[]): Promise<WebhookRegResult[]> {
  const results: WebhookRegResult[] = [];
  const scopes = grantedScopes || await getAccessScopes(shop, token).catch(() => []);
  const scopeSet = new Set(scopes);
  let existing: any[] = [];
  try {
    const j = await shopifyRest<any>(shop, token, "/webhooks.json");
    existing = j?.webhooks || [];
  } catch {}
  for (const topic of WEBHOOK_TOPICS) {
    const missing = (TOPIC_REQUIRED_SCOPES[topic] || []).filter((scope) => !scopeSet.has(scope));
    if (missing.length) {
      results.push({ topic, ok: false, error: shopifyPermissionMessage(missing) });
      continue;
    }
    const has = existing.find((w) => w.topic === topic && w.address === callbackUrl);
    if (has) { results.push({ topic, ok: true, id: has.id }); continue; }
    try {
      const j: any = await shopifyRest<any>(shop, token, "/webhooks.json", {
        method: "POST",
        body: JSON.stringify({ webhook: { topic, address: callbackUrl, format: "json" } }),
      });
      results.push({ topic, ok: true, id: j?.webhook?.id });
    } catch (e: any) {
      results.push({ topic, ok: false, error: String(e?.message || e) });
    }
  }
  return results;
}

export async function deleteAllWebhooks(shop: string, token: string) {
  const results: Array<{ id: any; topic: string; ok: boolean; error?: string }> = [];
  try {
    const j = await shopifyRest<any>(shop, token, "/webhooks.json");
    const list = j?.webhooks || [];
    for (const w of list) {
      try {
        await shopifyRest(shop, token, `/webhooks/${w.id}.json`, { method: "DELETE" });
        results.push({ id: w.id, topic: w.topic, ok: true });
      } catch (e: any) {
        results.push({ id: w.id, topic: w.topic, ok: false, error: String(e?.message || e) });
      }
    }
  } catch (e: any) {
    results.push({ id: null, topic: "list", ok: false, error: String(e?.message || e) });
  }
  return results;
}

export async function persistWebhookMeta(integrationId: string, results: WebhookRegResult[]) {
  const { data: integ } = await supabaseAdmin.from("store_integrations").select("meta").eq("id", integrationId).maybeSingle();
  const meta: any = (integ as any)?.meta || {};
  meta.webhooks = results.map((r) => ({ topic: r.topic, id: r.id ?? null, ok: r.ok, error: r.error ?? null }));
  meta.webhooks_registered_at = new Date().toISOString();
  await supabaseAdmin.from("store_integrations").update({ meta }).eq("id", integrationId);
}

export async function logEvent(row: {
  workspace_id: string;
  integration_id?: string | null;
  direction: "in" | "out";
  event: string;
  ok: boolean;
  status_code?: number | null;
  message?: string | null;
  payload?: unknown;
  response?: unknown;
}) {
  try {
    await supabaseAdmin.from("integration_debug_logs").insert({
      workspace_id: row.workspace_id,
      integration_id: row.integration_id ?? null,
      provider: "shopify",
      direction: row.direction,
      event: row.event,
      status_code: row.status_code ?? null,
      ok: row.ok,
      message: row.message ?? null,
      payload: (row.payload as any) ?? {},
      response: (row.response as any) ?? null,
    } as any);
  } catch (e) { console.error("shopify log failed", e); }
}

export async function upsertByIntegrationExternal(table: "ecom_orders" | "ecom_customers", row: Record<string, unknown>) {
  const payload = row as any;
  const { data: existing } = await supabaseAdmin
    .from(table as any).select("id")
    .eq("integration_id", payload.integration_id)
    .eq("external_id", payload.external_id)
    .maybeSingle();
  if ((existing as any)?.id) {
    const { error } = await supabaseAdmin.from(table as any).update(payload).eq("id", (existing as any).id);
    if (error) throw error;
    return;
  }
  const { error } = await supabaseAdmin.from(table as any).insert(payload);
  if (error) throw error;
}

export function mapOrderRow(workspaceId: string, integrationId: string, o: any) {
  const cust = o.customer || {};
  const phone = o.phone || cust.phone || o.shipping_address?.phone || o.billing_address?.phone || null;
  const name = [cust.first_name, cust.last_name].filter(Boolean).join(" ").trim() || cust.email || o.email || null;
  return {
    workspace_id: workspaceId,
    integration_id: integrationId,
    external_id: String(o.id),
    order_number: String(o.name || o.order_number || o.id),
    customer_name: name,
    customer_phone: phone ? `+${String(phone).replace(/[^\d]/g, "")}` : null,
    total: Number(o.total_price || o.current_total_price || 0),
    currency: o.currency || o.presentment_currency || "USD",
    payment_status: o.financial_status === "paid" ? "paid" : (o.financial_status || "pending"),
    fulfillment_status: o.fulfillment_status === "fulfilled" ? "fulfilled" : "unfulfilled",
    source: "shopify",
    items: o.line_items || [],
    placed_at: o.created_at || new Date().toISOString(),
  };
}

export function mapCustomerRow(workspaceId: string, integrationId: string, c: any) {
  const phone = c.phone || c.default_address?.phone || null;
  return {
    workspace_id: workspaceId,
    integration_id: integrationId,
    external_id: String(c.id),
    name: [c.first_name, c.last_name].filter(Boolean).join(" ").trim() || c.email || null,
    email: c.email || null,
    phone: phone ? `+${String(phone).replace(/[^\d]/g, "")}` : null,
    total_orders: Number(c.orders_count || 0),
    lifetime_value: Number(c.total_spent || 0),
  };
}

export async function findOrCreateContact(workspaceId: string, phone: string | null, name: string | null, email: string | null) {
  if (!phone) return null;
  const normalized = `+${String(phone).replace(/[^\d]/g, "")}`;
  const { data: ws } = await supabaseAdmin.from("workspaces").select("owner_id").eq("id", workspaceId).maybeSingle();
  const ownerId = (ws as any)?.owner_id;
  if (!ownerId) return null;
  const { data: id } = await supabaseAdmin.rpc("upsert_contact", {
    _workspace_id: workspaceId,
    _name: name || normalized,
    _phone: normalized,
    _email: email || undefined,
    _lead_source: "shopify",
    _user_id: ownerId,
  } as any);
  return (id as any) ?? null;
}

export async function backfillStore(workspaceId: string, integrationId: string, shop: string, token: string) {
  let orderCount = 0, customerCount = 0;
  const scopes = await getAccessScopes(shop, token).catch(() => []);
  const missing = missingShopifySyncScopes(scopes);
  if (missing.length) {
    const message = shopifyPermissionMessage(missing);
    await logEvent({ workspace_id: workspaceId, integration_id: integrationId, direction: "in", event: "sync.permissions.error", ok: false, message, response: { granted_scopes: scopes, missing_scopes: missing } });
    const { data: integ } = await supabaseAdmin.from("store_integrations").select("meta").eq("id", integrationId).maybeSingle();
    const meta: any = ((integ as any)?.meta) || {};
    meta.shopify_permissions = { ok: false, granted_scopes: scopes, missing_scopes: missing, message, checked_at: new Date().toISOString() };
    await supabaseAdmin.from("store_integrations").update({ meta, status: "needs_reconnect" }).eq("id", integrationId);
    throw new Error(message);
  }

  // Orders — last 250 of any status
  try {
    const j = await shopifyRest<any>(shop, token, `/orders.json?status=any&limit=250`);
    for (const o of (j?.orders || [])) {
      await upsertByIntegrationExternal("ecom_orders", mapOrderRow(workspaceId, integrationId, o));
      orderCount++;
    }
  } catch (e: any) {
    await logEvent({ workspace_id: workspaceId, integration_id: integrationId, direction: "in", event: "sync.orders.error", ok: false, message: String(e?.message || e) });
  }

  // Customers
  try {
    const j = await shopifyRest<any>(shop, token, `/customers.json?limit=250`);
    for (const c of (j?.customers || [])) {
      await upsertByIntegrationExternal("ecom_customers", mapCustomerRow(workspaceId, integrationId, c));
      customerCount++;
    }
  } catch (e: any) {
    await logEvent({ workspace_id: workspaceId, integration_id: integrationId, direction: "in", event: "sync.customers.error", ok: false, message: String(e?.message || e) });
  }

  // Products count
  let productCount = 0;
  try {
    const j = await shopifyRest<any>(shop, token, `/products/count.json`);
    productCount = Number(j?.count || 0);
  } catch {}

  // Revenue
  const { data: revRows } = await supabaseAdmin
    .from("ecom_orders").select("total")
    .eq("workspace_id", workspaceId).eq("integration_id", integrationId);
  const revenue = (revRows || []).reduce((s: number, r: any) => s + Number(r.total || 0), 0);

  const { data: integ } = await supabaseAdmin.from("store_integrations").select("meta").eq("id", integrationId).maybeSingle();
  const meta: any = ((integ as any)?.meta) || {};
  meta.shopify_permissions = { ok: true, granted_scopes: scopes, missing_scopes: [], checked_at: new Date().toISOString() };
  meta.stats = { ...(meta.stats || {}), orders: orderCount, customers: customerCount, products: productCount, revenue };
  await supabaseAdmin.from("store_integrations").update({
    meta, total_revenue: revenue, last_sync_at: new Date().toISOString(), status: "connected",
  }).eq("id", integrationId);

  await logEvent({ workspace_id: workspaceId, integration_id: integrationId, direction: "in", event: "sync.completed", ok: true, message: `${orderCount} orders, ${customerCount} customers, ${productCount} products` });
  return { orders: orderCount, customers: customerCount, products: productCount, revenue };
}

// ---- WhatsApp automation trigger (mirrors WooCommerce wiring) ----
function sanitizeParam(v: unknown) {
  const s = String(v ?? "").replace(/[\r\n\t]+/g, " ").replace(/ {4,}/g, "   ").trim();
  return s.length ? s : "-";
}

function looksCashOnDelivery(raw: unknown) {
  const text = String(raw || "").toLowerCase();
  return /(^|[^a-z0-9])cod([^a-z0-9]|$)|cash[\s_-]*on[\s_-]*(delivery|pickup)|(^|[^a-z0-9])cash([^a-z0-9]|$)/i.test(text);
}

function appendUrlButtonParams(out: any[], schema: any[], urlButtonValue?: string | null) {
  const buttonsComp = schema.find((c: any) => String(c?.type || "").toUpperCase() === "BUTTONS");
  const buttons = Array.isArray(buttonsComp?.buttons) ? buttonsComp.buttons : [];
  for (let i = 0; i < buttons.length; i++) {
    const btn = buttons[i];
    if (String(btn?.type || "").toUpperCase() !== "URL") continue;
    const urlTmpl = String(btn?.url || "");
    const m = urlTmpl.match(/^(.*?)\{\{\s*\d+\s*\}\}/);
    if (!m) continue;
    const prefix = m[1];
    let suffix = "";
    if (urlButtonValue) {
      if (urlButtonValue.startsWith(prefix)) {
        suffix = urlButtonValue.slice(prefix.length);
      } else {
        try {
          const u = new URL(urlButtonValue);
          const segs = u.pathname.split("/").filter(Boolean);
          suffix = segs[segs.length - 1] || "";
        } catch {
          suffix = urlButtonValue;
        }
      }
    }
    if (!suffix) {
      const ex = Array.isArray(btn?.example) ? btn.example[0] : null;
      if (ex && typeof ex === "string") suffix = ex.startsWith(prefix) ? ex.slice(prefix.length) : ex;
    }
    if (!suffix) suffix = "recover";
    out.push({ type: "button", sub_type: "url", index: String(i), parameters: [{ type: "text", text: sanitizeParam(suffix) }] });
  }
}

function getRecoveryTokenFromUrl(urlButtonValue?: string | null) {
  if (!urlButtonValue) return "";
  try {
    const u = new URL(urlButtonValue);
    return u.pathname.split("/").filter(Boolean).pop() || "";
  } catch {
    return String(urlButtonValue).split(/[?#]/)[0].split("/").filter(Boolean).pop() || "";
  }
}

function applyInlineRecoveryTokenParams(schema: any[], bodyParams: string[], urlButtonValue?: string | null) {
  const token = getRecoveryTokenFromUrl(urlButtonValue);
  if (!token) return bodyParams;
  const bodyComp = schema.find((c: any) => String(c?.type || "").toUpperCase() === "BODY");
  const text = String(bodyComp?.text || "");
  if (!text) return bodyParams;

  const next = [...bodyParams];
  const re = /(?:https?:\/\/[^\s{}]+)?\/(?:api\/public\/)?r\/\{\{\s*(\d+)\s*\}\}/gi;
  let match: RegExpExecArray | null;
  while ((match = re.exec(text)) !== null) {
    const index = Number(match[1]) - 1;
    if (index >= 0) next[index] = token;
  }
  return next;
}

function buildComponents(schemaIn: any, bodyParams: string[], variableCount?: number | null, urlButtonValue?: string | null) {
  const out: any[] = [];
  const schema = Array.isArray(schemaIn) ? schemaIn : [];
  for (const comp of schema) {
    const type = String(comp?.type || "").toUpperCase();
    if (type === "HEADER") {
      const format = String(comp?.format || "TEXT").toUpperCase();
      if (format === "TEXT") {
        const headerVars: string[] = Array.isArray(comp?.example?.header_text) ? comp.example.header_text : [];
        const hasVar = /\{\{\d+\}\}/.test(String(comp?.text || ""));
        if (hasVar) out.push({ type: "header", parameters: [{ type: "text", text: sanitizeParam(headerVars[0] ?? "Update") }] });
      } else if (["IMAGE", "VIDEO", "DOCUMENT"].includes(format)) {
        const link = comp?.example?.header_handle?.[0];
        if (link) {
          const key = format.toLowerCase();
          out.push({ type: "header", parameters: [{ type: key, [key]: { link } }] });
        }
      }
    }
  }
  const count = Math.max(0, Number(variableCount || 0));
  if (count) {
    const effectiveBodyParams = applyInlineRecoveryTokenParams(schema, bodyParams, urlButtonValue);
    const values = Array.from({ length: count }, (_, i) => sanitizeParam(effectiveBodyParams[i]));
    out.push({ type: "body", parameters: values.map((text) => ({ type: "text", text })) });
  }
  appendUrlButtonParams(out, schema, urlButtonValue);
  return out.length ? out : undefined;
}

function normalizeE164(raw: string, defaultCountry = "91") {
  let digits = String(raw).replace(/[^\d]/g, "");
  if (!digits) return digits;
  if (digits.length === 10) digits = defaultCountry + digits;
  return digits;
}

async function sendWhatsAppTemplate(workspaceId: string, integrationId: string, toPhone: string, templateName: string, language: string, params: string[], variableCount?: number | null, componentsSchema?: any, contactName?: string | null, urlButtonValue?: string | null, isAbandonedCart = false) {
  const { data: settings } = await supabaseAdmin
    .from("whatsapp_settings").select("phone_number_id, access_token")
    .eq("workspace_id", workspaceId).maybeSingle();
  if (!(settings as any)?.phone_number_id || !(settings as any)?.access_token) {
    await logEvent({ workspace_id: workspaceId, integration_id: integrationId, direction: "out", event: `wa.${templateName}`, ok: false, message: "WhatsApp credentials missing — connect a WhatsApp number first" });
    return { ok: false, error: "WhatsApp credentials missing" };
  }
  const phone = normalizeE164(toPhone);
  if (!phone || phone.length < 8) {
    await logEvent({ workspace_id: workspaceId, integration_id: integrationId, direction: "out", event: `wa.${templateName}`, ok: false, message: `Invalid phone number: ${toPhone}` });
    return { ok: false, error: "Invalid phone number" };
  }
  const components = buildComponents(componentsSchema, params, variableCount, urlButtonValue);
  console.log(`[shopify] send template="${templateName}" lang=${language} vars=${variableCount} params=${JSON.stringify(params)} to=${phone}`);
  const body = {
    messaging_product: "whatsapp",
    to: phone,
    type: "template",
    template: { name: templateName, language: { code: language }, ...(components ? { components } : {}) },
  };
  try {
    const result = await sendWhatsAppMessage({
      settings: {
        phone_number_id: (settings as any).phone_number_id,
        access_token: (settings as any).access_token,
      },
      toPhone: phone,
      payload: body,
      context: {
        workspaceId,
        purpose: isAbandonedCart ? "abandoned_cart" : "ecommerce",
        recipientId: phone,
        templateName,
        language,
        messageType: "template",
      },
    });
    const j: any = result.response ?? {};
    const waMessageId = result.wa_message_id ?? null;
    await logEvent({
      workspace_id: workspaceId, integration_id: integrationId, direction: "out",
      event: `wa.${templateName}`, ok: result.ok, status_code: result.http_status,
      message: result.ok
        ? `Sent template "${templateName}" to ${phone}`
        : (result.classification?.error || j?.error?.message || `HTTP ${result.http_status}`),
      payload: body, response: j,
    });
    if (result.ok && waMessageId) {
      try {
        const contactPhone = `+${phone}`;
        const { data: convoId } = await supabaseAdmin.rpc("resolve_conversation", {
          _workspace_id: workspaceId,
          _phone: contactPhone,
          _name: contactName || contactPhone,
          _last_message_at: new Date().toISOString(),
        } as any);
        const convo = convoId ? { id: convoId as string } : null;
        if (convo) {
          const bodyText = String((Array.isArray(componentsSchema) ? componentsSchema : []).find((c: any) => String(c?.type || "").toUpperCase() === "BODY")?.text || "");
          const rendered = bodyText.replace(/\{\{\s*(\d+)\s*\}\}/g, (_m, idx) => {
            const i = Math.max(0, Number(idx) - 1);
            return params[i] != null ? String(params[i]) : "";
          });
          const preview = rendered || `[template] ${templateName}`;
          await supabaseAdmin.from("messages").insert({
            workspace_id: workspaceId, conversation_id: (convo as any).id,
            direction: "out", type: "text", content: preview,
            wa_message_id: waMessageId, status: "sent",
          } as any);
          await supabaseAdmin.from("conversations").update({
            last_message_at: new Date().toISOString(), last_message_preview: preview.slice(0, 140),
          }).eq("id", (convo as any).id);
        }
      } catch (e) { console.error("shopify recordOutboundMessage failed", e); }
    }
    return {
      ok: result.ok,
      response: j,
      waMessageId,
      error: result.ok ? undefined : (result.classification?.error || j?.error?.message || `HTTP ${result.http_status}`),
    };
  } catch (e: any) {
    await logEvent({ workspace_id: workspaceId, integration_id: integrationId, direction: "out", event: `wa.${templateName}`, ok: false, message: String(e?.message || e), payload: body });
    return { ok: false, error: String(e?.message || e) };
  }
}

async function claimAutomationRun(args: { workspaceId: string; integrationId: string; automationKey: string; targetType: string; targetId: string }) {
  const claim = {
    workspace_id: args.workspaceId,
    integration_id: args.integrationId,
    automation_key: args.automationKey,
    target_type: args.targetType,
    target_id: args.targetId,
    ok: false,
    message: "Claimed before sending",
  } as any;
  let { error } = await supabaseAdmin.from("ecom_automation_runs").insert(claim);
  if (!error) return true;
  if ((error as any).code === "23505") {
    // A worker can stop after claiming but before recording the API result.
    // Reclaim failed/stale rows after a short safety window; successful rows
    // remain permanent duplicate guards.
    const staleBefore = new Date(Date.now() - 2 * 60_000).toISOString();
    const { data: stale } = await supabaseAdmin.from("ecom_automation_runs")
      .select("id, ok, sent_at")
      .eq("workspace_id", args.workspaceId)
      .eq("automation_key", args.automationKey)
      .eq("target_type", args.targetType)
      .eq("target_id", args.targetId)
      .eq("ok", false)
      .lte("sent_at", staleBefore)
      .maybeSingle();
    if (!stale?.id) return false;
    await supabaseAdmin.from("ecom_automation_runs").delete().eq("id", stale.id).eq("ok", false);
    ({ error } = await supabaseAdmin.from("ecom_automation_runs").insert(claim));
    if (!error) return true;
    if ((error as any).code === "23505") return false;
  }
  await logEvent({ workspace_id: args.workspaceId, integration_id: args.integrationId, direction: "out", event: `wa.${args.automationKey}`, ok: false, message: `Unable to claim automation run: ${error.message}` });
  return false;
}

async function markAutomationRun(args: { workspaceId: string; automationKey: string; targetType: string; targetId: string; ok: boolean; message?: string | null }) {
  await supabaseAdmin.from("ecom_automation_runs").update({
    ok: args.ok,
    message: args.message ?? null,
    sent_at: new Date().toISOString(),
  } as any)
    .eq("workspace_id", args.workspaceId)
    .eq("automation_key", args.automationKey)
    .eq("target_type", args.targetType)
    .eq("target_id", args.targetId);
}

export async function triggerShopifyAutomation(integration: any, eventKey: string, ctx: { phone: string | null; name?: string | null; orderNumber?: string | null; total?: number | null; currency?: string | null; isCod?: boolean; targetType?: string; targetId?: string | number | null; items?: any[]; email?: string | null; orderStatus?: string | null; orderDate?: string | null; recoveryUrl?: string | null }): Promise<{ ok: boolean; skipped?: string; error?: string; waMessageId?: string | null }> {
  if (!ctx.phone) {
    await logEvent({ workspace_id: integration.workspace_id, integration_id: integration.id, direction: "out", event: `wa.${eventKey}`, ok: false, message: "Skipped — order has no phone number" });
    return { ok: false, skipped: "missing_phone" };
  }
  const automations = (integration.meta?.automations as any) || {};
  // For COD orders on creation, prefer cod_verification over order_confirmation.
  const codAliases = ctx.isCod ? ["cod_verification"] : [];
  const aliases: Record<string, string[]> = {
    order_created: [...codAliases, "order_confirmation"],
    order_paid: ["order_confirmation", "payment_received"],
    order_fulfilled: ["order_shipped", "order_confirmation"],
    order_cancelled: ["order_cancelled"],
    cart_abandoned: ["abandoned_cart"],
  };
  const keys = [eventKey, ...(aliases[eventKey] || [])];
  let matchedKey: string | null = null;
  let conf: any = null;
  for (const k of keys) {
    const v = automations[k];
    if (v === true || v?.enabled) { matchedKey = k; conf = v; break; }
  }
  if (!conf) {
    await logEvent({
      workspace_id: integration.workspace_id, integration_id: integration.id,
      direction: "out", event: `wa.${eventKey}`, ok: false,
      message: `No automation configured for "${eventKey}"${ctx.isCod ? " (COD order)" : ""}. Tried: ${keys.join(", ")}. Enable it under Integrations → Shopify → Automations.`,
    });
    return { ok: false, skipped: "disabled" };
  }
  const configuredName = typeof conf === "object" ? conf.template_name : null;
  let template: any = null;
  if (configuredName) {
    const { data } = await supabaseAdmin.from("templates")
      .select("meta_template_name, language, variables_count, components, variable_mapping")
      .eq("workspace_id", integration.workspace_id).eq("meta_template_name", configuredName).maybeSingle();
    template = data;
  }
  if (!template) {
    const { data } = await supabaseAdmin.from("templates")
      .select("meta_template_name, language, variables_count, components, variable_mapping")
      .eq("workspace_id", integration.workspace_id).eq("status", "APPROVED")
      .order("created_at", { ascending: false }).limit(1).maybeSingle();
    template = data;
  }
  if (!template?.meta_template_name) {
    await logEvent({
      workspace_id: integration.workspace_id, integration_id: integration.id,
      direction: "out", event: `wa.${eventKey}`, ok: false,
      message: "No approved WhatsApp template found. Create & approve a template first.",
    });
    return { ok: false, skipped: "missing_template" };
  }
  // Guard: if the configured template or automation config is COD-specific,
  // only fire for COD orders. Prevents a `cod_order_confirmation` template
  // wired into the generic Order Confirmation slot from sending to prepaid orders.
  const codOnlyFlag = typeof conf === "object" && (conf.cod_only === true || conf.only_cod === true);
  const nameLooksCod = looksCashOnDelivery(String(configuredName || "") + " " + String(template.meta_template_name || ""));
  if ((codOnlyFlag || nameLooksCod) && !ctx.isCod) {
    await logEvent({
      workspace_id: integration.workspace_id, integration_id: integration.id,
      direction: "out", event: `wa.${matchedKey || eventKey}`, ok: true,
      message: `Skipped — COD-only template "${template.meta_template_name}" not sent for non-COD order`,
    });
    return { ok: false, skipped: "cod_only" };
  }
  const automationKey = matchedKey || eventKey;
  const targetType = ctx.targetType || "order";
  const targetId = String(ctx.targetId || ctx.orderNumber || ctx.phone || "").trim();
  if (!targetId) {
    await logEvent({ workspace_id: integration.workspace_id, integration_id: integration.id, direction: "out", event: `wa.${automationKey}`, ok: false, message: "Skipped — missing stable event/customer id for duplicate protection" });
    return { ok: false, skipped: "missing_target_id" };
  }
  const claimed = await claimAutomationRun({ workspaceId: integration.workspace_id, integrationId: integration.id, automationKey, targetType, targetId });
  if (!claimed) {
    await logEvent({ workspace_id: integration.workspace_id, integration_id: integration.id, direction: "out", event: `wa.${automationKey}`, ok: true, message: `Skipped duplicate ${automationKey} for ${targetType}:${targetId}` });
    return { ok: false, skipped: "already_claimed" };
  }
  const lang = (typeof conf === "object" ? conf.language : null) || template.language || "en_US";
  const storeName = (integration?.meta?.store_name || integration?.meta?.shop_name
    || (integration?.shop_domain ? String(integration.shop_domain).split(".")[0] : null)
    || "our store") as string;
  const symMap: Record<string, string> = { INR: "₹", USD: "$", EUR: "€", GBP: "£", AED: "AED ", AUD: "A$", CAD: "C$" };
  const cur = (ctx.currency || "").toUpperCase();
  const sym = symMap[cur] || (ctx.currency ? `${ctx.currency} ` : "");
  const amountStr = `${sym}${Number(ctx.total ?? 0).toFixed(2)}`;

  // Product info from order line items — slots classified as productName /
  // productPrice resolve from real data instead of an unrelated fallback.
  const items: any[] = Array.isArray(ctx.items) ? ctx.items : [];
  const firstItem = items[0] || null;
  const productName = firstItem?.name || firstItem?.title
    ? (items.length > 1 ? `${String(firstItem.name || firstItem.title)} +${items.length - 1} more` : String(firstItem.name || firstItem.title))
    : null;
  const productPrice = firstItem != null && (firstItem.price ?? firstItem.total) != null
    ? `${sym}${Number(firstItem.price ?? firstItem.total).toFixed(2)}`
    : null;

  // Smart resolver — see src/lib/wa-template-vars.server.ts for full
  // explanation. Keyword-driven mapping with positional fallback so any
  // template layout sends the right value to each placeholder.
  const isCart = ["cart_abandoned", "abandoned_cart"].includes(eventKey)
    || /cart|abandon/i.test(template.meta_template_name);
  const fallbackOrder: FieldKey[] = isCart
    ? ["name", "url", "amount", "storeName"]
    : ["name", "orderNumber", "storeName", "amount"];
  const resolved = resolveTemplateParams(
    template.components,
    {
      name: ctx.name || "Customer",
      orderNumber: ctx.orderNumber || "",
      storeName,
      amount: amountStr,
      amountRaw: ctx.total ?? null,
      currency: ctx.currency || null,
      url: ctx.recoveryUrl || null,
      productName,
      productPrice,
      orderStatus: ctx.orderStatus || null,
      orderDate: ctx.orderDate || null,
      customerEmail: ctx.email || null,
      customerPhone: ctx.phone || null,
    },
    fallbackOrder,
    template.variables_count,
    (template as any).variable_mapping ?? null,
  );
  const params = resolved.params;
  await logEvent({
    workspace_id: integration.workspace_id, integration_id: integration.id,
    direction: "out", event: `wa.${eventKey}.mapping`,
    ok: resolved.warnings.length === 0,
    message: resolved.warnings.length
      ? `Template "${template.meta_template_name}" mapping warnings: ${resolved.warnings.join("; ")}`
      : `Template "${template.meta_template_name}" mapped ${resolved.mapping.map(m => `{{${m.index}}}=${m.field}`).join(" ")}`,
    payload: { template: template.meta_template_name, language: lang, params, mapping: resolved.mapping, warnings: resolved.warnings, ctx: { name: ctx.name, orderNumber: ctx.orderNumber, total: ctx.total, currency: ctx.currency, storeName } },
  });
  const result = await sendWhatsAppTemplate(
    integration.workspace_id, integration.id, ctx.phone,
    template.meta_template_name, lang, params,
    template.variables_count, template.components, ctx.name ?? null,
    ctx.recoveryUrl ?? null,
    isCart,
  );
  await markAutomationRun({
    workspaceId: integration.workspace_id,
    automationKey,
    targetType,
    targetId,
    ok: !!result.ok,
    message: result.ok ? `Sent template ${template.meta_template_name}` : (result.error || "WhatsApp send failed"),
  });
  return {
    ok: !!result.ok,
    error: result.error,
    waMessageId: result.waMessageId ?? null,
  };
}

