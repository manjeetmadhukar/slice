import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

async function assertMember(supabase: any, workspaceId: string, userId: string) {
  const { data } = await supabase
    .from("workspace_members").select("role")
    .eq("workspace_id", workspaceId).eq("user_id", userId).maybeSingle();
  if (!data) throw new Error("Not a member of this workspace");
  return data.role as "owner" | "admin" | "agent" | "viewer";
}

const automationSchema = z.object({
  id: z.string().uuid().optional(),
  workspace_id: z.string().uuid(),
  name: z.string().min(1).max(120),
  type: z.enum(["welcome", "away", "keyword", "routing"]),
  enabled: z.boolean().default(true),
  keywords: z.array(z.string().min(1).max(80)).max(50).default([]),
  match_type: z.enum(["contains", "exact", "starts_with"]).default("contains"),
  reply_text: z.string().max(4096).nullable().optional(),
  template_id: z.string().uuid().nullable().optional(),
  away_start: z.string().regex(/^\d{2}:\d{2}$/).nullable().optional(),
  away_end: z.string().regex(/^\d{2}:\d{2}$/).nullable().optional(),
  away_days: z.array(z.number().int().min(0).max(6)).default([0, 1, 2, 3, 4, 5, 6]),
  assign_to: z.string().uuid().nullable().optional(),
  priority: z.number().int().min(0).max(1000).default(0),
});

export const saveAutomation = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) => automationSchema.parse(input))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const role = await assertMember(supabase, data.workspace_id, userId);
    if (role === "viewer") throw new Error("Viewers cannot edit automations");

    const row: any = {
      ...data,
      user_id: userId,
      updated_at: new Date().toISOString(),
      reply_text: data.reply_text ?? null,
      template_id: data.template_id ?? null,
      away_start: data.away_start ?? null,
      away_end: data.away_end ?? null,
      assign_to: data.assign_to ?? null,
    };

    if (data.id) {
      const { error } = await supabase.from("automations").update(row).eq("id", data.id);
      if (error) throw new Error(error.message);
      return { id: data.id };
    } else {
      const { data: ins, error } = await supabase.from("automations").insert(row).select("id").single();
      if (error) throw new Error(error.message);
      return { id: ins.id };
    }
  });

export const deleteAutomation = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    const { supabase } = context;
    const { error } = await supabase.from("automations").delete().eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const toggleAutomation = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) => z.object({ id: z.string().uuid(), enabled: z.boolean() }).parse(input))
  .handler(async ({ data, context }) => {
    const { supabase } = context;
    const { error } = await supabase.from("automations").update({ enabled: data.enabled }).eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });
