import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

// List enabled gateways (for customers to choose from)
export const listEnabledGateways = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase } = context;
    const { data, error } = await supabase
      .from("payment_gateways")
      .select("provider, display_name, key_id, is_enabled, meta")
      .eq("is_enabled", true);
    if (error) throw new Error(error.message);
    return { gateways: data ?? [] };
  });

// List plans (templates) available to purchase
export const listPurchasablePlans = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase } = context;
    const { data, error } = await supabase
      .from("plan_templates")
      .select("id, name, description, features, limits, price_monthly, price_yearly, currency, gateway_ids, is_active")
      .eq("is_active", true)
      .order("price_monthly", { ascending: true });
    if (error) throw new Error(error.message);
    return { plans: data ?? [] };
  });

// List recent payment transactions for current workspace
export const listWorkspaceTransactions = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) => z.object({ workspace_id: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    const { supabase } = context;
    const { data: rows, error } = await supabase
      .from("payment_transactions")
      .select("*")
      .eq("workspace_id", data.workspace_id)
      .order("created_at", { ascending: false })
      .limit(50);
    if (error) throw new Error(error.message);
    return { transactions: rows ?? [] };
  });

// ============ Create checkout ============

const CheckoutInput = z.object({
  workspace_id: z.string().uuid(),
  template_id: z.string().uuid(),
  provider: z.enum(["razorpay", "cashfree", "instamojo", "stripe"]),
  billing_interval: z.enum(["monthly", "yearly"]),
});

export const createCheckout = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) => CheckoutInput.parse(input))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;

    // Verify membership
    const { data: member } = await supabase
      .from("workspace_members")
      .select("role")
      .eq("workspace_id", data.workspace_id)
      .eq("user_id", userId)
      .maybeSingle();
    if (!member) throw new Error("Not a member of this workspace");

    // Load template
    const { data: tpl, error: tErr } = await supabase
      .from("plan_templates")
      .select("*")
      .eq("id", data.template_id)
      .eq("is_active", true)
      .maybeSingle();
    if (tErr) throw new Error(tErr.message);
    if (!tpl) throw new Error("Plan not found");

    // Load gateway config
    const { data: gwPublic, error: gErr } = await supabase
      .from("payment_gateways")
      .select("*")
      .eq("provider", data.provider)
      .eq("is_enabled", true)
      .maybeSingle();
    if (gErr) throw new Error(gErr.message);
    if (!gwPublic) throw new Error(`${data.provider} is not enabled. Ask your admin to configure it.`);
    // Load full row (including secrets) via admin — RLS may hide secret columns from end users.
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: gwFull } = await supabaseAdmin
      .from("payment_gateways").select("*")
      .eq("provider", data.provider).maybeSingle();
    const gw: any = gwFull ?? gwPublic;


    const amount = Number(data.billing_interval === "yearly" ? tpl.price_yearly : tpl.price_monthly);
    if (amount <= 0) throw new Error("This plan has no price set.");
    const currency = tpl.currency || "INR";

    // Insert transaction row first (status=created) so webhook can find it
    const { data: tx, error: txErr } = await supabase
      .from("payment_transactions")
      .insert({
        workspace_id: data.workspace_id,
        user_id: userId,
        template_id: tpl.id,
        plan_name_snapshot: tpl.name,
        provider: data.provider,
        billing_interval: data.billing_interval,
        amount,
        currency,
        status: "created",
      })
      .select("*")
      .single();
    if (txErr) throw new Error(txErr.message);

    // Provider-specific order creation
    let providerOrder: { order_id?: string; checkout_url?: string; client_payload?: Record<string, string | number> } = {};

    if (data.provider === "razorpay") {
      const keyId = gw.key_id;
      const keySecret = (gw as any).secret_key || process.env.RAZORPAY_KEY_SECRET;
      if (!keyId || !keySecret) throw new Error("Razorpay credentials not configured");
      const res = await fetch("https://api.razorpay.com/v1/orders", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: "Basic " + Buffer.from(`${keyId}:${keySecret}`).toString("base64"),
        },
        body: JSON.stringify({
          amount: Math.round(amount * 100), // paise
          currency,
          receipt: tx.id,
          notes: { workspace_id: data.workspace_id, template_id: tpl.id, tx_id: tx.id, interval: data.billing_interval },
        }),
      });
      const json: any = await res.json();
      if (!res.ok) throw new Error(json?.error?.description || "Razorpay order failed");
      providerOrder.order_id = json.id;
      providerOrder.client_payload = {
        key: keyId,
        order_id: json.id,
        amount: json.amount,
        currency: json.currency,
        name: tpl.name,
        description: `${tpl.name} — ${data.billing_interval}`,
      };
    } else if (data.provider === "stripe") {
      const secret = (gw as any).secret_key || process.env.STRIPE_SECRET_KEY;
      if (!secret) throw new Error("Stripe credentials not configured");
      const origin = process.env.PUBLIC_SITE_URL || "https://watiautomation.lovable.app";
      const params = new URLSearchParams();
      params.append("mode", "payment");
      params.append("success_url", `${origin}/subscription?payment=success`);
      params.append("cancel_url", `${origin}/subscription?payment=cancel`);
      params.append("line_items[0][quantity]", "1");
      params.append("line_items[0][price_data][currency]", currency.toLowerCase());
      params.append("line_items[0][price_data][unit_amount]", String(Math.round(amount * 100)));
      params.append("line_items[0][price_data][product_data][name]", `${tpl.name} (${data.billing_interval})`);
      params.append("metadata[tx_id]", tx.id);
      params.append("metadata[workspace_id]", data.workspace_id);
      params.append("metadata[template_id]", tpl.id);
      params.append("metadata[interval]", data.billing_interval);
      const res = await fetch("https://api.stripe.com/v1/checkout/sessions", {
        method: "POST",
        headers: { Authorization: `Bearer ${secret}`, "Content-Type": "application/x-www-form-urlencoded" },
        body: params,
      });
      const json: any = await res.json();
      if (!res.ok) throw new Error(json?.error?.message || "Stripe checkout failed");
      providerOrder.order_id = json.id;
      providerOrder.checkout_url = json.url;
    } else if (data.provider === "instamojo") {
      const auth = (gw as any).secret_key || process.env.INSTAMOJO_AUTH_TOKEN;
      if (!auth) throw new Error("Instamojo credentials not configured");
      const origin = process.env.PUBLIC_SITE_URL || "https://watiautomation.lovable.app";
      const body = new URLSearchParams({
        amount: String(amount),
        purpose: `${tpl.name} (${data.billing_interval})`,
        redirect_url: `${origin}/subscription?payment=instamojo&tx=${tx.id}`,
        send_email: "false",
        allow_repeated_payments: "false",
      });
      const res = await fetch("https://api.instamojo.com/v2/payment_requests/", {
        method: "POST",
        headers: { Authorization: `Bearer ${auth}`, "Content-Type": "application/x-www-form-urlencoded" },
        body,
      });
      const json: any = await res.json();
      if (!res.ok) throw new Error(json?.message || "Instamojo request failed");
      providerOrder.order_id = json.id;
      providerOrder.checkout_url = json.longurl;
    } else if (data.provider === "cashfree") {
      const appId = gw.key_id;
      const secret = (gw as any).secret_key || process.env.CASHFREE_SECRET_KEY;
      if (!appId || !secret) throw new Error("Cashfree credentials not configured");
      const origin = process.env.PUBLIC_SITE_URL || "https://watiautomation.lovable.app";
      const linkId = `plan_${tx.id.replace(/-/g, "")}`.slice(0, 45);
      const res = await fetch("https://api.cashfree.com/pg/links", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-api-version": "2023-08-01",
          "x-client-id": appId,
          "x-client-secret": secret,
        },
        body: JSON.stringify({
          link_id: linkId,
          link_amount: amount,
          link_currency: currency,
          link_purpose: `Subscription ${tx.id}`,
          customer_details: {
            customer_name: "Customer",
            customer_phone: "9999999999",
            customer_email: "noreply@example.com",
          },
          link_meta: {
            return_url: `${origin}/subscription?payment=cashfree&tx=${tx.id}`,
            notify_url: `${origin}/api/public/payments/cashfree`,
          },
          link_notify: { send_email: false, send_sms: false },
          link_auto_reminders: false,
        }),
      });
      const json: any = await res.json();
      if (!res.ok) throw new Error(json?.message || "Cashfree link failed");
      providerOrder.order_id = json.link_id || linkId;
      providerOrder.checkout_url = json.link_url;
    }

    // Persist provider order id back to transaction
    if (providerOrder.order_id) {
      await supabase
        .from("payment_transactions")
        .update({ order_id: providerOrder.order_id })
        .eq("id", tx.id);
    }

    return {
      tx_id: tx.id,
      provider: data.provider,
      ...providerOrder,
    };
  });
