// Central WhatsApp Cloud-API send helper.
//
// Every outbound call — campaigns, automations, bots, inbox, e-commerce
// hooks — should go through this function so that:
//
//   * transient failures (HTTP 429 / 5xx, network drops, Meta "try again"
//     codes) are automatically retried with exponential backoff before the
//     recipient is marked failed, and
//   * every attempt (successful or not) is persisted to
//     `whatsapp_delivery_logs` with the exact Meta error code, subcode,
//     trace id, HTTP status, and latency for post-mortem debugging.
//
// The helper never throws for a Meta-side rejection — it always resolves
// with a `{ ok, ... }` result so callers can decide how to record the
// outcome on their domain tables (campaign_recipients, messages, etc.).
import { supabaseAdmin } from "@/integrations/supabase/client.server";
import {
  classifyWhatsAppDeliveryError,
  type WhatsAppErrorClassification,
} from "./whatsapp-delivery-status";

const META_BASE = "https://graph.facebook.com/v21.0";

// Per-attempt inline retries — kept short so we still fit inside the
// worker time budget. Anything still failing after this is either
// permanent (marked "failed") or deferred to the cron dispatcher for
// backoff retries (campaign path only, see campaign-executor).
const MAX_INLINE_ATTEMPTS = 3;
const INLINE_BACKOFF_MS = [250, 750, 2000];

export type WhatsAppSendPurpose =
  | "campaign" | "automation" | "bot" | "inbox"
  | "shopify" | "woocommerce" | "abandoned_cart" | "ecommerce"
  | "browse_recovery"
  | "other";

export type WhatsAppSendContext = {
  workspaceId: string;
  purpose: WhatsAppSendPurpose;
  campaignId?: string | null;
  recipientId?: string | null;
  conversationId?: string | null;
  contactId?: string | null;
  templateName?: string | null;
  language?: string | null;
  messageType?: string | null;   // 'template' | 'text' | 'image' | ...
};

export type WhatsAppSendInput = {
  settings: { phone_number_id: string; access_token: string };
  toPhone: string;
  payload: any;                  // exact body to POST to /messages
  context: WhatsAppSendContext;
};

export type WhatsAppSendResult = {
  ok: boolean;
  http_status: number;
  wa_message_id?: string;
  attempts: number;
  latency_ms: number;
  classification?: WhatsAppErrorClassification;
  response?: any;
};

function sleep(ms: number) {
  return new Promise((r) => setTimeout(r, ms));
}

function redactedPayloadSummary(payload: any) {
  try {
    const t = payload?.type;
    const summary: any = { type: t };
    if (t === "template") {
      summary.template = {
        name: payload?.template?.name,
        language: payload?.template?.language?.code,
        components: (payload?.template?.components || []).map((c: any) => ({
          type: c?.type,
          param_count: Array.isArray(c?.parameters) ? c.parameters.length : 0,
          param_types: Array.isArray(c?.parameters)
            ? c.parameters.map((p: any) => p?.type).filter(Boolean)
            : [],
        })),
      };
    } else if (t === "text") {
      summary.text = { length: String(payload?.text?.body || "").length };
    } else if (t && payload?.[t]?.link) {
      summary[t] = { has_link: true };
    }
    return summary;
  } catch {
    return { type: payload?.type ?? null };
  }
}

async function logDelivery(input: WhatsAppSendInput, result: WhatsAppSendResult) {
  try {
    const ctx = input.context;
    const cls = result.classification;
    await supabaseAdmin.from("whatsapp_delivery_logs" as any).insert({
      workspace_id: ctx.workspaceId,
      purpose: ctx.purpose,
      campaign_id: ctx.campaignId ?? null,
      recipient_id: ctx.recipientId ?? null,
      conversation_id: ctx.conversationId ?? null,
      contact_id: ctx.contactId ?? null,
      to_phone: input.toPhone,
      template_name: ctx.templateName ?? null,
      language: ctx.language ?? null,
      message_type: ctx.messageType ?? input.payload?.type ?? null,
      request_summary: redactedPayloadSummary(input.payload),
      ok: result.ok,
      http_status: result.http_status,
      wa_message_id: result.wa_message_id ?? null,
      meta_code: cls?.code ?? null,
      meta_subcode: cls?.subcode ?? null,
      meta_title: cls?.title ?? null,
      meta_message: cls?.message ?? null,
      meta_details: cls?.details ?? null,
      meta_trace_id: cls?.trace_id ?? null,
      retryable: !!cls?.retryable,
      attempts: result.attempts,
      latency_ms: result.latency_ms,
    });
  } catch (e) {
    // Never fail the send because logging failed.
    console.error("whatsapp_delivery_logs insert failed", e);
  }
}

/**
 * Sends a WhatsApp Cloud-API message with inline retries + full logging.
 * Never throws — always returns a result the caller can act on.
 */
export async function sendWhatsAppMessage(input: WhatsAppSendInput): Promise<WhatsAppSendResult> {
  const url = `${META_BASE}/${input.settings.phone_number_id}/messages`;
  const startedAt = Date.now();
  const toPhoneDigits = String(input.toPhone || "").replace(/[^\d]/g, "");
  const body = JSON.stringify({ ...input.payload, to: toPhoneDigits });

  let lastResult: WhatsAppSendResult = {
    ok: false, http_status: 0, attempts: 0, latency_ms: 0,
  };

  for (let attempt = 1; attempt <= MAX_INLINE_ATTEMPTS; attempt++) {
    const attemptStart = Date.now();
    let httpStatus = 0;
    let json: any = null;
    let networkError: any = null;

    try {
      const res = await fetch(url, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${input.settings.access_token}`,
          "Content-Type": "application/json",
        },
        body,
      });
      httpStatus = res.status;
      json = await res.json().catch(() => ({}));
    } catch (e) {
      networkError = e;
    }

    const latency_ms = Date.now() - attemptStart;

    if (!networkError && httpStatus >= 200 && httpStatus < 300) {
      const wa_message_id = json?.messages?.[0]?.id as string | undefined;
      lastResult = {
        ok: true,
        http_status: httpStatus,
        wa_message_id,
        attempts: attempt,
        latency_ms: Date.now() - startedAt,
        response: json,
      };
      break;
    }

    // Classify + decide whether to retry inline.
    let classification: WhatsAppErrorClassification;
    if (networkError) {
      classification = {
        status: "failed",
        retryable: true,
        message: String(networkError?.message || networkError),
        error: `Network error contacting Meta: ${String(networkError?.message || networkError).slice(0, 200)}`,
      };
    } else {
      classification = classifyWhatsAppDeliveryError(json?.error ?? json, httpStatus);
    }

    lastResult = {
      ok: false,
      http_status: httpStatus,
      attempts: attempt,
      latency_ms: Date.now() - startedAt,
      classification,
      response: json,
    };

    // Auth / config failures — do NOT keep retrying inline; caller will surface.
    if (httpStatus === 401 || httpStatus === 403) break;

    if (!classification.retryable || attempt === MAX_INLINE_ATTEMPTS) break;
    await sleep(INLINE_BACKOFF_MS[attempt - 1] ?? 2000);
  }

  await logDelivery(input, lastResult);
  return lastResult;
}
