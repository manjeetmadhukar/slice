// Records WhatsApp template Quick Reply / interactive button clicks.
// Works for ANY button label (not just "Interested") so reports can be
// filtered by any button dynamically.
import { supabaseAdmin } from "@/integrations/supabase/client.server";
import { emitWorkspaceWebhook } from "./webhook-emit.server";

export interface ButtonClickInput {
  workspace_id: string;
  contact_id: string | null;
  contact_name: string | null;
  phone: string;
  conversation_id: string | null;
  button_text: string | null;
  button_payload: string | null;
  button_type: "quick_reply" | "list_reply";
  wa_message_id: string | null;
  context_wa_message_id: string | null;
  clicked_at: string;
}

function normalizePhone(phone: string) {
  const digits = String(phone || "").replace(/\D/g, "");
  return digits || null;
}

export async function recordTemplateButtonClick(input: ButtonClickInput) {
  try {
    let campaign_id: string | null = null;
    let template_name: string | null = null;

    // Resolve the originating campaign/template from the template message the
    // customer replied to (Meta sends context.id = our sent wa_message_id).
    if (input.context_wa_message_id) {
      const { data: recipient } = await supabaseAdmin
        .from("campaign_recipients")
        .select("campaign_id")
        .eq("workspace_id", input.workspace_id)
        .eq("message_id", input.context_wa_message_id)
        .maybeSingle();
      if (recipient?.campaign_id) {
        campaign_id = recipient.campaign_id as string;
        const { data: campaign } = await supabaseAdmin
          .from("campaigns")
          .select("template_name")
          .eq("id", campaign_id)
          .maybeSingle();
        template_name = (campaign as any)?.template_name ?? null;
      }
    }

    // Dedupe manually: the uniqueness index is partial (wa_message_id IS NOT NULL),
    // which PostgREST cannot use for an upsert conflict target.
    if (input.wa_message_id) {
      const { data: dupe } = await supabaseAdmin
        .from("template_button_clicks" as any)
        .select("id")
        .eq("workspace_id", input.workspace_id)
        .eq("wa_message_id", input.wa_message_id)
        .maybeSingle();
      if (dupe) return;
    }

    const { data: inserted, error } = await supabaseAdmin
      .from("template_button_clicks" as any)
      .insert({
        workspace_id: input.workspace_id,
        contact_id: input.contact_id,
        contact_name: input.contact_name,
        phone: input.phone,
        phone_normalized: normalizePhone(input.phone),
        conversation_id: input.conversation_id,
        campaign_id,
        template_name,
        button_text: input.button_text,
        button_payload: input.button_payload,
        button_type: input.button_type,
        wa_message_id: input.wa_message_id,
        context_wa_message_id: input.context_wa_message_id,
        clicked_at: input.clicked_at,
      })
      .select("id")
      .maybeSingle();


    if (error) {
      await supabaseAdmin.from("integration_debug_logs").insert({
        workspace_id: input.workspace_id,
        provider: "whatsapp",
        event: "button_click.insert_failed",
        direction: "in",
        ok: false,
        status_code: 500,
        message: `Failed to record button click: ${error.message}`,
        payload: { phone: input.phone, button: input.button_text },
      });
      return;
    }

    await supabaseAdmin.from("integration_debug_logs").insert({
      workspace_id: input.workspace_id,
      provider: "whatsapp",
      event: "button_click.recorded",
      direction: "in",
      ok: true,
      status_code: 200,
      message: `Button click recorded: "${input.button_text || input.button_payload}" from ${input.phone}`,
      payload: {
        phone: input.phone,
        button: input.button_text,
        campaign_id,
        template_name,
        context_wa_message_id: input.context_wa_message_id,
      },
    });


    // Tag the contact with the button label (and "Interested" for interested-style buttons)
    const label = (input.button_text || "").trim();
    if (input.contact_id && label) {
      const tags = new Set<string>([label]);
      if (/interested/i.test(label)) tags.add("Interested");
      const { data: contact } = await supabaseAdmin
        .from("contacts")
        .select("tags")
        .eq("id", input.contact_id)
        .maybeSingle();
      const existing: string[] = Array.isArray((contact as any)?.tags) ? (contact as any).tags : [];
      const merged = Array.from(new Set([...existing, ...tags]));
      if (merged.length !== existing.length) {
        await supabaseAdmin.from("contacts").update({ tags: merged }).eq("id", input.contact_id);
      }
    }

    await emitWorkspaceWebhook(input.workspace_id, "button.clicked", {
      id: (inserted as any)?.id ?? null,
      contact_id: input.contact_id,
      contact_name: input.contact_name,
      phone: input.phone,
      campaign_id,
      template_name,
      button_text: input.button_text,
      button_payload: input.button_payload,
      button_type: input.button_type,
      clicked_at: input.clicked_at,
    });
  } catch (e) {
    console.error("recordTemplateButtonClick failed", e);
  }
}
