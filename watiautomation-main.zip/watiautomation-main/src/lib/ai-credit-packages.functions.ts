import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

async function assertSuperAdmin(supabase: any, userId: string) {
  const { data } = await supabase.from("profiles").select("is_super_admin").eq("id", userId).maybeSingle();
  if (!data?.is_super_admin) throw new Error("forbidden");
}

/** Public (signed-in) list of active packages for the Buy dialog. */
export const listAiCreditPackages = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("ai_credit_packages")
      .select("*")
      .eq("is_active", true)
      .order("sort_order", { ascending: true });
    if (error) throw new Error(error.message);
    return data ?? [];
  });

/** Super-admin list (includes disabled). */
export const adminListAiCreditPackages = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertSuperAdmin(context.supabase, context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data, error } = await supabaseAdmin
      .from("ai_credit_packages")
      .select("*")
      .order("sort_order", { ascending: true });
    if (error) throw new Error(error.message);
    return data ?? [];
  });

const PackageInput = z.object({
  id: z.string().uuid().optional(),
  name: z.string().min(1).max(100),
  description: z.string().max(500).optional().nullable(),
  credits: z.number().int().min(1).max(10_000_000_000),
  bonus_credits: z.number().int().min(0).max(10_000_000_000).optional(),
  price: z.number().min(0).max(10_000_000),
  currency: z.string().length(3).default("INR"),
  is_active: z.boolean().optional(),
  is_featured: z.boolean().optional(),
  sort_order: z.number().int().optional(),
  gateway_ids: z.array(z.string()).max(10).optional(),
});

export const adminUpsertAiCreditPackage = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) => PackageInput.parse(d))
  .handler(async ({ data, context }) => {
    await assertSuperAdmin(context.supabase, context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    if (data.id) {
      const { id, ...rest } = data;
      const { error } = await supabaseAdmin.from("ai_credit_packages").update(rest).eq("id", id);
      if (error) throw new Error(error.message);
      return { id };
    }
    const { data: row, error } = await supabaseAdmin
      .from("ai_credit_packages")
      .insert(data)
      .select("id")
      .single();
    if (error) throw new Error(error.message);
    return { id: row.id };
  });

export const adminDeleteAiCreditPackage = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) => z.object({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    await assertSuperAdmin(context.supabase, context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin.from("ai_credit_packages").delete().eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

/** Create a payment checkout to buy an AI credit package. Mirrors createCheckout in payments.functions.ts. */
const CheckoutInput = z.object({
  workspace_id: z.string().uuid(),
  package_id: z.string().uuid(),
  provider: z.enum(["razorpay", "cashfree", "instamojo", "stripe"]),
});

export const createAiCreditCheckout = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) => CheckoutInput.parse(d))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;

    const { data: member } = await supabase
      .from("workspace_members").select("role")
      .eq("workspace_id", data.workspace_id).eq("user_id", userId).maybeSingle();
    if (!member) throw new Error("Not a member of this workspace");

    const { data: pkg, error: pErr } = await supabase
      .from("ai_credit_packages").select("*").eq("id", data.package_id).eq("is_active", true).maybeSingle();
    if (pErr) throw new Error(pErr.message);
    if (!pkg) throw new Error("Package not found");

    const { data: gwPublic, error: gErr } = await supabase
      .from("payment_gateways").select("*")
      .eq("provider", data.provider).eq("is_enabled", true).maybeSingle();
    if (gErr) throw new Error(gErr.message);
    if (!gwPublic) throw new Error(`${data.provider} is not enabled. Ask your admin to configure it.`);
    // Load full row (including secrets) via admin client — RLS may hide secret columns from end users.
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: gwFull } = await supabaseAdmin
      .from("payment_gateways").select("*")
      .eq("provider", data.provider).maybeSingle();
    const gw: any = gwFull ?? gwPublic;


    const amount = Number(pkg.price);
    const currency = pkg.currency || "INR";
    const totalCredits = Number(pkg.credits) + Number(pkg.bonus_credits || 0);

    const { data: tx, error: txErr } = await supabase
      .from("payment_transactions")
      .insert({
        workspace_id: data.workspace_id,
        user_id: userId,
        template_id: null,
        credit_package_id: pkg.id,
        credits_amount: totalCredits,
        purpose: "credits",
        plan_name_snapshot: `AI Credits — ${pkg.name}`,
        provider: data.provider,
        billing_interval: "monthly",
        amount,
        currency,
        status: "created",
      })
      .select("*").single();
    if (txErr) throw new Error(txErr.message);

    let providerOrder: { order_id?: string; checkout_url?: string; client_payload?: Record<string, string | number> } = {};

    if (data.provider === "razorpay") {
      const keyId = gw.key_id;
      const keySecret = gw.secret_key || process.env.RAZORPAY_KEY_SECRET;
      if (!keyId || !keySecret) throw new Error("Razorpay credentials not configured");
      const res = await fetch("https://api.razorpay.com/v1/orders", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: "Basic " + Buffer.from(`${keyId}:${keySecret}`).toString("base64"),
        },
        body: JSON.stringify({
          amount: Math.round(amount * 100),
          currency,
          receipt: tx.id,
          notes: { workspace_id: data.workspace_id, package_id: pkg.id, tx_id: tx.id, purpose: "credits" },
        }),
      });
      const json: any = await res.json();
      if (!res.ok) throw new Error(json?.error?.description || "Razorpay order failed");
      providerOrder.order_id = json.id;
      providerOrder.client_payload = {
        key: keyId, order_id: json.id, amount: json.amount, currency: json.currency,
        name: `AI Credits — ${pkg.name}`, description: `${totalCredits.toLocaleString()} credits`,
      };
    } else if (data.provider === "stripe") {
      const secret = gw.secret_key || process.env.STRIPE_SECRET_KEY;
      if (!secret) throw new Error("Stripe credentials not configured");
      const origin = process.env.PUBLIC_SITE_URL || "https://watiautomation.lovable.app";
      const params = new URLSearchParams();
      params.append("mode", "payment");
      params.append("success_url", `${origin}/dashboard?ai_credits=success`);
      params.append("cancel_url", `${origin}/dashboard?ai_credits=cancel`);
      params.append("line_items[0][quantity]", "1");
      params.append("line_items[0][price_data][currency]", currency.toLowerCase());
      params.append("line_items[0][price_data][unit_amount]", String(Math.round(amount * 100)));
      params.append("line_items[0][price_data][product_data][name]", `AI Credits — ${pkg.name}`);
      params.append("metadata[tx_id]", tx.id);
      params.append("metadata[workspace_id]", data.workspace_id);
      params.append("metadata[package_id]", pkg.id);
      params.append("metadata[purpose]", "credits");
      const res = await fetch("https://api.stripe.com/v1/checkout/sessions", {
        method: "POST",
        headers: { Authorization: `Bearer ${secret}`, "Content-Type": "application/x-www-form-urlencoded" },
        body: params,
      });
      const json: any = await res.json();
      if (!res.ok) throw new Error(json?.error?.message || "Stripe checkout failed");
      providerOrder.order_id = json.id;
      providerOrder.checkout_url = json.url;
    } else if (data.provider === "instamojo") {
      const auth = gw.secret_key || process.env.INSTAMOJO_AUTH_TOKEN;
      if (!auth) throw new Error("Instamojo credentials not configured");
      const origin = process.env.PUBLIC_SITE_URL || "https://watiautomation.lovable.app";
      const body = new URLSearchParams({
        amount: String(amount),
        purpose: `AI Credits — ${pkg.name}`,
        redirect_url: `${origin}/dashboard?ai_credits=instamojo&tx=${tx.id}`,
        send_email: "false",
        allow_repeated_payments: "false",
      });
      const res = await fetch("https://api.instamojo.com/v2/payment_requests/", {
        method: "POST",
        headers: { Authorization: `Bearer ${auth}`, "Content-Type": "application/x-www-form-urlencoded" },
        body,
      });
      const json: any = await res.json();
      if (!res.ok) throw new Error(json?.message || "Instamojo request failed");
      providerOrder.order_id = json.id;
      providerOrder.checkout_url = json.longurl;
    } else if (data.provider === "cashfree") {
      const appId = gw.key_id;
      const secret = gw.secret_key || process.env.CASHFREE_SECRET_KEY;
      if (!appId || !secret) throw new Error("Cashfree credentials not configured");

      const origin = process.env.PUBLIC_SITE_URL || "https://watiautomation.lovable.app";
      const linkId = `cred_${tx.id.replace(/-/g, "")}`.slice(0, 45);
      const res = await fetch("https://api.cashfree.com/pg/links", {
        method: "POST",
        headers: {
          "Content-Type": "application/json", "x-api-version": "2023-08-01",
          "x-client-id": appId, "x-client-secret": secret,
        },
        body: JSON.stringify({
          link_id: linkId,
          link_amount: amount,
          link_currency: currency,
          link_purpose: `AI Credits ${tx.id}`,
          customer_details: {
            customer_name: "Customer",
            customer_phone: "9999999999",
            customer_email: "noreply@example.com",
          },
          link_meta: {
            return_url: `${origin}/dashboard?ai_credits=cashfree&tx=${tx.id}`,
            notify_url: `${origin}/api/public/payments/cashfree`,
          },
          link_notify: { send_email: false, send_sms: false },
          link_auto_reminders: false,
        }),
      });
      const json: any = await res.json();
      if (!res.ok) throw new Error(json?.message || "Cashfree link failed");
      providerOrder.order_id = json.link_id || linkId;
      providerOrder.checkout_url = json.link_url;
    }

    if (providerOrder.order_id) {
      await supabase.from("payment_transactions").update({ order_id: providerOrder.order_id }).eq("id", tx.id);
    }

    return { tx_id: tx.id, provider: data.provider, ...providerOrder };
  });
