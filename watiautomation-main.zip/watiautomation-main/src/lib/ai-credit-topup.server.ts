import { supabaseAdmin } from "@/integrations/supabase/client.server";

/**
 * If the paid transaction was for an AI credit package, top up the workspace's
 * AI credit wallet exactly once. Safe to call multiple times — uses a marker
 * in raw_event.credits_applied_at to prevent double-crediting.
 */
export async function creditAiWalletFromTransaction(tx: any): Promise<void> {
  if (!tx || tx.purpose !== "credits") return;
  if (!tx.workspace_id || !tx.credits_amount) return;

  // Idempotency: re-read latest row so a concurrent webhook can't double-credit
  const { data: fresh } = await supabaseAdmin
    .from("payment_transactions")
    .select("id, workspace_id, credits_amount, raw_event, plan_name_snapshot, user_id, credit_package_id")
    .eq("id", tx.id)
    .maybeSingle();
  if (!fresh) return;
  const raw = (fresh.raw_event as any) || {};
  if (raw.credits_applied_at) return;

  const amount = Number(fresh.credits_amount || 0);
  if (amount <= 0) return;

  const { error } = await supabaseAdmin.rpc("admin_adjust_ai_credits", {
    _workspace_id: fresh.workspace_id,
    _delta: amount,
    _entry_type: "recharge",
    _notes: `Purchase: ${fresh.plan_name_snapshot} (tx ${fresh.id})`,
    _actor: fresh.user_id,
  });
  if (error) {
    console.error("[ai-credit-topup] rpc failed", error);
    return;
  }

  await supabaseAdmin
    .from("payment_transactions")
    .update({ raw_event: { ...raw, credits_applied_at: new Date().toISOString() } })
    .eq("id", fresh.id);
}
