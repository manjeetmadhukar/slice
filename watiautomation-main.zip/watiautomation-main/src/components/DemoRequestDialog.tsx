import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { Loader2, Mail, Phone, CheckCircle2 } from "lucide-react";

export function DemoRequestDialog({
  open,
  onOpenChange,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
}) {
  const [loading, setLoading] = useState(false);
  const [done, setDone] = useState(false);
  const [form, setForm] = useState({
    full_name: "",
    email: "",
    phone: "",
    company: "",
    business_type: "",
    message: "",
  });

  function set<K extends keyof typeof form>(k: K, v: string) {
    setForm((f) => ({ ...f, [k]: v }));
  }

  async function submit() {
    if (!form.full_name || !form.email) {
      toast.error("Please add your name and email");
      return;
    }
    setLoading(true);
    try {
      const res = await fetch("/api/public/demo-request", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const j = await res.json();
      if (!res.ok) throw new Error(j.error ?? "Failed to send");
      setDone(true);
      toast.success("Thanks! We'll reach out shortly.");
    } catch (e: any) {
      toast.error(e.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <Dialog
      open={open}
      onOpenChange={(v) => {
        onOpenChange(v);
        if (!v) {
          setDone(false);
          setForm({ full_name: "", email: "", phone: "", company: "", business_type: "", message: "" });
        }
      }}
    >
      <DialogContent className="max-w-lg">
        {done ? (
          <div className="py-8 text-center">
            <div className="mx-auto grid h-14 w-14 place-items-center rounded-full bg-success/10 text-success">
              <CheckCircle2 className="h-7 w-7" />
            </div>
            <h3 className="mt-4 font-display text-xl font-semibold">You're on the list!</h3>
            <p className="mt-2 text-sm text-muted-foreground">
              Our team will reach out within one business day to schedule your personalized demo.
            </p>
            <Button className="mt-6" onClick={() => onOpenChange(false)}>
              Close
            </Button>
          </div>
        ) : (
          <>
            <DialogHeader>
              <DialogTitle>Book a personalized demo</DialogTitle>
              <DialogDescription>
                See how Slice fits your business. Free 30-minute walkthrough with a product expert.
              </DialogDescription>
            </DialogHeader>

            <div className="grid gap-4 py-2 sm:grid-cols-2">
              <div className="space-y-1.5 sm:col-span-2">
                <Label>Full name *</Label>
                <Input value={form.full_name} onChange={(e) => set("full_name", e.target.value)} placeholder="Jane Doe" />
              </div>
              <div className="space-y-1.5">
                <Label>Work email *</Label>
                <Input type="email" value={form.email} onChange={(e) => set("email", e.target.value)} placeholder="jane@company.com" />
              </div>
              <div className="space-y-1.5">
                <Label>Phone</Label>
                <Input value={form.phone} onChange={(e) => set("phone", e.target.value)} placeholder="+91 98xxx" />
              </div>
              <div className="space-y-1.5">
                <Label>Company</Label>
                <Input value={form.company} onChange={(e) => set("company", e.target.value)} placeholder="Acme Inc." />
              </div>
              <div className="space-y-1.5">
                <Label>Business type</Label>
                <Input value={form.business_type} onChange={(e) => set("business_type", e.target.value)} placeholder="E-commerce, SaaS, Edu…" />
              </div>
              <div className="space-y-1.5 sm:col-span-2">
                <Label>What are you hoping to solve?</Label>
                <Textarea
                  rows={3}
                  value={form.message}
                  onChange={(e) => set("message", e.target.value)}
                  placeholder="Tell us about your use case…"
                />
              </div>
            </div>

            <div className="flex flex-wrap items-center justify-between gap-3 border-t pt-4 text-xs text-muted-foreground">
              <a href="mailto:slice@dotscube.com" className="inline-flex items-center gap-1.5 hover:text-foreground">
                <Mail className="h-3.5 w-3.5" /> slice@dotscube.com
              </a>
              <a href="tel:+919602299003" className="inline-flex items-center gap-1.5 hover:text-foreground">
                <Phone className="h-3.5 w-3.5" /> +91 96022 99003
              </a>
            </div>

            <Button className="w-full" size="lg" disabled={loading} onClick={submit}>
              {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Request demo
            </Button>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}
