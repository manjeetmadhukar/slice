import { useEffect, useMemo, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { useQuery } from "@tanstack/react-query";
import { toast } from "sonner";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Coins, Loader2, ShoppingCart, Sparkles } from "lucide-react";
import { listAiCreditPackages, createAiCreditCheckout } from "@/lib/ai-credit-packages.functions";
import { listEnabledGateways } from "@/lib/payments.functions";

declare global { interface Window { Razorpay?: any } }

export function BuyAiCreditsDialog({
  workspaceId, open, onOpenChange,
}: { workspaceId: string; open: boolean; onOpenChange: (v: boolean) => void }) {
  const pkgFn = useServerFn(listAiCreditPackages);
  const gwFn = useServerFn(listEnabledGateways);
  const checkoutFn = useServerFn(createAiCreditCheckout);

  const { data: packages, isLoading } = useQuery({
    queryKey: ["ai-credit-packages"], enabled: open, queryFn: () => pkgFn(),
  });
  const { data: gwData } = useQuery({
    queryKey: ["enabled-gateways"], enabled: open, queryFn: () => gwFn(),
  });

  const gateways = gwData?.gateways ?? [];
  const [selectedPkg, setSelectedPkg] = useState<string | null>(null);
  const [provider, setProvider] = useState<string>("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (gateways.length && !provider) setProvider(gateways[0].provider);
  }, [gateways, provider]);

  const pkg = useMemo(() => (packages ?? []).find((p: any) => p.id === selectedPkg), [packages, selectedPkg]);

  async function loadRazorpay(): Promise<boolean> {
    if (window.Razorpay) return true;
    return new Promise((resolve) => {
      const s = document.createElement("script");
      s.src = "https://checkout.razorpay.com/v1/checkout.js";
      s.onload = () => resolve(true);
      s.onerror = () => resolve(false);
      document.body.appendChild(s);
    });
  }

  async function handleBuy() {
    if (!selectedPkg || !provider) { toast.error("Pick a package and a payment method"); return; }
    setBusy(true);
    try {
      const res: any = await checkoutFn({
        data: { workspace_id: workspaceId, package_id: selectedPkg, provider: provider as any },
      });
      if (provider === "razorpay") {
        const ok = await loadRazorpay();
        if (!ok) throw new Error("Could not load Razorpay");
        const rp = new window.Razorpay!({
          ...res.client_payload,
          handler: () => {
            toast.success("Payment received. Credits will appear once confirmed.");
            onOpenChange(false);
          },
          modal: { ondismiss: () => setBusy(false) },
        });
        rp.open();
      } else if (res.checkout_url) {
        window.location.href = res.checkout_url;
      } else {
        toast.error("No checkout URL returned");
      }
    } catch (e: any) {
      toast.error(e.message || "Checkout failed");
    } finally {
      setBusy(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Coins className="h-5 w-5 text-primary" /> Buy AI Credits
          </DialogTitle>
        </DialogHeader>

        {isLoading ? (
          <div className="p-8 text-center text-sm text-muted-foreground">Loading packages…</div>
        ) : (packages ?? []).length === 0 ? (
          <div className="p-8 text-center text-sm text-muted-foreground">No credit packages available yet.</div>
        ) : (
          <div className="grid gap-3 sm:grid-cols-2">
            {(packages ?? []).map((p: any) => {
              const bonus = Number(p.bonus_credits || 0);
              const total = Number(p.credits) + bonus;
              const active = selectedPkg === p.id;
              return (
                <Card
                  key={p.id}
                  onClick={() => setSelectedPkg(p.id)}
                  className={`p-4 cursor-pointer transition ${active ? "border-primary ring-2 ring-primary/30" : "hover:border-primary/40"}`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <p className="font-semibold flex items-center gap-2">
                        {p.name}
                        {p.is_featured && <Badge variant="secondary" className="text-[10px]"><Sparkles className="h-3 w-3 mr-0.5" /> Popular</Badge>}
                      </p>
                      {p.description && <p className="text-xs text-muted-foreground mt-0.5">{p.description}</p>}
                    </div>
                    <p className="font-display text-lg font-bold whitespace-nowrap">{p.currency} {Number(p.price).toLocaleString()}</p>
                  </div>
                  <div className="mt-3 text-sm">
                    <span className="font-semibold tabular-nums">{total.toLocaleString()}</span>
                    <span className="text-muted-foreground"> credits</span>
                    {bonus > 0 && <span className="text-success ml-1">(+{bonus.toLocaleString()} bonus)</span>}
                  </div>
                </Card>
              );
            })}
          </div>
        )}

        {gateways.length > 0 && (
          <div className="mt-2">
            <p className="text-xs text-muted-foreground mb-1">Payment method</p>
            <Select value={provider} onValueChange={setProvider}>
              <SelectTrigger><SelectValue placeholder="Select gateway" /></SelectTrigger>
              <SelectContent>
                {gateways.map((g: any) => (
                  <SelectItem key={g.provider} value={g.provider}>{g.display_name || g.provider}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        )}
        {gateways.length === 0 && (
          <p className="text-xs text-warning">No payment gateway is enabled yet. Ask your admin to configure one under Settings → Payments.</p>
        )}

        <DialogFooter>
          <Button variant="ghost" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button onClick={handleBuy} disabled={busy || !selectedPkg || !provider}>
            {busy ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <ShoppingCart className="h-4 w-4 mr-2" />}
            {pkg ? `Pay ${pkg.currency} ${Number(pkg.price).toLocaleString()}` : "Continue"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
