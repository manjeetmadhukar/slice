import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { toast } from "sonner";
import { Copy, Plus, Trash2, Facebook, Globe, Zap, Download, Puzzle, Building2 } from "lucide-react";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { MetaLeadAds } from "@/components/MetaLeadAds";

const PROVIDERS = [
  { key: "meta", label: "Meta Ads (Lead Ads)", icon: Facebook, hint: "Use with Zapier/Make: Meta Lead Ads → Webhooks → POST JSON" },
  { key: "wordpress", label: "WordPress Form", icon: Globe, hint: "Use with WPForms / CF7 / Elementor → Webhook integration, or a Zap from your form" },
  { key: "indiamart", label: "IndiaMART", icon: Building2, hint: "Paste this URL in IndiaMART Seller Panel → Lead Manager → Push API (CRM Integration)" },
  { key: "generic", label: "Generic / Other", icon: Zap, hint: "Any tool that can POST JSON or form data" },
] as const;

const FIELD_MAP = `Recognized field names (case-insensitive):
• name      ← name, full_name, fullName, your-name
• phone     ← phone, phone_number, mobile, tel
• email     ← email, your-email
• message   ← message, notes, comment, your-message`;

function genToken() {
  const a = new Uint8Array(24);
  crypto.getRandomValues(a);
  return Array.from(a).map((b) => b.toString(16).padStart(2, "0")).join("");
}

export function LeadIntake({ workspaceId }: { workspaceId: string | null }) {
  const qc = useQueryClient();
  const [provider, setProvider] = useState<"meta" | "wordpress" | "indiamart" | "generic">("meta");

  const { data: tokens = [] } = useQuery({
    queryKey: ["lead-intake-tokens", workspaceId],
    enabled: !!workspaceId,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("lead_intake_tokens")
        .select("*")
        .eq("workspace_id", workspaceId!)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data;
    },
  });

  const { data: stages = [] } = useQuery({
    queryKey: ["pipeline-stages-intake", workspaceId],
    enabled: !!workspaceId,
    queryFn: async () => {
      const { data } = await supabase.from("pipeline_stages")
        .select("id, name").eq("workspace_id", workspaceId!).order("position");
      return data ?? [];
    },
  });

  const origin = typeof window !== "undefined" ? window.location.origin : "";

  async function createToken() {
    if (!workspaceId) return;
    const { error } = await supabase.from("lead_intake_tokens").insert({
      workspace_id: workspaceId,
      provider,
      token: genToken(),
      enabled: true,
    });
    if (error) return toast.error(error.message);
    toast.success("Endpoint created");
    qc.invalidateQueries({ queryKey: ["lead-intake-tokens"] });
  }

  async function toggle(id: string, enabled: boolean) {
    await supabase.from("lead_intake_tokens").update({ enabled }).eq("id", id);
    qc.invalidateQueries({ queryKey: ["lead-intake-tokens"] });
  }
  async function setStage(id: string, stageId: string | null) {
    await supabase.from("lead_intake_tokens").update({ default_stage_id: stageId }).eq("id", id);
    qc.invalidateQueries({ queryKey: ["lead-intake-tokens"] });
  }
  async function deleteToken(id: string) {
    if (!confirm("Delete this endpoint? Any tool using its URL will stop creating leads.")) return;
    await supabase.from("lead_intake_tokens").delete().eq("id", id);
    qc.invalidateQueries({ queryKey: ["lead-intake-tokens"] });
  }

  function copy(s: string) {
    navigator.clipboard.writeText(s);
    toast.success("Copied");
  }

  return (
    <div className="space-y-6">
      <MetaLeadAds workspaceId={workspaceId} />

      <Card className="p-6">
        <h3 className="font-display text-lg font-semibold">Lead Intake URLs</h3>
        <p className="text-sm text-muted-foreground mt-1">
          Generate a webhook URL and paste it into Meta Lead Ads (via Zapier/Make), a WordPress form plugin, or any tool.
          Incoming leads automatically create a contact and a deal in your pipeline.
        </p>

        <div className="mt-5 flex flex-wrap items-end gap-3">
          <div className="space-y-1">
            <Label>Provider</Label>
            <div className="flex gap-2">
              {PROVIDERS.map((p) => (
                <Button
                  key={p.key}
                  type="button"
                  size="sm"
                  variant={provider === p.key ? "default" : "outline"}
                  onClick={() => setProvider(p.key as any)}
                >
                  <p.icon className="h-4 w-4 mr-1.5" />
                  {p.label}
                </Button>
              ))}
            </div>
          </div>
          <Button onClick={createToken}><Plus className="h-4 w-4 mr-1.5" />Generate URL</Button>
        </div>

        <div className="mt-6 space-y-3">
          {tokens.length === 0 && (
            <div className="text-center text-sm text-muted-foreground py-8 border rounded-lg">
              No endpoints yet. Generate one above.
            </div>
          )}
          {tokens.map((t: any) => {
            const url = `${origin}/api/public/leads/${t.provider}/${t.token}`;
            const p = PROVIDERS.find((x) => x.key === t.provider);
            return (
              <div key={t.id} className="border rounded-lg p-4 space-y-3">
                <div className="flex items-center justify-between gap-3">
                  <div className="flex items-center gap-2">
                    {p && <p.icon className="h-4 w-4" />}
                    <span className="font-medium">{p?.label ?? t.provider}</span>
                    <Badge variant={t.enabled ? "default" : "secondary"}>{t.enabled ? "Active" : "Disabled"}</Badge>
                    {t.last_used_at && (
                      <span className="text-xs text-muted-foreground">
                        Last lead: {new Date(t.last_used_at).toLocaleString()}
                      </span>
                    )}
                  </div>
                  <div className="flex items-center gap-2">
                    <Switch checked={t.enabled} onCheckedChange={(v) => toggle(t.id, v)} />
                    <Button size="sm" variant="ghost" onClick={() => deleteToken(t.id)}>
                      <Trash2 className="h-4 w-4 text-destructive" />
                    </Button>
                  </div>
                </div>

                <div className="flex gap-2">
                  <Input readOnly value={url} className="font-mono text-xs" />
                  <Button size="sm" variant="outline" onClick={() => copy(url)}>
                    <Copy className="h-4 w-4" />
                  </Button>
                </div>

                <div className="flex flex-wrap items-center gap-2 text-sm">
                  <Label className="text-muted-foreground">Land in stage:</Label>
                  <select
                    value={t.default_stage_id ?? ""}
                    onChange={(e) => setStage(t.id, e.target.value || null)}
                    className="border rounded px-2 py-1 text-sm bg-background"
                  >
                    <option value="">First stage (default)</option>
                    {stages.map((s: any) => (
                      <option key={s.id} value={s.id}>{s.name}</option>
                    ))}
                  </select>
                </div>
              </div>
            );
          })}
        </div>
      </Card>

      <Card className="p-6 space-y-4">
        <div className="flex items-start justify-between gap-4 flex-wrap">
          <div>
            <h3 className="font-display text-lg font-semibold flex items-center gap-2">
              <Puzzle className="h-5 w-5" /> WordPress plugin — Slice CRM Lead Connector
            </h3>
            <p className="text-sm text-muted-foreground mt-1 max-w-2xl">
              One-click install. Works with <b>Elementor Pro</b>, <b>Contact Form 7</b>, <b>WPForms</b>, <b>MetForm</b>,{" "}
              <b>Forminator</b>, <b>Gravity Forms</b>, <b>Fluent Forms</b>, and <b>custom HTML forms</b>. No Zapier needed.
            </p>
          </div>
          <a href="/slice-lead-connector.zip" download>
            <Button><Download className="h-4 w-4 mr-1.5" />Download plugin (v1.0.0)</Button>
          </a>
        </div>

        <div className="rounded-lg border bg-muted/30 p-4 text-sm space-y-1">
          <p className="font-medium">Install in 4 steps</p>
          <ol className="list-decimal pl-5 space-y-1 text-muted-foreground">
            <li>Generate a <b>WordPress Form</b> URL above and copy it.</li>
            <li>In WordPress admin: <b>Plugins → Add New → Upload Plugin</b>, choose <code>slice-lead-connector.zip</code>, click Install &amp; Activate.</li>
            <li>Open <b>Settings → Slice CRM Leads</b>, paste the URL, click Save.</li>
            <li>Click <b>Send a test lead</b> — it should land in your pipeline instantly.</li>
          </ol>
        </div>
      </Card>

      <Card className="p-6 space-y-3">
        <h3 className="font-display text-lg font-semibold">Per-form setup guides</h3>
        <p className="text-sm text-muted-foreground">After installing the plugin and saving the webhook URL, no extra steps are needed for these — submissions are captured automatically.</p>

        <Accordion type="single" collapsible className="w-full">
          <AccordionItem value="elementor">
            <AccordionTrigger>Elementor Pro Forms</AccordionTrigger>
            <AccordionContent>
              <ol className="list-decimal pl-5 space-y-1 text-sm text-muted-foreground">
                <li>Edit your form widget in Elementor.</li>
                <li>In the field's <b>Advanced</b> tab, set the <b>ID</b> to <code>name</code>, <code>email</code>, <code>phone</code>, or <code>message</code>.</li>
                <li>Save / Publish. Every submission is sent to Slice automatically.</li>
                <li>Alternative: keep your existing Webhook action and paste the URL above — works in parallel.</li>
              </ol>
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="cf7">
            <AccordionTrigger>Contact Form 7</AccordionTrigger>
            <AccordionContent>
              <ol className="list-decimal pl-5 space-y-1 text-sm text-muted-foreground">
                <li>Edit the form and use field names like <code>your-name</code>, <code>your-email</code>, <code>your-phone</code>, <code>your-message</code> (CF7 defaults work).</li>
                <li>Make sure CF7 mail is configured — the plugin fires after <b>mail sent</b>.</li>
                <li>Submit a test entry; it'll arrive in Slice in a few seconds.</li>
              </ol>
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="wpforms">
            <AccordionTrigger>WPForms (Lite &amp; Pro)</AccordionTrigger>
            <AccordionContent>
              <ol className="list-decimal pl-5 space-y-1 text-sm text-muted-foreground">
                <li>Use the <b>Name</b>, <b>Email</b>, and <b>Phone</b> field types (the plugin reads them by type).</li>
                <li>Label additional fields clearly — "Message", "Enquiry", etc.</li>
                <li>Publish the form. Submissions sync automatically.</li>
              </ol>
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="metform">
            <AccordionTrigger>MetForm</AccordionTrigger>
            <AccordionContent>
              <ol className="list-decimal pl-5 space-y-1 text-sm text-muted-foreground">
                <li>In MetForm builder, set each input's <b>Name</b> to <code>name</code> / <code>email</code> / <code>phone</code> / <code>message</code>.</li>
                <li>Save and embed the form. Submissions go straight to Slice.</li>
              </ol>
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="forminator">
            <AccordionTrigger>Forminator</AccordionTrigger>
            <AccordionContent>
              <ol className="list-decimal pl-5 space-y-1 text-sm text-muted-foreground">
                <li>Edit the form. Each field has a <b>Field Label</b> + auto-generated name — keep them descriptive (name, email, phone).</li>
                <li>Publish. The plugin listens to Forminator's submission hook and forwards leads automatically.</li>
              </ol>
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="gravity">
            <AccordionTrigger>Gravity Forms</AccordionTrigger>
            <AccordionContent>
              <ol className="list-decimal pl-5 space-y-1 text-sm text-muted-foreground">
                <li>Label fields as <b>Name</b>, <b>Email</b>, <b>Phone</b>, <b>Message</b> — the plugin uses field labels.</li>
                <li>Publish and submit a test entry.</li>
              </ol>
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="fluent">
            <AccordionTrigger>Fluent Forms</AccordionTrigger>
            <AccordionContent>
              <ol className="list-decimal pl-5 space-y-1 text-sm text-muted-foreground">
                <li>Use the default Name / Email / Phone input names (<code>names</code>, <code>email</code>, <code>phone</code>).</li>
                <li>Save and embed. All submissions are forwarded to Slice.</li>
              </ol>
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="custom">
            <AccordionTrigger>Custom HTML form (any theme / page builder)</AccordionTrigger>
            <AccordionContent>
              <ol className="list-decimal pl-5 space-y-1 text-sm text-muted-foreground">
                <li>Add <code>class="slice-lead-form"</code> to your <code>&lt;form&gt;</code> tag.</li>
                <li>Name your inputs <code>name</code>, <code>email</code>, <code>phone</code>, <code>message</code>.</li>
                <li>That's it — the plugin captures the submission and sends it to Slice in the background.</li>
              </ol>
              <pre className="mt-2 text-xs bg-muted/50 rounded p-3 whitespace-pre-wrap">{`<form class="slice-lead-form" action="/thank-you" method="post">
  <input name="name" placeholder="Your name" required />
  <input name="email" type="email" placeholder="Email" />
  <input name="phone" type="tel" placeholder="Phone" required />
  <textarea name="message" placeholder="How can we help?"></textarea>
  <button type="submit">Send</button>
</form>`}</pre>
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="meta-zapier">
            <AccordionTrigger>Meta Ads (via Zapier, no plugin needed)</AccordionTrigger>
            <AccordionContent>
              <ol className="list-decimal pl-5 space-y-1 text-sm text-muted-foreground">
                <li>Zapier → Create Zap → Trigger: <b>Facebook Lead Ads</b> (New Lead).</li>
                <li>Action: <b>Webhooks by Zapier → POST</b>.</li>
                <li>URL: paste your <b>Meta Ads</b> intake URL from above.</li>
                <li>Payload type: <b>JSON</b>. Map <code>full_name → name</code>, <code>phone_number → phone</code>, <code>email → email</code>.</li>
                <li>Publish. New Meta leads land in your pipeline within seconds.</li>
              </ol>
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="indiamart">
            <AccordionTrigger>IndiaMART (Push API / CRM Integration)</AccordionTrigger>
            <AccordionContent>
              <ol className="list-decimal pl-5 space-y-1 text-sm text-muted-foreground">
                <li>Above, choose <b>IndiaMART</b> as the Provider and click <b>Generate URL</b>. Copy the URL.</li>
                <li>Log in to <b>seller.indiamart.com</b> → <b>Lead Manager</b> → <b>Settings</b> → <b>Push API / CRM Integration</b>.
                  (If you don't see it, request access from your IndiaMART relationship manager — Push API is enabled on request for paid sellers.)</li>
                <li>Choose <b>Custom CRM</b> / <b>Other</b> and paste the URL into the <b>Webhook / Endpoint URL</b> field.</li>
                <li>Method: <b>POST</b>. Content-Type: <b>application/json</b>. No extra auth headers needed — the token in the URL authenticates the request.</li>
                <li>Save, then click <b>Send Test Lead</b>. IndiaMART posts fields like <code>SENDER_NAME</code>, <code>SENDER_MOBILE</code>, <code>SENDER_EMAIL</code>, <code>QUERY_MESSAGE</code>, <code>QUERY_PRODUCT_NAME</code> — Slice maps them automatically.</li>
                <li>Every new buyer enquiry now creates a contact + deal tagged <b>IndiaMART</b> in your pipeline.</li>
              </ol>
              <p className="text-xs text-muted-foreground mt-2">
                Tip: open <b>Integrations → Debug Center</b> to see the exact payload IndiaMART sent and Slice's response for every lead.
              </p>
            </AccordionContent>
          </AccordionItem>
        </Accordion>

        <pre className="text-xs bg-muted/50 rounded p-3 whitespace-pre-wrap">{FIELD_MAP}</pre>

        <p className="text-xs text-muted-foreground">
          Test any endpoint with:{" "}
          <code className="text-xs">curl -X POST -H "Content-Type: application/json" -d '{`{"name":"Test","phone":"+919999999999"}`}' &lt;your-url&gt;</code>
        </p>
      </Card>
    </div>
  );
}
