import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { toast } from "sonner";
import { Webhook, Plus, Trash2, Send, Copy, Zap, BookOpen, ExternalLink, CheckCircle2 } from "lucide-react";

export const WEBHOOK_EVENTS = [
  { key: "contact.created", label: "Contact created" },
  { key: "contact.updated", label: "Contact updated" },
  { key: "message.received", label: "Inbound WhatsApp message" },
  { key: "message.sent", label: "Outbound WhatsApp message" },
  { key: "conversation.opened", label: "Conversation opened" },
  { key: "conversation.closed", label: "Conversation closed" },
  { key: "campaign.sent", label: "Campaign sent" },
  { key: "order.created", label: "Order created" },
  { key: "order.status_changed", label: "Order status changed" },
  { key: "cart.abandoned", label: "Cart abandoned" },
  { key: "button.clicked", label: "Template button clicked (e.g. Interested)" },
];

type Endpoint = {
  id: string;
  workspace_id: string;
  name: string;
  url: string;
  events: string[];
  enabled: boolean;
  last_triggered_at: string | null;
  last_status: string | null;
  created_at: string;
};

export function WebhooksZapier({ workspaceId }: { workspaceId: string | null }) {
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Endpoint | null>(null);

  const { data: endpoints = [], isLoading } = useQuery({
    queryKey: ["webhook-endpoints", workspaceId],
    enabled: !!workspaceId,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("webhook_endpoints")
        .select("*")
        .eq("workspace_id", workspaceId!)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return (data || []) as Endpoint[];
    },
  });

  const refresh = () => qc.invalidateQueries({ queryKey: ["webhook-endpoints", workspaceId] });

  async function toggleEnabled(ep: Endpoint, enabled: boolean) {
    const { error } = await supabase
      .from("webhook_endpoints").update({ enabled }).eq("id", ep.id);
    if (error) return toast.error(error.message);
    refresh();
  }

  async function remove(ep: Endpoint) {
    if (!confirm(`Delete webhook "${ep.name}"?`)) return;
    const { error } = await supabase.from("webhook_endpoints").delete().eq("id", ep.id);
    if (error) return toast.error(error.message);
    toast.success("Webhook deleted");
    refresh();
  }

  async function sendTest(ep: Endpoint) {
    const payload = {
      event: "test.ping",
      timestamp: new Date().toISOString(),
      workspace_id: ep.workspace_id,
      data: { message: "Hello from Slice! This is a test webhook delivery." },
    };
    try {
      await fetch(ep.url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        mode: "no-cors",
        body: JSON.stringify(payload),
      });
      await supabase.from("webhook_endpoints").update({
        last_triggered_at: new Date().toISOString(),
        last_status: "test_sent",
      }).eq("id", ep.id);
      toast.success("Test sent. Check your Zap's run history to confirm.");
      refresh();
    } catch (e: any) {
      toast.error(e?.message || "Failed to send test");
    }
  }

  return (
    <div className="space-y-6">
      <Card className="p-6 bg-gradient-to-br from-violet-500/10 via-purple-500/5 to-transparent border-violet-500/20">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div className="flex items-start gap-4">
            <div className="rounded-xl bg-gradient-to-br from-violet-500 to-purple-600 p-3 text-white">
              <Zap className="h-6 w-6" />
            </div>
            <div>
              <h2 className="text-xl font-bold flex items-center gap-2">
                Webhooks & Zapier
                <Badge variant="secondary" className="text-xs">5000+ apps</Badge>
              </h2>
              <p className="text-sm text-muted-foreground max-w-xl mt-1">
                Send real-time events from Slice to Zapier, Make, n8n, or any HTTPS endpoint.
                Trigger Google Sheets rows, Slack messages, CRM updates, emails — anything.
              </p>
            </div>
          </div>
          <Button onClick={() => { setEditing(null); setOpen(true); }} className="gap-2">
            <Plus className="h-4 w-4" />Add webhook
          </Button>
        </div>
      </Card>

      <div className="grid gap-4 md:grid-cols-2">
        <Card className="p-5">
          <div className="font-semibold mb-3 flex items-center gap-2">
            <Webhook className="h-4 w-4" />Your webhooks
          </div>
          {isLoading ? (
            <p className="text-sm text-muted-foreground">Loading…</p>
          ) : endpoints.length === 0 ? (
            <p className="text-sm text-muted-foreground">
              No webhooks yet. Click <strong>Add webhook</strong> to connect your first Zapier Zap.
            </p>
          ) : (
            <ul className="space-y-3">
              {endpoints.map((ep) => (
                <li key={ep.id} className="rounded-lg border p-3 space-y-2">
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0 flex-1">
                      <div className="font-medium truncate">{ep.name}</div>
                      <div className="text-xs text-muted-foreground truncate">{ep.url}</div>
                    </div>
                    <Switch checked={ep.enabled} onCheckedChange={(v) => toggleEnabled(ep, v)} />
                  </div>
                  <div className="flex flex-wrap gap-1">
                    {ep.events.length === 0 ? (
                      <Badge variant="outline" className="text-xs">No events selected</Badge>
                    ) : ep.events.slice(0, 4).map((e) => (
                      <Badge key={e} variant="secondary" className="text-xs">{e}</Badge>
                    ))}
                    {ep.events.length > 4 && (
                      <Badge variant="outline" className="text-xs">+{ep.events.length - 4}</Badge>
                    )}
                  </div>
                  <div className="flex items-center gap-2 pt-1">
                    <Button size="sm" variant="outline" className="gap-1.5" onClick={() => sendTest(ep)}>
                      <Send className="h-3 w-3" />Send test
                    </Button>
                    <Button size="sm" variant="ghost" className="gap-1.5" onClick={() => { setEditing(ep); setOpen(true); }}>
                      Edit
                    </Button>
                    <Button size="sm" variant="ghost" className="gap-1.5 text-destructive ml-auto" onClick={() => remove(ep)}>
                      <Trash2 className="h-3 w-3" />
                    </Button>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </Card>

        <Card className="p-5">
          <div className="font-semibold mb-3 flex items-center gap-2">
            <BookOpen className="h-4 w-4" />Zapier setup guide
          </div>
          <ol className="space-y-3 text-sm">
            <li className="flex gap-3">
              <span className="rounded-full bg-primary/10 text-primary h-6 w-6 flex items-center justify-center text-xs font-semibold shrink-0">1</span>
              <div>
                <div className="font-medium">Create a new Zap in Zapier</div>
                <div className="text-muted-foreground text-xs">
                  Go to{" "}
                  <a href="https://zapier.com/app/zaps" target="_blank" rel="noreferrer" className="text-primary inline-flex items-center gap-0.5 hover:underline">
                    zapier.com <ExternalLink className="h-3 w-3" />
                  </a>{" "}
                  and click <strong>Create Zap</strong>.
                </div>
              </div>
            </li>
            <li className="flex gap-3">
              <span className="rounded-full bg-primary/10 text-primary h-6 w-6 flex items-center justify-center text-xs font-semibold shrink-0">2</span>
              <div>
                <div className="font-medium">Pick "Webhooks by Zapier" as the trigger</div>
                <div className="text-muted-foreground text-xs">Event: <strong>Catch Hook</strong>. Click Continue.</div>
              </div>
            </li>
            <li className="flex gap-3">
              <span className="rounded-full bg-primary/10 text-primary h-6 w-6 flex items-center justify-center text-xs font-semibold shrink-0">3</span>
              <div>
                <div className="font-medium">Copy the Webhook URL Zapier gives you</div>
                <div className="text-muted-foreground text-xs">It looks like <code className="px-1 py-0.5 bg-muted rounded text-[10px]">https://hooks.zapier.com/hooks/catch/...</code></div>
              </div>
            </li>
            <li className="flex gap-3">
              <span className="rounded-full bg-primary/10 text-primary h-6 w-6 flex items-center justify-center text-xs font-semibold shrink-0">4</span>
              <div>
                <div className="font-medium">Click "Add webhook" here, paste the URL</div>
                <div className="text-muted-foreground text-xs">Pick the events to send and hit Save, then click <strong>Send test</strong> to trigger a sample payload.</div>
              </div>
            </li>
            <li className="flex gap-3">
              <span className="rounded-full bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 h-6 w-6 flex items-center justify-center text-xs font-semibold shrink-0">
                <CheckCircle2 className="h-3.5 w-3.5" />
              </span>
              <div>
                <div className="font-medium">Back in Zapier, click "Test trigger"</div>
                <div className="text-muted-foreground text-xs">Zapier will pick up the sample. Add any action (Google Sheets, Slack, Gmail, HubSpot…) and publish.</div>
              </div>
            </li>
          </ol>
        </Card>
      </div>

      <Card className="p-5">
        <div className="font-semibold mb-3">Sample payload &amp; events</div>
        <Accordion type="single" collapsible className="w-full">
          <AccordionItem value="payload">
            <AccordionTrigger className="text-sm">Example payload shape</AccordionTrigger>
            <AccordionContent>
              <pre className="text-xs bg-muted p-3 rounded overflow-x-auto">
{`POST <your webhook URL>
Content-Type: application/json

{
  "event": "contact.created",
  "timestamp": "2026-06-06T10:00:00Z",
  "workspace_id": "ws_…",
  "data": {
    "id": "ctc_…",
    "name": "Aisha Khan",
    "phone": "+919812345678",
    "email": "aisha@example.com",
    "tags": ["lead", "instagram"]
  }
}`}
              </pre>
            </AccordionContent>
          </AccordionItem>
          <AccordionItem value="events">
            <AccordionTrigger className="text-sm">Available events ({WEBHOOK_EVENTS.length})</AccordionTrigger>
            <AccordionContent>
              <ul className="grid sm:grid-cols-2 gap-2 text-sm">
                {WEBHOOK_EVENTS.map((e) => (
                  <li key={e.key} className="flex items-center gap-2">
                    <Badge variant="outline" className="font-mono text-[10px]">{e.key}</Badge>
                    <span className="text-muted-foreground text-xs">{e.label}</span>
                  </li>
                ))}
              </ul>
            </AccordionContent>
          </AccordionItem>
          <AccordionItem value="tools">
            <AccordionTrigger className="text-sm">Other tools you can connect</AccordionTrigger>
            <AccordionContent>
              <div className="text-sm text-muted-foreground">
                Any HTTPS endpoint works. Popular destinations: <strong>Zapier, Make (Integromat), n8n, Pipedream, Workato, IFTTT, Slack incoming webhooks, Discord webhooks, Google Apps Script, AWS Lambda Function URLs, custom backends</strong>.
              </div>
            </AccordionContent>
          </AccordionItem>
        </Accordion>
      </Card>

      <WebhookDialog
        open={open}
        onOpenChange={setOpen}
        workspaceId={workspaceId}
        editing={editing}
        onSaved={refresh}
      />
    </div>
  );
}

function WebhookDialog({
  open, onOpenChange, workspaceId, editing, onSaved,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  workspaceId: string | null;
  editing: Endpoint | null;
  onSaved: () => void;
}) {
  const [name, setName] = useState(editing?.name || "");
  const [url, setUrl] = useState(editing?.url || "");
  const [events, setEvents] = useState<string[]>(editing?.events || []);
  const [saving, setSaving] = useState(false);

  // Reset when dialog opens
  function handleOpen(v: boolean) {
    if (v) {
      setName(editing?.name || "");
      setUrl(editing?.url || "");
      setEvents(editing?.events || []);
    }
    onOpenChange(v);
  }

  function toggleEvent(key: string) {
    setEvents((prev) => prev.includes(key) ? prev.filter((e) => e !== key) : [...prev, key]);
  }

  async function save() {
    if (!workspaceId) return;
    if (!name.trim()) return toast.error("Give the webhook a name");
    let parsed: URL;
    try {
      parsed = new URL(url.trim());
    } catch {
      return toast.error("Enter a valid URL (must start with https://)");
    }
    if (parsed.protocol !== "https:" && parsed.protocol !== "http:") {
      return toast.error("URL must use http or https");
    }
    setSaving(true);
    try {
      if (editing) {
        const { error } = await supabase.from("webhook_endpoints").update({
          name: name.trim(), url: url.trim(), events,
        }).eq("id", editing.id);
        if (error) throw error;
        toast.success("Webhook updated");
      } else {
        const { error } = await supabase.from("webhook_endpoints").insert({
          workspace_id: workspaceId,
          name: name.trim(),
          url: url.trim(),
          events,
          enabled: true,
        } as any);
        if (error) throw error;
        toast.success("Webhook added");
      }
      onSaved();
      onOpenChange(false);
    } catch (e: any) {
      toast.error(e?.message || "Failed to save");
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={handleOpen}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>{editing ? "Edit webhook" : "Add webhook"}</DialogTitle>
          <DialogDescription>
            Slice will POST a JSON payload to this URL whenever a selected event fires.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div className="space-y-1.5">
            <Label htmlFor="wh-name">Name</Label>
            <Input id="wh-name" placeholder="e.g. Zapier → Google Sheets" value={name} onChange={(e) => setName(e.target.value)} />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="wh-url">Webhook URL</Label>
            <Input id="wh-url" placeholder="https://hooks.zapier.com/hooks/catch/..." value={url} onChange={(e) => setUrl(e.target.value)} />
            <p className="text-xs text-muted-foreground">Paste the URL from your Zapier "Catch Hook" trigger.</p>
          </div>
          <div className="space-y-2">
            <Label>Events to send</Label>
            <div className="max-h-56 overflow-y-auto border rounded-md p-3 space-y-2">
              {WEBHOOK_EVENTS.map((e) => (
                <label key={e.key} className="flex items-start gap-2 text-sm cursor-pointer">
                  <Checkbox
                    checked={events.includes(e.key)}
                    onCheckedChange={() => toggleEvent(e.key)}
                    className="mt-0.5"
                  />
                  <div className="flex-1">
                    <div className="font-medium">{e.label}</div>
                    <code className="text-[10px] text-muted-foreground">{e.key}</code>
                  </div>
                </label>
              ))}
            </div>
          </div>
        </div>
        <DialogFooter>
          <Button variant="ghost" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button onClick={save} disabled={saving}>{saving ? "Saving…" : "Save webhook"}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
