import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Coins, AlertTriangle, ShoppingCart } from "lucide-react";
import { getAiCreditSummary } from "@/lib/ai-credits.functions";
import { BuyAiCreditsDialog } from "@/components/BuyAiCreditsDialog";

export function AiCreditWidget({ workspaceId }: { workspaceId: string }) {
  const fn = useServerFn(getAiCreditSummary);
  const [buyOpen, setBuyOpen] = useState(false);
  const { data } = useQuery({
    queryKey: ["ai-credit-summary", workspaceId],
    enabled: !!workspaceId,
    queryFn: () => fn({ data: { workspace_id: workspaceId } }),
    refetchInterval: 60_000,
  });

  const balance = data?.balance ?? 0;
  const low = data?.lowThreshold ?? 500;
  const isExhausted = balance <= 0;
  const isLow = !isExhausted && balance < low;

  return (
    <Card className={`p-5 ${isExhausted ? "border-destructive/40 bg-destructive/5" : isLow ? "border-warning/40 bg-warning/5" : ""}`}>
      <div className="flex items-start justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="grid h-10 w-10 place-items-center rounded-lg bg-primary/15 text-primary shrink-0">
            <Coins className="h-5 w-5" />
          </div>
          <div>
            <p className="text-sm text-muted-foreground flex items-center gap-2">
              AI Credits
              {isExhausted && <Badge variant="destructive" className="text-[10px]">Exhausted</Badge>}
              {isLow && <Badge variant="outline" className="text-[10px] border-warning text-warning">Low</Badge>}
            </p>
            <p className="mt-1 font-display text-3xl font-bold tabular-nums">{balance.toLocaleString()}</p>
          </div>
        </div>
        <div className="text-right text-xs text-muted-foreground space-y-1">
          <p>Used today: <span className="font-medium text-foreground tabular-nums">{(data?.usedToday ?? 0).toLocaleString()}</span></p>
          <p>Used this month: <span className="font-medium text-foreground tabular-nums">{(data?.usedMonth ?? 0).toLocaleString()}</span></p>
        </div>
      </div>
      {isExhausted && (
        <div className="mt-3 flex items-start gap-2 text-xs text-destructive">
          <AlertTriangle className="h-3.5 w-3.5 mt-0.5 shrink-0" />
          <p>Your AI credits have been exhausted. Please recharge to continue using AI features. All other Slice features continue to work.</p>
        </div>
      )}
      {isLow && (
        <div className="mt-3 flex items-start gap-2 text-xs text-warning">
          <AlertTriangle className="h-3.5 w-3.5 mt-0.5 shrink-0" />
          <p>AI credits are running low (below {low.toLocaleString()}). Ask your admin to recharge.</p>
        </div>
      )}
      <div className="mt-4 flex justify-end">
        <Button size="sm" variant={isExhausted || isLow ? "default" : "outline"} onClick={() => setBuyOpen(true)}>
          <ShoppingCart className="h-3.5 w-3.5 mr-1.5" /> Buy AI Credits
        </Button>
      </div>
      <BuyAiCreditsDialog workspaceId={workspaceId} open={buyOpen} onOpenChange={setBuyOpen} />
    </Card>
  );
}

