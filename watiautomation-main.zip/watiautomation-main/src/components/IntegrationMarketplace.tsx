import { useMemo, useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { toast } from "sonner";
import {
  Store, ShoppingCart, Facebook, FileText, Globe, Building2, Home, Phone,
  Sparkles, Workflow, Zap, IndianRupee, Sheet, CheckCircle2, ArrowRight, Search,
  BookOpen, Settings as SettingsIcon, ExternalLink,
} from "lucide-react";
import { Link } from "@tanstack/react-router";

export type IntegrationCategory =
  | "lead-sources" | "ecommerce" | "automation" | "crm" | "payments" | "productivity";

export type MarketplaceItem = {
  key: string;
  name: string;
  description: string;
  category: IntegrationCategory;
  icon: any;
  color: string; // tailwind gradient
  status: "live" | "coming-soon";
  // For "live" items, where to go when user clicks Configure / Connect
  action?: { kind: "tab"; tab: string } | { kind: "link"; to: string };
  setupGuide?: string; // anchor in setup guide center
  tags?: string[];
};

export const MARKETPLACE: MarketplaceItem[] = [
  // ---------------- Lead Sources ----------------
  {
    key: "meta-lead-ads", name: "Facebook Lead Ads",
    description: "Import leads from Meta lead-gen forms in real time.",
    category: "lead-sources", icon: Facebook, color: "from-blue-500 to-indigo-600",
    status: "live", action: { kind: "tab", tab: "lead-sources" }, setupGuide: "meta-lead-ads",
    tags: ["leads", "ads"],
  },
  {
    key: "website-form", name: "Website Lead Forms",
    description: "Collect leads from any website via JS snippet, REST or webhook.",
    category: "lead-sources", icon: Globe, color: "from-fuchsia-500 to-pink-600",
    status: "live", action: { kind: "tab", tab: "lead-sources" }, setupGuide: "website-form",
  },
  {
    key: "wordpress", name: "WordPress",
    description: "Capture leads from Contact Form 7, Elementor and Gravity Forms.",
    category: "lead-sources", icon: Globe, color: "from-slate-500 to-slate-700",
    status: "live", action: { kind: "tab", tab: "lead-sources" }, setupGuide: "wordpress",
  },
  {
    key: "google-forms", name: "Google Forms",
    description: "Sync responses from Google Forms as CRM leads.",
    category: "lead-sources", icon: FileText, color: "from-purple-500 to-violet-600",
    status: "coming-soon", setupGuide: "google-forms",
  },
  {
    key: "google-ads-leads", name: "Google Ads Lead Forms",
    description: "Pull lead-form submissions directly from Google Ads.",
    category: "lead-sources", icon: Sparkles, color: "from-yellow-500 to-amber-600",
    status: "coming-soon",
  },
  {
    key: "indiamart", name: "IndiaMART",
    description: "Auto-import IndiaMART buyer inquiries via Push API.",
    category: "lead-sources", icon: Building2, color: "from-orange-500 to-red-600",
    status: "live", action: { kind: "tab", tab: "lead-sources" }, setupGuide: "indiamart",
  },
  {
    key: "tradeindia", name: "TradeIndia",
    description: "Sync TradeIndia inquiries as leads instantly.",
    category: "lead-sources", icon: Building2, color: "from-rose-500 to-pink-600",
    status: "coming-soon",
  },
  {
    key: "justdial", name: "JustDial",
    description: "Receive JustDial leads with auto WhatsApp follow-up.",
    category: "lead-sources", icon: Phone, color: "from-amber-500 to-orange-600",
    status: "coming-soon",
  },
  {
    key: "magicbricks", name: "MagicBricks",
    description: "Import buyer & seller leads from MagicBricks.",
    category: "lead-sources", icon: Home, color: "from-red-500 to-rose-600",
    status: "coming-soon",
  },
  {
    key: "99acres", name: "99Acres",
    description: "Capture 99acres property buyer enquiries.",
    category: "lead-sources", icon: Home, color: "from-emerald-500 to-teal-600",
    status: "coming-soon",
  },
  {
    key: "housing", name: "Housing.com",
    description: "Sync Housing.com property leads.",
    category: "lead-sources", icon: Home, color: "from-indigo-500 to-blue-600",
    status: "coming-soon",
  },
  {
    key: "softwaresuggest", name: "SoftwareSuggest",
    description: "Capture SoftwareSuggest evaluation leads.",
    category: "lead-sources", icon: Sparkles, color: "from-cyan-500 to-sky-600",
    status: "coming-soon",
  },

  // ---------------- Ecommerce ----------------
  {
    key: "shopify", name: "Shopify",
    description: "Sync customers, orders & abandoned carts; automate WhatsApp.",
    category: "ecommerce", icon: Store, color: "from-emerald-500 to-green-600",
    status: "live", action: { kind: "tab", tab: "ecommerce" }, setupGuide: "shopify",
  },
  {
    key: "woocommerce", name: "WooCommerce",
    description: "Two-way sync of products, orders and customers via plugin.",
    category: "ecommerce", icon: ShoppingCart, color: "from-violet-500 to-purple-600",
    status: "live", action: { kind: "tab", tab: "ecommerce" }, setupGuide: "woocommerce",
  },

  // ---------------- Automation ----------------
  {
    key: "zapier", name: "Zapier",
    description: "Trigger workflows from 5000+ apps via webhook.",
    category: "automation", icon: Zap, color: "from-orange-500 to-amber-600",
    status: "live", action: { kind: "tab", tab: "api-webhooks" }, setupGuide: "zapier",
  },
  {
    key: "pabbly", name: "Pabbly Connect",
    description: "Push leads to Pabbly via webhooks.",
    category: "automation", icon: Workflow, color: "from-purple-500 to-fuchsia-600",
    status: "live", action: { kind: "tab", tab: "api-webhooks" }, setupGuide: "pabbly",
  },
  {
    key: "systeme", name: "Systeme.io",
    description: "Funnel & webinar registration sync.",
    category: "automation", icon: Workflow, color: "from-blue-500 to-cyan-600",
    status: "coming-soon",
  },

  // ---------------- CRM & Sales ----------------
  {
    key: "hubspot", name: "HubSpot",
    description: "Two-way contact & deal sync with HubSpot CRM.",
    category: "crm", icon: Building2, color: "from-orange-500 to-red-600",
    status: "coming-soon",
  },
  {
    key: "zoho", name: "Zoho CRM",
    description: "Sync leads & contacts with Zoho CRM.",
    category: "crm", icon: Building2, color: "from-rose-500 to-red-600",
    status: "coming-soon",
  },
  {
    key: "salesforce", name: "Salesforce",
    description: "Enterprise CRM sync — leads, accounts, opportunities.",
    category: "crm", icon: Building2, color: "from-sky-500 to-blue-600",
    status: "coming-soon",
  },
  {
    key: "pipedrive", name: "Pipedrive",
    description: "Sales pipeline sync with Pipedrive.",
    category: "crm", icon: Building2, color: "from-slate-500 to-zinc-700",
    status: "coming-soon",
  },

  // ---------------- Payments ----------------
  {
    key: "razorpay", name: "Razorpay",
    description: "Payment events, subscriptions & reminders.",
    category: "payments", icon: IndianRupee, color: "from-blue-500 to-indigo-600",
    status: "live", action: { kind: "link", to: "/subscription" }, setupGuide: "razorpay",
  },

  // ---------------- Productivity ----------------
  {
    key: "google-sheets", name: "Google Sheets",
    description: "Read/write rows; auto-create leads from new rows.",
    category: "productivity", icon: Sheet, color: "from-green-500 to-emerald-600",
    status: "coming-soon",
  },
];

const CATEGORY_LABELS: Record<IntegrationCategory, string> = {
  "lead-sources": "Lead Sources",
  ecommerce: "Ecommerce",
  automation: "Automation Tools",
  crm: "CRM & Sales",
  payments: "Payments",
  productivity: "Productivity",
};

export function IntegrationMarketplace({
  connectedKeys,
  onSwitchTab,
  filterCategory,
}: {
  connectedKeys: Set<string>;
  onSwitchTab?: (tab: string) => void;
  filterCategory?: IntegrationCategory;
}) {
  const [q, setQ] = useState("");
  const [category, setCategory] = useState<IntegrationCategory | "all">(filterCategory ?? "all");

  const items = useMemo(() => {
    return MARKETPLACE.filter((i) => {
      if (filterCategory && i.category !== filterCategory) return false;
      if (!filterCategory && category !== "all" && i.category !== category) return false;
      if (q && !(`${i.name} ${i.description}`.toLowerCase().includes(q.toLowerCase()))) return false;
      return true;
    });
  }, [q, category, filterCategory]);

  const grouped = useMemo(() => {
    const map = new Map<IntegrationCategory, MarketplaceItem[]>();
    for (const it of items) {
      if (!map.has(it.category)) map.set(it.category, []);
      map.get(it.category)!.push(it);
    }
    return map;
  }, [items]);

  return (
    <div className="space-y-6">
      {!filterCategory && (
        <div className="flex flex-wrap items-center gap-3">
          <div className="relative flex-1 min-w-[220px] max-w-md">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search integrations…" className="pl-8" />
          </div>
          <div className="flex flex-wrap gap-1.5">
            <CatChip active={category === "all"} onClick={() => setCategory("all")}>All</CatChip>
            {(Object.keys(CATEGORY_LABELS) as IntegrationCategory[]).map((c) => (
              <CatChip key={c} active={category === c} onClick={() => setCategory(c)}>{CATEGORY_LABELS[c]}</CatChip>
            ))}
          </div>
        </div>
      )}

      {Array.from(grouped.entries()).map(([cat, list]) => (
        <section key={cat} className="space-y-3">
          {!filterCategory && (
            <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider">{CATEGORY_LABELS[cat]}</h3>
          )}
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {list.map((it) => (
              <IntegrationCard
                key={it.key}
                item={it}
                connected={connectedKeys.has(it.key)}
                onSwitchTab={onSwitchTab}
              />
            ))}
          </div>
        </section>
      ))}

      {items.length === 0 && (
        <Card className="p-10 text-center text-muted-foreground">No integrations match your search.</Card>
      )}
    </div>
  );
}

function CatChip({ active, onClick, children }: any) {
  return (
    <button
      onClick={onClick}
      className={`text-xs px-3 py-1.5 rounded-full border transition ${active ? "bg-primary text-primary-foreground border-primary" : "bg-background hover:bg-muted border-border"}`}
    >{children}</button>
  );
}

export function IntegrationCard({ item, connected, onSwitchTab }: {
  item: MarketplaceItem; connected: boolean; onSwitchTab?: (tab: string) => void;
}) {
  const [requestOpen, setRequestOpen] = useState(false);
  const Icon = item.icon;

  const handleAction = () => {
    if (item.status !== "live" || !item.action) return;
    if (item.action.kind === "tab" && onSwitchTab) onSwitchTab(item.action.tab);
  };

  return (
    <>
      <Card className="p-4 flex flex-col gap-3 hover:border-primary/50 transition relative">
        {connected && (
          <Badge className="absolute right-3 top-3 bg-emerald-500/15 text-emerald-700 dark:text-emerald-400 border-emerald-500/30 gap-1">
            <CheckCircle2 className="h-3 w-3" />Connected
          </Badge>
        )}
        {item.status === "coming-soon" && !connected && (
          <Badge variant="secondary" className="absolute right-3 top-3">Coming soon</Badge>
        )}
        <div className="flex items-start gap-3">
          <div className={`h-10 w-10 rounded-lg bg-gradient-to-br ${item.color} flex items-center justify-center text-white shrink-0`}>
            <Icon className="h-5 w-5" />
          </div>
          <div className="min-w-0">
            <div className="font-semibold leading-tight">{item.name}</div>
            <p className="text-xs text-muted-foreground mt-1 line-clamp-2">{item.description}</p>
          </div>
        </div>
        <div className="flex flex-wrap gap-2 mt-auto pt-1">
          {item.status === "live" ? (
            item.action?.kind === "link" ? (
              <Button asChild size="sm" className="gap-1.5">
                <Link to={item.action.to}>
                  {connected ? <SettingsIcon className="h-3.5 w-3.5" /> : <ArrowRight className="h-3.5 w-3.5" />}
                  {connected ? "Configure" : "Connect"}
                </Link>
              </Button>
            ) : (
              <Button size="sm" onClick={handleAction} className="gap-1.5">
                {connected ? <SettingsIcon className="h-3.5 w-3.5" /> : <ArrowRight className="h-3.5 w-3.5" />}
                {connected ? "Configure" : "Connect"}
              </Button>
            )
          ) : (
            <Button size="sm" variant="outline" onClick={() => setRequestOpen(true)} className="gap-1.5">
              <Sparkles className="h-3.5 w-3.5" />Request access
            </Button>
          )}
          {item.setupGuide && (
            <Button size="sm" variant="ghost" className="gap-1.5" onClick={() => onSwitchTab?.("setup-guides")}>
              <BookOpen className="h-3.5 w-3.5" />Guide
            </Button>
          )}
        </div>
      </Card>

      <Dialog open={requestOpen} onOpenChange={setRequestOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Request access — {item.name}</DialogTitle>
            <DialogDescription>
              We're rolling out this integration soon. Let us know you're interested and we'll prioritise it.
            </DialogDescription>
          </DialogHeader>
          <p className="text-sm text-muted-foreground">
            Click the button below and our team will reach out as soon as {item.name} is available.
          </p>
          <DialogFooter>
            <Button variant="outline" onClick={() => setRequestOpen(false)}>Cancel</Button>
            <Button onClick={() => { toast.success(`Thanks! We've noted your interest in ${item.name}.`); setRequestOpen(false); }}>
              Notify me
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}

/* -------------------- Connected Apps -------------------- */

export function ConnectedAppsList({
  storeIntegrations,
  metaConnections,
  webhookCount,
  onSwitchTab,
}: {
  storeIntegrations: any[];
  metaConnections: number;
  webhookCount: number;
  onSwitchTab: (tab: string) => void;
}) {
  type Row = { name: string; provider: string; icon: any; color: string; status: string; lastSync?: string; tab: string };
  const rows: Row[] = [];
  for (const i of storeIntegrations) {
    const meta = MARKETPLACE.find((m) => m.key === i.provider);
    rows.push({
      name: meta?.name ?? i.provider,
      provider: i.provider,
      icon: meta?.icon ?? Store,
      color: meta?.color ?? "from-slate-500 to-slate-700",
      status: i.status ?? "active",
      lastSync: i.meta?.last_sync_at || i.updated_at,
      tab: "ecommerce",
    });
  }
  if (metaConnections > 0) {
    rows.push({
      name: "Facebook Lead Ads", provider: "meta-lead-ads", icon: Facebook,
      color: "from-blue-500 to-indigo-600", status: "active", tab: "lead-sources",
    });
  }
  if (webhookCount > 0) {
    rows.push({
      name: `Webhooks (${webhookCount})`, provider: "webhooks", icon: Zap,
      color: "from-orange-500 to-amber-600", status: "active", tab: "api-webhooks",
    });
  }

  if (rows.length === 0) {
    return (
      <Card className="p-10 text-center text-muted-foreground">
        No connected apps yet. Visit the Marketplace to connect your first integration.
      </Card>
    );
  }

  return (
    <Card className="overflow-hidden">
      <div className="grid grid-cols-[1fr_auto_auto_auto] items-center px-4 py-3 text-xs font-medium text-muted-foreground border-b">
        <div>Integration</div><div className="px-4">Status</div><div className="px-4 hidden sm:block">Last sync</div><div>Actions</div>
      </div>
      {rows.map((r, idx) => {
        const Icon = r.icon;
        return (
          <div key={idx} className="grid grid-cols-[1fr_auto_auto_auto] items-center px-4 py-3 border-b last:border-0 gap-2">
            <div className="flex items-center gap-3 min-w-0">
              <div className={`h-9 w-9 rounded-lg bg-gradient-to-br ${r.color} flex items-center justify-center text-white shrink-0`}>
                <Icon className="h-4 w-4" />
              </div>
              <div className="font-medium truncate">{r.name}</div>
            </div>
            <div className="px-4">
              <Badge variant="secondary" className="gap-1 bg-emerald-500/15 text-emerald-700 dark:text-emerald-400 border-emerald-500/30">
                <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" />{r.status}
              </Badge>
            </div>
            <div className="px-4 text-xs text-muted-foreground hidden sm:block">
              {r.lastSync ? new Date(r.lastSync).toLocaleString() : "—"}
            </div>
            <Button size="sm" variant="ghost" className="gap-1" onClick={() => onSwitchTab(r.tab)}>
              <SettingsIcon className="h-3.5 w-3.5" />Configure
            </Button>
          </div>
        );
      })}
    </Card>
  );
}

/* -------------------- Setup Guides -------------------- */

const GUIDES: { key: string; title: string; steps: string[]; troubleshooting: string[] }[] = [
  {
    key: "meta-lead-ads", title: "Facebook Lead Ads",
    steps: [
      "Open Lead Sources → Facebook Lead Ads",
      "Sign in with Facebook and grant permissions",
      "Select your Business Manager, Page and Form",
      "Map form fields to CRM fields (Name, Phone, Email)",
      "Enable Auto Sync and run a test lead",
    ],
    troubleshooting: [
      "If no forms appear, ensure your Page has at least one published lead form.",
      "Re-grant the leads_retrieval permission if the token expired.",
    ],
  },
  {
    key: "wordpress", title: "WordPress Lead Connector",
    steps: [
      "Download the Slice Lead Connector plugin from Lead Sources",
      "Upload via WP Admin → Plugins → Add New → Upload",
      "Activate and open the plugin settings",
      "Paste your workspace API URL & token",
      "Map your CF7 / Elementor / Gravity form fields",
    ],
    troubleshooting: [
      "If leads do not arrive, check WP Admin → Tools → Site Health for cron status.",
      "Test the webhook from the plugin settings page.",
    ],
  },
  {
    key: "website-form", title: "Custom Website Forms",
    steps: [
      "Open Lead Sources → Website Lead Integration",
      "Copy the JavaScript snippet OR REST endpoint",
      "Paste the snippet before </body> of your site",
      "Submit a test entry and confirm it appears in Contacts",
    ],
    troubleshooting: [
      "Verify the endpoint accepts POST with JSON body { name, phone, email, source }.",
    ],
  },
  {
    key: "shopify", title: "Shopify",
    steps: [
      "Open Ecommerce → Shopify and click Connect",
      "Enter your *.myshopify.com store URL",
      "Approve the install in Shopify Admin",
      "Choose what to sync (customers, orders, abandoned carts)",
      "Enable WhatsApp automations and run a test",
    ],
    troubleshooting: [
      "If sync fails, click Re-register webhooks from the store card.",
    ],
  },
  {
    key: "woocommerce", title: "WooCommerce",
    steps: [
      "Open Ecommerce → WooCommerce and click Connect",
      "Download the Slice WooCommerce Connector plugin",
      "Install & activate it in WP Admin → Plugins",
      "Paste API keys generated from the wizard",
      "Pick what to sync and enable automations",
    ],
    troubleshooting: [
      "If the order webhook is empty, ensure the plugin is v2.3.0 or newer.",
    ],
  },
  {
    key: "razorpay", title: "Razorpay",
    steps: [
      "Open Subscription → Payment Gateways",
      "Add your Razorpay Key ID and Secret",
      "Enable the events you want to listen to",
      "Run a test payment to verify webhooks",
    ],
    troubleshooting: [
      "Verify webhook URL in Razorpay dashboard matches the one shown here.",
    ],
  },
  {
    key: "zapier", title: "Zapier",
    steps: [
      "Open API & Webhooks → copy your endpoint URL",
      "In Zapier, create a Webhook trigger and paste the URL",
      "Map the payload to your downstream app",
      "Turn the Zap on and send a test event",
    ],
    troubleshooting: [
      "Zapier needs at least one test event before activation.",
    ],
  },
  {
    key: "pabbly", title: "Pabbly Connect",
    steps: [
      "Open API & Webhooks → copy your endpoint URL",
      "In Pabbly, create a new workflow with a Webhook trigger",
      "Paste the URL and capture a sample event",
      "Configure downstream actions and activate",
    ],
    troubleshooting: [
      "If events are not captured, send a manual test from API & Webhooks tab.",
    ],
  },
  {
    key: "google-forms", title: "Google Forms (coming soon)",
    steps: [
      "Sign in with Google",
      "Select the form to sync",
      "Map fields to CRM contact fields",
      "Choose follow-up automation",
    ],
    troubleshooting: ["This integration is in development. Click 'Notify me' on the card to be alerted."],
  },
];

export function SetupGuideCenter({ onTest }: { onTest?: (key: string) => void }) {
  const [open, setOpen] = useState<string | null>(null);
  return (
    <div className="space-y-3">
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {GUIDES.map((g) => {
          const item = MARKETPLACE.find((m) => m.setupGuide === g.key);
          const Icon = item?.icon ?? BookOpen;
          return (
            <Card key={g.key} className="p-4 flex flex-col gap-3">
              <div className="flex items-center gap-3">
                <div className={`h-10 w-10 rounded-lg bg-gradient-to-br ${item?.color ?? "from-slate-500 to-slate-700"} flex items-center justify-center text-white`}>
                  <Icon className="h-5 w-5" />
                </div>
                <div className="font-semibold">{g.title}</div>
              </div>
              <p className="text-xs text-muted-foreground">{g.steps.length} steps · setup in minutes</p>
              <div className="flex gap-2 mt-auto">
                <Button size="sm" onClick={() => setOpen(g.key)} className="gap-1.5">
                  <BookOpen className="h-3.5 w-3.5" />View guide
                </Button>
                {onTest && item?.status === "live" && (
                  <Button size="sm" variant="outline" onClick={() => onTest(g.key)} className="gap-1.5">
                    Test connection
                  </Button>
                )}
              </div>
            </Card>
          );
        })}
      </div>

      <Dialog open={!!open} onOpenChange={(v) => !v && setOpen(null)}>
        <DialogContent className="max-w-2xl">
          {open && (() => {
            const g = GUIDES.find((x) => x.key === open)!;
            return (
              <>
                <DialogHeader>
                  <DialogTitle>{g.title} — Setup Guide</DialogTitle>
                  <DialogDescription>Follow these steps to connect {g.title} to your workspace.</DialogDescription>
                </DialogHeader>
                <div className="space-y-4">
                  <div>
                    <h4 className="text-sm font-semibold mb-2">Step-by-step</h4>
                    <ol className="space-y-2">
                      {g.steps.map((s, i) => (
                        <li key={i} className="flex gap-3 text-sm">
                          <span className="h-6 w-6 rounded-full bg-primary/10 text-primary flex items-center justify-center text-xs font-semibold shrink-0">{i + 1}</span>
                          <span className="pt-0.5">{s}</span>
                        </li>
                      ))}
                    </ol>
                  </div>
                  <div className="rounded-lg border border-dashed p-6 text-center text-xs text-muted-foreground">
                    Screenshots coming soon
                  </div>
                  <div>
                    <h4 className="text-sm font-semibold mb-2">Troubleshooting</h4>
                    <ul className="space-y-1.5">
                      {g.troubleshooting.map((t, i) => (
                        <li key={i} className="text-sm text-muted-foreground flex gap-2">
                          <ExternalLink className="h-3.5 w-3.5 mt-0.5 shrink-0" />{t}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </>
            );
          })()}
        </DialogContent>
      </Dialog>
    </div>
  );
}
