import { Check, X, Info, icons as LucideIcons } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { formatPrice } from "@/components/PricingFields";
import { ReactNode, useState } from "react";

function InfoTip({ title, description }: { title: string; description: string }) {
  const [open, setOpen] = useState(false);
  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <button
          type="button"
          aria-label={`About ${title}`}
          onMouseEnter={() => setOpen(true)}
          onMouseLeave={() => setOpen(false)}
          onClick={(e) => {
            e.preventDefault();
            setOpen((v) => !v);
          }}
          className="inline-flex shrink-0 items-center justify-center rounded-full text-muted-foreground/70 hover:text-foreground focus:outline-none focus-visible:ring-2 focus-visible:ring-ring transition-colors"
        >
          <Info className="h-3.5 w-3.5" />
        </button>
      </PopoverTrigger>
      <PopoverContent
        side="top"
        align="start"
        sideOffset={6}
        onOpenAutoFocus={(e) => e.preventDefault()}
        onMouseEnter={() => setOpen(true)}
        onMouseLeave={() => setOpen(false)}
        className="w-64 text-xs leading-relaxed"
      >
        <p className="font-semibold text-sm mb-1">{title}</p>
        <p className="text-muted-foreground">{description}</p>
      </PopoverContent>
    </Popover>
  );
}

export interface PricingPlan {
  id: string;
  name: string;
  description: string | null;
  price_monthly: number;
  price_yearly: number;
  currency: string;
  is_popular?: boolean;
  badge_text?: string | null;
  gateway_ids?: string[] | null;
}

export interface MasterFeature {
  id: string;
  name: string;
  description: string | null;
  category: string;
  icon: string | null;
  position: number;
}

export interface PlanFeatureLink {
  template_id: string;
  feature_id: string;
  included: boolean;
  custom_value: string | null;
}

interface Props {
  plans: PricingPlan[];
  masterFeatures: MasterFeature[];
  planFeatures: PlanFeatureLink[];
  interval: "monthly" | "yearly";
  cta?: (plan: PricingPlan) => ReactNode;
  highlightPlanId?: string | null;
}

function FeatureIcon({ name }: { name: string | null }) {
  if (!name) return null;
  const Cmp = (LucideIcons as any)[name];
  if (!Cmp) return null;
  return <Cmp className="h-4 w-4 text-muted-foreground shrink-0" />;
}

function Cell({ link }: { link: PlanFeatureLink | undefined }) {
  if (!link) {
    return <X className="h-5 w-5 text-muted-foreground/40 mx-auto" />;
  }
  if (link.custom_value && link.custom_value.trim()) {
    return <span className="text-sm font-medium">{link.custom_value}</span>;
  }
  if (link.included) {
    return (
      <span className="inline-flex h-6 w-6 items-center justify-center rounded-full bg-emerald-100 dark:bg-emerald-900/40 mx-auto">
        <Check className="h-3.5 w-3.5 text-emerald-600 dark:text-emerald-300" />
      </span>
    );
  }
  return (
    <span className="inline-flex h-6 w-6 items-center justify-center rounded-full bg-red-50 dark:bg-red-900/30 mx-auto">
      <X className="h-3.5 w-3.5 text-red-500 dark:text-red-300" />
    </span>
  );
}

export function PricingComparisonTable({
  plans,
  masterFeatures,
  planFeatures,
  interval,
  cta,
  highlightPlanId,
}: Props) {
  if (plans.length === 0) {
    return (
      <div className="rounded-lg border p-8 text-center text-sm text-muted-foreground">
        No plans configured yet.
      </div>
    );
  }

  // Group features by category, preserving order
  const categories: { name: string; features: MasterFeature[] }[] = [];
  const catMap = new Map<string, MasterFeature[]>();
  for (const f of masterFeatures) {
    if (!catMap.has(f.category)) {
      catMap.set(f.category, []);
      categories.push({ name: f.category, features: catMap.get(f.category)! });
    }
    catMap.get(f.category)!.push(f);
  }

  // Index planFeatures by template+feature
  const linkMap = new Map<string, PlanFeatureLink>();
  for (const l of planFeatures) linkMap.set(`${l.template_id}::${l.feature_id}`, l);

  return (
    <div className="overflow-x-auto rounded-2xl border bg-card">
      <table className="w-full border-collapse min-w-[720px]">
        <thead className="sticky top-0 z-10 bg-card">
          <tr className="border-b">
            <th className="text-left p-5 align-bottom min-w-[220px]">
              <p className="text-xs uppercase tracking-wider text-muted-foreground">
                Compare plans
              </p>
              <p className="text-xs text-muted-foreground mt-1">
                Billing: {interval === "yearly" ? "Yearly" : "Monthly"}
              </p>
            </th>
            {plans.map((p) => {
              const price = interval === "yearly" ? p.price_yearly : p.price_monthly;
              const popular = p.is_popular || p.id === highlightPlanId;
              return (
                <th
                  key={p.id}
                  className={`p-5 align-bottom text-center relative ${
                    popular ? "bg-primary/5 pt-9" : ""
                  }`}
                  style={{ minWidth: 180 }}
                >
                  {popular && (
                    <Badge className="absolute top-2 left-1/2 -translate-x-1/2">
                      {p.badge_text || "Most popular"}
                    </Badge>
                  )}

                  <div className="font-semibold text-base">{p.name}</div>
                  {p.description && (
                    <div className="text-xs text-muted-foreground mt-1 line-clamp-2">
                      {p.description}
                    </div>
                  )}
                  <div className="mt-3 flex items-baseline justify-center gap-1">
                    <span className="text-2xl font-bold">
                      {price > 0 ? formatPrice(price, p.currency) : "Free"}
                    </span>
                    {price > 0 && (
                      <span className="text-xs text-muted-foreground">
                        /{interval === "yearly" ? "yr" : "mo"}
                      </span>
                    )}
                  </div>
                  {cta ? (
                    <div className="mt-3">{cta(p)}</div>
                  ) : (
                    <Button size="sm" variant={popular ? "default" : "outline"} className="mt-3 w-full">
                      Get started
                    </Button>
                  )}
                </th>
              );
            })}
          </tr>
        </thead>
        <tbody>
          {categories.map((cat) => (
            <FeatureCategory
              key={cat.name}
              category={cat.name}
              features={cat.features}
              plans={plans}
              linkMap={linkMap}
            />
          ))}
        </tbody>
      </table>
    </div>
  );
}

function FeatureCategory({
  category,
  features,
  plans,
  linkMap,
}: {
  category: string;
  features: MasterFeature[];
  plans: PricingPlan[];
  linkMap: Map<string, PlanFeatureLink>;
}) {
  return (
    <>
      <tr className="bg-muted/40">
        <td colSpan={plans.length + 1} className="px-5 py-2.5 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
          {category}
        </td>
      </tr>
      {features.map((f) => (
        <tr key={f.id} className="border-b last:border-b-0 hover:bg-muted/20">
          <td className="px-5 py-3 text-sm">
            <div className="flex items-center gap-2">
              <FeatureIcon name={f.icon} />
              <div className="flex items-center gap-1.5 min-w-0">
                <span className="font-medium">{f.name}</span>
                {f.description && (
                  <InfoTip title={f.name} description={f.description} />
                )}
              </div>
            </div>
          </td>
          {plans.map((p) => (
            <td
              key={p.id}
              className={`px-5 py-3 text-center ${p.is_popular ? "bg-primary/5" : ""}`}
            >
              <Cell link={linkMap.get(`${p.id}::${f.id}`)} />
            </td>
          ))}
        </tr>
      ))}
    </>
  );
}
