import { Link, useNavigate, useRouterState } from "@tanstack/react-router";
import { MessageCircle, LayoutDashboard, Users, FileText, Send, Settings, LogOut, UsersRound, Check, ChevronsUpDown, Plus, Inbox, Zap, Target, Kanban, Bell, ShoppingBag, BarChart3, Plug, Store, CreditCard, Smartphone, Shield, Bot, Sparkles, Menu, Coins, MousePointerClick } from "lucide-react";
import { Sheet, SheetContent, SheetTrigger, SheetTitle } from "@/components/ui/sheet";
import { useEffect, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { cn } from "@/lib/utils";
import { WorkspaceProvider, useWorkspace } from "@/lib/workspace-context";
import { CurrencyProvider, useCurrency, CURRENCIES } from "@/lib/currency";
import { createWorkspace } from "@/lib/workspaces.functions";
import { getMyAdminStatus } from "@/lib/admin.functions";
import { toast } from "sonner";
import { useWorkspacePlan } from "@/lib/use-workspace-plan";
import { useTrialStatus } from "@/lib/use-trial-status";
import { TrialExpiredGate } from "@/components/TrialExpiredGate";
import { PermissionsProvider, usePermissions } from "@/lib/permissions-context";

type NavItem = { to: string; label: string; icon: any; feature: string | null; module?: string | null };


const navItems: NavItem[] = [
  { to: "/dashboard", label: "Dashboard", icon: LayoutDashboard, feature: null, module: "dashboard" },
  { to: "/inbox", label: "Inbox", icon: Inbox, feature: "inbox", module: "inbox" },
  { to: "/contacts", label: "Contacts", icon: Users, feature: "contacts", module: "contacts" },
  { to: "/pipeline", label: "Pipeline", icon: Kanban, feature: "pipeline", module: "pipeline" },
  { to: "/follow-ups", label: "Follow-ups", icon: Bell, feature: "follow_ups", module: "follow_ups" },
  { to: "/orders", label: "Commerce", icon: ShoppingBag, feature: "commerce", module: "commerce" },
  { to: "/browse-recovery", label: "Browse Recovery", icon: Sparkles, feature: "browse_recovery", module: "browse_recovery" },
  { to: "/templates", label: "Templates", icon: FileText, feature: "templates", module: "templates" },
  { to: "/campaigns", label: "Campaigns", icon: Send, feature: "campaigns", module: "campaigns" },
  { to: "/remarketing", label: "Remarketing", icon: Target, feature: "remarketing", module: "remarketing" },
  { to: "/automations", label: "Automations", icon: Zap, feature: "automations", module: "automations" },
  { to: "/bots", label: "AI Bots", icon: Bot, feature: "bots", module: "bots" },
  { to: "/ai", label: "AI Insights", icon: Sparkles, feature: "ai", module: "ai" },
  { to: "/ai-settings", label: "AI Settings", icon: Sparkles, feature: "ai", module: "ai" },
  { to: "/interested-leads", label: "Interested Leads", icon: MousePointerClick, feature: "interested_leads", module: "analytics" },
  { to: "/analytics", label: "Analytics", icon: BarChart3, feature: "analytics", module: "analytics" },
  { to: "/integrations", label: "Integrations", icon: Plug, feature: "integrations", module: "integrations" },
  { to: "/whatsapp-setup", label: "WhatsApp Setup", icon: Plug, feature: null, module: "integrations" },
  { to: "/whatsapp-accounts", label: "WhatsApp Accounts", icon: Smartphone, feature: null, module: "integrations" },
  { to: "/vendors", label: "Vendor Catalog", icon: Store, feature: null, module: null },
  { to: "/reseller", label: "Reseller Program", icon: Sparkles, feature: "reseller_program", module: null },
  { to: "/subscription", label: "My Subscription", icon: CreditCard, feature: null, module: null },
  { to: "/team", label: "Team", icon: UsersRound, feature: null, module: "team" },
  { to: "/settings", label: "Settings", icon: Settings, feature: null, module: "settings" },
];


export function AppShell({ children }: { children: React.ReactNode }) {
  return (
    <WorkspaceProvider>
      <PermissionsProvider>
        <CurrencyProvider>
          <Shell>{children}</Shell>
        </CurrencyProvider>
      </PermissionsProvider>
    </WorkspaceProvider>
  );
}


function Shell({ children }: { children: React.ReactNode }) {
  const navigate = useNavigate();
  const path = useRouterState({ select: (s) => s.location.pathname });
  const getStatus = useServerFn(getMyAdminStatus);
  const { data: adminStatus } = useQuery({
    queryKey: ["my-admin-status"],
    queryFn: () => getStatus(),
    staleTime: 60_000,
  });
  const { hasFeature } = useWorkspacePlan();
  const trial = useTrialStatus();
  const { hasPermission, isPrivileged } = usePermissions();
  const isSuperAdmin = !!adminStatus?.is_super_admin;
  const locked = trial.isLocked && !isSuperAdmin;
  const allowedWhenLocked = new Set(["/subscription", "/settings"]);
  const filtered = navItems.filter((it) => {
    // "My Subscription" is a super-admin-only entry (still reachable for locked trials).
    if (it.to === "/subscription" && !isSuperAdmin && !locked) return false;
    if (it.feature && !hasFeature(it.feature)) return false;
    if (!isPrivileged && it.module && !hasPermission(it.module, "view")) return false;
    if (locked && !allowedWhenLocked.has(it.to)) return false;
    return true;
  });
  const items: NavItem[] = isSuperAdmin
    ? [
        ...filtered,
        { to: "/admin", label: "Super Admin", icon: Shield, feature: null },
        { to: "/admin/ai-credits", label: "AI Credits", icon: Coins, feature: null },
      ]
    : filtered;


  const onAllowedRoute = allowedWhenLocked.has(path) || path.startsWith("/subscription");
  const showGate = locked && !onAllowedRoute;

  // Auto-redirect locked users to the subscription/packages page.
  useEffect(() => {
    if (locked && !onAllowedRoute) {
      navigate({ to: "/subscription" });
    }
  }, [locked, onAllowedRoute, navigate]);


  const [mobileOpen, setMobileOpen] = useState(false);
  useEffect(() => { setMobileOpen(false); }, [path]);

  const sidebarInner = (
    <>
      <Link to="/dashboard" className="flex items-center gap-2 px-6 py-5 border-b border-sidebar-border">
        <img src="/slice-logo.png" alt="Slice" className="h-9 w-9 rounded-lg object-contain bg-white p-0.5" />
        <span className="font-display text-lg font-bold">Slice</span>
      </Link>

      <div className="px-3 pt-3 space-y-2">
        <WorkspaceSwitcher />
        <CurrencySwitcher />
      </div>

      <nav className="flex-1 space-y-1 p-3 overflow-y-auto">
        {items.map((item) => {
          const active = path === item.to || path.startsWith(item.to + "/");
          return (
            <Link
              key={item.to}
              to={item.to}
              className={cn(
                "flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition",
                active
                  ? "bg-sidebar-primary text-sidebar-primary-foreground"
                  : "text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground",
              )}
            >
              <item.icon className="h-4 w-4 shrink-0" />
              {item.label}
            </Link>
          );
        })}
      </nav>
      <div className="border-t border-sidebar-border p-3">
        <Button
          variant="ghost"
          className="w-full justify-start text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
          onClick={async () => {
            await supabase.auth.signOut();
            navigate({ to: "/login" });
          }}
        >
          <LogOut className="mr-2 h-4 w-4" /> Sign out
        </Button>
      </div>
    </>
  );

  return (
    <div className="flex min-h-screen bg-[image:var(--gradient-subtle)]">
      <aside className="hidden w-64 flex-col bg-sidebar text-sidebar-foreground md:flex">
        {sidebarInner}
      </aside>

      {/* Mobile top bar */}
      <div className="md:hidden fixed top-0 inset-x-0 z-40 flex items-center justify-between bg-sidebar text-sidebar-foreground px-4 py-3 border-b border-sidebar-border">
        <Link to="/dashboard" className="flex items-center gap-2 min-w-0">
          <img src="/slice-logo.png" alt="Slice" className="h-7 w-7 shrink-0 rounded-md object-contain bg-white p-0.5" />
          <span className="font-display font-bold truncate">Slice</span>
        </Link>
        <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
          <SheetTrigger asChild>
            <Button variant="ghost" size="icon" className="text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground" aria-label="Open menu">
              <Menu className="h-5 w-5" />
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="w-72 p-0 bg-sidebar text-sidebar-foreground border-sidebar-border flex flex-col [&>button]:text-sidebar-foreground">
            <SheetTitle className="sr-only">Navigation</SheetTitle>
            {sidebarInner}
          </SheetContent>
        </Sheet>
      </div>

      <main className="flex-1 overflow-auto pt-14 md:pt-0 min-w-0">
        <div className="container max-w-6xl mx-auto px-4 py-6 sm:px-6 sm:py-8">
          {showGate ? <TrialExpiredGate trial={trial} /> : children}
        </div>
      </main>
    </div>
  );
}


function WorkspaceSwitcher() {
  const { memberships, current, setCurrent, refetch } = useWorkspace();
  const createFn = useServerFn(createWorkspace);
  const getStatus = useServerFn(getMyAdminStatus);
  const { data: adminStatus } = useQuery({
    queryKey: ["my-admin-status"],
    queryFn: () => getStatus(),
    staleTime: 60_000,
  });
  const canCreateMore =
    !!adminStatus?.is_super_admin ||
    !!adminStatus?.allow_multi_workspace ||
    memberships.length === 0;
  const [open, setOpen] = useState(false);
  const [createOpen, setCreateOpen] = useState(false);
  const [name, setName] = useState("");
  const [loading, setLoading] = useState(false);

  async function create() {
    if (!name.trim()) return;
    setLoading(true);
    try {
      const res = await createFn({ data: { name: name.trim() } });
      toast.success("Workspace created");
      setName("");
      setCreateOpen(false);
      refetch();
      setCurrent(res.workspace.id);
    } catch (e: any) {
      toast.error(e.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <>
      <Popover open={open} onOpenChange={setOpen}>
        <PopoverTrigger asChild>
          <button className="w-full flex items-center justify-between gap-2 rounded-lg border border-sidebar-border bg-sidebar-accent/30 px-3 py-2 text-sm hover:bg-sidebar-accent">
            <span className="truncate text-left">
              <span className="block text-[10px] uppercase tracking-wide text-sidebar-foreground/50">Workspace</span>
              <span className="block font-medium truncate">{current?.workspaces.name ?? "—"}</span>
            </span>
            <ChevronsUpDown className="h-4 w-4 shrink-0 text-sidebar-foreground/50" />
          </button>
        </PopoverTrigger>
        <PopoverContent className="w-64 p-1" align="start">
          {memberships.map((m) => (
            <button
              key={m.workspace_id}
              onClick={() => { setCurrent(m.workspace_id); setOpen(false); }}
              className="w-full flex items-center justify-between gap-2 rounded-md px-3 py-2 text-sm hover:bg-accent"
            >
              <span className="truncate">
                <span className="block font-medium truncate">{m.workspaces.name}</span>
                <span className="block text-[11px] text-muted-foreground capitalize">{m.role}</span>
              </span>
              {m.workspace_id === current?.workspace_id && <Check className="h-4 w-4 text-primary" />}
            </button>
          ))}
          {canCreateMore ? (
            <div className="border-t mt-1 pt-1">
              <button
                onClick={() => { setOpen(false); setCreateOpen(true); }}
                className="w-full flex items-center gap-2 rounded-md px-3 py-2 text-sm hover:bg-accent"
              >
                <Plus className="h-4 w-4" /> New workspace
              </button>
            </div>
          ) : (
            <div className="border-t mt-1 pt-1 px-3 py-2 text-[11px] text-muted-foreground">
              Multi-workspace is disabled for your account. Contact your administrator to enable it.
            </div>
          )}
        </PopoverContent>
      </Popover>

      <Dialog open={createOpen} onOpenChange={setCreateOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>Create workspace</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <Label>Workspace name</Label>
            <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Acme Inc." maxLength={80} />
          </div>
          <DialogFooter>
            <Button onClick={create} disabled={loading || !name.trim()}>Create</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}

function CurrencySwitcher() {
  const { currency, setCurrency } = useCurrency();
  return (
    <div className="rounded-lg border border-sidebar-border bg-sidebar-accent/30 px-3 py-2">
      <p className="text-[10px] uppercase tracking-wide text-sidebar-foreground/50 mb-1">Currency</p>
      <div className="flex gap-1">
        {CURRENCIES.map((c) => (
          <button
            key={c.code}
            onClick={() => setCurrency(c.code)}
            className={cn(
              "flex-1 rounded-md px-2 py-1 text-xs font-medium transition",
              currency === c.code
                ? "bg-sidebar-primary text-sidebar-primary-foreground"
                : "text-sidebar-foreground/70 hover:bg-sidebar-accent",
            )}
            title={c.label}
          >
            {c.code}
          </button>
        ))}
      </div>
    </div>
  );
}

