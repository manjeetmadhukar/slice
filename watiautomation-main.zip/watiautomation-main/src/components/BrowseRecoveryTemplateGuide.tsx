// Inline "How to get a Browse Recovery template approved" guide.
//
// Mirrors AbandonedCartTemplateGuide, but for browse-abandonment reminders,
// where the URL button points at the Slice browse short link
// https://slice.dotscube.com/br/{{1}} so clicks are tracked.
import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { BookOpen, Copy, Check } from "lucide-react";
import { toast } from "sonner";

const SAMPLE_BODY = `Hi {{1}}, 👋
You were checking out {{2}} at {{3}} ✨
💰 Price: {{4}}
It's still available — tap below to take another look before it's gone.`;

const SAMPLE_FOOTER = `Reply STOP to unsubscribe`;

const BUTTON_URL_BASE = "https://slice.dotscube.com/br/";

function CopyRow({ value, label }: { value: string; label?: string }) {
  const [done, setDone] = useState(false);
  return (
    <div className="flex items-center gap-2">
      <code className="flex-1 rounded bg-muted px-2 py-1 text-xs whitespace-pre-wrap break-all">{value}</code>
      <Button
        type="button"
        size="sm"
        variant="ghost"
        onClick={async () => {
          await navigator.clipboard.writeText(value);
          setDone(true);
          toast.success(`Copied${label ? ` ${label}` : ""}`);
          setTimeout(() => setDone(false), 1200);
        }}
      >
        {done ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
      </Button>
    </div>
  );
}

export function BrowseRecoveryTemplateGuide() {
  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm">
          <BookOpen className="mr-2 h-4 w-4" />
          Template approval guide
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Get a Browse Recovery template approved</DialogTitle>
          <DialogDescription>
            Follow these steps to submit a Meta-approved template that works with Slice's browse
            recovery short link.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-5 text-sm">
          <section>
            <h3 className="font-semibold mb-1">1. Category</h3>
            <p className="text-muted-foreground">
              Choose <span className="font-medium text-foreground">Marketing → Custom</span>.
              Browse reminders are promotional; submitting them as Utility gets them rejected.
            </p>
          </section>

          <section>
            <h3 className="font-semibold mb-1">2. Name & language</h3>
            <p className="text-muted-foreground">
              Use a snake_case name such as{" "}
              <code className="rounded bg-muted px-1 py-0.5 text-xs">browse_recovery_reminder</code>.
              Set the language to match the{" "}
              <span className="font-medium text-foreground">Template language</span> field on this
              page (for example <code className="rounded bg-muted px-1 py-0.5 text-xs">en_US</code>).
            </p>
          </section>

          <section>
            <h3 className="font-semibold mb-1">3. Header (optional)</h3>
            <p className="text-muted-foreground">
              A <span className="font-medium text-foreground">Media → Image</span> header works best
              — Slice fills it with the product image captured by the tracking script. Upload any
              product photo as the sample when Meta asks.
            </p>
          </section>

          <section>
            <h3 className="font-semibold mb-1">4. Body text (example)</h3>
            <p className="text-muted-foreground mb-2">
              Use numbered variables. Slice auto-maps them from the browse event.
            </p>
            <CopyRow value={SAMPLE_BODY} label="body" />
            <div className="mt-2 rounded border bg-muted/40 p-2 text-xs space-y-0.5">
              <div><span className="font-medium">{`{{1}}`}</span> → Visitor / contact name</div>
              <div><span className="font-medium">{`{{2}}`}</span> → Product name</div>
              <div><span className="font-medium">{`{{3}}`}</span> → Store name</div>
              <div><span className="font-medium">{`{{4}}`}</span> → Product price</div>
            </div>
            <p className="text-muted-foreground text-xs mt-2">
              Meta requires a sample value for every variable, e.g.{" "}
              <span className="font-medium text-foreground">Priya, Silk Kurta Set, Gulabi, ₹2,499</span>.
            </p>
          </section>

          <section>
            <h3 className="font-semibold mb-1">5. Footer (recommended)</h3>
            <CopyRow value={SAMPLE_FOOTER} label="footer" />
            <p className="text-muted-foreground text-xs mt-1">
              Marketing templates with an opt-out footer are approved faster.
            </p>
          </section>

          <section>
            <h3 className="font-semibold mb-1">6. "View product" URL button</h3>
            <p className="text-muted-foreground mb-2">
              Add a <span className="font-medium text-foreground">Dynamic URL</span> button labelled{" "}
              <span className="font-medium text-foreground">View product</span>. The URL must end with{" "}
              <code className="rounded bg-muted px-1 py-0.5 text-xs">{`{{1}}`}</code>:
            </p>
            <CopyRow value={`${BUTTON_URL_BASE}{{1}}`} label="button URL" />
            <p className="text-muted-foreground text-xs mt-2">Sample value to paste for Meta:</p>
            <div className="mt-1">
              <CopyRow value={`${BUTTON_URL_BASE}sample-token-xyz`} label="sample URL" />
            </div>
            <p className="text-muted-foreground text-xs mt-2">
              Slice replaces the token at send time. Clicks open{" "}
              <code className="rounded bg-muted px-1 py-0.5 text-xs">{BUTTON_URL_BASE}&lt;token&gt;</code>,
              which redirects to the exact product page and records the click for analytics.
            </p>
          </section>

          <section>
            <h3 className="font-semibold mb-1">7. After approval</h3>
            <ul className="text-muted-foreground list-disc pl-5 space-y-1">
              <li>Open <span className="font-medium text-foreground">Templates</span> and click{" "}
                  <span className="font-medium text-foreground">Sync from Meta</span>.</li>
              <li>Come back here, pick the template in{" "}
                  <span className="font-medium text-foreground">WhatsApp template</span>, set{" "}
                  <span className="font-medium text-foreground">Send reminder after</span>, and save.</li>
              <li>Install the tracking script from the{" "}
                  <span className="font-medium text-foreground">Install</span> tab, then browse a
                  product on the store to test.</li>
            </ul>
          </section>

          <section className="rounded border border-amber-200 bg-amber-50 p-3 text-xs dark:border-amber-900/50 dark:bg-amber-950/30">
            <p className="font-medium text-amber-900 dark:text-amber-100">Common rejection reasons</p>
            <ul className="mt-1 list-disc pl-5 text-amber-900/90 dark:text-amber-100/90 space-y-0.5">
              <li>Variable placed in the middle of the URL — Meta only allows it at the end.</li>
              <li>Promotional copy submitted under the Utility category.</li>
              <li>Missing sample values for variables or the button URL.</li>
              <li>Emojis or capital letters in the template name.</li>
              <li>Two variables next to each other, or a body that starts/ends with a variable.</li>
            </ul>
          </section>
        </div>
      </DialogContent>
    </Dialog>
  );
}
