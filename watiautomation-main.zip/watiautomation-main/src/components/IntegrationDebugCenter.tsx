import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import {
  Activity, CheckCircle2, XCircle, AlertCircle, Send, RefreshCw, ArrowDown, ArrowUp,
  Zap, Stethoscope, MessageSquare, Hash, Clock,
} from "lucide-react";
import {
  getIntegrationDebugLogs, sendTestWhatsApp, getIntegrationHealth, syncWooCommerceData,
} from "@/lib/integrations.functions";

export function IntegrationDebugCenter({ integration }: { integration: any }) {
  const qc = useQueryClient();
  const fetchLogs = useServerFn(getIntegrationDebugLogs);
  const fetchHealth = useServerFn(getIntegrationHealth);
  const sendTest = useServerFn(sendTestWhatsApp);
  const syncNow = useServerFn(syncWooCommerceData);
  const [testOpen, setTestOpen] = useState(false);
  const [testPhone, setTestPhone] = useState("");

  const { data: health } = useQuery({
    queryKey: ["integration-health", integration.id],
    queryFn: () => fetchHealth({ data: { integration_id: integration.id } }),
    refetchInterval: 15_000,
  });

  const { data: logsRes } = useQuery({
    queryKey: ["integration-logs", integration.id],
    queryFn: () => fetchLogs({ data: { workspace_id: integration.workspace_id, integration_id: integration.id, limit: 50 } }),
    refetchInterval: 10_000,
  });
  const logs = logsRes?.logs || [];

  const testMutation = useMutation({
    mutationFn: () => sendTest({ data: { workspace_id: integration.workspace_id, integration_id: integration.id, phone: testPhone } }),
    onSuccess: (r: any) => {
      if (r.ok) toast.success("Test message sent");
      else toast.error(`Test failed: ${r.error}`);
      qc.invalidateQueries({ queryKey: ["integration-logs", integration.id] });
      qc.invalidateQueries({ queryKey: ["integration-health", integration.id] });
      setTestOpen(false);
      setTestPhone("");
    },
    onError: (e: any) => toast.error(e?.message || "Test failed"),
  });

  const syncMutation = useMutation({
    mutationFn: () => syncNow({ data: { workspace_id: integration.workspace_id, integration_id: integration.id } }),
    onSuccess: (r: any) => {
      if (r.ok) toast.success(`Synced ${r.orders} orders, ${r.customers} customers, ${r.products} products`);
      else toast.error(r.error || "Sync failed");
      qc.invalidateQueries({ queryKey: ["store-integrations"] });
      qc.invalidateQueries({ queryKey: ["integration-logs", integration.id] });
      qc.invalidateQueries({ queryKey: ["integration-health", integration.id] });
    },
    onError: (e: any) => toast.error(e?.message || "Sync failed"),
  });

  const h = health?.health;
  const checks = [
    { label: "Connection", ok: !!h?.connected, hint: h?.connected ? "Connected" : "Not connected" },
    { label: "API Key", ok: !!h?.api_key_set, hint: h?.api_key_set ? "Configured" : "Missing" },
    { label: "Workspace Linked", ok: !!h?.workspace_linked, hint: h?.workspace_linked ? "Linked" : "Not linked" },
    { label: "Last Event", ok: !!h?.last_inbound, hint: h?.last_inbound ? `${h.last_inbound.event} • ${new Date(h.last_inbound.created_at).toLocaleTimeString()}` : "No events yet" },
  ];

  return (
    <div className="space-y-6">
      {/* Health tiles */}
      <Card className="p-5">
        <div className="flex items-center gap-2 mb-4">
          <Stethoscope className="h-4 w-4" />
          <h3 className="font-semibold">Integration Health</h3>
          <Badge variant="outline" className="ml-auto">Auto-refresh 15s</Badge>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {checks.map((c) => (
            <div key={c.label} className="rounded-lg border p-3 flex items-start gap-2">
              {c.ok ? <CheckCircle2 className="h-4 w-4 text-emerald-500 mt-0.5" /> : <XCircle className="h-4 w-4 text-red-500 mt-0.5" />}
              <div className="min-w-0">
                <div className="text-sm font-medium">{c.label}</div>
                <div className="text-xs text-muted-foreground truncate">{c.hint}</div>
              </div>
            </div>
          ))}
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-3">
          <Stat label="Orders synced" value={h?.stats?.orders_synced || 0} icon={Hash} />
          <Stat label="Customers synced" value={h?.stats?.customers_synced || 0} icon={Hash} />
          <Stat label="WA sent (24h)" value={h?.messages_sent_24h || 0} icon={MessageSquare} tone="success" />
          <Stat label="WA failed (24h)" value={h?.messages_failed_24h || 0} icon={AlertCircle} tone={h?.messages_failed_24h ? "danger" : undefined} />
        </div>
      </Card>

      {/* Test message */}
      <Card className="p-5">
        <div className="flex items-center gap-2 mb-3">
          <Zap className="h-4 w-4" />
          <h3 className="font-semibold">Test WhatsApp Notification</h3>
        </div>
        <p className="text-sm text-muted-foreground mb-3">
          Send a quick test message to verify the WhatsApp + WooCommerce pipeline end-to-end.
        </p>
        <div className="flex flex-wrap gap-2">
          <Button onClick={() => syncMutation.mutate()} disabled={syncMutation.isPending} variant="outline">
            <RefreshCw className={`h-4 w-4 mr-2 ${syncMutation.isPending ? "animate-spin" : ""}`} />Sync WooCommerce now
          </Button>
          <Button onClick={() => setTestOpen(true)}><Send className="h-4 w-4 mr-2" />Send test message</Button>
        </div>
      </Card>

      {/* Debug log table */}
      <Card className="p-5">
        <div className="flex items-center gap-2 mb-4">
          <Activity className="h-4 w-4" />
          <h3 className="font-semibold">Debug Logs</h3>
          <Badge variant="outline" className="ml-auto">Last 50 events</Badge>
          <Button size="sm" variant="ghost" onClick={() => qc.invalidateQueries({ queryKey: ["integration-logs", integration.id] })}>
            <RefreshCw className="h-3 w-3" />
          </Button>
        </div>
        {logs.length === 0 ? (
          <div className="text-sm text-muted-foreground text-center py-8">
            No events yet. Once your WooCommerce store sends an order or test ping, it will show here.
          </div>
        ) : (
          <div className="space-y-2 max-h-[480px] overflow-auto">
            {logs.map((log: any) => (
              <LogRow key={log.id} log={log} />
            ))}
          </div>
        )}
      </Card>

      <Dialog open={testOpen} onOpenChange={setTestOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Send test WhatsApp message</DialogTitle>
            <DialogDescription>We'll send a quick text message to verify your setup.</DialogDescription>
          </DialogHeader>
          <div className="space-y-2">
            <Label>Phone number (with country code)</Label>
            <Input value={testPhone} onChange={(e) => setTestPhone(e.target.value)} placeholder="+919999999999" />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setTestOpen(false)}>Cancel</Button>
            <Button onClick={() => testMutation.mutate()} disabled={testPhone.length < 6 || testMutation.isPending}>
              {testMutation.isPending ? "Sending…" : "Send"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function Stat({ label, value, icon: Icon, tone }: { label: string; value: number | string; icon: any; tone?: "success" | "danger" }) {
  const color = tone === "danger" ? "text-red-500" : tone === "success" ? "text-emerald-500" : "text-foreground";
  return (
    <div className="rounded-lg border p-3">
      <div className="flex items-center gap-2 text-xs text-muted-foreground">
        <Icon className="h-3 w-3" /> {label}
      </div>
      <div className={`text-2xl font-bold mt-1 ${color}`}>{value}</div>
    </div>
  );
}

function LogRow({ log }: { log: any }) {
  const [open, setOpen] = useState(false);
  const Icon = log.direction === "in" ? ArrowDown : ArrowUp;
  return (
    <div className="rounded-lg border bg-card">
      <button onClick={() => setOpen((v) => !v)} className="w-full flex items-center gap-3 p-3 text-left hover:bg-accent/30 transition-colors">
        <Icon className={`h-4 w-4 ${log.direction === "in" ? "text-blue-500" : "text-purple-500"}`} />
        <span className="font-mono text-xs px-2 py-0.5 rounded bg-muted">{log.event}</span>
        {log.ok ? (
          <Badge variant="outline" className="text-emerald-600 border-emerald-300">{log.status_code ?? "OK"}</Badge>
        ) : (
          <Badge variant="destructive">{log.status_code ?? "ERR"}</Badge>
        )}
        <span className="text-xs text-muted-foreground truncate flex-1">{log.message || "—"}</span>
        <span className="text-xs text-muted-foreground flex items-center gap-1">
          <Clock className="h-3 w-3" /> {new Date(log.created_at).toLocaleTimeString()}
        </span>
      </button>
      {open && (
        <div className="border-t p-3 space-y-2 bg-muted/30">
          {log.payload && (
            <div>
              <div className="text-xs font-semibold mb-1">Payload</div>
              <pre className="text-xs overflow-auto max-h-40 bg-background p-2 rounded border">{JSON.stringify(log.payload, null, 2)}</pre>
            </div>
          )}
          {log.response && (
            <div>
              <div className="text-xs font-semibold mb-1">Response</div>
              <pre className="text-xs overflow-auto max-h-40 bg-background p-2 rounded border">{JSON.stringify(log.response, null, 2)}</pre>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
