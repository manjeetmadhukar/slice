import { Link } from "@tanstack/react-router";
import { Lock, ArrowRight, Clock } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { formatTrialExpiry, type TrialStatus } from "@/lib/use-trial-status";

export function TrialExpiredGate({ trial }: { trial: TrialStatus }) {
  return (
    <div className="grid min-h-[70vh] place-items-center px-4">
      <Card className="w-full max-w-lg p-8 text-center border-destructive/30 bg-destructive/5">
        <div className="mx-auto grid h-14 w-14 place-items-center rounded-full bg-destructive/10 text-destructive">
          <Lock className="h-7 w-7" />
        </div>
        <h2 className="mt-5 font-display text-2xl font-semibold">Your free trial has ended</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          Upgrade your plan to regain access to the dashboard, campaigns, inbox, and all other features.
        </p>

        <div className="mt-5 inline-flex items-center gap-2 rounded-full border bg-background px-3 py-1.5 text-xs text-muted-foreground">
          <Clock className="h-3.5 w-3.5" />
          Trial expired on <span className="font-medium text-foreground">{formatTrialExpiry(trial.trialEndsAt)}</span>
        </div>

        <div className="mt-6 flex flex-col gap-2 sm:flex-row sm:justify-center">
          <Link to="/subscription">
            <Button size="lg" className="w-full sm:w-auto">
              Upgrade now <ArrowRight className="ml-1.5 h-4 w-4" />
            </Button>
          </Link>
        </div>
      </Card>
    </div>
  );
}
