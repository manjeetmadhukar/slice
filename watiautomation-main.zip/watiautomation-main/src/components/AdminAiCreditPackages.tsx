import { useServerFn } from "@tanstack/react-start";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from "@/components/ui/table";
import { Plus, Pencil, Trash2, Package } from "lucide-react";
import {
  adminListAiCreditPackages,
  adminUpsertAiCreditPackage,
  adminDeleteAiCreditPackage,
} from "@/lib/ai-credit-packages.functions";

type Pkg = {
  id?: string; name: string; description?: string | null; credits: number; bonus_credits?: number;
  price: number; currency: string; is_active?: boolean; is_featured?: boolean; sort_order?: number;
};

const EMPTY: Pkg = { name: "", description: "", credits: 1000, bonus_credits: 0, price: 199, currency: "INR", is_active: true, is_featured: false, sort_order: 0 };

export function AdminAiCreditPackages() {
  const qc = useQueryClient();
  const listFn = useServerFn(adminListAiCreditPackages);
  const upsertFn = useServerFn(adminUpsertAiCreditPackage);
  const delFn = useServerFn(adminDeleteAiCreditPackage);

  const { data: packages, isLoading } = useQuery({
    queryKey: ["admin-ai-credit-packages"], queryFn: () => listFn(),
  });

  const [editing, setEditing] = useState<Pkg | null>(null);
  const del = useMutation({
    mutationFn: (id: string) => delFn({ data: { id } }),
    onSuccess: () => { toast.success("Deleted"); qc.invalidateQueries({ queryKey: ["admin-ai-credit-packages"] }); },
    onError: (e: any) => toast.error(e.message),
  });

  const save = useMutation({
    mutationFn: (p: Pkg) => upsertFn({ data: {
      id: p.id, name: p.name, description: p.description || undefined,
      credits: Number(p.credits), bonus_credits: Number(p.bonus_credits || 0),
      price: Number(p.price), currency: p.currency || "INR",
      is_active: p.is_active, is_featured: p.is_featured,
      sort_order: Number(p.sort_order || 0),
    } }),
    onSuccess: () => { toast.success("Saved"); setEditing(null); qc.invalidateQueries({ queryKey: ["admin-ai-credit-packages"] }); },
    onError: (e: any) => toast.error(e.message),
  });

  return (
    <Card>
      <div className="flex items-center justify-between p-4 border-b">
        <div className="flex items-center gap-2"><Package className="h-4 w-4" /><h2 className="font-semibold">Credit packages (Buy AI Credits)</h2></div>
        <Button size="sm" onClick={() => setEditing({ ...EMPTY })}><Plus className="h-4 w-4 mr-1" /> New package</Button>
      </div>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Name</TableHead>
            <TableHead className="text-right">Credits</TableHead>
            <TableHead className="text-right">Price</TableHead>
            <TableHead>Status</TableHead>
            <TableHead className="text-right">Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {isLoading ? (
            <TableRow><TableCell colSpan={5} className="text-center p-6 text-sm text-muted-foreground">Loading…</TableCell></TableRow>
          ) : (packages ?? []).length === 0 ? (
            <TableRow><TableCell colSpan={5} className="text-center p-6 text-sm text-muted-foreground">No packages yet</TableCell></TableRow>
          ) : (packages ?? []).map((p: any) => {
            const total = Number(p.credits) + Number(p.bonus_credits || 0);
            return (
              <TableRow key={p.id}>
                <TableCell>
                  <div className="font-medium flex items-center gap-2">{p.name}
                    {p.is_featured && <Badge variant="secondary" className="text-[10px]">Popular</Badge>}
                  </div>
                  {p.description && <div className="text-[11px] text-muted-foreground">{p.description}</div>}
                </TableCell>
                <TableCell className="text-right tabular-nums">
                  {total.toLocaleString()}
                  {p.bonus_credits > 0 && <span className="text-success text-[11px] ml-1">(+{Number(p.bonus_credits).toLocaleString()})</span>}
                </TableCell>
                <TableCell className="text-right tabular-nums">{p.currency} {Number(p.price).toLocaleString()}</TableCell>
                <TableCell>{p.is_active ? <Badge variant="outline">Active</Badge> : <Badge variant="secondary">Disabled</Badge>}</TableCell>
                <TableCell className="text-right">
                  <Button size="sm" variant="ghost" onClick={() => setEditing(p)}><Pencil className="h-3.5 w-3.5" /></Button>
                  <Button size="sm" variant="ghost" onClick={() => { if (confirm(`Delete "${p.name}"?`)) del.mutate(p.id); }}>
                    <Trash2 className="h-3.5 w-3.5 text-destructive" />
                  </Button>
                </TableCell>
              </TableRow>
            );
          })}
        </TableBody>
      </Table>

      {editing && (
        <Dialog open onOpenChange={(v) => { if (!v) setEditing(null); }}>
          <DialogContent className="max-w-lg">
            <DialogHeader><DialogTitle>{editing.id ? "Edit package" : "New credit package"}</DialogTitle></DialogHeader>
            <div className="grid gap-3">
              <div><Label>Name</Label><Input value={editing.name} onChange={(e) => setEditing({ ...editing, name: e.target.value })} /></div>
              <div><Label>Description</Label><Textarea rows={2} value={editing.description || ""} onChange={(e) => setEditing({ ...editing, description: e.target.value })} /></div>
              <div className="grid grid-cols-2 gap-3">
                <div><Label>Credits</Label><Input type="number" min={1} value={editing.credits} onChange={(e) => setEditing({ ...editing, credits: Number(e.target.value) })} /></div>
                <div><Label>Bonus credits</Label><Input type="number" min={0} value={editing.bonus_credits || 0} onChange={(e) => setEditing({ ...editing, bonus_credits: Number(e.target.value) })} /></div>
                <div><Label>Price</Label><Input type="number" min={0} step="0.01" value={editing.price} onChange={(e) => setEditing({ ...editing, price: Number(e.target.value) })} /></div>
                <div><Label>Currency</Label><Input value={editing.currency} onChange={(e) => setEditing({ ...editing, currency: e.target.value.toUpperCase().slice(0, 3) })} /></div>
                <div><Label>Sort order</Label><Input type="number" value={editing.sort_order || 0} onChange={(e) => setEditing({ ...editing, sort_order: Number(e.target.value) })} /></div>
              </div>
              <div className="flex items-center gap-6">
                <label className="flex items-center gap-2 text-sm"><Switch checked={!!editing.is_active} onCheckedChange={(v) => setEditing({ ...editing, is_active: v })} /> Active</label>
                <label className="flex items-center gap-2 text-sm"><Switch checked={!!editing.is_featured} onCheckedChange={(v) => setEditing({ ...editing, is_featured: v })} /> Featured</label>
              </div>
            </div>
            <DialogFooter>
              <Button variant="ghost" onClick={() => setEditing(null)}>Cancel</Button>
              <Button onClick={() => save.mutate(editing)} disabled={save.isPending || !editing.name}>Save</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </Card>
  );
}
