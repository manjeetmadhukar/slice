import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Link } from "@tanstack/react-router";
import { Coins, Info, Zap, Gauge, Crown } from "lucide-react";

/**
 * Explains to users how AI Bots / AI Assistant usage is billed.
 *
 * Slice uses the Lovable AI Gateway. Every AI reply, classification,
 * tagging, or analysis call is metered per request and deducted from the
 * workspace's credit balance. Cost depends on:
 *   - The model selected (Flash/Mini < Pro < GPT-5)
 *   - Length of the conversation context + the AI's reply
 *
 * We deliberately do NOT show invented per-message numbers; pricing is
 * usage-based. Users can monitor real spend in Settings → Plans & credits.
 */
export function AiUsageCostNotice({ compact = false }: { compact?: boolean }) {
  if (compact) {
    return (
      <Card className="p-3 border-primary/30 bg-primary/5 text-xs flex items-start gap-2">
        <Coins className="h-4 w-4 text-primary shrink-0 mt-0.5" />
        <p className="text-muted-foreground">
          AI Bot replies are billed per message from your workspace AI credits. Cost depends on the
          chosen model and message length.{" "}
          <Link to="/subscription" className="text-primary underline-offset-2 hover:underline">
            View balance
          </Link>
        </p>
      </Card>
    );
  }

  return (
    <Card className="p-5 border-primary/30 bg-gradient-to-br from-primary/5 to-transparent">
      <div className="flex items-start gap-3">
        <div className="grid h-10 w-10 place-items-center rounded-lg bg-primary/15 text-primary shrink-0">
          <Coins className="h-5 w-5" />
        </div>
        <div className="flex-1 space-y-3">
          <div>
            <h3 className="font-semibold flex items-center gap-2">
              How AI Bots are billed
              <Badge variant="secondary" className="text-[10px]">Usage-based</Badge>
            </h3>
            <p className="text-sm text-muted-foreground mt-1">
              Every time your bot replies, classifies a lead, or analyses a conversation, it makes
              an AI request that is metered and deducted from your workspace's AI credit balance.
              You only pay for what the bot actually uses — there is no fixed monthly fee per bot.
            </p>
          </div>

          <div className="grid gap-2 sm:grid-cols-3">
            <CostTier
              icon={Zap}
              tone="text-emerald-600"
              label="Economy"
              models="Gemini Flash / GPT-5 Nano"
              note="Lowest cost per reply. Great for FAQ, lead capture, simple Q&A."
            />
            <CostTier
              icon={Gauge}
              tone="text-amber-600"
              label="Balanced"
              models="Gemini Pro / GPT-5 Mini"
              note="Mid-range cost. Better reasoning and longer context."
            />
            <CostTier
              icon={Crown}
              tone="text-violet-600"
              label="Premium"
              models="GPT-5 / GPT-5 Pro"
              note="Highest cost per reply. Best for nuanced sales conversations."
            />
          </div>

          <div className="rounded-lg border bg-background/60 p-3 text-xs text-muted-foreground flex items-start gap-2">
            <Info className="h-3.5 w-3.5 mt-0.5 shrink-0" />
            <div className="space-y-1">
              <p>
                <strong className="text-foreground">What counts as usage:</strong> each inbound
                message processed by the bot, each generated reply, and any AI tagging / sentiment
                analysis triggered for that conversation.
              </p>
              <p>
                <strong className="text-foreground">Tip to reduce spend:</strong> pick the cheapest
                model that meets your quality bar, keep system prompts short, and disable AI
                analysis on workspaces that don't need it (AI Settings → toggle off).
              </p>
              <p>
                Track real-time consumption and top up under{" "}
                <Link to="/subscription" className="text-primary underline-offset-2 hover:underline">
                  Plans &amp; credits
                </Link>
                .
              </p>
            </div>
          </div>
        </div>
      </div>
    </Card>
  );
}

function CostTier({
  icon: Icon,
  tone,
  label,
  models,
  note,
}: {
  icon: any;
  tone: string;
  label: string;
  models: string;
  note: string;
}) {
  return (
    <div className="rounded-lg border bg-background/60 p-3">
      <div className={`flex items-center gap-1.5 text-sm font-medium ${tone}`}>
        <Icon className="h-4 w-4" /> {label}
      </div>
      <p className="text-xs font-medium mt-1">{models}</p>
      <p className="text-xs text-muted-foreground mt-1">{note}</p>
    </div>
  );
}
