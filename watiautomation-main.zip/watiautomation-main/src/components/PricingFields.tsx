import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { SUPPORTED_CURRENCIES, PAYMENT_PROVIDERS, type SupportedCurrency, type PaymentProvider } from "@/lib/features-catalog";

export interface PricingValue {
  price_monthly: number;
  price_yearly: number;
  currency: SupportedCurrency;
  gateway_ids?: PaymentProvider[];
}

export function PricingFields({
  value,
  onChange,
  showGateways = false,
}: {
  value: PricingValue;
  onChange: (v: PricingValue) => void;
  showGateways?: boolean;
}) {
  return (
    <div className="space-y-3">
      <div className="grid grid-cols-3 gap-3 rounded-lg border p-4">
        <div className="space-y-1">
          <Label className="text-xs text-muted-foreground">Monthly price</Label>
          <Input
            type="number"
            min={0}
            value={value.price_monthly}
            onChange={(e) => onChange({ ...value, price_monthly: Number(e.target.value || 0) })}
          />
        </div>
        <div className="space-y-1">
          <Label className="text-xs text-muted-foreground">Yearly price</Label>
          <Input
            type="number"
            min={0}
            value={value.price_yearly}
            onChange={(e) => onChange({ ...value, price_yearly: Number(e.target.value || 0) })}
          />
        </div>
        <div className="space-y-1">
          <Label className="text-xs text-muted-foreground">Currency</Label>
          <select
            value={value.currency}
            onChange={(e) => onChange({ ...value, currency: e.target.value as SupportedCurrency })}
            className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
          >
            {SUPPORTED_CURRENCIES.map((c) => <option key={c} value={c}>{c}</option>)}
          </select>
        </div>
      </div>
      {showGateways && (
        <div className="rounded-lg border p-4 space-y-2">
          <Label>Accepted payment gateways</Label>
          <div className="grid grid-cols-2 gap-2">
            {PAYMENT_PROVIDERS.map((p) => {
              const checked = (value.gateway_ids ?? []).includes(p.key);
              return (
                <label key={p.key} className="flex items-center gap-2 text-sm cursor-pointer">
                  <Checkbox
                    checked={checked}
                    onCheckedChange={(v) => {
                      const cur = new Set(value.gateway_ids ?? []);
                      if (v) cur.add(p.key); else cur.delete(p.key);
                      onChange({ ...value, gateway_ids: Array.from(cur) as PaymentProvider[] });
                    }}
                  />
                  <span>{p.label}</span>
                  <span className="text-xs text-muted-foreground">({p.region})</span>
                </label>
              );
            })}
          </div>
          <p className="text-xs text-muted-foreground">Customers will be able to pay using any selected gateway.</p>
        </div>
      )}
      <p className="text-xs text-muted-foreground">Set 0 to hide that billing interval.</p>
    </div>
  );
}

export function formatPrice(amount: number, currency: string) {
  if (!amount) return "Free";
  try {
    return new Intl.NumberFormat(undefined, { style: "currency", currency: currency || "INR", maximumFractionDigits: 0 }).format(amount);
  } catch {
    return `${currency} ${amount}`;
  }
}
