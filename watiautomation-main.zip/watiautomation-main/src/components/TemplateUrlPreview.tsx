// Quality-of-life helper for the WhatsApp Template Builder:
// resolves a dynamic URL button's {{1}} with the example value so the
// merchant can open/copy and verify the destination before submitting to Meta.
// Purely a preview — never records a click or affects production tokens.
import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import { Copy, Check, ExternalLink, Loader2, Wand2, AlertTriangle, CheckCircle2 } from "lucide-react";
import { checkPreviewUrl } from "@/lib/url-preview.functions";

type CheckResult =
  | { ok: true; status: number; redirectsTo: string | null }
  | { ok: false; status: number; error: string };

export function TemplateUrlPreview({ url, example }: { url: string; example: string }) {
  const check = useServerFn(checkPreviewUrl);
  const [preview, setPreview] = useState("");
  const [result, setResult] = useState<CheckResult | null>(null);
  const [checking, setChecking] = useState(false);
  const [copied, setCopied] = useState(false);

  const build = () => {
    const raw = (url || "").trim();
    const value = (example || "").trim();
    if (!raw) { toast.error("Enter the button URL first"); return ""; }
    if (!value) { toast.error("Enter an example value first"); return ""; }
    const built = raw.includes("{{1}}")
      ? raw.replace(/\{\{\s*1\s*\}\}/g, encodeURIComponent(value))
      : raw.replace(/\/?$/, raw.endsWith("/") ? "" : "/") + encodeURIComponent(value);
    return built;
  };

  const generate = async () => {
    const built = build();
    if (!built) return;
    setPreview(built);
    setResult(null);
    setChecking(true);
    try {
      const res = (await check({ data: { url: built } })) as CheckResult;
      setResult(res);
    } catch (e: any) {
      setResult({ ok: false, status: 0, error: e?.message || "Could not verify the URL" });
    } finally {
      setChecking(false);
    }
  };

  return (
    <div className="rounded-md border p-2.5 space-y-2 bg-background">
      <div className="flex items-center justify-between gap-2">
        <p className="text-xs font-medium">Preview URL</p>
        <Button type="button" size="sm" variant="secondary" onClick={generate} disabled={checking}>
          {checking ? <Loader2 className="mr-1.5 h-3.5 w-3.5 animate-spin" /> : <Wand2 className="mr-1.5 h-3.5 w-3.5" />}
          Generate Preview URL
        </Button>
      </div>
      <p className="text-[11px] text-muted-foreground">
        Replaces {`{{1}}`} with your example value so you can check the destination. Test-only — no production tokens or analytics are affected.
      </p>

      {preview && (
        <>
          <div className="flex items-center gap-2">
            <Input readOnly value={preview} className="text-xs" onFocus={(e) => e.currentTarget.select()} />
            <Button
              type="button"
              size="icon"
              variant="ghost"
              title="Copy URL"
              onClick={async () => {
                await navigator.clipboard.writeText(preview);
                setCopied(true);
                toast.success("Preview URL copied");
                setTimeout(() => setCopied(false), 1200);
              }}
            >
              {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
            </Button>
            <Button
              type="button"
              size="icon"
              variant="ghost"
              title="Open in new tab"
              onClick={() => window.open(preview, "_blank", "noopener,noreferrer")}
            >
              <ExternalLink className="h-4 w-4" />
            </Button>
          </div>

          {checking && (
            <p className="text-[11px] text-muted-foreground flex items-center gap-1.5">
              <Loader2 className="h-3 w-3 animate-spin" /> Checking that the link is reachable…
            </p>
          )}

          {result && result.ok && (
            <div className="rounded border border-emerald-300 bg-emerald-50 p-2 text-[11px] text-emerald-900 dark:border-emerald-900/50 dark:bg-emerald-950/30 dark:text-emerald-100">
              <p className="flex items-center gap-1.5 font-medium">
                <CheckCircle2 className="h-3.5 w-3.5" /> Link is reachable (HTTP {result.status})
              </p>
              {result.redirectsTo && (
                <p className="mt-0.5 break-all">Redirects to: <code>{result.redirectsTo}</code></p>
              )}
            </div>
          )}

          {result && !result.ok && (
            <div className="rounded border border-amber-300 bg-amber-50 p-2 text-[11px] text-amber-900 dark:border-amber-900/50 dark:bg-amber-950/30 dark:text-amber-100">
              <p className="flex items-center gap-1.5 font-medium">
                <AlertTriangle className="h-3.5 w-3.5" /> {result.error}
              </p>
              <p className="mt-0.5">
                Sample tokens usually 404 — that's expected. Meta still needs a sample value, and Slice fills the real token at send time.
              </p>
            </div>
          )}
        </>
      )}
    </div>
  );
}
