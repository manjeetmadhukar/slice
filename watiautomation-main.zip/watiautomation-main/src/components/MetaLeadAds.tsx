import { useEffect, useState } from "react";
import { useQuery, useQueryClient, useMutation } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter,
} from "@/components/ui/dialog";
import { toast } from "sonner";
import {
  Facebook, RefreshCw, Trash2, Users, Tag as TagIcon, Plus, Settings2, Link as LinkIcon, Loader2,
  Zap, Copy, ExternalLink, BookOpen,
} from "lucide-react";
import {
  getMetaLeadConnectUrl, listMetaConnections, syncMetaPages, listMetaPages,
  toggleMetaPageSubscription, syncPageForms, listMetaForms, updateFormRouting,
  disconnectMeta, listLeadAgents, upsertLeadAgent, deleteLeadAgent,
} from "@/lib/meta-leads.functions";

export function MetaLeadAds({ workspaceId }: { workspaceId: string | null }) {
  const qc = useQueryClient();
  const origin = typeof window !== "undefined" ? window.location.origin : "";
  const redirectUri = `${origin}/api/public/meta/leads/callback`;

  const getUrl = useServerFn(getMetaLeadConnectUrl);
  const sync = useServerFn(syncMetaPages);
  const togglePage = useServerFn(toggleMetaPageSubscription);
  const syncForms = useServerFn(syncPageForms);
  const updateForm = useServerFn(updateFormRouting);
  const disconnect = useServerFn(disconnectMeta);

  const { data: connections = [] } = useQuery({
    queryKey: ["meta-connections", workspaceId],
    enabled: !!workspaceId,
    queryFn: () => listMetaConnections({ data: { workspaceId: workspaceId! } }),
  });
  const { data: pages = [] } = useQuery({
    queryKey: ["meta-pages", workspaceId],
    enabled: !!workspaceId,
    queryFn: () => listMetaPages({ data: { workspaceId: workspaceId! } }),
  });
  const { data: forms = [] } = useQuery({
    queryKey: ["meta-forms", workspaceId],
    enabled: !!workspaceId,
    queryFn: () => listMetaForms({ data: { workspaceId: workspaceId! } }),
  });
  const { data: stages = [] } = useQuery({
    queryKey: ["pipeline-stages-meta", workspaceId],
    enabled: !!workspaceId,
    queryFn: async () => {
      const { data } = await supabase
        .from("pipeline_stages")
        .select("id, name")
        .eq("workspace_id", workspaceId!)
        .order("position");
      return data ?? [];
    },
  });
  const { data: members = [] } = useQuery({
    queryKey: ["workspace-members-meta", workspaceId],
    enabled: !!workspaceId,
    queryFn: async () => {
      const { data } = await supabase
        .from("workspace_members")
        .select("user_id, role, profiles:user_id(id, email, full_name)")
        .eq("workspace_id", workspaceId!);
      return (data ?? []) as any[];
    },
  });
  const { data: agents = [] } = useQuery({
    queryKey: ["lead-agents", workspaceId],
    enabled: !!workspaceId,
    queryFn: () => listLeadAgents({ data: { workspaceId: workspaceId! } }),
  });

  // Listen for popup post-message
  useEffect(() => {
    function onMsg(e: MessageEvent) {
      if (e.data?.type === "meta-lead-oauth") {
        if (e.data.ok) {
          toast.success("Facebook connected");
          qc.invalidateQueries({ queryKey: ["meta-connections"] });
        } else {
          toast.error("Facebook connection failed");
        }
      }
    }
    window.addEventListener("message", onMsg);
    return () => window.removeEventListener("message", onMsg);
  }, [qc]);

  async function connect() {
    if (!workspaceId) return;
    const popup = window.open("", "fb-oauth", "width=600,height=720");
    if (!popup) return toast.error("Popup blocked. Please allow popups and retry.");
    try {
      const { url } = await getUrl({ data: { workspaceId, redirectUri } });
      popup.location.href = url;
    } catch (e: any) {
      popup.close();
      toast.error(e.message ?? "Could not start OAuth");
    }
  }

  const syncPagesMu = useMutation({
    mutationFn: (connectionId: string) => sync({ data: { connectionId } }),
    onSuccess: (r: any) => {
      toast.success(`Synced ${r.count ?? 0} pages`);
      qc.invalidateQueries({ queryKey: ["meta-pages"] });
    },
    onError: (e: any) => toast.error(e.message),
  });
  const togglePageMu = useMutation({
    mutationFn: (v: { pageRowId: string; subscribed: boolean }) => togglePage({ data: v }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["meta-pages"] }),
    onError: (e: any) => toast.error(e.message),
  });
  const syncFormsMu = useMutation({
    mutationFn: (pageRowId: string) => syncForms({ data: { pageRowId } }),
    onSuccess: (r: any) => {
      toast.success(`Synced ${r.count ?? 0} forms`);
      qc.invalidateQueries({ queryKey: ["meta-forms"] });
    },
    onError: (e: any) => toast.error(e.message),
  });

  return (
    <Card className="p-6 space-y-5">
      <div className="flex items-start justify-between gap-4 flex-wrap">
        <div>
          <h3 className="font-display text-lg font-semibold flex items-center gap-2">
            <Facebook className="h-5 w-5 text-blue-600" /> Facebook Lead Ads — Direct Connection
          </h3>
          <p className="text-sm text-muted-foreground mt-1 max-w-2xl">
            Connect your Facebook account, pick the Pages and Forms you want, and assign each form to an agent, pipeline stage, and tags. No webhook setup needed.
          </p>
        </div>
        <div className="flex gap-2">
          <AgentsDialog workspaceId={workspaceId} agents={agents} />
          <Button onClick={connect} disabled={!workspaceId}>
            <Facebook className="h-4 w-4 mr-1.5" /> Connect Facebook
          </Button>
        </div>
      </div>

      {connections.length === 0 && (
        <div className="text-center text-sm text-muted-foreground py-8 border rounded-lg">
          No Facebook accounts connected yet.
        </div>
      )}

      {connections.map((c: any) => (
        <div key={c.id} className="border rounded-lg p-4 space-y-3">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <div className="flex items-center gap-2">
              <Facebook className="h-4 w-4 text-blue-600" />
              <span className="font-medium">{c.fb_user_name}</span>
              <Badge variant="secondary">FB ID {c.fb_user_id}</Badge>
            </div>
            <div className="flex gap-2">
              <Button size="sm" variant="outline" onClick={() => syncPagesMu.mutate(c.id)} disabled={syncPagesMu.isPending}>
                {syncPagesMu.isPending ? <Loader2 className="h-4 w-4 animate-spin mr-1" /> : <RefreshCw className="h-4 w-4 mr-1" />}
                Sync pages
              </Button>
              <Button size="sm" variant="ghost" onClick={async () => {
                if (!confirm("Disconnect this Facebook account?")) return;
                await disconnect({ data: { connectionId: c.id } });
                qc.invalidateQueries({ queryKey: ["meta-connections"] });
                qc.invalidateQueries({ queryKey: ["meta-pages"] });
                qc.invalidateQueries({ queryKey: ["meta-forms"] });
              }}>
                <Trash2 className="h-4 w-4 text-destructive" />
              </Button>
            </div>
          </div>
        </div>
      ))}

      {pages.length > 0 && (
        <div className="space-y-3">
          <h4 className="font-medium text-sm">Pages</h4>
          {pages.map((p: any) => {
            const pageForms = forms.filter((f: any) => f.page_id === p.page_id);
            return (
              <div key={p.id} className="border rounded-lg p-4 space-y-3">
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <div>
                    <div className="font-medium">{p.page_name}</div>
                    <div className="text-xs text-muted-foreground">{p.category || "Page"}</div>
                  </div>
                  <div className="flex items-center gap-3">
                    <label className="flex items-center gap-2 text-sm">
                      <Switch
                        checked={p.subscribed}
                        onCheckedChange={(v) => togglePageMu.mutate({ pageRowId: p.id, subscribed: v })}
                      />
                      <span>{p.subscribed ? "Receiving leads" : "Not receiving"}</span>
                    </label>
                    <Button size="sm" variant="outline" onClick={() => syncFormsMu.mutate(p.id)} disabled={syncFormsMu.isPending}>
                      <RefreshCw className="h-4 w-4 mr-1" /> Sync forms
                    </Button>
                  </div>
                </div>

                {pageForms.length > 0 && (
                  <div className="space-y-2 mt-2">
                    {pageForms.map((f: any) => (
                      <FormRoutingRow
                        key={f.id}
                        form={f}
                        stages={stages}
                        members={members}
                        agents={agents}
                        onSave={async (patch) => {
                          await updateForm({ data: { formRowId: f.id, ...patch } });
                          qc.invalidateQueries({ queryKey: ["meta-forms"] });
                          toast.success("Routing saved");
                        }}
                      />
                    ))}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      <PabblyConnectSection workspaceId={workspaceId} />
    </Card>
  );
}

function PabblyConnectSection({ workspaceId }: { workspaceId: string | null }) {
  const qc = useQueryClient();
  const origin = typeof window !== "undefined" ? window.location.origin : "";
  const [guideOpen, setGuideOpen] = useState(false);

  const { data: tokens = [] } = useQuery({
    queryKey: ["pabbly-intake-tokens", workspaceId],
    enabled: !!workspaceId,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("lead_intake_tokens")
        .select("*")
        .eq("workspace_id", workspaceId!)
        .eq("provider", "meta")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data ?? [];
    },
  });

  const token = tokens[0];
  const webhookUrl = token ? `${origin}/api/public/leads/meta/${token.token}` : "";

  async function provision() {
    if (!workspaceId) return;
    const a = new Uint8Array(24);
    crypto.getRandomValues(a);
    const tok = Array.from(a).map((b) => b.toString(16).padStart(2, "0")).join("");
    const { error } = await supabase.from("lead_intake_tokens").insert({
      workspace_id: workspaceId,
      provider: "meta",
      token: tok,
      enabled: true,
    });
    if (error) return toast.error(error.message);
    toast.success("Pabbly Connect webhook created");
    qc.invalidateQueries({ queryKey: ["pabbly-intake-tokens"] });
  }

  function copy(s: string) {
    navigator.clipboard.writeText(s);
    toast.success("Copied");
  }

  return (
    <div className="border rounded-lg p-4 space-y-3 bg-muted/20">
      <div className="flex items-start justify-between gap-3 flex-wrap">
        <div className="flex items-start gap-3">
          <div className="h-10 w-10 rounded-lg bg-orange-100 dark:bg-orange-950 flex items-center justify-center shrink-0">
            <Zap className="h-5 w-5 text-orange-600" />
          </div>
          <div>
            <h4 className="font-medium flex items-center gap-2">
              Meta Lead Ads via Pabbly Connect
              <Badge variant="secondary" className="text-[10px]">Alternative</Badge>
            </h4>
            <p className="text-xs text-muted-foreground mt-0.5 max-w-xl">
              No Facebook App review needed. Connect Facebook inside Pabbly, then forward leads to this CRM via a webhook URL.
            </p>
          </div>
        </div>
        <div className="flex gap-2">
          <Button size="sm" variant="outline" onClick={() => setGuideOpen(true)}>
            <BookOpen className="h-4 w-4 mr-1.5" /> Setup guide
          </Button>
          {!token && (
            <Button size="sm" onClick={provision} disabled={!workspaceId}>
              <Plus className="h-4 w-4 mr-1.5" /> Generate webhook URL
            </Button>
          )}
        </div>
      </div>

      {token && (
        <div className="space-y-2">
          <Label className="text-xs">Webhook URL (paste into Pabbly Connect "Webhooks by Pabbly" action)</Label>
          <div className="flex gap-2">
            <Input readOnly value={webhookUrl} className="font-mono text-xs" />
            <Button size="sm" variant="outline" onClick={() => copy(webhookUrl)}>
              <Copy className="h-4 w-4" />
            </Button>
          </div>
          <p className="text-[11px] text-muted-foreground">
            Send POST with JSON body containing <code className="font-mono">name</code>, <code className="font-mono">phone</code>, <code className="font-mono">email</code>, optional <code className="font-mono">message</code>, <code className="font-mono">source</code>, <code className="font-mono">form_name</code>.
          </p>
        </div>
      )}

      <Dialog open={guideOpen} onOpenChange={setGuideOpen}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Zap className="h-5 w-5 text-orange-600" />
              Connect Meta Lead Ads via Pabbly Connect
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 text-sm">
            <p className="text-muted-foreground">
              Use this when you don't have Facebook App review approved, or want a no-code workflow. Pabbly Connect listens to Meta Lead Ads in real time and forwards each lead to your CRM.
            </p>

            <ol className="space-y-3 list-decimal pl-5">
              <li>
                <strong>Create a Pabbly Connect account</strong> at{" "}
                <a href="https://www.pabbly.com/connect/" target="_blank" rel="noreferrer" className="text-primary underline inline-flex items-center gap-1">
                  pabbly.com/connect <ExternalLink className="h-3 w-3" />
                </a>
                {" "}and log in.
              </li>
              <li>
                Click <strong>Create Workflow</strong>. Name it e.g. "Meta Lead Ads → CRM".
              </li>
              <li>
                <strong>Trigger:</strong> Choose app <em>Facebook Lead Ads</em>, event <em>New Lead</em>. Click <em>Connect</em> and sign in with the Facebook account that owns the Page.
              </li>
              <li>
                Select the <strong>Page</strong> and <strong>Lead Form</strong> you want to forward. Click <em>Save &amp; Send Test Request</em> and submit a test lead from Facebook's Lead Ads Testing Tool to capture sample fields.
              </li>
              <li>
                <strong>Action:</strong> Choose app <em>Webhooks by Pabbly</em>, event <em>POST</em>.
              </li>
              <li>
                Generate your webhook URL above (button "Generate webhook URL") and paste it into the Pabbly action's <strong>URL</strong> field.
              </li>
              <li>
                Set <strong>Payload Type</strong> to <em>JSON</em> and add parameters. For each row, type the
                <strong> Parameter Label</strong> exactly as shown, then click inside the
                <strong> Parameter Value</strong> box and press <kbd className="px-1 border rounded">/</kbd> to open
                the Facebook trigger field picker and <strong>select the mapped field</strong> (do NOT type the
                field name as plain text):
                <div className="mt-2 rounded border bg-muted/50 p-3 font-mono text-xs space-y-1">
                  <div>name → <span className="text-muted-foreground">/ → Facebook Lead Ads → Full Name</span></div>
                  <div>phone → <span className="text-muted-foreground">/ → Facebook Lead Ads → Phone Number</span></div>
                  <div>email → <span className="text-muted-foreground">/ → Facebook Lead Ads → Email</span></div>
                  <div>form_name → <span className="text-muted-foreground">/ → Facebook Lead Ads → Form Name</span></div>
                  <div>source → <span className="text-muted-foreground">pabbly-meta-leads (static text is OK here)</span></div>
                </div>
                <div className="mt-2 rounded-lg border border-amber-300 dark:border-amber-800 bg-amber-50 dark:bg-amber-950/40 p-3 text-xs">
                  ⚠️ <strong>Common mistake:</strong> If the Value box shows the plain text
                  <code className="font-mono mx-1">full_name</code> / <code className="font-mono">phone_number</code>
                  / <code className="font-mono">email</code> instead of a coloured pill from the picker, the literal
                  string will be sent and your leads will show "full_name" as the name. Delete the text, press
                  <kbd className="px-1 border rounded mx-1">/</kbd> and pick the field from the Facebook trigger.
                </div>
              </li>
              <li>
                Click <strong>Save &amp; Send Test Request</strong>. You should see a <code className="font-mono">200 OK</code> with <code className="font-mono">{`{ ok: true }`}</code>. The test lead now appears in your CRM Contacts & Pipeline with the real name / phone / email.
              </li>
              <li>
                Turn the workflow <strong>ON</strong> at the top right. Done — every new Facebook lead flows in within seconds.
              </li>
            </ol>

            <div className="rounded-lg border border-blue-200 dark:border-blue-900 bg-blue-50 dark:bg-blue-950/40 p-3 text-xs">
              <strong>Tip:</strong> You can create one workflow per Lead Form, or use Pabbly's Router step to route different forms to different sources/tags using the same webhook URL.
            </div>

          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setGuideOpen(false)}>Close</Button>
            <Button asChild>
              <a href="https://www.pabbly.com/connect/integrations/facebook-lead-ads/" target="_blank" rel="noreferrer">
                Open Pabbly Connect <ExternalLink className="h-4 w-4 ml-1.5" />
              </a>
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}


function FormRoutingRow({
  form, stages, members, agents, onSave,
}: {
  form: any;
  stages: any[];
  members: any[];
  agents: any[];
  onSave: (patch: any) => Promise<void>;
}) {
  const [open, setOpen] = useState(false);
  const [userId, setUserId] = useState<string>(form.assigned_user_id ?? "");
  const [agentId, setAgentId] = useState<string>(form.assigned_agent_id ?? "");
  const [label, setLabel] = useState<string>(form.assigned_agent_label ?? "");
  const [stageId, setStageId] = useState<string>(form.default_stage_id ?? "");
  const [tagsCsv, setTagsCsv] = useState<string>(
    Array.isArray(form.default_tags) ? form.default_tags.join(", ") : "",
  );
  const [enabled, setEnabled] = useState<boolean>(form.enabled !== false);

  const assigneeName = form.assigned_user_id
    ? members.find((m: any) => m.user_id === form.assigned_user_id)?.profiles?.full_name ?? "Team member"
    : form.assigned_agent_id
      ? agents.find((a: any) => a.id === form.assigned_agent_id)?.name ?? "Agent"
      : form.assigned_agent_label || "Unassigned";

  return (
    <div className="flex items-center justify-between gap-3 rounded border bg-muted/30 px-3 py-2 flex-wrap">
      <div className="flex items-center gap-2 min-w-0">
        <Switch
          checked={enabled}
          onCheckedChange={async (v) => {
            setEnabled(v);
            await onSave({ enabled: v });
          }}
        />
        <div className="min-w-0">
          <div className="text-sm font-medium truncate">{form.form_name}</div>
          <div className="text-xs text-muted-foreground flex items-center gap-2 flex-wrap">
            <Badge variant="outline" className="text-[10px]">{form.status || "Active"}</Badge>
            <span>→ {assigneeName}</span>
            {form.last_lead_at && <span>· Last lead {new Date(form.last_lead_at).toLocaleDateString()}</span>}
          </div>
        </div>
      </div>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogTrigger asChild>
          <Button size="sm" variant="outline"><Settings2 className="h-4 w-4 mr-1" /> Routing</Button>
        </DialogTrigger>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Route leads from "{form.form_name}"</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Assign to team member</Label>
              <Select value={userId || "none"} onValueChange={(v) => { setUserId(v === "none" ? "" : v); setAgentId(""); setLabel(""); }}>
                <SelectTrigger><SelectValue placeholder="Pick a member" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">— None —</SelectItem>
                  {members.map((m: any) => (
                    <SelectItem key={m.user_id} value={m.user_id}>
                      {m.profiles?.full_name || m.profiles?.email} · {m.role}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Or assign to custom agent</Label>
              <Select value={agentId || "none"} onValueChange={(v) => { setAgentId(v === "none" ? "" : v); setUserId(""); setLabel(""); }}>
                <SelectTrigger><SelectValue placeholder="Pick an agent" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">— None —</SelectItem>
                  {agents.map((a: any) => (
                    <SelectItem key={a.id} value={a.id}>{a.name}{a.email ? ` · ${a.email}` : ""}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Or label / tracking parameter</Label>
              <Input value={label} placeholder="e.g. north-region, Anita" onChange={(e) => { setLabel(e.target.value); setUserId(""); setAgentId(""); }} />
            </div>
            <div className="space-y-2">
              <Label>Land in pipeline stage</Label>
              <Select value={stageId || "first"} onValueChange={(v) => setStageId(v === "first" ? "" : v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="first">First stage (default)</SelectItem>
                  {stages.map((s: any) => (
                    <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Default tags (comma separated)</Label>
              <Input value={tagsCsv} placeholder="hot, mumbai, summer-2026" onChange={(e) => setTagsCsv(e.target.value)} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button onClick={async () => {
              await onSave({
                assigned_user_id: userId || null,
                assigned_agent_id: agentId || null,
                assigned_agent_label: label || null,
                default_stage_id: stageId || null,
                default_tags: tagsCsv.split(",").map((t) => t.trim()).filter(Boolean),
              });
              setOpen(false);
            }}>Save</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function AgentsDialog({ workspaceId, agents }: { workspaceId: string | null; agents: any[] }) {
  const qc = useQueryClient();
  const upsert = useServerFn(upsertLeadAgent);
  const del = useServerFn(deleteLeadAgent);
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline"><Users className="h-4 w-4 mr-1.5" />Agents ({agents.length})</Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader><DialogTitle>Lead agents</DialogTitle></DialogHeader>
        <div className="space-y-2">
          {agents.map((a: any) => (
            <div key={a.id} className="flex items-center justify-between rounded border p-2 text-sm">
              <div>
                <div className="font-medium">{a.name}</div>
                <div className="text-xs text-muted-foreground">{a.email || a.phone || "—"}</div>
              </div>
              <Button size="sm" variant="ghost" onClick={async () => {
                await del({ data: { id: a.id } });
                qc.invalidateQueries({ queryKey: ["lead-agents"] });
              }}>
                <Trash2 className="h-4 w-4 text-destructive" />
              </Button>
            </div>
          ))}
          <div className="border rounded p-3 space-y-2">
            <div className="text-xs font-medium">Add new agent</div>
            <Input placeholder="Name" value={name} onChange={(e) => setName(e.target.value)} />
            <Input placeholder="Email (optional)" value={email} onChange={(e) => setEmail(e.target.value)} />
            <Input placeholder="Phone (optional)" value={phone} onChange={(e) => setPhone(e.target.value)} />
            <Button size="sm" disabled={!name || !workspaceId} onClick={async () => {
              await upsert({ data: { workspaceId: workspaceId!, name, email, phone } });
              setName(""); setEmail(""); setPhone("");
              qc.invalidateQueries({ queryKey: ["lead-agents"] });
            }}>
              <Plus className="h-4 w-4 mr-1" /> Add
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
