// Inline "How to create an Abandoned Cart template" guide.
//
// Most Meta-template rejections we see are because merchants:
//   * pick the wrong category (Marketing instead of Utility, or vice-versa)
//   * write a button URL with the {{1}} variable in the middle of the path
//     instead of at the end (Meta only allows the variable at the tail)
//   * forget to provide a sample value for the URL button so the template
//     reviewer can't open it
//
// This dialog walks them through a working setup that matches the Slice
// recovery short link (https://slice.dotscube.com/r/{{1}}).
import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { BookOpen, Copy, Check } from "lucide-react";
import { toast } from "sonner";

const SAMPLE_BODY = `Hi {{1}}, ✨
The item you loved is still waiting for you at {{2}} 💖
🛍 Product: {{3}}
Complete your order today and bring home timeless elegance crafted just for you.
Don't miss out on your favorite style 🌸`;

const SAMPLE_FOOTER = `Reply STOP to unsubscribe`;

const BUTTON_URL_BASE = "https://slice.dotscube.com/r/";

function CopyRow({ value, label }: { value: string; label?: string }) {
  const [done, setDone] = useState(false);
  return (
    <div className="flex items-center gap-2">
      <code className="flex-1 rounded bg-muted px-2 py-1 text-xs break-all">{value}</code>
      <Button
        type="button"
        size="sm"
        variant="ghost"
        onClick={async () => {
          await navigator.clipboard.writeText(value);
          setDone(true);
          toast.success(`Copied${label ? ` ${label}` : ""}`);
          setTimeout(() => setDone(false), 1200);
        }}
      >
        {done ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
      </Button>
    </div>
  );
}

export function AbandonedCartTemplateGuide() {
  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="outline">
          <BookOpen className="mr-2 h-4 w-4" />
          Abandoned cart guide
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Create an Abandoned Cart template</DialogTitle>
          <DialogDescription>
            Follow these steps to get a Meta-approved template that works with Slice's
            "Complete Purchase" recovery short link.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-5 text-sm">
          <section>
            <h3 className="font-semibold mb-1">1. Category</h3>
            <p className="text-muted-foreground">
              Choose <span className="font-medium text-foreground">Marketing → Custom</span>.
              Abandoned-cart reminders are promotional, so Meta requires the Marketing category.
              Templates submitted as Utility are rejected.
            </p>
          </section>

          <section>
            <h3 className="font-semibold mb-1">2. Name & language</h3>
            <p className="text-muted-foreground">
              Use a snake_case name like{" "}
              <code className="rounded bg-muted px-1 py-0.5 text-xs">abandoned_cart_reminder</code>.
              Language is usually <span className="font-medium text-foreground">English (en)</span>
              {" "}or your store's primary language.
            </p>
          </section>

          <section>
            <h3 className="font-semibold mb-1">3. Body text</h3>
            <p className="text-muted-foreground mb-2">
              Use <code className="rounded bg-muted px-1 py-0.5 text-xs">{`{{1}}`}</code>,
              {" "}<code className="rounded bg-muted px-1 py-0.5 text-xs">{`{{2}}`}</code>,
              {" "}<code className="rounded bg-muted px-1 py-0.5 text-xs">{`{{3}}`}</code> for
              dynamic values. Slice will auto-detect what goes where based on the surrounding words.
            </p>
            <CopyRow value={SAMPLE_BODY} label="body" />
            <div className="mt-2 rounded border bg-muted/40 p-2 text-xs">
              <div><span className="font-medium">{`{{1}}`}</span> → Customer Name</div>
              <div><span className="font-medium">{`{{2}}`}</span> → Store Name</div>
              <div><span className="font-medium">{`{{3}}`}</span> → Product Name</div>
            </div>
          </section>

          <section>
            <h3 className="font-semibold mb-1">4. Footer (optional but recommended)</h3>
            <CopyRow value={SAMPLE_FOOTER} label="footer" />
            <p className="text-muted-foreground text-xs mt-1">
              Marketing templates with an opt-out footer are approved faster.
            </p>
          </section>

          <section>
            <h3 className="font-semibold mb-1">5. "Complete Purchase" URL button</h3>
            <p className="text-muted-foreground mb-2">
              Add a <span className="font-medium text-foreground">Dynamic URL</span> button with
              the label <span className="font-medium text-foreground">Complete Purchase</span>.
              The URL must end with <code className="rounded bg-muted px-1 py-0.5 text-xs">{`{{1}}`}</code>:
            </p>
            <CopyRow value={`${BUTTON_URL_BASE}{{1}}`} label="button URL" />
            <p className="text-muted-foreground text-xs mt-2">
              For the <span className="font-medium">sample value</span> Meta asks for, paste:
            </p>
            <div className="mt-1">
              <CopyRow value={`${BUTTON_URL_BASE}sample-token-xyz`} label="sample URL" />
            </div>
            <p className="text-muted-foreground text-xs mt-2">
              Slice automatically fills <code className="rounded bg-muted px-1 py-0.5 text-xs">{`{{1}}`}</code>
              {" "}with the recovery token at send time. Clicks open
              {" "}<code className="rounded bg-muted px-1 py-0.5 text-xs">{BUTTON_URL_BASE}&lt;token&gt;</code>,
              which redirects the customer back to their exact cart and tracks the click for analytics.
            </p>
          </section>

          <section>
            <h3 className="font-semibold mb-1">6. After approval</h3>
            <ul className="text-muted-foreground list-disc pl-5 space-y-1">
              <li>Click <span className="font-medium text-foreground">Sync from Meta</span> on this page.</li>
              <li>If the warning <span className="font-medium text-foreground">"Fields not mapped"</span> appears,
                  click <span className="font-medium text-foreground">Auto-map all</span> — Slice will guess
                  the right field per variable.</li>
              <li>Open <span className="font-medium text-foreground">Automations → Abandoned cart</span>{" "}
                  and select this template. It will fire automatically from the WooCommerce/Shopify webhook.</li>
            </ul>
          </section>

          <section className="rounded border border-amber-200 bg-amber-50 p-3 text-xs dark:border-amber-900/50 dark:bg-amber-950/30">
            <p className="font-medium text-amber-900 dark:text-amber-100">Common rejection reasons</p>
            <ul className="mt-1 list-disc pl-5 text-amber-900/90 dark:text-amber-100/90 space-y-0.5">
              <li>Variable placed in the middle of the URL — Meta only allows it at the end.</li>
              <li>Promotional copy submitted as Utility category.</li>
              <li>No sample value for the button — Meta reviewers can't test it.</li>
              <li>Emojis or excessive punctuation in the template name.</li>
            </ul>
          </section>
        </div>
      </DialogContent>
    </Dialog>
  );
}
