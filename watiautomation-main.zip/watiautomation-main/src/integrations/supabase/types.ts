export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      abandoned_cart_reminder_locks: {
        Row: {
          created_at: string
          id: string
          last_cart_id: string | null
          last_cart_token: string | null
          phone_key: string
          prev_sent_at: string | null
          send_count: number
          sent_at: string
          updated_at: string
          workspace_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          last_cart_id?: string | null
          last_cart_token?: string | null
          phone_key: string
          prev_sent_at?: string | null
          send_count?: number
          sent_at?: string
          updated_at?: string
          workspace_id: string
        }
        Update: {
          created_at?: string
          id?: string
          last_cart_id?: string | null
          last_cart_token?: string | null
          phone_key?: string
          prev_sent_at?: string | null
          send_count?: number
          sent_at?: string
          updated_at?: string
          workspace_id?: string
        }
        Relationships: []
      }
      abandoned_carts: {
        Row: {
          abandoned_at: string
          cart_token: string | null
          checkout_url: string | null
          click_count: number
          clicked_at: string | null
          contact_id: string | null
          created_at: string
          currency: string
          customer_email: string | null
          customer_name: string | null
          customer_phone: string | null
          external_id: string | null
          id: string
          integration_id: string | null
          items: Json
          last_reminder_at: string | null
          provider: string | null
          provider_recovery_url: string | null
          recovered_at: string | null
          recovered_revenue: number
          recovery_expires_at: string | null
          recovery_token: string | null
          recovery_url: string | null
          reminders_sent: number
          send_scheduled_at: string | null
          status: string
          total: number
          updated_at: string
          workspace_id: string
        }
        Insert: {
          abandoned_at?: string
          cart_token?: string | null
          checkout_url?: string | null
          click_count?: number
          clicked_at?: string | null
          contact_id?: string | null
          created_at?: string
          currency?: string
          customer_email?: string | null
          customer_name?: string | null
          customer_phone?: string | null
          external_id?: string | null
          id?: string
          integration_id?: string | null
          items?: Json
          last_reminder_at?: string | null
          provider?: string | null
          provider_recovery_url?: string | null
          recovered_at?: string | null
          recovered_revenue?: number
          recovery_expires_at?: string | null
          recovery_token?: string | null
          recovery_url?: string | null
          reminders_sent?: number
          send_scheduled_at?: string | null
          status?: string
          total?: number
          updated_at?: string
          workspace_id: string
        }
        Update: {
          abandoned_at?: string
          cart_token?: string | null
          checkout_url?: string | null
          click_count?: number
          clicked_at?: string | null
          contact_id?: string | null
          created_at?: string
          currency?: string
          customer_email?: string | null
          customer_name?: string | null
          customer_phone?: string | null
          external_id?: string | null
          id?: string
          integration_id?: string | null
          items?: Json
          last_reminder_at?: string | null
          provider?: string | null
          provider_recovery_url?: string | null
          recovered_at?: string | null
          recovered_revenue?: number
          recovery_expires_at?: string | null
          recovery_token?: string | null
          recovery_url?: string | null
          reminders_sent?: number
          send_scheduled_at?: string | null
          status?: string
          total?: number
          updated_at?: string
          workspace_id?: string
        }
        Relationships: []
      }
      ai_assistant_settings: {
        Row: {
          business_hours_end: number
          business_hours_start: number
          created_at: string
          enabled: boolean
          language_preference: string
          max_followups_per_contact: number
          min_hours_between_followups: number
          model: string
          openai_api_key: string | null
          pause_on_human_reply: boolean
          system_prompt: string
          timezone: string
          tone: string
          updated_at: string
          workspace_id: string
        }
        Insert: {
          business_hours_end?: number
          business_hours_start?: number
          created_at?: string
          enabled?: boolean
          language_preference?: string
          max_followups_per_contact?: number
          min_hours_between_followups?: number
          model?: string
          openai_api_key?: string | null
          pause_on_human_reply?: boolean
          system_prompt?: string
          timezone?: string
          tone?: string
          updated_at?: string
          workspace_id: string
        }
        Update: {
          business_hours_end?: number
          business_hours_start?: number
          created_at?: string
          enabled?: boolean
          language_preference?: string
          max_followups_per_contact?: number
          min_hours_between_followups?: number
          model?: string
          openai_api_key?: string | null
          pause_on_human_reply?: boolean
          system_prompt?: string
          timezone?: string
          tone?: string
          updated_at?: string
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "ai_assistant_settings_workspace_id_fkey"
            columns: ["workspace_id"]
            isOneToOne: true
            referencedRelation: "workspaces"
            referencedColumns: ["id"]
          },
        ]
      }
      ai_credit_accounts: {
        Row: {
          balance: number
          created_at: string
          lifetime_added: number
          lifetime_used: number
          low_threshold: number
          updated_at: string
          workspace_id: string
        }
        Insert: {
          balance?: number
          created_at?: string
          lifetime_added?: number
          lifetime_used?: number
          low_threshold?: number
          updated_at?: string
          workspace_id: string
        }
        Update: {
          balance?: number
          created_at?: string
          lifetime_added?: number
          lifetime_used?: number
          low_threshold?: number
          updated_at?: string
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "ai_credit_accounts_workspace_id_fkey"
            columns: ["workspace_id"]
            isOneToOne: true
            referencedRelation: "workspaces"
            referencedColumns: ["id"]
          },
        ]
      }
      ai_credit_ledger: {
        Row: {
          actor_user_id: string | null
          balance_after: number
          created_at: string
          delta: number
          entry_type: string
          feature: string | null
          id: string
          meta: Json
          model: string | null
          notes: string | null
          workspace_id: string
        }
        Insert: {
          actor_user_id?: string | null
          balance_after: number
          created_at?: string
          delta: number
          entry_type: string
          feature?: string | null
          id?: string
          meta?: Json
          model?: string | null
          notes?: string | null
          workspace_id: string
        }
        Update: {
          actor_user_id?: string | null
          balance_after?: number
          created_at?: string
          delta?: number
          entry_type?: string
          feature?: string | null
          id?: string
          meta?: Json
          model?: string | null
          notes?: string | null
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "ai_credit_ledger_workspace_id_fkey"
            columns: ["workspace_id"]
            isOneToOne: false
            referencedRelation: "workspaces"
            referencedColumns: ["id"]
          },
        ]
      }
      ai_credit_packages: {
        Row: {
          bonus_credits: number
          created_at: string
          credits: number
          currency: string
          description: string | null
          gateway_ids: string[]
          id: string
          is_active: boolean
          is_featured: boolean
          name: string
          price: number
          sort_order: number
          updated_at: string
        }
        Insert: {
          bonus_credits?: number
          created_at?: string
          credits: number
          currency?: string
          description?: string | null
          gateway_ids?: string[]
          id?: string
          is_active?: boolean
          is_featured?: boolean
          name: string
          price: number
          sort_order?: number
          updated_at?: string
        }
        Update: {
          bonus_credits?: number
          created_at?: string
          credits?: number
          currency?: string
          description?: string | null
          gateway_ids?: string[]
          id?: string
          is_active?: boolean
          is_featured?: boolean
          name?: string
          price?: number
          sort_order?: number
          updated_at?: string
        }
        Relationships: []
      }
      ai_message_analyses: {
        Row: {
          confidence: number | null
          contact_id: string | null
          conversation_id: string
          conversion_probability: number | null
          created_at: string
          direction: string
          follow_up_id: string | null
          id: string
          intent: string | null
          language: string | null
          lead_stage: string | null
          message_id: string | null
          objections: string[]
          raw: Json
          reasoning: string | null
          recommended_action: string | null
          sentiment: string | null
          urgency: string | null
          workspace_id: string
        }
        Insert: {
          confidence?: number | null
          contact_id?: string | null
          conversation_id: string
          conversion_probability?: number | null
          created_at?: string
          direction: string
          follow_up_id?: string | null
          id?: string
          intent?: string | null
          language?: string | null
          lead_stage?: string | null
          message_id?: string | null
          objections?: string[]
          raw?: Json
          reasoning?: string | null
          recommended_action?: string | null
          sentiment?: string | null
          urgency?: string | null
          workspace_id: string
        }
        Update: {
          confidence?: number | null
          contact_id?: string | null
          conversation_id?: string
          conversion_probability?: number | null
          created_at?: string
          direction?: string
          follow_up_id?: string | null
          id?: string
          intent?: string | null
          language?: string | null
          lead_stage?: string | null
          message_id?: string | null
          objections?: string[]
          raw?: Json
          reasoning?: string | null
          recommended_action?: string | null
          sentiment?: string | null
          urgency?: string | null
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "ai_message_analyses_contact_id_fkey"
            columns: ["contact_id"]
            isOneToOne: false
            referencedRelation: "contacts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ai_message_analyses_conversation_id_fkey"
            columns: ["conversation_id"]
            isOneToOne: false
            referencedRelation: "conversations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ai_message_analyses_follow_up_id_fkey"
            columns: ["follow_up_id"]
            isOneToOne: false
            referencedRelation: "follow_ups"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ai_message_analyses_workspace_id_fkey"
            columns: ["workspace_id"]
            isOneToOne: false
            referencedRelation: "workspaces"
            referencedColumns: ["id"]
          },
        ]
      }
      automations: {
        Row: {
          assign_to: string | null
          away_days: number[]
          away_end: string | null
          away_start: string | null
          created_at: string
          enabled: boolean
          id: string
          keywords: string[]
          match_type: string
          name: string
          priority: number
          reply_text: string | null
          template_id: string | null
          type: Database["public"]["Enums"]["automation_type"]
          updated_at: string
          user_id: string
          workspace_id: string
        }
        Insert: {
          assign_to?: string | null
          away_days?: number[]
          away_end?: string | null
          away_start?: string | null
          created_at?: string
          enabled?: boolean
          id?: string
          keywords?: string[]
          match_type?: string
          name: string
          priority?: number
          reply_text?: string | null
          template_id?: string | null
          type: Database["public"]["Enums"]["automation_type"]
          updated_at?: string
          user_id: string
          workspace_id: string
        }
        Update: {
          assign_to?: string | null
          away_days?: number[]
          away_end?: string | null
          away_start?: string | null
          created_at?: string
          enabled?: boolean
          id?: string
          keywords?: string[]
          match_type?: string
          name?: string
          priority?: number
          reply_text?: string | null
          template_id?: string | null
          type?: Database["public"]["Enums"]["automation_type"]
          updated_at?: string
          user_id?: string
          workspace_id?: string
        }
        Relationships: []
      }
      bot_edges: {
        Row: {
          bot_id: string
          created_at: string
          id: string
          source_handle: string | null
          source_node_id: string
          target_node_id: string
          workspace_id: string
        }
        Insert: {
          bot_id: string
          created_at?: string
          id?: string
          source_handle?: string | null
          source_node_id: string
          target_node_id: string
          workspace_id: string
        }
        Update: {
          bot_id?: string
          created_at?: string
          id?: string
          source_handle?: string | null
          source_node_id?: string
          target_node_id?: string
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "bot_edges_bot_id_fkey"
            columns: ["bot_id"]
            isOneToOne: false
            referencedRelation: "bots"
            referencedColumns: ["id"]
          },
        ]
      }
      bot_nodes: {
        Row: {
          bot_id: string
          created_at: string
          data: Json
          id: string
          position: Json
          type: string
          workspace_id: string
        }
        Insert: {
          bot_id: string
          created_at?: string
          data?: Json
          id?: string
          position?: Json
          type: string
          workspace_id: string
        }
        Update: {
          bot_id?: string
          created_at?: string
          data?: Json
          id?: string
          position?: Json
          type?: string
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "bot_nodes_bot_id_fkey"
            columns: ["bot_id"]
            isOneToOne: false
            referencedRelation: "bots"
            referencedColumns: ["id"]
          },
        ]
      }
      bot_runs: {
        Row: {
          bot_id: string
          created_at: string
          detail: Json
          event: string
          id: string
          node_id: string | null
          node_type: string | null
          session_id: string | null
          workspace_id: string
        }
        Insert: {
          bot_id: string
          created_at?: string
          detail?: Json
          event: string
          id?: string
          node_id?: string | null
          node_type?: string | null
          session_id?: string | null
          workspace_id: string
        }
        Update: {
          bot_id?: string
          created_at?: string
          detail?: Json
          event?: string
          id?: string
          node_id?: string | null
          node_type?: string | null
          session_id?: string | null
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "bot_runs_bot_id_fkey"
            columns: ["bot_id"]
            isOneToOne: false
            referencedRelation: "bots"
            referencedColumns: ["id"]
          },
        ]
      }
      bot_sessions: {
        Row: {
          awaiting_input: boolean
          bot_id: string
          contact_id: string | null
          contact_phone: string
          conversation_id: string | null
          created_at: string
          current_node_id: string | null
          id: string
          resume_at: string | null
          status: string
          updated_at: string
          variables: Json
          workspace_id: string
        }
        Insert: {
          awaiting_input?: boolean
          bot_id: string
          contact_id?: string | null
          contact_phone: string
          conversation_id?: string | null
          created_at?: string
          current_node_id?: string | null
          id?: string
          resume_at?: string | null
          status?: string
          updated_at?: string
          variables?: Json
          workspace_id: string
        }
        Update: {
          awaiting_input?: boolean
          bot_id?: string
          contact_id?: string | null
          contact_phone?: string
          conversation_id?: string | null
          created_at?: string
          current_node_id?: string | null
          id?: string
          resume_at?: string | null
          status?: string
          updated_at?: string
          variables?: Json
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "bot_sessions_bot_id_fkey"
            columns: ["bot_id"]
            isOneToOne: false
            referencedRelation: "bots"
            referencedColumns: ["id"]
          },
        ]
      }
      bots: {
        Row: {
          created_at: string
          created_by: string | null
          description: string | null
          enabled: boolean
          id: string
          name: string
          priority: number
          triggers: Json
          updated_at: string
          workspace_id: string
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          description?: string | null
          enabled?: boolean
          id?: string
          name: string
          priority?: number
          triggers?: Json
          updated_at?: string
          workspace_id: string
        }
        Update: {
          created_at?: string
          created_by?: string | null
          description?: string | null
          enabled?: boolean
          id?: string
          name?: string
          priority?: number
          triggers?: Json
          updated_at?: string
          workspace_id?: string
        }
        Relationships: []
      }
      browse_events: {
        Row: {
          category: string | null
          contact_id: string | null
          conversion_value_minor: number | null
          converted_at: string | null
          created_at: string
          currency: string | null
          dispatch_scheduled_at: string | null
          dispatched_at: string | null
          id: string
          phone: string | null
          phone_normalized: string | null
          price_minor: number | null
          product_id: string
          product_image_url: string | null
          product_title: string | null
          product_url: string
          session_key: string | null
          skip_reason: string | null
          source: string | null
          viewed_at: string
          visitor_key: string | null
          wa_message_id: string | null
          workspace_id: string
        }
        Insert: {
          category?: string | null
          contact_id?: string | null
          conversion_value_minor?: number | null
          converted_at?: string | null
          created_at?: string
          currency?: string | null
          dispatch_scheduled_at?: string | null
          dispatched_at?: string | null
          id?: string
          phone?: string | null
          phone_normalized?: string | null
          price_minor?: number | null
          product_id: string
          product_image_url?: string | null
          product_title?: string | null
          product_url: string
          session_key?: string | null
          skip_reason?: string | null
          source?: string | null
          viewed_at?: string
          visitor_key?: string | null
          wa_message_id?: string | null
          workspace_id: string
        }
        Update: {
          category?: string | null
          contact_id?: string | null
          conversion_value_minor?: number | null
          converted_at?: string | null
          created_at?: string
          currency?: string | null
          dispatch_scheduled_at?: string | null
          dispatched_at?: string | null
          id?: string
          phone?: string | null
          phone_normalized?: string | null
          price_minor?: number | null
          product_id?: string
          product_image_url?: string | null
          product_title?: string | null
          product_url?: string
          session_key?: string | null
          skip_reason?: string | null
          source?: string | null
          viewed_at?: string
          visitor_key?: string | null
          wa_message_id?: string | null
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "browse_events_contact_id_fkey"
            columns: ["contact_id"]
            isOneToOne: false
            referencedRelation: "contacts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "browse_events_workspace_id_fkey"
            columns: ["workspace_id"]
            isOneToOne: false
            referencedRelation: "workspaces"
            referencedColumns: ["id"]
          },
        ]
      }
      browse_recovery_clicks: {
        Row: {
          browse_event_id: string
          clicked_at: string | null
          conversion_value_minor: number | null
          converted_at: string | null
          created_at: string
          id: string
          target_url: string
          token: string
          workspace_id: string
        }
        Insert: {
          browse_event_id: string
          clicked_at?: string | null
          conversion_value_minor?: number | null
          converted_at?: string | null
          created_at?: string
          id?: string
          target_url: string
          token: string
          workspace_id: string
        }
        Update: {
          browse_event_id?: string
          clicked_at?: string | null
          conversion_value_minor?: number | null
          converted_at?: string | null
          created_at?: string
          id?: string
          target_url?: string
          token?: string
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "browse_recovery_clicks_browse_event_id_fkey"
            columns: ["browse_event_id"]
            isOneToOne: false
            referencedRelation: "browse_events"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "browse_recovery_clicks_workspace_id_fkey"
            columns: ["workspace_id"]
            isOneToOne: false
            referencedRelation: "workspaces"
            referencedColumns: ["id"]
          },
        ]
      }
      browse_recovery_settings: {
        Row: {
          category_include: string[]
          created_at: string
          delay_minutes: number
          enabled: boolean
          frequency_cap_hours: number
          min_price_minor: number | null
          product_exclude: string[]
          product_include: string[]
          template_id: string | null
          template_language: string | null
          updated_at: string
          workspace_id: string
        }
        Insert: {
          category_include?: string[]
          created_at?: string
          delay_minutes?: number
          enabled?: boolean
          frequency_cap_hours?: number
          min_price_minor?: number | null
          product_exclude?: string[]
          product_include?: string[]
          template_id?: string | null
          template_language?: string | null
          updated_at?: string
          workspace_id: string
        }
        Update: {
          category_include?: string[]
          created_at?: string
          delay_minutes?: number
          enabled?: boolean
          frequency_cap_hours?: number
          min_price_minor?: number | null
          product_exclude?: string[]
          product_include?: string[]
          template_id?: string | null
          template_language?: string | null
          updated_at?: string
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "browse_recovery_settings_workspace_id_fkey"
            columns: ["workspace_id"]
            isOneToOne: true
            referencedRelation: "workspaces"
            referencedColumns: ["id"]
          },
        ]
      }
      browse_tracker_tokens: {
        Row: {
          created_at: string
          id: string
          label: string | null
          last_used_at: string | null
          token: string
          workspace_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          label?: string | null
          last_used_at?: string | null
          token: string
          workspace_id: string
        }
        Update: {
          created_at?: string
          id?: string
          label?: string | null
          last_used_at?: string | null
          token?: string
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "browse_tracker_tokens_workspace_id_fkey"
            columns: ["workspace_id"]
            isOneToOne: false
            referencedRelation: "workspaces"
            referencedColumns: ["id"]
          },
        ]
      }
      campaign_recipients: {
        Row: {
          attempts: number
          campaign_id: string
          contact_id: string | null
          delivered_at: string | null
          error: string | null
          http_status: number | null
          id: string
          last_attempt_at: string | null
          message_id: string | null
          meta_code: number | null
          meta_subcode: number | null
          name: string | null
          next_retry_at: string | null
          phone: string
          read_at: string | null
          retry_count: number
          sent_at: string | null
          status: string
          user_id: string
          workspace_id: string
        }
        Insert: {
          attempts?: number
          campaign_id: string
          contact_id?: string | null
          delivered_at?: string | null
          error?: string | null
          http_status?: number | null
          id?: string
          last_attempt_at?: string | null
          message_id?: string | null
          meta_code?: number | null
          meta_subcode?: number | null
          name?: string | null
          next_retry_at?: string | null
          phone: string
          read_at?: string | null
          retry_count?: number
          sent_at?: string | null
          status?: string
          user_id: string
          workspace_id: string
        }
        Update: {
          attempts?: number
          campaign_id?: string
          contact_id?: string | null
          delivered_at?: string | null
          error?: string | null
          http_status?: number | null
          id?: string
          last_attempt_at?: string | null
          message_id?: string | null
          meta_code?: number | null
          meta_subcode?: number | null
          name?: string | null
          next_retry_at?: string | null
          phone?: string
          read_at?: string | null
          retry_count?: number
          sent_at?: string | null
          status?: string
          user_id?: string
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "campaign_recipients_campaign_id_fkey"
            columns: ["campaign_id"]
            isOneToOne: false
            referencedRelation: "campaigns"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "campaign_recipients_contact_id_fkey"
            columns: ["contact_id"]
            isOneToOne: false
            referencedRelation: "contacts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "campaign_recipients_workspace_id_fkey"
            columns: ["workspace_id"]
            isOneToOne: false
            referencedRelation: "workspaces"
            referencedColumns: ["id"]
          },
        ]
      }
      campaigns: {
        Row: {
          completed_at: string | null
          created_at: string
          delivered_count: number
          failed_count: number
          header_media_url: string | null
          id: string
          name: string
          read_count: number
          scheduled_at: string | null
          sent_count: number
          status: Database["public"]["Enums"]["campaign_status"]
          template_id: string | null
          template_language: string | null
          template_name: string | null
          total_count: number
          user_id: string
          variables: Json
          workspace_id: string
        }
        Insert: {
          completed_at?: string | null
          created_at?: string
          delivered_count?: number
          failed_count?: number
          header_media_url?: string | null
          id?: string
          name: string
          read_count?: number
          scheduled_at?: string | null
          sent_count?: number
          status?: Database["public"]["Enums"]["campaign_status"]
          template_id?: string | null
          template_language?: string | null
          template_name?: string | null
          total_count?: number
          user_id: string
          variables?: Json
          workspace_id: string
        }
        Update: {
          completed_at?: string | null
          created_at?: string
          delivered_count?: number
          failed_count?: number
          header_media_url?: string | null
          id?: string
          name?: string
          read_count?: number
          scheduled_at?: string | null
          sent_count?: number
          status?: Database["public"]["Enums"]["campaign_status"]
          template_id?: string | null
          template_language?: string | null
          template_name?: string | null
          total_count?: number
          user_id?: string
          variables?: Json
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "campaigns_template_id_fkey"
            columns: ["template_id"]
            isOneToOne: false
            referencedRelation: "templates"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "campaigns_workspace_id_fkey"
            columns: ["workspace_id"]
            isOneToOne: false
            referencedRelation: "workspaces"
            referencedColumns: ["id"]
          },
        ]
      }
      cart_recovery_clicks: {
        Row: {
          abandoned_cart_id: string
          clicked_at: string
          id: string
          ip: string | null
          recovery_token: string
          referer: string | null
          user_agent: string | null
          workspace_id: string
        }
        Insert: {
          abandoned_cart_id: string
          clicked_at?: string
          id?: string
          ip?: string | null
          recovery_token: string
          referer?: string | null
          user_agent?: string | null
          workspace_id: string
        }
        Update: {
          abandoned_cart_id?: string
          clicked_at?: string
          id?: string
          ip?: string | null
          recovery_token?: string
          referer?: string | null
          user_agent?: string | null
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "cart_recovery_clicks_abandoned_cart_id_fkey"
            columns: ["abandoned_cart_id"]
            isOneToOne: false
            referencedRelation: "abandoned_carts"
            referencedColumns: ["id"]
          },
        ]
      }
      contact_group_members: {
        Row: {
          added_at: string
          contact_id: string
          group_id: string
          id: string
          workspace_id: string
        }
        Insert: {
          added_at?: string
          contact_id: string
          group_id: string
          id?: string
          workspace_id: string
        }
        Update: {
          added_at?: string
          contact_id?: string
          group_id?: string
          id?: string
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "contact_group_members_group_id_fkey"
            columns: ["group_id"]
            isOneToOne: false
            referencedRelation: "contact_groups"
            referencedColumns: ["id"]
          },
        ]
      }
      contact_groups: {
        Row: {
          created_at: string
          description: string | null
          id: string
          name: string
          user_id: string
          workspace_id: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          id?: string
          name: string
          user_id: string
          workspace_id: string
        }
        Update: {
          created_at?: string
          description?: string | null
          id?: string
          name?: string
          user_id?: string
          workspace_id?: string
        }
        Relationships: []
      }
      contact_segments: {
        Row: {
          created_at: string
          description: string | null
          id: string
          name: string
          search: string | null
          tags_any: string[]
          user_id: string
          workspace_id: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          id?: string
          name: string
          search?: string | null
          tags_any?: string[]
          user_id: string
          workspace_id: string
        }
        Update: {
          created_at?: string
          description?: string | null
          id?: string
          name?: string
          search?: string | null
          tags_any?: string[]
          user_id?: string
          workspace_id?: string
        }
        Relationships: []
      }
      contacts: {
        Row: {
          ai_confidence: number | null
          ai_language: string | null
          ai_last_intent: string | null
          ai_lead_stage: string | null
          ai_updated_at: string | null
          assigned_agent_id: string | null
          assigned_agent_label: string | null
          assigned_user_id: string | null
          avatar_url: string | null
          city: string | null
          created_at: string
          custom_fields: Json
          email: string | null
          id: string
          lead_source: string | null
          lead_stage: string | null
          lifetime_value: number
          name: string
          notes: string | null
          phone: string
          tags: string[]
          total_orders: number
          user_id: string
          workspace_id: string
        }
        Insert: {
          ai_confidence?: number | null
          ai_language?: string | null
          ai_last_intent?: string | null
          ai_lead_stage?: string | null
          ai_updated_at?: string | null
          assigned_agent_id?: string | null
          assigned_agent_label?: string | null
          assigned_user_id?: string | null
          avatar_url?: string | null
          city?: string | null
          created_at?: string
          custom_fields?: Json
          email?: string | null
          id?: string
          lead_source?: string | null
          lead_stage?: string | null
          lifetime_value?: number
          name: string
          notes?: string | null
          phone: string
          tags?: string[]
          total_orders?: number
          user_id: string
          workspace_id: string
        }
        Update: {
          ai_confidence?: number | null
          ai_language?: string | null
          ai_last_intent?: string | null
          ai_lead_stage?: string | null
          ai_updated_at?: string | null
          assigned_agent_id?: string | null
          assigned_agent_label?: string | null
          assigned_user_id?: string | null
          avatar_url?: string | null
          city?: string | null
          created_at?: string
          custom_fields?: Json
          email?: string | null
          id?: string
          lead_source?: string | null
          lead_stage?: string | null
          lifetime_value?: number
          name?: string
          notes?: string | null
          phone?: string
          tags?: string[]
          total_orders?: number
          user_id?: string
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "contacts_workspace_id_fkey"
            columns: ["workspace_id"]
            isOneToOne: false
            referencedRelation: "workspaces"
            referencedColumns: ["id"]
          },
        ]
      }
      conversations: {
        Row: {
          assigned_to: string | null
          contact_id: string | null
          contact_name: string | null
          contact_phone: string
          created_at: string
          id: string
          labels: string[]
          last_message_at: string
          last_message_preview: string | null
          priority: string
          status: Database["public"]["Enums"]["conversation_status"]
          unread_count: number
          workspace_id: string
        }
        Insert: {
          assigned_to?: string | null
          contact_id?: string | null
          contact_name?: string | null
          contact_phone: string
          created_at?: string
          id?: string
          labels?: string[]
          last_message_at?: string
          last_message_preview?: string | null
          priority?: string
          status?: Database["public"]["Enums"]["conversation_status"]
          unread_count?: number
          workspace_id: string
        }
        Update: {
          assigned_to?: string | null
          contact_id?: string | null
          contact_name?: string | null
          contact_phone?: string
          created_at?: string
          id?: string
          labels?: string[]
          last_message_at?: string
          last_message_preview?: string | null
          priority?: string
          status?: Database["public"]["Enums"]["conversation_status"]
          unread_count?: number
          workspace_id?: string
        }
        Relationships: []
      }
      deal_activities: {
        Row: {
          created_at: string
          data: Json
          deal_id: string
          id: string
          type: string
          user_id: string | null
          workspace_id: string
        }
        Insert: {
          created_at?: string
          data?: Json
          deal_id: string
          id?: string
          type: string
          user_id?: string | null
          workspace_id: string
        }
        Update: {
          created_at?: string
          data?: Json
          deal_id?: string
          id?: string
          type?: string
          user_id?: string | null
          workspace_id?: string
        }
        Relationships: []
      }
      deal_notes: {
        Row: {
          body: string
          created_at: string
          deal_id: string
          id: string
          updated_at: string
          user_id: string
          workspace_id: string
        }
        Insert: {
          body: string
          created_at?: string
          deal_id: string
          id?: string
          updated_at?: string
          user_id: string
          workspace_id: string
        }
        Update: {
          body?: string
          created_at?: string
          deal_id?: string
          id?: string
          updated_at?: string
          user_id?: string
          workspace_id?: string
        }
        Relationships: []
      }
      deal_tag_links: {
        Row: {
          created_at: string
          deal_id: string
          tag_id: string
          workspace_id: string
        }
        Insert: {
          created_at?: string
          deal_id: string
          tag_id: string
          workspace_id: string
        }
        Update: {
          created_at?: string
          deal_id?: string
          tag_id?: string
          workspace_id?: string
        }
        Relationships: []
      }
      deal_tags: {
        Row: {
          color: string
          created_at: string
          id: string
          name: string
          workspace_id: string
        }
        Insert: {
          color?: string
          created_at?: string
          id?: string
          name: string
          workspace_id: string
        }
        Update: {
          color?: string
          created_at?: string
          id?: string
          name?: string
          workspace_id?: string
        }
        Relationships: []
      }
      deals: {
        Row: {
          assigned_agent_id: string | null
          assigned_agent_label: string | null
          assigned_to: string | null
          assigned_user_id: string | null
          contact_id: string | null
          created_at: string
          currency: string
          expected_close_date: string | null
          id: string
          notes: string | null
          position: number
          score: number
          source: string | null
          stage_id: string
          tags: string[]
          title: string
          updated_at: string
          user_id: string
          value: number
          workspace_id: string
        }
        Insert: {
          assigned_agent_id?: string | null
          assigned_agent_label?: string | null
          assigned_to?: string | null
          assigned_user_id?: string | null
          contact_id?: string | null
          created_at?: string
          currency?: string
          expected_close_date?: string | null
          id?: string
          notes?: string | null
          position?: number
          score?: number
          source?: string | null
          stage_id: string
          tags?: string[]
          title: string
          updated_at?: string
          user_id: string
          value?: number
          workspace_id: string
        }
        Update: {
          assigned_agent_id?: string | null
          assigned_agent_label?: string | null
          assigned_to?: string | null
          assigned_user_id?: string | null
          contact_id?: string | null
          created_at?: string
          currency?: string
          expected_close_date?: string | null
          id?: string
          notes?: string | null
          position?: number
          score?: number
          source?: string | null
          stage_id?: string
          tags?: string[]
          title?: string
          updated_at?: string
          user_id?: string
          value?: number
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "deals_contact_id_fkey"
            columns: ["contact_id"]
            isOneToOne: false
            referencedRelation: "contacts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "deals_stage_id_fkey"
            columns: ["stage_id"]
            isOneToOne: false
            referencedRelation: "pipeline_stages"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "deals_workspace_id_fkey"
            columns: ["workspace_id"]
            isOneToOne: false
            referencedRelation: "workspaces"
            referencedColumns: ["id"]
          },
        ]
      }
      demo_requests: {
        Row: {
          business_type: string | null
          company: string | null
          created_at: string
          email: string
          full_name: string
          id: string
          message: string | null
          phone: string | null
          status: string
        }
        Insert: {
          business_type?: string | null
          company?: string | null
          created_at?: string
          email: string
          full_name: string
          id?: string
          message?: string | null
          phone?: string | null
          status?: string
        }
        Update: {
          business_type?: string | null
          company?: string | null
          created_at?: string
          email?: string
          full_name?: string
          id?: string
          message?: string | null
          phone?: string | null
          status?: string
        }
        Relationships: []
      }
      ecom_automation_runs: {
        Row: {
          automation_key: string
          id: string
          integration_id: string | null
          message: string | null
          ok: boolean
          sent_at: string
          target_id: string
          target_type: string
          workspace_id: string
        }
        Insert: {
          automation_key: string
          id?: string
          integration_id?: string | null
          message?: string | null
          ok?: boolean
          sent_at?: string
          target_id: string
          target_type: string
          workspace_id: string
        }
        Update: {
          automation_key?: string
          id?: string
          integration_id?: string | null
          message?: string | null
          ok?: boolean
          sent_at?: string
          target_id?: string
          target_type?: string
          workspace_id?: string
        }
        Relationships: []
      }
      ecom_customers: {
        Row: {
          contact_id: string | null
          created_at: string
          email: string | null
          external_id: string | null
          id: string
          integration_id: string | null
          last_order_at: string | null
          lifetime_value: number
          name: string | null
          phone: string | null
          total_orders: number
          workspace_id: string
        }
        Insert: {
          contact_id?: string | null
          created_at?: string
          email?: string | null
          external_id?: string | null
          id?: string
          integration_id?: string | null
          last_order_at?: string | null
          lifetime_value?: number
          name?: string | null
          phone?: string | null
          total_orders?: number
          workspace_id: string
        }
        Update: {
          contact_id?: string | null
          created_at?: string
          email?: string | null
          external_id?: string | null
          id?: string
          integration_id?: string | null
          last_order_at?: string | null
          lifetime_value?: number
          name?: string | null
          phone?: string | null
          total_orders?: number
          workspace_id?: string
        }
        Relationships: []
      }
      ecom_orders: {
        Row: {
          cod_status: string | null
          contact_id: string | null
          created_at: string
          currency: string
          customer_id: string | null
          customer_name: string | null
          customer_phone: string | null
          external_id: string | null
          fulfillment_status: string
          id: string
          integration_id: string | null
          items: Json
          order_number: string | null
          payment_status: string
          placed_at: string
          source: string | null
          total: number
          whatsapp_notified: boolean
          workspace_id: string
        }
        Insert: {
          cod_status?: string | null
          contact_id?: string | null
          created_at?: string
          currency?: string
          customer_id?: string | null
          customer_name?: string | null
          customer_phone?: string | null
          external_id?: string | null
          fulfillment_status?: string
          id?: string
          integration_id?: string | null
          items?: Json
          order_number?: string | null
          payment_status?: string
          placed_at?: string
          source?: string | null
          total?: number
          whatsapp_notified?: boolean
          workspace_id: string
        }
        Update: {
          cod_status?: string | null
          contact_id?: string | null
          created_at?: string
          currency?: string
          customer_id?: string | null
          customer_name?: string | null
          customer_phone?: string | null
          external_id?: string | null
          fulfillment_status?: string
          id?: string
          integration_id?: string | null
          items?: Json
          order_number?: string | null
          payment_status?: string
          placed_at?: string
          source?: string | null
          total?: number
          whatsapp_notified?: boolean
          workspace_id?: string
        }
        Relationships: []
      }
      follow_ups: {
        Row: {
          ai_generated: boolean
          ai_message: string | null
          ai_reasoning: string | null
          assigned_to: string | null
          attempt_count: number
          completed_at: string | null
          contact_id: string | null
          conversation_id: string | null
          created_at: string
          deal_id: string | null
          due_at: string
          id: string
          notes: string | null
          send_error: string | null
          sent_at: string | null
          source_message_id: string | null
          status: string
          template_id: string | null
          title: string
          type: string
          user_id: string
          workspace_id: string
        }
        Insert: {
          ai_generated?: boolean
          ai_message?: string | null
          ai_reasoning?: string | null
          assigned_to?: string | null
          attempt_count?: number
          completed_at?: string | null
          contact_id?: string | null
          conversation_id?: string | null
          created_at?: string
          deal_id?: string | null
          due_at: string
          id?: string
          notes?: string | null
          send_error?: string | null
          sent_at?: string | null
          source_message_id?: string | null
          status?: string
          template_id?: string | null
          title: string
          type?: string
          user_id: string
          workspace_id: string
        }
        Update: {
          ai_generated?: boolean
          ai_message?: string | null
          ai_reasoning?: string | null
          assigned_to?: string | null
          attempt_count?: number
          completed_at?: string | null
          contact_id?: string | null
          conversation_id?: string | null
          created_at?: string
          deal_id?: string | null
          due_at?: string
          id?: string
          notes?: string | null
          send_error?: string | null
          sent_at?: string | null
          source_message_id?: string | null
          status?: string
          template_id?: string | null
          title?: string
          type?: string
          user_id?: string
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "follow_ups_contact_id_fkey"
            columns: ["contact_id"]
            isOneToOne: false
            referencedRelation: "contacts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "follow_ups_conversation_id_fkey"
            columns: ["conversation_id"]
            isOneToOne: false
            referencedRelation: "conversations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "follow_ups_deal_id_fkey"
            columns: ["deal_id"]
            isOneToOne: false
            referencedRelation: "deals"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "follow_ups_workspace_id_fkey"
            columns: ["workspace_id"]
            isOneToOne: false
            referencedRelation: "workspaces"
            referencedColumns: ["id"]
          },
        ]
      }
      integration_debug_logs: {
        Row: {
          created_at: string
          direction: string
          event: string
          id: string
          integration_id: string | null
          message: string | null
          ok: boolean
          payload: Json
          provider: string
          response: Json | null
          status_code: number | null
          workspace_id: string
        }
        Insert: {
          created_at?: string
          direction?: string
          event: string
          id?: string
          integration_id?: string | null
          message?: string | null
          ok?: boolean
          payload?: Json
          provider?: string
          response?: Json | null
          status_code?: number | null
          workspace_id: string
        }
        Update: {
          created_at?: string
          direction?: string
          event?: string
          id?: string
          integration_id?: string | null
          message?: string | null
          ok?: boolean
          payload?: Json
          provider?: string
          response?: Json | null
          status_code?: number | null
          workspace_id?: string
        }
        Relationships: []
      }
      landing_faqs: {
        Row: {
          answer: string
          created_at: string
          id: string
          is_active: boolean
          position: number
          question: string
          updated_at: string
        }
        Insert: {
          answer: string
          created_at?: string
          id?: string
          is_active?: boolean
          position?: number
          question: string
          updated_at?: string
        }
        Update: {
          answer?: string
          created_at?: string
          id?: string
          is_active?: boolean
          position?: number
          question?: string
          updated_at?: string
        }
        Relationships: []
      }
      landing_features: {
        Row: {
          category: string
          created_at: string
          description: string | null
          icon: string
          id: string
          is_active: boolean
          name: string
          position: number
          updated_at: string
        }
        Insert: {
          category?: string
          created_at?: string
          description?: string | null
          icon?: string
          id?: string
          is_active?: boolean
          name: string
          position?: number
          updated_at?: string
        }
        Update: {
          category?: string
          created_at?: string
          description?: string | null
          icon?: string
          id?: string
          is_active?: boolean
          name?: string
          position?: number
          updated_at?: string
        }
        Relationships: []
      }
      landing_testimonials: {
        Row: {
          company: string | null
          created_at: string
          id: string
          is_active: boolean
          name: string
          photo_url: string | null
          position: number
          rating: number
          review: string
          role: string | null
          updated_at: string
        }
        Insert: {
          company?: string | null
          created_at?: string
          id?: string
          is_active?: boolean
          name: string
          photo_url?: string | null
          position?: number
          rating?: number
          review: string
          role?: string | null
          updated_at?: string
        }
        Update: {
          company?: string | null
          created_at?: string
          id?: string
          is_active?: boolean
          name?: string
          photo_url?: string | null
          position?: number
          rating?: number
          review?: string
          role?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      lead_agents: {
        Row: {
          active: boolean
          created_at: string
          email: string | null
          id: string
          name: string
          phone: string | null
          workspace_id: string
        }
        Insert: {
          active?: boolean
          created_at?: string
          email?: string | null
          id?: string
          name: string
          phone?: string | null
          workspace_id: string
        }
        Update: {
          active?: boolean
          created_at?: string
          email?: string | null
          id?: string
          name?: string
          phone?: string | null
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "lead_agents_workspace_id_fkey"
            columns: ["workspace_id"]
            isOneToOne: false
            referencedRelation: "workspaces"
            referencedColumns: ["id"]
          },
        ]
      }
      lead_intake_tokens: {
        Row: {
          created_at: string
          default_stage_id: string | null
          enabled: boolean
          id: string
          last_used_at: string | null
          provider: string
          token: string
          workspace_id: string
        }
        Insert: {
          created_at?: string
          default_stage_id?: string | null
          enabled?: boolean
          id?: string
          last_used_at?: string | null
          provider: string
          token: string
          workspace_id: string
        }
        Update: {
          created_at?: string
          default_stage_id?: string | null
          enabled?: boolean
          id?: string
          last_used_at?: string | null
          provider?: string
          token?: string
          workspace_id?: string
        }
        Relationships: []
      }
      master_features: {
        Row: {
          category: string
          created_at: string
          description: string | null
          icon: string | null
          id: string
          is_active: boolean
          name: string
          position: number
          updated_at: string
        }
        Insert: {
          category: string
          created_at?: string
          description?: string | null
          icon?: string | null
          id?: string
          is_active?: boolean
          name: string
          position?: number
          updated_at?: string
        }
        Update: {
          category?: string
          created_at?: string
          description?: string | null
          icon?: string | null
          id?: string
          is_active?: boolean
          name?: string
          position?: number
          updated_at?: string
        }
        Relationships: []
      }
      member_permissions: {
        Row: {
          can_create: boolean
          can_delete: boolean
          can_edit: boolean
          can_view: boolean
          created_at: string
          module: string
          updated_at: string
          user_id: string
          workspace_id: string
        }
        Insert: {
          can_create?: boolean
          can_delete?: boolean
          can_edit?: boolean
          can_view?: boolean
          created_at?: string
          module: string
          updated_at?: string
          user_id: string
          workspace_id: string
        }
        Update: {
          can_create?: boolean
          can_delete?: boolean
          can_edit?: boolean
          can_view?: boolean
          created_at?: string
          module?: string
          updated_at?: string
          user_id?: string
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "member_permissions_workspace_id_fkey"
            columns: ["workspace_id"]
            isOneToOne: false
            referencedRelation: "workspaces"
            referencedColumns: ["id"]
          },
        ]
      }
      messages: {
        Row: {
          content: string | null
          conversation_id: string
          created_at: string
          direction: Database["public"]["Enums"]["message_direction"]
          id: string
          is_automated: boolean
          is_internal: boolean
          media_mime: string | null
          media_url: string | null
          reactions: Json
          reply_to_preview: string | null
          reply_to_wa_message_id: string | null
          sender_user_id: string | null
          status: string
          status_error: string | null
          status_error_code: number | null
          status_updated_at: string | null
          type: Database["public"]["Enums"]["message_type"]
          wa_message_id: string | null
          workspace_id: string
        }
        Insert: {
          content?: string | null
          conversation_id: string
          created_at?: string
          direction: Database["public"]["Enums"]["message_direction"]
          id?: string
          is_automated?: boolean
          is_internal?: boolean
          media_mime?: string | null
          media_url?: string | null
          reactions?: Json
          reply_to_preview?: string | null
          reply_to_wa_message_id?: string | null
          sender_user_id?: string | null
          status?: string
          status_error?: string | null
          status_error_code?: number | null
          status_updated_at?: string | null
          type?: Database["public"]["Enums"]["message_type"]
          wa_message_id?: string | null
          workspace_id: string
        }
        Update: {
          content?: string | null
          conversation_id?: string
          created_at?: string
          direction?: Database["public"]["Enums"]["message_direction"]
          id?: string
          is_automated?: boolean
          is_internal?: boolean
          media_mime?: string | null
          media_url?: string | null
          reactions?: Json
          reply_to_preview?: string | null
          reply_to_wa_message_id?: string | null
          sender_user_id?: string | null
          status?: string
          status_error?: string | null
          status_error_code?: number | null
          status_updated_at?: string | null
          type?: Database["public"]["Enums"]["message_type"]
          wa_message_id?: string | null
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "messages_conversation_id_fkey"
            columns: ["conversation_id"]
            isOneToOne: false
            referencedRelation: "conversations"
            referencedColumns: ["id"]
          },
        ]
      }
      meta_lead_connections: {
        Row: {
          created_at: string
          fb_user_id: string
          fb_user_name: string | null
          id: string
          long_lived_token: string
          scope: string | null
          token_expires_at: string | null
          updated_at: string
          user_id: string
          workspace_id: string
        }
        Insert: {
          created_at?: string
          fb_user_id: string
          fb_user_name?: string | null
          id?: string
          long_lived_token: string
          scope?: string | null
          token_expires_at?: string | null
          updated_at?: string
          user_id: string
          workspace_id: string
        }
        Update: {
          created_at?: string
          fb_user_id?: string
          fb_user_name?: string | null
          id?: string
          long_lived_token?: string
          scope?: string | null
          token_expires_at?: string | null
          updated_at?: string
          user_id?: string
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "meta_lead_connections_workspace_id_fkey"
            columns: ["workspace_id"]
            isOneToOne: false
            referencedRelation: "workspaces"
            referencedColumns: ["id"]
          },
        ]
      }
      meta_lead_forms: {
        Row: {
          assigned_agent_id: string | null
          assigned_agent_label: string | null
          assigned_user_id: string | null
          created_at: string
          default_stage_id: string | null
          default_tags: Json
          enabled: boolean
          form_id: string
          form_name: string | null
          id: string
          last_lead_at: string | null
          page_id: string
          status: string | null
          updated_at: string
          workspace_id: string
        }
        Insert: {
          assigned_agent_id?: string | null
          assigned_agent_label?: string | null
          assigned_user_id?: string | null
          created_at?: string
          default_stage_id?: string | null
          default_tags?: Json
          enabled?: boolean
          form_id: string
          form_name?: string | null
          id?: string
          last_lead_at?: string | null
          page_id: string
          status?: string | null
          updated_at?: string
          workspace_id: string
        }
        Update: {
          assigned_agent_id?: string | null
          assigned_agent_label?: string | null
          assigned_user_id?: string | null
          created_at?: string
          default_stage_id?: string | null
          default_tags?: Json
          enabled?: boolean
          form_id?: string
          form_name?: string | null
          id?: string
          last_lead_at?: string | null
          page_id?: string
          status?: string | null
          updated_at?: string
          workspace_id?: string
        }
        Relationships: []
      }
      meta_lead_pages: {
        Row: {
          business_name: string | null
          category: string | null
          connection_id: string
          created_at: string
          id: string
          page_access_token: string
          page_id: string
          page_name: string | null
          subscribed: boolean
          updated_at: string
          workspace_id: string
        }
        Insert: {
          business_name?: string | null
          category?: string | null
          connection_id: string
          created_at?: string
          id?: string
          page_access_token: string
          page_id: string
          page_name?: string | null
          subscribed?: boolean
          updated_at?: string
          workspace_id: string
        }
        Update: {
          business_name?: string | null
          category?: string | null
          connection_id?: string
          created_at?: string
          id?: string
          page_access_token?: string
          page_id?: string
          page_name?: string | null
          subscribed?: boolean
          updated_at?: string
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "meta_lead_pages_connection_id_fkey"
            columns: ["connection_id"]
            isOneToOne: false
            referencedRelation: "meta_lead_connections"
            referencedColumns: ["id"]
          },
        ]
      }
      otp_codes: {
        Row: {
          attempts: number
          code_hash: string
          consumed_at: string | null
          context: Json | null
          created_at: string
          expires_at: string
          id: string
          integration_id: string | null
          phone: string
          workspace_id: string
        }
        Insert: {
          attempts?: number
          code_hash: string
          consumed_at?: string | null
          context?: Json | null
          created_at?: string
          expires_at: string
          id?: string
          integration_id?: string | null
          phone: string
          workspace_id: string
        }
        Update: {
          attempts?: number
          code_hash?: string
          consumed_at?: string | null
          context?: Json | null
          created_at?: string
          expires_at?: string
          id?: string
          integration_id?: string | null
          phone?: string
          workspace_id?: string
        }
        Relationships: []
      }
      payment_gateways: {
        Row: {
          created_at: string
          display_name: string
          id: string
          is_enabled: boolean
          key_id: string | null
          meta: Json
          provider: string
          secret_key: string | null
          updated_at: string
          webhook_secret: string | null
        }
        Insert: {
          created_at?: string
          display_name: string
          id?: string
          is_enabled?: boolean
          key_id?: string | null
          meta?: Json
          provider: string
          secret_key?: string | null
          updated_at?: string
          webhook_secret?: string | null
        }
        Update: {
          created_at?: string
          display_name?: string
          id?: string
          is_enabled?: boolean
          key_id?: string | null
          meta?: Json
          provider?: string
          secret_key?: string | null
          updated_at?: string
          webhook_secret?: string | null
        }
        Relationships: []
      }
      payment_transactions: {
        Row: {
          amount: number
          billing_interval: string
          created_at: string
          credit_package_id: string | null
          credits_amount: number | null
          currency: string
          id: string
          order_id: string | null
          payment_id: string | null
          plan_name_snapshot: string
          provider: string
          purpose: string
          raw_event: Json
          status: string
          template_id: string | null
          updated_at: string
          user_id: string
          workspace_id: string
        }
        Insert: {
          amount?: number
          billing_interval?: string
          created_at?: string
          credit_package_id?: string | null
          credits_amount?: number | null
          currency?: string
          id?: string
          order_id?: string | null
          payment_id?: string | null
          plan_name_snapshot: string
          provider: string
          purpose?: string
          raw_event?: Json
          status?: string
          template_id?: string | null
          updated_at?: string
          user_id: string
          workspace_id: string
        }
        Update: {
          amount?: number
          billing_interval?: string
          created_at?: string
          credit_package_id?: string | null
          credits_amount?: number | null
          currency?: string
          id?: string
          order_id?: string | null
          payment_id?: string | null
          plan_name_snapshot?: string
          provider?: string
          purpose?: string
          raw_event?: Json
          status?: string
          template_id?: string | null
          updated_at?: string
          user_id?: string
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "payment_transactions_credit_package_id_fkey"
            columns: ["credit_package_id"]
            isOneToOne: false
            referencedRelation: "ai_credit_packages"
            referencedColumns: ["id"]
          },
        ]
      }
      pipeline_stages: {
        Row: {
          color: string
          created_at: string
          id: string
          is_lost: boolean
          is_won: boolean
          name: string
          position: number
          workspace_id: string
        }
        Insert: {
          color?: string
          created_at?: string
          id?: string
          is_lost?: boolean
          is_won?: boolean
          name: string
          position?: number
          workspace_id: string
        }
        Update: {
          color?: string
          created_at?: string
          id?: string
          is_lost?: boolean
          is_won?: boolean
          name?: string
          position?: number
          workspace_id?: string
        }
        Relationships: []
      }
      plan_requests: {
        Row: {
          admin_notes: string | null
          billing_interval: string
          created_at: string
          currency: string
          features: Json
          id: string
          limits: Json
          notes: string | null
          plan_name: string
          price_monthly: number
          price_yearly: number
          requested_by: string
          reviewed_at: string | null
          reviewed_by: string | null
          status: string
          updated_at: string
          workspace_id: string
        }
        Insert: {
          admin_notes?: string | null
          billing_interval?: string
          created_at?: string
          currency?: string
          features?: Json
          id?: string
          limits?: Json
          notes?: string | null
          plan_name?: string
          price_monthly?: number
          price_yearly?: number
          requested_by: string
          reviewed_at?: string | null
          reviewed_by?: string | null
          status?: string
          updated_at?: string
          workspace_id: string
        }
        Update: {
          admin_notes?: string | null
          billing_interval?: string
          created_at?: string
          currency?: string
          features?: Json
          id?: string
          limits?: Json
          notes?: string | null
          plan_name?: string
          price_monthly?: number
          price_yearly?: number
          requested_by?: string
          reviewed_at?: string | null
          reviewed_by?: string | null
          status?: string
          updated_at?: string
          workspace_id?: string
        }
        Relationships: []
      }
      plan_template_features: {
        Row: {
          created_at: string
          custom_value: string | null
          feature_id: string
          id: string
          included: boolean
          position: number
          template_id: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          custom_value?: string | null
          feature_id: string
          id?: string
          included?: boolean
          position?: number
          template_id: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          custom_value?: string | null
          feature_id?: string
          id?: string
          included?: boolean
          position?: number
          template_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "plan_template_features_feature_id_fkey"
            columns: ["feature_id"]
            isOneToOne: false
            referencedRelation: "master_features"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "plan_template_features_template_id_fkey"
            columns: ["template_id"]
            isOneToOne: false
            referencedRelation: "plan_templates"
            referencedColumns: ["id"]
          },
        ]
      }
      plan_templates: {
        Row: {
          badge_text: string | null
          created_at: string
          created_by: string | null
          currency: string
          description: string | null
          features: Json
          gateway_ids: string[]
          id: string
          is_active: boolean
          is_popular: boolean
          is_reseller: boolean
          limits: Json
          name: string
          position: number
          price_monthly: number
          price_yearly: number
          updated_at: string
        }
        Insert: {
          badge_text?: string | null
          created_at?: string
          created_by?: string | null
          currency?: string
          description?: string | null
          features?: Json
          gateway_ids?: string[]
          id?: string
          is_active?: boolean
          is_popular?: boolean
          is_reseller?: boolean
          limits?: Json
          name: string
          position?: number
          price_monthly?: number
          price_yearly?: number
          updated_at?: string
        }
        Update: {
          badge_text?: string | null
          created_at?: string
          created_by?: string | null
          currency?: string
          description?: string | null
          features?: Json
          gateway_ids?: string[]
          id?: string
          is_active?: boolean
          is_popular?: boolean
          is_reseller?: boolean
          limits?: Json
          name?: string
          position?: number
          price_monthly?: number
          price_yearly?: number
          updated_at?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          allow_multi_workspace: boolean
          created_at: string
          created_by_admin: boolean
          email: string | null
          full_name: string | null
          id: string
          is_archived: boolean
          is_super_admin: boolean
          is_suspended: boolean
          trial_ends_at: string | null
          trial_started_at: string | null
          username: string | null
        }
        Insert: {
          allow_multi_workspace?: boolean
          created_at?: string
          created_by_admin?: boolean
          email?: string | null
          full_name?: string | null
          id: string
          is_archived?: boolean
          is_super_admin?: boolean
          is_suspended?: boolean
          trial_ends_at?: string | null
          trial_started_at?: string | null
          username?: string | null
        }
        Update: {
          allow_multi_workspace?: boolean
          created_at?: string
          created_by_admin?: boolean
          email?: string | null
          full_name?: string | null
          id?: string
          is_archived?: boolean
          is_super_admin?: boolean
          is_suspended?: boolean
          trial_ends_at?: string | null
          trial_started_at?: string | null
          username?: string | null
        }
        Relationships: []
      }
      reseller_accounts: {
        Row: {
          allow_custom_domain: boolean
          approved_at: string
          approved_by: string | null
          brand_name: string
          commission_pct: number
          created_at: string
          custom_domain: string | null
          features: Json
          license_key: string | null
          logo_path: string | null
          logo_url: string | null
          max_customers: number
          plan_template_id: string | null
          primary_color: string | null
          status: string
          subdomain: string | null
          support_email: string | null
          updated_at: string
          white_label: boolean
          workspace_id: string
        }
        Insert: {
          allow_custom_domain?: boolean
          approved_at?: string
          approved_by?: string | null
          brand_name: string
          commission_pct?: number
          created_at?: string
          custom_domain?: string | null
          features?: Json
          license_key?: string | null
          logo_path?: string | null
          logo_url?: string | null
          max_customers?: number
          plan_template_id?: string | null
          primary_color?: string | null
          status?: string
          subdomain?: string | null
          support_email?: string | null
          updated_at?: string
          white_label?: boolean
          workspace_id: string
        }
        Update: {
          allow_custom_domain?: boolean
          approved_at?: string
          approved_by?: string | null
          brand_name?: string
          commission_pct?: number
          created_at?: string
          custom_domain?: string | null
          features?: Json
          license_key?: string | null
          logo_path?: string | null
          logo_url?: string | null
          max_customers?: number
          plan_template_id?: string | null
          primary_color?: string | null
          status?: string
          subdomain?: string | null
          support_email?: string | null
          updated_at?: string
          white_label?: boolean
          workspace_id?: string
        }
        Relationships: []
      }
      reseller_applications: {
        Row: {
          admin_notes: string | null
          applicant_id: string
          brand_name: string | null
          business_name: string
          contact_email: string | null
          contact_phone: string | null
          country: string | null
          created_at: string
          id: string
          notes: string | null
          requested_plan_template_id: string | null
          reviewed_at: string | null
          reviewed_by: string | null
          status: string
          updated_at: string
          website: string | null
          workspace_id: string
        }
        Insert: {
          admin_notes?: string | null
          applicant_id: string
          brand_name?: string | null
          business_name: string
          contact_email?: string | null
          contact_phone?: string | null
          country?: string | null
          created_at?: string
          id?: string
          notes?: string | null
          requested_plan_template_id?: string | null
          reviewed_at?: string | null
          reviewed_by?: string | null
          status?: string
          updated_at?: string
          website?: string | null
          workspace_id: string
        }
        Update: {
          admin_notes?: string | null
          applicant_id?: string
          brand_name?: string | null
          business_name?: string
          contact_email?: string | null
          contact_phone?: string | null
          country?: string | null
          created_at?: string
          id?: string
          notes?: string | null
          requested_plan_template_id?: string | null
          reviewed_at?: string | null
          reviewed_by?: string | null
          status?: string
          updated_at?: string
          website?: string | null
          workspace_id?: string
        }
        Relationships: []
      }
      reseller_customers: {
        Row: {
          commission_amount: number
          created_at: string
          currency: string
          customer_email: string | null
          customer_name: string
          customer_phone: string | null
          customer_workspace_id: string | null
          features: Json
          id: string
          license_expires_at: string | null
          license_key: string | null
          license_status: string
          monthly_price: number
          notes: string | null
          plan_template_id: string | null
          reseller_workspace_id: string
          status: string
          updated_at: string
        }
        Insert: {
          commission_amount?: number
          created_at?: string
          currency?: string
          customer_email?: string | null
          customer_name: string
          customer_phone?: string | null
          customer_workspace_id?: string | null
          features?: Json
          id?: string
          license_expires_at?: string | null
          license_key?: string | null
          license_status?: string
          monthly_price?: number
          notes?: string | null
          plan_template_id?: string | null
          reseller_workspace_id: string
          status?: string
          updated_at?: string
        }
        Update: {
          commission_amount?: number
          created_at?: string
          currency?: string
          customer_email?: string | null
          customer_name?: string
          customer_phone?: string | null
          customer_workspace_id?: string | null
          features?: Json
          id?: string
          license_expires_at?: string | null
          license_key?: string | null
          license_status?: string
          monthly_price?: number
          notes?: string | null
          plan_template_id?: string | null
          reseller_workspace_id?: string
          status?: string
          updated_at?: string
        }
        Relationships: []
      }
      store_integrations: {
        Row: {
          access_token: string | null
          api_key: string | null
          api_secret: string | null
          created_at: string
          id: string
          last_sync_at: string | null
          meta: Json
          provider: string
          status: string
          store_url: string
          total_revenue: number
          updated_at: string
          user_id: string
          webhook_secret: string | null
          workspace_id: string
        }
        Insert: {
          access_token?: string | null
          api_key?: string | null
          api_secret?: string | null
          created_at?: string
          id?: string
          last_sync_at?: string | null
          meta?: Json
          provider: string
          status?: string
          store_url: string
          total_revenue?: number
          updated_at?: string
          user_id: string
          webhook_secret?: string | null
          workspace_id: string
        }
        Update: {
          access_token?: string | null
          api_key?: string | null
          api_secret?: string | null
          created_at?: string
          id?: string
          last_sync_at?: string | null
          meta?: Json
          provider?: string
          status?: string
          store_url?: string
          total_revenue?: number
          updated_at?: string
          user_id?: string
          webhook_secret?: string | null
          workspace_id?: string
        }
        Relationships: []
      }
      subscriptions: {
        Row: {
          admin_notes: string | null
          approved_at: string | null
          approved_by: string | null
          billing_interval: string
          cancelled_at: string | null
          created_at: string
          currency: string
          id: string
          notes: string | null
          plan_id: string
          plan_name_snapshot: string | null
          price_snapshot: number
          rejected_at: string | null
          requested_by: string
          status: string
          updated_at: string
          vendor_id: string
          vendor_name_snapshot: string | null
          workspace_id: string
        }
        Insert: {
          admin_notes?: string | null
          approved_at?: string | null
          approved_by?: string | null
          billing_interval?: string
          cancelled_at?: string | null
          created_at?: string
          currency?: string
          id?: string
          notes?: string | null
          plan_id: string
          plan_name_snapshot?: string | null
          price_snapshot?: number
          rejected_at?: string | null
          requested_by: string
          status?: string
          updated_at?: string
          vendor_id: string
          vendor_name_snapshot?: string | null
          workspace_id: string
        }
        Update: {
          admin_notes?: string | null
          approved_at?: string | null
          approved_by?: string | null
          billing_interval?: string
          cancelled_at?: string | null
          created_at?: string
          currency?: string
          id?: string
          notes?: string | null
          plan_id?: string
          plan_name_snapshot?: string | null
          price_snapshot?: number
          rejected_at?: string | null
          requested_by?: string
          status?: string
          updated_at?: string
          vendor_id?: string
          vendor_name_snapshot?: string | null
          workspace_id?: string
        }
        Relationships: []
      }
      template_button_clicks: {
        Row: {
          button_payload: string | null
          button_text: string | null
          button_type: string
          campaign_id: string | null
          clicked_at: string
          contact_id: string | null
          contact_name: string | null
          context_wa_message_id: string | null
          conversation_id: string | null
          created_at: string
          id: string
          phone: string
          phone_normalized: string | null
          template_name: string | null
          wa_message_id: string | null
          workspace_id: string
        }
        Insert: {
          button_payload?: string | null
          button_text?: string | null
          button_type?: string
          campaign_id?: string | null
          clicked_at?: string
          contact_id?: string | null
          contact_name?: string | null
          context_wa_message_id?: string | null
          conversation_id?: string | null
          created_at?: string
          id?: string
          phone: string
          phone_normalized?: string | null
          template_name?: string | null
          wa_message_id?: string | null
          workspace_id: string
        }
        Update: {
          button_payload?: string | null
          button_text?: string | null
          button_type?: string
          campaign_id?: string | null
          clicked_at?: string
          contact_id?: string | null
          contact_name?: string | null
          context_wa_message_id?: string | null
          conversation_id?: string | null
          created_at?: string
          id?: string
          phone?: string
          phone_normalized?: string | null
          template_name?: string | null
          wa_message_id?: string | null
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "template_button_clicks_campaign_id_fkey"
            columns: ["campaign_id"]
            isOneToOne: false
            referencedRelation: "campaigns"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "template_button_clicks_contact_id_fkey"
            columns: ["contact_id"]
            isOneToOne: false
            referencedRelation: "contacts"
            referencedColumns: ["id"]
          },
        ]
      }
      templates: {
        Row: {
          body: string | null
          category: string | null
          components: Json | null
          created_at: string
          id: string
          language: string
          meta_template_name: string
          status: string | null
          synced_at: string | null
          user_id: string
          variable_mapping: Json | null
          variables_count: number
          workspace_id: string
        }
        Insert: {
          body?: string | null
          category?: string | null
          components?: Json | null
          created_at?: string
          id?: string
          language?: string
          meta_template_name: string
          status?: string | null
          synced_at?: string | null
          user_id: string
          variable_mapping?: Json | null
          variables_count?: number
          workspace_id: string
        }
        Update: {
          body?: string | null
          category?: string | null
          components?: Json | null
          created_at?: string
          id?: string
          language?: string
          meta_template_name?: string
          status?: string | null
          synced_at?: string | null
          user_id?: string
          variable_mapping?: Json | null
          variables_count?: number
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "templates_workspace_id_fkey"
            columns: ["workspace_id"]
            isOneToOne: false
            referencedRelation: "workspaces"
            referencedColumns: ["id"]
          },
        ]
      }
      vendor_plans: {
        Row: {
          billing_interval: string
          created_at: string
          currency: string
          description: string | null
          features: string[]
          id: string
          is_popular: boolean
          name: string
          position: number
          price: number
          vendor_id: string
          workspace_id: string
        }
        Insert: {
          billing_interval?: string
          created_at?: string
          currency?: string
          description?: string | null
          features?: string[]
          id?: string
          is_popular?: boolean
          name: string
          position?: number
          price?: number
          vendor_id: string
          workspace_id: string
        }
        Update: {
          billing_interval?: string
          created_at?: string
          currency?: string
          description?: string | null
          features?: string[]
          id?: string
          is_popular?: boolean
          name?: string
          position?: number
          price?: number
          vendor_id?: string
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "vendor_plans_vendor_id_fkey"
            columns: ["vendor_id"]
            isOneToOne: false
            referencedRelation: "vendors"
            referencedColumns: ["id"]
          },
        ]
      }
      vendors: {
        Row: {
          category: string | null
          contact_email: string | null
          contact_phone: string | null
          created_at: string
          description: string | null
          id: string
          logo_url: string | null
          name: string
          status: string
          updated_at: string
          user_id: string
          website: string | null
          workspace_id: string
        }
        Insert: {
          category?: string | null
          contact_email?: string | null
          contact_phone?: string | null
          created_at?: string
          description?: string | null
          id?: string
          logo_url?: string | null
          name: string
          status?: string
          updated_at?: string
          user_id: string
          website?: string | null
          workspace_id: string
        }
        Update: {
          category?: string | null
          contact_email?: string | null
          contact_phone?: string | null
          created_at?: string
          description?: string | null
          id?: string
          logo_url?: string | null
          name?: string
          status?: string
          updated_at?: string
          user_id?: string
          website?: string | null
          workspace_id?: string
        }
        Relationships: []
      }
      webhook_endpoints: {
        Row: {
          created_at: string
          created_by: string | null
          enabled: boolean
          events: string[]
          id: string
          last_status: string | null
          last_triggered_at: string | null
          name: string
          secret: string | null
          updated_at: string
          url: string
          workspace_id: string
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          enabled?: boolean
          events?: string[]
          id?: string
          last_status?: string | null
          last_triggered_at?: string | null
          name: string
          secret?: string | null
          updated_at?: string
          url: string
          workspace_id: string
        }
        Update: {
          created_at?: string
          created_by?: string | null
          enabled?: boolean
          events?: string[]
          id?: string
          last_status?: string | null
          last_triggered_at?: string | null
          name?: string
          secret?: string | null
          updated_at?: string
          url?: string
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "webhook_endpoints_workspace_id_fkey"
            columns: ["workspace_id"]
            isOneToOne: false
            referencedRelation: "workspaces"
            referencedColumns: ["id"]
          },
        ]
      }
      whatsapp_accounts: {
        Row: {
          access_token: string
          business_name: string | null
          connected_at: string
          connected_by: string
          created_at: string
          display_name: string | null
          display_name_status: string | null
          id: string
          is_active: boolean
          last_error: string | null
          last_synced_at: string | null
          messaging_tier: string | null
          meta: Json
          phone_number: string | null
          phone_number_id: string
          quality_rating: string | null
          status: string
          sync_status: string
          updated_at: string
          waba_id: string
          webhook_last_event_at: string | null
          webhook_status: string
          workspace_id: string
        }
        Insert: {
          access_token: string
          business_name?: string | null
          connected_at?: string
          connected_by: string
          created_at?: string
          display_name?: string | null
          display_name_status?: string | null
          id?: string
          is_active?: boolean
          last_error?: string | null
          last_synced_at?: string | null
          messaging_tier?: string | null
          meta?: Json
          phone_number?: string | null
          phone_number_id: string
          quality_rating?: string | null
          status?: string
          sync_status?: string
          updated_at?: string
          waba_id: string
          webhook_last_event_at?: string | null
          webhook_status?: string
          workspace_id: string
        }
        Update: {
          access_token?: string
          business_name?: string | null
          connected_at?: string
          connected_by?: string
          created_at?: string
          display_name?: string | null
          display_name_status?: string | null
          id?: string
          is_active?: boolean
          last_error?: string | null
          last_synced_at?: string | null
          messaging_tier?: string | null
          meta?: Json
          phone_number?: string | null
          phone_number_id?: string
          quality_rating?: string | null
          status?: string
          sync_status?: string
          updated_at?: string
          waba_id?: string
          webhook_last_event_at?: string | null
          webhook_status?: string
          workspace_id?: string
        }
        Relationships: []
      }
      whatsapp_bridge_sessions: {
        Row: {
          connected_at: string | null
          created_at: string
          display_name: string | null
          last_error: string | null
          last_seen_at: string | null
          phone_e164: string | null
          qr_data_url: string | null
          qr_expires_at: string | null
          status: string
          updated_at: string
          workspace_id: string
        }
        Insert: {
          connected_at?: string | null
          created_at?: string
          display_name?: string | null
          last_error?: string | null
          last_seen_at?: string | null
          phone_e164?: string | null
          qr_data_url?: string | null
          qr_expires_at?: string | null
          status?: string
          updated_at?: string
          workspace_id: string
        }
        Update: {
          connected_at?: string | null
          created_at?: string
          display_name?: string | null
          last_error?: string | null
          last_seen_at?: string | null
          phone_e164?: string | null
          qr_data_url?: string | null
          qr_expires_at?: string | null
          status?: string
          updated_at?: string
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "whatsapp_bridge_sessions_workspace_id_fkey"
            columns: ["workspace_id"]
            isOneToOne: true
            referencedRelation: "workspaces"
            referencedColumns: ["id"]
          },
        ]
      }
      whatsapp_delivery_logs: {
        Row: {
          attempts: number
          campaign_id: string | null
          contact_id: string | null
          conversation_id: string | null
          created_at: string
          http_status: number | null
          id: string
          language: string | null
          latency_ms: number | null
          message_type: string | null
          meta_code: number | null
          meta_details: string | null
          meta_message: string | null
          meta_subcode: number | null
          meta_title: string | null
          meta_trace_id: string | null
          ok: boolean
          purpose: string
          recipient_id: string | null
          request_summary: Json | null
          retryable: boolean
          template_name: string | null
          to_phone: string | null
          wa_message_id: string | null
          workspace_id: string
        }
        Insert: {
          attempts?: number
          campaign_id?: string | null
          contact_id?: string | null
          conversation_id?: string | null
          created_at?: string
          http_status?: number | null
          id?: string
          language?: string | null
          latency_ms?: number | null
          message_type?: string | null
          meta_code?: number | null
          meta_details?: string | null
          meta_message?: string | null
          meta_subcode?: number | null
          meta_title?: string | null
          meta_trace_id?: string | null
          ok: boolean
          purpose: string
          recipient_id?: string | null
          request_summary?: Json | null
          retryable?: boolean
          template_name?: string | null
          to_phone?: string | null
          wa_message_id?: string | null
          workspace_id: string
        }
        Update: {
          attempts?: number
          campaign_id?: string | null
          contact_id?: string | null
          conversation_id?: string | null
          created_at?: string
          http_status?: number | null
          id?: string
          language?: string | null
          latency_ms?: number | null
          message_type?: string | null
          meta_code?: number | null
          meta_details?: string | null
          meta_message?: string | null
          meta_subcode?: number | null
          meta_title?: string | null
          meta_trace_id?: string | null
          ok?: boolean
          purpose?: string
          recipient_id?: string | null
          request_summary?: Json | null
          retryable?: boolean
          template_name?: string | null
          to_phone?: string | null
          wa_message_id?: string | null
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "whatsapp_delivery_logs_campaign_id_fkey"
            columns: ["campaign_id"]
            isOneToOne: false
            referencedRelation: "campaigns"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "whatsapp_delivery_logs_workspace_id_fkey"
            columns: ["workspace_id"]
            isOneToOne: false
            referencedRelation: "workspaces"
            referencedColumns: ["id"]
          },
        ]
      }
      whatsapp_group_members: {
        Row: {
          contact_id: string | null
          created_at: string
          display_name: string | null
          group_id: string
          id: string
          is_admin: boolean
          phone_e164: string | null
          updated_at: string
          wa_jid: string
          workspace_id: string
        }
        Insert: {
          contact_id?: string | null
          created_at?: string
          display_name?: string | null
          group_id: string
          id?: string
          is_admin?: boolean
          phone_e164?: string | null
          updated_at?: string
          wa_jid: string
          workspace_id: string
        }
        Update: {
          contact_id?: string | null
          created_at?: string
          display_name?: string | null
          group_id?: string
          id?: string
          is_admin?: boolean
          phone_e164?: string | null
          updated_at?: string
          wa_jid?: string
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "whatsapp_group_members_contact_id_fkey"
            columns: ["contact_id"]
            isOneToOne: false
            referencedRelation: "contacts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "whatsapp_group_members_group_id_fkey"
            columns: ["group_id"]
            isOneToOne: false
            referencedRelation: "whatsapp_groups"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "whatsapp_group_members_workspace_id_fkey"
            columns: ["workspace_id"]
            isOneToOne: false
            referencedRelation: "workspaces"
            referencedColumns: ["id"]
          },
        ]
      }
      whatsapp_groups: {
        Row: {
          contact_group_id: string | null
          created_at: string
          description: string | null
          id: string
          is_imported: boolean
          last_synced_at: string | null
          name: string
          participant_count: number
          updated_at: string
          wa_group_id: string
          workspace_id: string
        }
        Insert: {
          contact_group_id?: string | null
          created_at?: string
          description?: string | null
          id?: string
          is_imported?: boolean
          last_synced_at?: string | null
          name: string
          participant_count?: number
          updated_at?: string
          wa_group_id: string
          workspace_id: string
        }
        Update: {
          contact_group_id?: string | null
          created_at?: string
          description?: string | null
          id?: string
          is_imported?: boolean
          last_synced_at?: string | null
          name?: string
          participant_count?: number
          updated_at?: string
          wa_group_id?: string
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "whatsapp_groups_contact_group_id_fkey"
            columns: ["contact_group_id"]
            isOneToOne: false
            referencedRelation: "contact_groups"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "whatsapp_groups_workspace_id_fkey"
            columns: ["workspace_id"]
            isOneToOne: false
            referencedRelation: "workspaces"
            referencedColumns: ["id"]
          },
        ]
      }
      whatsapp_settings: {
        Row: {
          access_token: string | null
          business_phone: string | null
          display_name: string | null
          phone_number_id: string | null
          updated_at: string
          user_id: string
          verified: boolean
          waba_id: string | null
          workspace_id: string
        }
        Insert: {
          access_token?: string | null
          business_phone?: string | null
          display_name?: string | null
          phone_number_id?: string | null
          updated_at?: string
          user_id: string
          verified?: boolean
          waba_id?: string | null
          workspace_id: string
        }
        Update: {
          access_token?: string | null
          business_phone?: string | null
          display_name?: string | null
          phone_number_id?: string | null
          updated_at?: string
          user_id?: string
          verified?: boolean
          waba_id?: string | null
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "whatsapp_settings_workspace_id_fkey"
            columns: ["workspace_id"]
            isOneToOne: true
            referencedRelation: "workspaces"
            referencedColumns: ["id"]
          },
        ]
      }
      workspace_invitations: {
        Row: {
          accepted_at: string | null
          created_at: string
          email: string
          expires_at: string
          id: string
          invited_by: string
          role: Database["public"]["Enums"]["app_role"]
          token: string
          workspace_id: string
        }
        Insert: {
          accepted_at?: string | null
          created_at?: string
          email: string
          expires_at?: string
          id?: string
          invited_by: string
          role?: Database["public"]["Enums"]["app_role"]
          token?: string
          workspace_id: string
        }
        Update: {
          accepted_at?: string | null
          created_at?: string
          email?: string
          expires_at?: string
          id?: string
          invited_by?: string
          role?: Database["public"]["Enums"]["app_role"]
          token?: string
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "workspace_invitations_workspace_id_fkey"
            columns: ["workspace_id"]
            isOneToOne: false
            referencedRelation: "workspaces"
            referencedColumns: ["id"]
          },
        ]
      }
      workspace_members: {
        Row: {
          created_at: string
          id: string
          is_active: boolean
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
          workspace_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          is_active?: boolean
          role?: Database["public"]["Enums"]["app_role"]
          user_id: string
          workspace_id: string
        }
        Update: {
          created_at?: string
          id?: string
          is_active?: boolean
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "workspace_members_workspace_id_fkey"
            columns: ["workspace_id"]
            isOneToOne: false
            referencedRelation: "workspaces"
            referencedColumns: ["id"]
          },
        ]
      }
      workspace_plans: {
        Row: {
          assigned_by: string | null
          billing_interval: string
          created_at: string
          currency: string
          expires_at: string | null
          features: Json
          id: string
          limits: Json
          notes: string | null
          plan_name: string
          price_monthly: number
          price_yearly: number
          starts_at: string | null
          updated_at: string
          workspace_id: string
        }
        Insert: {
          assigned_by?: string | null
          billing_interval?: string
          created_at?: string
          currency?: string
          expires_at?: string | null
          features?: Json
          id?: string
          limits?: Json
          notes?: string | null
          plan_name?: string
          price_monthly?: number
          price_yearly?: number
          starts_at?: string | null
          updated_at?: string
          workspace_id: string
        }
        Update: {
          assigned_by?: string | null
          billing_interval?: string
          created_at?: string
          currency?: string
          expires_at?: string | null
          features?: Json
          id?: string
          limits?: Json
          notes?: string | null
          plan_name?: string
          price_monthly?: number
          price_yearly?: number
          starts_at?: string | null
          updated_at?: string
          workspace_id?: string
        }
        Relationships: []
      }
      workspaces: {
        Row: {
          allow_team_user_creation: boolean
          created_at: string
          id: string
          name: string
          owner_id: string
          slug: string
          updated_at: string
        }
        Insert: {
          allow_team_user_creation?: boolean
          created_at?: string
          id?: string
          name: string
          owner_id: string
          slug: string
          updated_at?: string
        }
        Update: {
          allow_team_user_creation?: boolean
          created_at?: string
          id?: string
          name?: string
          owner_id?: string
          slug?: string
          updated_at?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      admin_adjust_ai_credits: {
        Args: {
          _actor?: string
          _delta: number
          _entry_type: string
          _notes?: string
          _workspace_id: string
        }
        Returns: number
      }
      admin_delete_user_data: { Args: { _user_id: string }; Returns: undefined }
      admin_delete_workspace: {
        Args: { _workspace_id: string }
        Returns: undefined
      }
      claim_cart_reminder: {
        Args: {
          _cart_id: string
          _cart_token: string
          _phone_key: string
          _window_minutes: number
          _workspace_id: string
        }
        Returns: boolean
      }
      cleanup_debug_logs: { Args: never; Returns: undefined }
      consume_ai_credits: {
        Args: {
          _amount: number
          _feature: string
          _meta?: Json
          _model: string
          _workspace_id: string
        }
        Returns: {
          balance_after: number
          ok: boolean
        }[]
      }
      generate_license_key: { Args: never; Returns: string }
      get_workspace_role: {
        Args: { _user_id: string; _workspace_id: string }
        Returns: Database["public"]["Enums"]["app_role"]
      }
      has_workspace_role: {
        Args: {
          _roles: Database["public"]["Enums"]["app_role"][]
          _user_id: string
          _workspace_id: string
        }
        Returns: boolean
      }
      is_super_admin: { Args: { _user_id: string }; Returns: boolean }
      is_workspace_member: {
        Args: { _user_id: string; _workspace_id: string }
        Returns: boolean
      }
      normalize_phone: { Args: { p: string }; Returns: string }
      phone_match_key: { Args: { p: string }; Returns: string }
      release_cart_reminder: {
        Args: { _cart_id: string; _phone_key: string; _workspace_id: string }
        Returns: undefined
      }
      resolve_conversation: {
        Args: {
          _contact_id?: string
          _last_message_at?: string
          _name?: string
          _phone: string
          _workspace_id: string
        }
        Returns: string
      }
      upsert_contact: {
        Args: {
          _city?: string
          _custom_fields?: Json
          _email?: string
          _lead_source?: string
          _name: string
          _phone: string
          _tags?: string[]
          _user_id?: string
          _workspace_id: string
        }
        Returns: string
      }
      upsert_contacts_bulk: {
        Args: { _rows: Json; _user_id: string; _workspace_id: string }
        Returns: {
          id: string
          phone: string
        }[]
      }
    }
    Enums: {
      app_role: "owner" | "admin" | "agent" | "viewer"
      automation_type: "welcome" | "away" | "keyword" | "routing"
      campaign_status:
        | "draft"
        | "scheduled"
        | "sending"
        | "completed"
        | "failed"
      conversation_status: "open" | "pending" | "resolved"
      message_direction: "in" | "out"
      message_type:
        | "text"
        | "image"
        | "video"
        | "document"
        | "audio"
        | "location"
        | "note"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["owner", "admin", "agent", "viewer"],
      automation_type: ["welcome", "away", "keyword", "routing"],
      campaign_status: ["draft", "scheduled", "sending", "completed", "failed"],
      conversation_status: ["open", "pending", "resolved"],
      message_direction: ["in", "out"],
      message_type: [
        "text",
        "image",
        "video",
        "document",
        "audio",
        "location",
        "note",
      ],
    },
  },
} as const
