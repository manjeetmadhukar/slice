import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useState, useEffect } from "react";
import { z } from "zod";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { Loader2, Check, Sparkles } from "lucide-react";

export const Route = createFileRoute("/signup")({
  component: SignupPage,
  head: () => ({
    meta: [
      { title: "Start your 7-day free trial — Slice" },
      {
        name: "description",
        content: "Create your Slice account in 30 seconds. 7-day free trial. No credit card required.",
      },
    ],
  }),
});

const schema = z.object({
  full_name: z.string().trim().min(1, "Name is required").max(120),
  email: z.string().trim().email("Enter a valid email").max(255),
  phone: z.string().trim().min(6, "Enter a valid phone").max(40),
  company: z.string().trim().max(120).optional().or(z.literal("")),
  password: z.string().min(6, "Min. 6 characters").max(72),
});

function SignupPage() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [form, setForm] = useState({
    full_name: "",
    email: "",
    phone: "",
    company: "",
    password: "",
  });

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      if (data.session) navigate({ to: "/dashboard" });
    });
  }, [navigate]);

  function set<K extends keyof typeof form>(k: K, v: string) {
    setForm((f) => ({ ...f, [k]: v }));
  }

  async function submit() {
    const parsed = schema.safeParse(form);
    if (!parsed.success) {
      toast.error(parsed.error.issues[0].message);
      return;
    }
    setLoading(true);
    try {
      const { error } = await supabase.auth.signUp({
        email: form.email,
        password: form.password,
        options: {
          emailRedirectTo: window.location.origin,
          data: {
            full_name: form.full_name,
            phone: form.phone,
            company: form.company,
          },
        },
      });
      if (error) throw error;
      toast.success("Account created! Please check your email to verify, then sign in.");
      navigate({ to: "/login" });
    } catch (e: any) {
      toast.error(e.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="grid min-h-screen lg:grid-cols-2">
      {/* Left: brand panel */}
      <div className="relative hidden overflow-hidden bg-[image:var(--gradient-hero)] p-12 text-primary-foreground lg:flex lg:flex-col lg:justify-between">
        <div className="pointer-events-none absolute -right-32 -top-32 h-96 w-96 rounded-full bg-white/10 blur-3xl" />
        <div className="pointer-events-none absolute -bottom-32 -left-32 h-96 w-96 rounded-full bg-white/10 blur-3xl" />

        <Link to="/" className="relative flex items-center gap-2">
          <img src="/slice-logo.png" alt="Slice" className="h-10 w-10 rounded-lg bg-white/10 object-contain p-1" />
          <span className="font-display text-xl font-bold">Slice</span>
        </Link>

        <div className="relative">
          <Sparkles className="h-8 w-8 opacity-80" />
          <h2 className="mt-4 font-display text-4xl font-bold leading-tight">
            Your 7-day free trial<br />starts in 30 seconds.
          </h2>
          <p className="mt-4 max-w-md text-base opacity-90">
            Instant access to the full Slice platform — multi-agent inbox, automations, campaigns, and CRM. No card, no hassle.
          </p>
          <ul className="mt-8 space-y-3">
            {[
              "Connect your Meta WhatsApp Business account",
              "Import contacts & send your first campaign",
              "Build automation flows & chatbots",
              "Recover abandoned carts on autopilot",
            ].map((t) => (
              <li key={t} className="flex items-center gap-2.5 text-sm">
                <span className="grid h-5 w-5 place-items-center rounded-full bg-white/20">
                  <Check className="h-3 w-3" />
                </span>
                {t}
              </li>
            ))}
          </ul>
        </div>

        <p className="relative text-xs opacity-70">© 2026 Slice by Dotscube</p>
      </div>

      {/* Right: form */}
      <div className="flex flex-col justify-center bg-background px-6 py-12 sm:px-12">
        <div className="mx-auto w-full max-w-md">
          <Link to="/" className="mb-8 flex items-center gap-2 lg:hidden">
            <img src="/slice-logo.png" alt="Slice" className="h-9 w-9 rounded-lg object-contain" />
            <span className="font-display text-lg font-bold">Slice</span>
          </Link>

          <h1 className="font-display text-3xl font-bold">Create your account</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            7-day free trial. No credit card required.
          </p>

          <div className="mt-8 space-y-4">
            <div className="space-y-1.5">
              <Label>Full name</Label>
              <Input value={form.full_name} onChange={(e) => set("full_name", e.target.value)} placeholder="Jane Doe" />
            </div>
            <div className="space-y-1.5">
              <Label>Work email</Label>
              <Input type="email" value={form.email} onChange={(e) => set("email", e.target.value)} placeholder="jane@company.com" />
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-1.5">
                <Label>Phone</Label>
                <Input value={form.phone} onChange={(e) => set("phone", e.target.value)} placeholder="+91 98xxx" />
              </div>
              <div className="space-y-1.5">
                <Label>Company</Label>
                <Input value={form.company} onChange={(e) => set("company", e.target.value)} placeholder="Acme Inc." />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label>Password</Label>
              <Input
                type="password"
                value={form.password}
                onChange={(e) => set("password", e.target.value)}
                placeholder="Min. 6 characters"
              />
            </div>

            <Button className="w-full shadow-[var(--shadow-glow)]" size="lg" disabled={loading} onClick={submit}>
              {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Start free trial
            </Button>

            <p className="text-center text-xs text-muted-foreground">
              By signing up you agree to our terms and privacy policy.
            </p>

            <div className="border-t pt-4 text-center text-sm">
              Already have an account?{" "}
              <Link to="/login" className="font-medium text-primary hover:underline">
                Sign in
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
