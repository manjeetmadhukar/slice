import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useState, useEffect } from "react";
import { z } from "zod";
import { useServerFn } from "@tanstack/react-start";
import { supabase } from "@/integrations/supabase/client";
import { resolveUsernameToEmail } from "@/lib/login-resolver.functions";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { toast } from "sonner";
import { MessageCircle, Loader2 } from "lucide-react";


export const Route = createFileRoute("/login")({
  component: LoginPage,
  head: () => ({ meta: [{ title: "Sign in — Slice" }] }),
});

const credsSchema = z.object({
  identifier: z.string().trim().min(1).max(255),
  password: z.string().min(6).max(72),
});


function LoginPage() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [identifier, setIdentifier] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [fullName, setFullName] = useState("");
  const [forgotOpen, setForgotOpen] = useState(false);
  const [forgotEmail, setForgotEmail] = useState("");
  const [forgotLoading, setForgotLoading] = useState(false);
  const resolveFn = useServerFn(resolveUsernameToEmail);

  async function sendReset() {
    const target = forgotEmail.trim();
    if (!z.string().email().safeParse(target).success) {
      toast.error("Enter a valid email address");
      return;
    }
    setForgotLoading(true);
    try {
      const { error } = await supabase.auth.resetPasswordForEmail(target, {
        redirectTo: `${window.location.origin}/reset-password`,
      });
      if (error) throw error;
      toast.success("Password reset link sent. Check your email.");
      setForgotOpen(false);
    } catch (e: any) {
      toast.error(e.message);
    } finally {
      setForgotLoading(false);
    }
  }


  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      if (data.session) navigate({ to: "/dashboard" });
    });
  }, [navigate]);

  async function handle(mode: "signin" | "signup") {
    if (mode === "signin") {
      const parsed = credsSchema.safeParse({ identifier, password });
      if (!parsed.success) { toast.error(parsed.error.issues[0].message); return; }
    } else {
      if (!z.string().email().safeParse(email).success) { toast.error("Invalid email"); return; }
      if (password.length < 6) { toast.error("Password too short"); return; }
    }
    setLoading(true);
    try {
      if (mode === "signup") {
        const { error } = await supabase.auth.signUp({
          email, password,
          options: {
            emailRedirectTo: window.location.origin,
            data: { full_name: fullName || email.split("@")[0] },
          },
        });
        if (error) throw error;
        toast.success("Account created. Check your email to confirm, then sign in.");
      } else {
        // Resolve username to email if needed
        let loginEmail = identifier;
        if (!identifier.includes("@")) {
          const res = await resolveFn({ data: { username: identifier } });
          if (!res.email) throw new Error("No account found for that username");
          loginEmail = res.email;
        }
        const { error } = await supabase.auth.signInWithPassword({ email: loginEmail, password });
        if (error) throw error;
        navigate({ to: "/dashboard" });
      }
    } catch (e: any) {
      toast.error(e.message);
    } finally {
      setLoading(false);
    }
  }


  return (
    <div className="min-h-screen bg-[image:var(--gradient-subtle)]">
      <div className="container mx-auto flex min-h-screen max-w-md flex-col justify-center px-6 py-12">
        <Link to="/" className="mb-8 flex items-center gap-2 self-center">
          <img src="/slice-logo.png" alt="Slice" className="h-10 w-10 rounded-lg object-contain" />
          <span className="font-display text-xl font-bold">Slice</span>
        </Link>

        <div className="rounded-2xl border bg-card p-8 shadow-[var(--shadow-lg)]">
          <h1 className="text-center font-display text-2xl font-semibold">Welcome</h1>
          <p className="mt-1 text-center text-sm text-muted-foreground">
            Sign in to manage your WhatsApp campaigns
          </p>

          <Tabs defaultValue="signin" className="mt-6">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="signin">Sign in</TabsTrigger>
              <TabsTrigger value="signup">Create account</TabsTrigger>
            </TabsList>

            <TabsContent value="signin" className="space-y-4 pt-4">
              <div className="space-y-2">
                <Label>Email or username</Label>
                <Input value={identifier} onChange={(e) => setIdentifier(e.target.value)} placeholder="you@company.com or jane.doe" />
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label>Password</Label>
                  <button
                    type="button"
                    className="text-xs text-muted-foreground underline-offset-2 hover:text-foreground hover:underline"
                    onClick={() => {
                      setForgotEmail(identifier.includes("@") ? identifier : "");
                      setForgotOpen(true);
                    }}
                  >
                    Forgot password?
                  </button>
                </div>
                <Input type="password" value={password} onChange={(e) => setPassword(e.target.value)} />
              </div>
              <Button className="w-full" disabled={loading} onClick={() => handle("signin")}>
                {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                Sign in
              </Button>

            </TabsContent>

            <TabsContent value="signup" className="space-y-4 pt-4">
              <div className="space-y-2">
                <Label>Full name</Label>
                <Input value={fullName} onChange={(e) => setFullName(e.target.value)} placeholder="Jane Doe" />
              </div>
              <div className="space-y-2">
                <Label>Email</Label>
                <Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
              </div>
              <div className="space-y-2">
                <Label>Password</Label>
                <Input type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Min. 6 characters" />
              </div>
              <Button className="w-full" disabled={loading} onClick={() => handle("signup")}>
                {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                Create account
              </Button>
            </TabsContent>
          </Tabs>
        </div>
      </div>

      <Dialog open={forgotOpen} onOpenChange={setForgotOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Reset your password</DialogTitle>
            <DialogDescription>
              Enter your account email and we'll send you a link to set a new password.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-2">
            <Label>Email</Label>
            <Input
              type="email"
              value={forgotEmail}
              onChange={(e) => setForgotEmail(e.target.value)}
              placeholder="you@company.com"
            />
          </div>
          <DialogFooter>
            <Button disabled={forgotLoading} onClick={sendReset}>
              {forgotLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Send reset link
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>

  );
}
