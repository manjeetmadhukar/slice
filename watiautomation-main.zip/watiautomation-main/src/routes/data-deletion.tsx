import { createFileRoute, Link } from "@tanstack/react-router";

export const Route = createFileRoute("/data-deletion")({
  component: DataDeletionPage,
  head: () => ({
    meta: [
      { title: "User Data Deletion — Slice" },
      { name: "description", content: "How to request deletion of your Slice account and associated data." },
      { property: "og:title", content: "User Data Deletion — Slice" },
      { property: "og:description", content: "How to request deletion of your Slice account and associated data." },
      { property: "og:url", content: "/data-deletion" },
    ],
    links: [{ rel: "canonical", href: "/data-deletion" }],
  }),
});

function DataDeletionPage() {
  return (
    <main className="min-h-screen bg-background">
      <div className="container mx-auto max-w-3xl px-6 py-16">
        <Link to="/" className="text-sm text-muted-foreground hover:text-foreground">← Back to home</Link>
        <h1 className="font-display text-4xl font-bold tracking-tight mt-6">User Data Deletion</h1>
        <p className="text-muted-foreground mt-2">Last updated: June 3, 2026</p>

        <div className="mt-8 max-w-none space-y-6 text-sm leading-relaxed">
          <section>
            <p>
              Slice, operated by Dotscube, lets you delete your account and the personal data
              associated with it at any time. This page explains how.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold">Option 1 — Delete from the app</h2>
            <ol className="list-decimal pl-5 space-y-1">
              <li>Sign in to your Slice account.</li>
              <li>Go to <span className="font-medium">Settings → Workspace</span>.</li>
              <li>Click <span className="font-medium">Delete workspace</span> and confirm.</li>
            </ol>
            <p className="mt-2 text-muted-foreground">
              This permanently removes your workspace, contacts, conversations, templates, and
              campaigns. WhatsApp numbers are disconnected from our platform; your underlying
              Meta WhatsApp Business Account remains in Meta Business Manager.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold">Option 2 — Email request</h2>
            <p>
              Send an email from the address linked to your account to
              <a href="mailto:slice@dotscube.com?subject=Data%20deletion%20request" className="underline ml-1">slice@dotscube.com</a>
              with the subject “Data deletion request”. Please include:
            </p>
            <ul className="list-disc pl-5 space-y-1">
              <li>Your registered email address</li>
              <li>Your workspace name</li>
              <li>The WhatsApp phone number(s) connected, if any</li>
            </ul>
            <p className="mt-2">
              We will confirm and complete the deletion within <span className="font-medium">7 business days</span>.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold">What gets deleted</h2>
            <ul className="list-disc pl-5 space-y-1">
              <li>Account profile, workspace, team members</li>
              <li>Contacts, conversations, messages, media</li>
              <li>Templates, campaigns, automations, bots</li>
              <li>WhatsApp access tokens and integration credentials</li>
            </ul>
            <p className="mt-2 text-muted-foreground">
              Some information may be retained where required by law (e.g. invoicing records) or in
              de-identified aggregated form.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold">Questions</h2>
            <p>
              Contact us at <a href="mailto:slice@dotscube.com" className="underline">slice@dotscube.com</a> or
              call +91 96022 99003.
            </p>
          </section>
        </div>
      </div>
    </main>
  );
}
