// Public API: retrieve Interested Leads (template Quick Reply button clicks)
// with pagination + filters.
//
//   GET /api/public/interested-leads?workspace_id=...&page=1&page_size=50
//   Headers: Authorization: Bearer <Slice user access token>
//
// Filters: search, from, to, campaign_id, template_name, button_text
// Access is enforced by row-level security using the caller's own token, so
// workspace users only see their workspace and super admins see everything.
import { createFileRoute } from "@tanstack/react-router";
import { createClient } from "@supabase/supabase-js";
import type { Database } from "@/integrations/supabase/types";

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, content-type",
  "Access-Control-Allow-Methods": "GET, OPTIONS",
};

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "Content-Type": "application/json", ...CORS },
  });
}

export const Route = createFileRoute("/api/public/interested-leads")({
  server: {
    handlers: {
      OPTIONS: async () => new Response(null, { status: 204, headers: CORS }),
      GET: async ({ request }) => {
        const auth = request.headers.get("authorization") || "";
        if (!auth.startsWith("Bearer ")) {
          return json({ error: "Missing Bearer token" }, 401);
        }
        const token = auth.slice(7).trim();
        const url = process.env.SUPABASE_URL;
        const key = process.env.SUPABASE_PUBLISHABLE_KEY || process.env.SUPABASE_ANON_KEY;
        if (!url || !key) return json({ error: "Server not configured" }, 500);

        const supabase = createClient<Database>(url, key, {
          global: { headers: { Authorization: `Bearer ${token}` } },
          auth: { storage: undefined, persistSession: false, autoRefreshToken: false },
        });

        const { data: userData, error: userErr } = await supabase.auth.getUser(token);
        if (userErr || !userData?.user) return json({ error: "Invalid token" }, 401);

        const q = new URL(request.url).searchParams;
        const page = Math.max(1, Number(q.get("page") || 1));
        const pageSize = Math.min(500, Math.max(1, Number(q.get("page_size") || 50)));
        const start = (page - 1) * pageSize;

        let query = supabase
          .from("template_button_clicks" as any)
          .select(
            "id, workspace_id, contact_id, contact_name, phone, campaign_id, template_name, button_text, button_payload, button_type, clicked_at",
            { count: "exact" },
          );

        const workspaceId = q.get("workspace_id");
        if (workspaceId) query = query.eq("workspace_id", workspaceId);
        const from = q.get("from");
        if (from) query = query.gte("clicked_at", from);
        const to = q.get("to");
        if (to) query = query.lte("clicked_at", to);
        const campaignId = q.get("campaign_id");
        if (campaignId) query = query.eq("campaign_id", campaignId);
        const templateName = q.get("template_name");
        if (templateName) query = query.eq("template_name", templateName);
        const buttonText = q.get("button_text");
        if (buttonText) query = query.eq("button_text", buttonText);
        const search = q.get("search");
        if (search) {
          const s = search.replace(/[%,()]/g, " ").trim();
          const digits = s.replace(/\D/g, "");
          const parts = [`contact_name.ilike.%${s}%`, `phone.ilike.%${s}%`];
          if (digits) parts.push(`phone_normalized.ilike.%${digits}%`);
          query = query.or(parts.join(","));
        }

        const { data, count, error } = await query
          .order("clicked_at", { ascending: false })
          .range(start, start + pageSize - 1);
        if (error) return json({ error: error.message }, 400);

        return json({
          data: data ?? [],
          pagination: {
            page,
            page_size: pageSize,
            total: count ?? 0,
            total_pages: Math.max(1, Math.ceil((count ?? 0) / pageSize)),
          },
        });
      },
    },
  },
});
