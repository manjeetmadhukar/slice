import { createFileRoute } from "@tanstack/react-router";
import { createHmac, timingSafeEqual } from "crypto";
import { supabaseAdmin } from "@/integrations/supabase/client.server";
import { recordTemplateButtonClick } from "@/lib/button-clicks.server";
import { runAutomations } from "@/lib/automation-runner.server";
import { runBotForMessage } from "@/lib/bot-runner.server";
import { classifyWhatsAppDeliveryError } from "@/lib/whatsapp-delivery-status";

function verifyMetaSignature(rawBody: string, header: string | null): boolean {
  const appSecret = process.env.META_APP_SECRET;
  if (!appSecret || !header) return false;
  const sig = header.startsWith("sha256=") ? header.slice(7) : header;
  const expected = createHmac("sha256", appSecret).update(rawBody).digest("hex");
  try {
    const a = Buffer.from(sig, "hex");
    const b = Buffer.from(expected, "hex");
    if (a.length !== b.length) return false;
    return timingSafeEqual(a, b);
  } catch {
    return false;
  }
}

function getMessageTimestamp(msg: any): string {
  const seconds = Number(msg?.timestamp);
  if (Number.isFinite(seconds) && seconds > 0) return new Date(seconds * 1000).toISOString();
  return new Date().toISOString();
}

// Meta WhatsApp Cloud API webhook receiver.
// Configure the same URL in Meta Business > Webhooks for "messages" field.
// Verification token comes from env: WHATSAPP_VERIFY_TOKEN
export const Route = createFileRoute("/api/public/whatsapp-webhook")({
  server: {
    handlers: {
      // Meta verification handshake
      GET: async ({ request }) => {
        const url = new URL(request.url);
        const mode = url.searchParams.get("hub.mode");
        const token = url.searchParams.get("hub.verify_token");
        const challenge = url.searchParams.get("hub.challenge");
        const expected = process.env.WHATSAPP_VERIFY_TOKEN;
        if (mode === "subscribe" && expected && token === expected) {
          return new Response(challenge || "", { status: 200 });
        }
        return new Response("forbidden", { status: 403 });
      },
      POST: async ({ request }) => {
        const rawBody = await request.text();
        if (!verifyMetaSignature(rawBody, request.headers.get("x-hub-signature-256"))) {
          console.warn("[whatsapp-webhook] signature verification failed");
          return new Response("invalid signature", { status: 401 });
        }
        let payload: any;
        try { payload = JSON.parse(rawBody); }
        catch { return new Response("bad json", { status: 400 }); }

        try {
          for (const entry of payload.entry ?? []) {
            for (const change of entry.changes ?? []) {
              const value = change.value || {};
              const phoneNumberId: string | undefined = value.metadata?.phone_number_id;
              if (!phoneNumberId) continue;

              // Resolve workspace by phone_number_id. The same number can exist in
              // older workspace settings rows after reconnects, so never use
              // maybeSingle() here — pick the latest active account deterministically.
              const settings = await resolveWhatsAppConnection(phoneNumberId);
              if (!settings) {
                console.warn(`[whatsapp-webhook] no settings for phone_number_id=${phoneNumberId}`);
                continue;
              }


              const workspace_id = settings.workspace_id;
              const businessPhone: string | undefined = value.metadata?.display_phone_number
                ? normalizeWhatsAppPhone(value.metadata.display_phone_number)
                : undefined;

              const webhookPatch = { webhook_status: "verified", webhook_last_event_at: new Date().toISOString(), last_error: null };
              const webhookUpdate = supabaseAdmin.from("whatsapp_accounts").update(webhookPatch);
              if (settings.account_id) await webhookUpdate.eq("id", settings.account_id);
              else await webhookUpdate.eq("phone_number_id", phoneNumberId).eq("workspace_id", workspace_id);

              // Visibility log so users can confirm Meta is delivering events to this workspace.
              const inboundCount = Array.isArray(value.messages) ? value.messages.length : 0;
              const statusCount = Array.isArray(value.statuses) ? value.statuses.length : 0;
              await supabaseAdmin.from("integration_debug_logs").insert({
                workspace_id,
                provider: "whatsapp",
                event: inboundCount > 0
                  ? "webhook.inbound_messages"
                  : statusCount > 0
                  ? "webhook.delivery_status"
                  : "webhook.other",
                direction: "in",
                ok: true,
                status_code: 200,
                message: `inbound=${inboundCount} status=${statusCount} field=${change.field ?? "?"}`,
                payload: {
                  phone_number_id: phoneNumberId,
                  inbound_message_count: inboundCount,
                  status_count: statusCount,
                  contacts: value.contacts?.map((c: any) => ({ wa_id: c.wa_id, name: c.profile?.name })) ?? [],
                },
              }).then(() => {}, () => {});


              // Delivery status updates (sent / delivered / read / failed) for outbound messages.
              // Status events from Meta can arrive OUT OF ORDER (e.g. a late `delivered`
              // arrives after `read`). We enforce monotonic ranking so a higher status
              // (read > delivered > sent) is never overwritten by a lower one.
              const STATUS_RANK: Record<string, number> = { sent: 1, delivered: 2, read: 3, failed: 4, suppressed: 4 };
              for (const st of value.statuses ?? []) {
                const waId: string | undefined = st.id;
                const statusVal: string | undefined = st.status;
                if (!waId || !statusVal) continue;
                const nowIso = new Date().toISOString();
                const classifiedFailure = statusVal === "failed" ? classifyWhatsAppDeliveryError(st.errors) : null;
                const recipientStatus = classifiedFailure?.status || statusVal;
                const newRank = STATUS_RANK[recipientStatus] ?? STATUS_RANK[statusVal] ?? 0;

                // Log raw status payload for diagnostics (helps verify Meta sends reads)
                supabaseAdmin.from("integration_debug_logs").insert({
                  workspace_id,
                  provider: "whatsapp",
                  event: `webhook.status.${statusVal}`,
                  direction: "in",
                  ok: true,
                  status_code: 200,
                  message: `wamid=${waId} status=${statusVal}`,
                  payload: st,
                }).then(() => {}, () => {});

                // Look up current message status — only update if new status is higher rank
                const { data: existingMsg } = await supabaseAdmin
                  .from("messages")
                  .select("status")
                  .eq("wa_message_id", waId)
                  .maybeSingle();
                const currentRank = existingMsg?.status ? (STATUS_RANK[existingMsg.status] ?? 0) : 0;
                if (newRank >= currentRank) {
                  await supabaseAdmin
                    .from("messages")
                    .update({
                      status: recipientStatus,
                      status_updated_at: nowIso,
                      // Persist the exact Meta reason so the Inbox can show
                      // *why* a message failed instead of a bare red icon.
                      status_error: classifiedFailure?.error ?? null,
                      status_error_code: classifiedFailure?.code ?? null,
                    } as any)
                    .eq("wa_message_id", waId);
                }

                // Update campaign_recipients — set timestamp columns unconditionally
                // (they only go forward), but only bump `status` text if rank is higher.
                const recipientPatch: { status?: string; delivered_at?: string; read_at?: string; error?: string } = {};

                if (statusVal === "delivered") recipientPatch.delivered_at = nowIso;
                else if (statusVal === "read") {
                  recipientPatch.read_at = nowIso;
                  // ensure delivered_at is also set when read arrives without prior delivered
                  recipientPatch.delivered_at = nowIso;
                } else if (statusVal === "failed") {
                  recipientPatch.error = classifiedFailure?.error || "WhatsApp delivery failed";
                  // An abandoned-cart reminder that Meta refused to deliver
                  // (e.g. #131049 marketing cap) must go back into the queue —
                  // the dispatcher already stamped it as "sent".
                  if (classifiedFailure) {
                    const { reconcileCartReminderFailure } = await import("@/lib/cart-reminder-status.server");
                    await reconcileCartReminderFailure({
                      workspaceId: workspace_id,
                      waMessageId: waId,
                      recipientId: st.recipient_id ?? null,
                      classification: classifiedFailure,
                    });

                    const { reconcileBrowseReminderFailure } = await import("@/lib/browse-reminder-status.server");
                    await reconcileBrowseReminderFailure({
                      workspaceId: workspace_id,
                      waMessageId: waId,
                      classification: classifiedFailure,
                    });
                  }
                }


                // Read existing recipient status to decide whether to bump status text
                const { data: existingRec } = await supabaseAdmin
                  .from("campaign_recipients")
                  .select("status, delivered_at, read_at")
                  .eq("message_id", waId)
                  .maybeSingle();
                if (existingRec) {
                  const existingRank = STATUS_RANK[existingRec.status] ?? 0;
                  if (newRank >= existingRank) recipientPatch.status = recipientStatus;
                  // never null an existing delivered_at/read_at
                  if (existingRec.delivered_at && !recipientPatch.delivered_at) {
                    // keep prior
                  }
                }

                const { data: recRows } = await supabaseAdmin
                  .from("campaign_recipients")
                  .update(recipientPatch)
                  .eq("message_id", waId)
                  .select("campaign_id");

                const campaignIds = Array.from(new Set((recRows ?? []).map((r: any) => r.campaign_id).filter(Boolean)));
                for (const cid of campaignIds) {
                  const { data: agg } = await supabaseAdmin
                    .from("campaign_recipients")
                    .select("status, delivered_at, read_at")
                    .eq("campaign_id", cid);
                  const list = agg ?? [];
                  const delivered_count = list.filter((r: any) => r.delivered_at || r.status === "delivered" || r.status === "read").length;
                  const read_count = list.filter((r: any) => r.read_at || r.status === "read").length;
                  const failed_count = list.filter((r: any) => r.status === "failed").length;
                  await supabaseAdmin
                    .from("campaigns")
                    .update({ delivered_count, read_count, failed_count })
                    .eq("id", cid);
                }
              }


              // Combine inbound messages, outbound echoes, and Coexistence history.
              // Existing WhatsApp Business App users can send/receive messages through
              // `history` and `smb_message_echoes`, not just the standard `messages` field.
              const historyMsgs: Array<{ msg: any; direction: "in" | "out" }> = [];
              for (const h of value.history ?? []) {
                for (const thread of h?.threads ?? []) {
                  const threadPhone = thread?.id;
                  for (const hm of thread?.messages ?? []) {
                    const fromPhone = normalizeWhatsAppPhone(hm?.from || "");
                    const isBusiness = businessPhone ? fromPhone === businessPhone : !!hm?.to;
                    historyMsgs.push({
                      msg: {
                        ...hm,
                        to: hm?.to || (isBusiness ? threadPhone : value.metadata?.display_phone_number),
                        history_thread_id: threadPhone,
                      },
                      direction: isBusiness ? "out" : "in",
                    });
                  }
                }
              }

              const inboundMsgs = (value.messages ?? []).map((m: any) => ({ msg: m, direction: "in" as const }));
              const echoMsgs: Array<{ msg: any; direction: "out" }> = [
                ...(value.message_echoes ?? []),
                ...(value.smb_message_echoes ?? []),
              ].map((m: any) => ({ msg: m, direction: "out" as const }));

              // Some accounts deliver echoes inside value.messages where msg.from === business number
              const filteredInbound = inboundMsgs.filter((x: { msg: any; direction: "in" }) => {
                if (!businessPhone) return true;
                if (normalizeWhatsAppPhone(x.msg.from) === businessPhone) {
                  echoMsgs.push({ msg: x.msg, direction: "out" });
                  return false;
                }
                return true;
              });

              for (const { msg, direction } of [...filteredInbound, ...echoMsgs, ...historyMsgs]) {
                // ----- Reactions: update the target message instead of creating a new row -----
                if (msg.type === "reaction" && msg.reaction?.message_id) {
                  const targetWaId = msg.reaction.message_id;
                  const emoji = msg.reaction.emoji ?? "";
                  const reactor = direction === "in"
                    ? normalizeWhatsAppPhone(msg.from || "")
                    : "me";
                  const { data: target } = await supabaseAdmin
                    .from("messages").select("id, reactions")
                    .eq("workspace_id", workspace_id)
                    .eq("wa_message_id", targetWaId).maybeSingle();
                  if (target) {
                    const current: Array<{ by: string; emoji: string }> =
                      Array.isArray((target as any).reactions) ? (target as any).reactions : [];
                    const filtered = current.filter((r) => r.by !== reactor);
                    const next = emoji ? [...filtered, { by: reactor, emoji }] : filtered;
                    await supabaseAdmin.from("messages")
                      .update({ reactions: next }).eq("id", target.id);
                  }
                  continue;
                }

                // Inbound: contact = sender (from). Outbound echo: contact = recipient (to / recipient_id).
                const counterpartyRaw: string | undefined =
                  direction === "in"
                    ? msg.from
                    : msg.to || msg.recipient_id || msg.recipient || msg.history_thread_id || value.contacts?.[0]?.wa_id;
                if (!counterpartyRaw) continue;
                const contactPhone = normalizeWhatsAppPhone(counterpartyRaw);
                const contactName: string | undefined =
                  value.contacts?.find((c: any) => c.wa_id === counterpartyRaw)?.profile?.name
                  || value.contacts?.[0]?.profile?.name;

                const { data: upsertedId } = await supabaseAdmin.rpc("upsert_contact", {
                  _workspace_id: workspace_id,
                  _name: contactName || contactPhone,
                  _phone: contactPhone,
                  _user_id: settings.user_id,
                } as any);
                let matchedContact: { id: string; name: string; phone: string } | null = null;
                if (upsertedId) {
                  const { data: row } = await supabaseAdmin
                    .from("contacts")
                    .select("id, name, phone")
                    .eq("id", upsertedId as any)
                    .maybeSingle();
                  matchedContact = (row as any) ?? null;
                }

                // Skip duplicates (echo can race with our own outbound insert)
                if (msg.id) {
                  const { data: existing } = await supabaseAdmin
                    .from("messages").select("id").eq("wa_message_id", msg.id).maybeSingle();
                  if (existing) continue;
                }

                // If we matched an existing contact by digit-suffix, reuse its stored phone
                // so we don't split into a separate conversation row.
                let convoPhone = contactPhone;
                if (matchedContact?.phone) {
                  const existingConvoPhone = normalizeWhatsAppPhone(matchedContact.phone);
                  const { data: existingConvo } = await supabaseAdmin
                    .from("conversations")
                    .select("id, contact_phone")
                    .eq("workspace_id", workspace_id)
                    .eq("contact_id", matchedContact.id)
                    .maybeSingle();
                  if (existingConvo?.contact_phone) convoPhone = existingConvo.contact_phone;
                  else convoPhone = existingConvoPhone;
                }

                // Resolve conversation (one per WhatsApp number, matched by phone key)
                const { data: resolvedConvoId, error: resolveErr } = await supabaseAdmin.rpc(
                  "resolve_conversation",
                  {
                    _workspace_id: workspace_id,
                    _phone: convoPhone,
                    _name: matchedContact?.name || contactName || contactPhone,
                    _contact_id: matchedContact?.id ?? null,
                    _last_message_at: getMessageTimestamp(msg),
                  } as any,
                );
                const { data: convo, error: convoSelErr } = resolvedConvoId
                  ? await supabaseAdmin.from("conversations").select("*").eq("id", resolvedConvoId as any).single()
                  : { data: null, error: resolveErr } as any;
                const convoErr = convoSelErr || resolveErr;
                if (!convo) {
                  supabaseAdmin.from("integration_debug_logs").insert({
                    workspace_id,
                    provider: "whatsapp",
                    event: "webhook.conversation_upsert_failed",
                    direction: "in",
                    ok: false,
                    status_code: 500,
                    message: `Failed to upsert conversation for ${contactPhone}: ${convoErr?.message || "unknown"}`,
                    payload: { contactPhone, error: convoErr?.message || String(convoErr || "") },
                  }).then(() => {}, () => {});
                  continue;
                }

                let type: string = msg.type;
                let content: string | null = null;
                let media_url: string | null = null;
                let media_mime: string | null = null;

                if (type === "text") content = msg.text?.body ?? null;
                else if (type === "button") {
                  content = msg.button?.text || msg.button?.payload || "Button reply";
                } else if (type === "interactive") {
                  const buttonReply = msg.interactive?.button_reply;
                  const listReply = msg.interactive?.list_reply;
                  content = buttonReply?.title || buttonReply?.id || listReply?.title || listReply?.id || "Interactive reply";
                } else if (type === "template") {
                  content = templatePreview(msg.template) || "Template message";
                }
                else if (["image", "video", "audio", "document", "sticker"].includes(type)) {
                  const m = msg[type];
                  content = m?.caption ?? m?.filename ?? null;
                  media_mime = m?.mime_type ?? null;
                  if (m?.id && settings.access_token) {
                    media_url = await downloadMediaToBucket({
                      mediaId: m.id,
                      mime: media_mime,
                      filename: m?.filename,
                      accessToken: settings.access_token,
                      workspaceId: workspace_id,
                    });
                  }
                } else if (type === "location") {
                  const lat = msg.location?.latitude;
                  const lng = msg.location?.longitude;
                  const name = msg.location?.name;
                  const addr = msg.location?.address;
                  const parts = [name, addr, (lat != null && lng != null) ? `📍 ${lat}, ${lng}` : null].filter(Boolean);
                  content = parts.join("\n") || "Location shared";
                } else if (type === "contacts") {
                  const list = Array.isArray(msg.contacts) ? msg.contacts : [];
                  const lines = list.map((c: any) => {
                    const nm = c?.name?.formatted_name || [c?.name?.first_name, c?.name?.last_name].filter(Boolean).join(" ") || "Contact";
                    const phones = (c?.phones || []).map((p: any) => p?.phone).filter(Boolean).join(", ");
                    return phones ? `${nm} — ${phones}` : nm;
                  });
                  content = `📇 Shared contact${list.length > 1 ? "s" : ""}:\n${lines.join("\n")}`;
                } else if (type === "order") {
                  const items = Array.isArray(msg.order?.product_items) ? msg.order.product_items : [];
                  const total = items.reduce((s: number, it: any) => s + Number(it?.item_price || 0) * Number(it?.quantity || 0), 0);
                  const cur = items[0]?.currency || "";
                  content = `🛒 Order with ${items.length} item(s)${total ? ` · Total ${cur} ${total.toFixed(2)}` : ""}`;
                } else if (type === "system") {
                  content = msg.system?.body || "System notification";
                } else if (type === "request_welcome") {
                  content = "👋 Conversation opened";
                } else if (type === "reaction") {
                  // already handled above via continue; safety fallback
                  content = msg.reaction?.emoji || "Reaction";
                } else if (type === "unsupported") {
                  const errDesc = msg.errors?.[0]?.title || msg.errors?.[0]?.message || msg.errors?.[0]?.error_data?.details;
                  content = errDesc
                    ? `⚠️ ${errDesc}`
                    : "⚠️ This message type isn't supported on WhatsApp Business API yet. Ask the sender to resend as text, image, video, audio or document.";
                } else {
                  // Last-resort fallback: try to extract any meaningful text instead of "[unknown]"
                  const extracted =
                    msg.text?.body ||
                    msg[type]?.caption ||
                    msg[type]?.body ||
                    msg[type]?.text ||
                    null;
                  content = extracted || `⚠️ Received a ${type || "new"} message that can't be previewed here.`;
                }

                // Diagnostic: log raw payload for any non-standard inbound type so we can debug
                // future "unknown" messages and improve handling.
                const STANDARD_TYPES = new Set([
                  "text","image","video","audio","document","sticker","location","button","interactive","template","reaction",
                ]);
                if (direction === "in" && !STANDARD_TYPES.has(type)) {
                  supabaseAdmin.from("integration_debug_logs").insert({
                    workspace_id,
                    provider: "whatsapp",
                    event: `webhook.inbound.${type || "unknown"}`,
                    direction: "in",
                    ok: true,
                    status_code: 200,
                    message: `Non-standard inbound type=${type || "unknown"} from ${contactPhone}`,
                    payload: msg,
                  }).then(() => {}, () => {});
                }

                const normType = ["text", "image", "video", "audio", "document", "location"].includes(type)
                  ? (type as any) : (type === "sticker" ? "image" : "text");

                // Capture reply-to context (Meta sends msg.context.id for replies)
                let reply_to_wa_message_id: string | null = msg.context?.id ?? null;
                let reply_to_preview: string | null = null;
                if (reply_to_wa_message_id) {
                  const { data: refMsg } = await supabaseAdmin
                    .from("messages").select("content, type")
                    .eq("workspace_id", workspace_id)
                    .eq("wa_message_id", reply_to_wa_message_id).maybeSingle();
                  if (refMsg) {
                    reply_to_preview = (refMsg.content || `[${refMsg.type}]`).slice(0, 120);
                  }
                }

                // Prepend ad referral context (Click-to-WhatsApp / Meta ads) so the
                // user can see which ad the lead came from.
                let finalContent = content;
                if (msg.referral && direction === "in") {
                  const r = msg.referral;
                  const adLabel = r.headline || r.source_type || "Ad";
                  const adLine = `🎯 From Meta Ad: ${adLabel}`;
                  finalContent = finalContent ? `${adLine}\n${finalContent}` : adLine;
                }

                const { error: insertErr } = await supabaseAdmin.from("messages").insert({
                  workspace_id,
                  conversation_id: convo.id,
                  direction,
                  type: normType,
                  content: finalContent,
                  media_url,
                  media_mime,
                  wa_message_id: msg.id,
                  status: direction === "out" ? "sent" : undefined,
                  reply_to_wa_message_id,
                  reply_to_preview,
                  created_at: getMessageTimestamp(msg),
                });
                if (insertErr) {
                  supabaseAdmin.from("integration_debug_logs").insert({
                    workspace_id,
                    provider: "whatsapp",
                    event: "webhook.message_insert_failed",
                    direction: "in",
                    ok: false,
                    status_code: 500,
                    message: `Failed to insert inbound message: ${insertErr.message}`,
                    payload: { wa_message_id: msg.id, type: normType, error: insertErr.message },
                  }).then(() => {}, () => {});
                }


                const preview = finalContent || `[${type}]`;
                await supabaseAdmin.from("conversations").update({
                  last_message_at: getMessageTimestamp(msg),
                  last_message_preview: preview.slice(0, 140),
                  unread_count: direction === "in"
                    ? (convo.unread_count ?? 0) + 1
                    : convo.unread_count,
                  status: convo.status === "resolved" ? "open" : convo.status,
                }).eq("id", convo.id);

                // Track Quick Reply / interactive button clicks for reporting.
                // Meta usually delivers template quick replies as type="button", but some
                // payload variants arrive as plain text replying to the template message
                // (msg.context.id -> the campaign message we sent). Both are recorded.
                if (direction === "in") {
                  const br = msg.interactive?.button_reply;
                  const lr = msg.interactive?.list_reply;
                  const isTemplateButton = type === "button" || type === "interactive";
                  const contextId: string | null = msg.context?.id ?? null;
                  const isContextReply =
                    !isTemplateButton && type === "text" && !!contextId &&
                    !!content && content.trim().length > 0 && content.trim().length <= 40;

                  if (isTemplateButton || isContextReply) {
                    const isButton = type === "button" || !!br || isContextReply;
                    const label = type === "button"
                      ? (msg.button?.text || msg.button?.payload || null)
                      : type === "interactive"
                        ? (br?.title || lr?.title || null)
                        : (content || "").trim();
                    const payloadValue = type === "button"
                      ? (msg.button?.payload || msg.button?.text || null)
                      : type === "interactive"
                        ? (br?.id || lr?.id || null)
                        : (content || "").trim();

                    // A plain-text reply only counts when it answers a campaign message.
                    let record = isTemplateButton;
                    if (isContextReply && contextId) {
                      const { data: rec } = await supabaseAdmin
                        .from("campaign_recipients")
                        .select("id")
                        .eq("workspace_id", workspace_id)
                        .eq("message_id", contextId)
                        .maybeSingle();
                      record = !!rec;
                    }

                    if (record && (label || payloadValue)) {
                      await recordTemplateButtonClick({
                        workspace_id,
                        contact_id: matchedContact?.id ?? null,
                        contact_name: matchedContact?.name || contactName || null,
                        phone: convo.contact_phone,
                        conversation_id: convo.id,
                        button_text: label,
                        button_payload: payloadValue,
                        button_type: isButton ? "quick_reply" : "list_reply",
                        wa_message_id: msg.id ?? null,
                        context_wa_message_id: contextId,
                        clicked_at: getMessageTimestamp(msg),
                      });
                    }
                  }
                }


                if (direction === "in") {
                  const { count: inboundCount } = await supabaseAdmin
                    .from("messages").select("id", { count: "exact", head: true })
                    .eq("conversation_id", convo.id).eq("direction", "in");

                  // Extract triggerable text for automations/bots from text, button, and interactive replies.
                  // Button/Quick reply payloads should trigger keyword automations same as typed text.
                  let triggerText: string | null = null;
                  if (type === "text") {
                    triggerText = content;
                  } else if (type === "button") {
                    triggerText = msg.button?.text || msg.button?.payload || content;
                  } else if (type === "interactive") {
                    const br = msg.interactive?.button_reply;
                    const lr = msg.interactive?.list_reply;
                    triggerText = br?.title || br?.id || lr?.title || lr?.id || content;
                  }

                  const botResult = await runBotForMessage({
                    workspace_id,
                    conversation_id: convo.id,
                    contact_phone: convo.contact_phone,
                    contact_id: matchedContact?.id ?? null,
                    message_text: triggerText,
                    is_first_message: (inboundCount ?? 0) <= 1,
                  });

                  // Fall through to legacy automations only if no bot handled the message
                  if (!botResult.handled) {
                    await runAutomations({
                      workspace_id,
                      conversation_id: convo.id,
                      contact_phone: convo.contact_phone,
                      message_text: triggerText,
                      is_first_message: (inboundCount ?? 0) <= 1,
                    });
                  }
                }
              }
            }
          }
        } catch (e) {
          console.error("webhook error", e);
        }

        return new Response("ok", { status: 200 });
      },
    },
  },
});

function normalizeWhatsAppPhone(phone: string) {
  const digits = phone.replace(/[^\d]/g, "");
  return digits ? `+${digits}` : phone;
}

async function resolveWhatsAppConnection(phoneNumberId: string): Promise<{
  workspace_id: string;
  user_id: string;
  access_token: string | null;
  account_id?: string | null;
} | null> {
  const { data: accounts, error: accountError } = await supabaseAdmin
    .from("whatsapp_accounts")
    .select("id, workspace_id, connected_by, access_token, is_active, status, updated_at, connected_at")
    .eq("phone_number_id", phoneNumberId)
    .order("is_active", { ascending: false })
    .order("updated_at", { ascending: false, nullsFirst: false })
    .order("connected_at", { ascending: false, nullsFirst: false })
    .limit(1);

  if (accountError) {
    console.warn(`[whatsapp-webhook] account lookup failed for phone_number_id=${phoneNumberId}: ${accountError.message}`);
  }

  const account = accounts?.[0];
  if (account?.workspace_id) {
    return {
      workspace_id: account.workspace_id,
      user_id: account.connected_by,
      access_token: account.access_token,
      account_id: account.id,
    };
  }

  const { data: settingsRows, error: settingsError } = await supabaseAdmin
    .from("whatsapp_settings")
    .select("workspace_id, user_id, access_token, updated_at")
    .eq("phone_number_id", phoneNumberId)
    .order("updated_at", { ascending: false, nullsFirst: false })
    .limit(1);

  if (settingsError) {
    console.warn(`[whatsapp-webhook] settings lookup failed for phone_number_id=${phoneNumberId}: ${settingsError.message}`);
  }

  return settingsRows?.[0] ?? null;
}

function templatePreview(template: any): string | null {
  const name = template?.name ? `Template: ${template.name}` : null;
  const components = Array.isArray(template?.components) ? template.components : [];
  const parts: string[] = [];
  for (const component of components) {
    const parameters = Array.isArray(component?.parameters) ? component.parameters : [];
    for (const parameter of parameters) {
      const text = parameter?.text || parameter?.payload || parameter?.button?.text;
      if (text) parts.push(String(text));
    }
  }
  return parts.length ? parts.join("\n") : name;
}

const META_BASE = "https://graph.facebook.com/v21.0";

function extFromMime(mime: string | null | undefined): string {
  if (!mime) return "bin";
  const map: Record<string, string> = {
    "image/jpeg": "jpg",
    "image/png": "png",
    "image/webp": "webp",
    "image/gif": "gif",
    "video/mp4": "mp4",
    "video/3gpp": "3gp",
    "audio/ogg": "ogg",
    "audio/mpeg": "mp3",
    "audio/mp4": "m4a",
    "audio/aac": "aac",
    "audio/amr": "amr",
    "application/pdf": "pdf",
  };
  if (map[mime]) return map[mime];
  const tail = (mime.split("/")[1] || "bin").split(";")[0];
  return tail;
}

async function downloadMediaToBucket(args: {
  mediaId: string;
  mime: string | null;
  filename?: string | null;
  accessToken: string;
  workspaceId: string;
}): Promise<string | null> {
  try {
    const metaRes = await fetch(`${META_BASE}/${args.mediaId}`, {
      headers: { Authorization: `Bearer ${args.accessToken}` },
    });
    if (!metaRes.ok) return null;
    const metaJson: any = await metaRes.json();
    const mediaUrl: string | undefined = metaJson.url;
    if (!mediaUrl) return null;

    const binRes = await fetch(mediaUrl, {
      headers: { Authorization: `Bearer ${args.accessToken}` },
    });
    if (!binRes.ok) return null;
    const buf = new Uint8Array(await binRes.arrayBuffer());
    const mime = args.mime || binRes.headers.get("content-type") || "application/octet-stream";
    const ext = extFromMime(mime);
    const baseName = args.filename
      ? args.filename.replace(/[^a-zA-Z0-9._-]/g, "_")
      : `${args.mediaId}.${ext}`;
    const path = `${args.workspaceId}/inbound/${Date.now()}-${baseName}`;

    const { error: upErr } = await supabaseAdmin.storage
      .from("chat-media")
      .upload(path, buf, { contentType: mime, upsert: false });
    if (upErr) {
      console.error("media upload error", upErr);
      return null;
    }
    const { data: pub } = supabaseAdmin.storage.from("chat-media").getPublicUrl(path);
    return pub.publicUrl ?? null;
  } catch (e) {
    console.error("downloadMediaToBucket error", e);
    return null;
  }
}

