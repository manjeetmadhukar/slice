import { createFileRoute } from "@tanstack/react-router";
import { supabaseAdmin } from "@/integrations/supabase/client.server";

export const Route = createFileRoute("/api/public/landing")({
  server: {
    handlers: {
      GET: async () => {
        const [features, testimonials, faqs, plans] = await Promise.all([
          supabaseAdmin
            .from("landing_features")
            .select("id, name, description, icon, category, position")
            .eq("is_active", true)
            .order("position", { ascending: true }),
          supabaseAdmin
            .from("landing_testimonials")
            .select("id, name, company, role, photo_url, review, rating, position")
            .eq("is_active", true)
            .order("position", { ascending: true }),
          supabaseAdmin
            .from("landing_faqs")
            .select("id, question, answer, position")
            .eq("is_active", true)
            .order("position", { ascending: true }),
          supabaseAdmin
            .from("plan_templates")
            .select("id, name, description, features, limits, price_monthly, price_yearly, currency, gateway_ids")
            .eq("is_active", true)
            .order("price_monthly", { ascending: true }),
        ]);

        return new Response(
          JSON.stringify({
            features: features.data ?? [],
            testimonials: testimonials.data ?? [],
            faqs: faqs.data ?? [],
            plans: plans.data ?? [],
          }),
          {
            status: 200,
            headers: {
              "Content-Type": "application/json",
              "Cache-Control": "public, max-age=60",
            },
          },
        );
      },
    },
  },
});
