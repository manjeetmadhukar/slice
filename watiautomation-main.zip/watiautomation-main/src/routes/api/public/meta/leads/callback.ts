// OAuth redirect handler for Facebook Lead Ads connect flow.
// User starts at getMetaLeadConnectUrl, FB redirects back here with ?code & ?state.
import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/api/public/meta/leads/callback")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const url = new URL(request.url);
        const code = url.searchParams.get("code");
        const state = url.searchParams.get("state");
        const error = url.searchParams.get("error");

        const html = (title: string, body: string, ok = true) =>
          new Response(
            `<!doctype html><html><head><title>${title}</title>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<style>body{font-family:system-ui,sans-serif;background:#0b0f17;color:#e6edf3;display:flex;align-items:center;justify-content:center;height:100vh;margin:0}
.card{background:#111827;border:1px solid #1f2937;border-radius:12px;padding:32px;max-width:420px;text-align:center}
h1{margin:0 0 8px;font-size:20px}p{margin:8px 0;color:#9ca3af;font-size:14px}
.ok{color:#10b981}.err{color:#ef4444}</style></head>
<body><div class="card"><h1 class="${ok ? "ok" : "err"}">${title}</h1><p>${body}</p>
<script>
try { window.opener && window.opener.postMessage({ type:"meta-lead-oauth", ok:${ok} }, "*"); } catch(e){}
setTimeout(()=>window.close(), 1200);
</script></div></body></html>`,
            { headers: { "content-type": "text/html; charset=utf-8" } },
          );

        if (error) return html("Connection cancelled", error, false);
        if (!code || !state) return html("Missing code/state", "Try connecting again.", false);

        const { verifyState, exchangeCodeForToken, graphGet } = await import(
          "@/lib/meta-leads.server"
        );
        const parsed = verifyState(state);
        if (!parsed) return html("Invalid state", "Security check failed. Try again.", false);

        try {
          const { access_token, expires_in } = await exchangeCodeForToken(code, parsed.r);
          // Get FB user id + name
          const me = await graphGet("/me", access_token, { fields: "id,name" });

          const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
          const expiresAt = expires_in
            ? new Date(Date.now() + expires_in * 1000).toISOString()
            : null;
          const { error: upErr } = await supabaseAdmin
            .from("meta_lead_connections")
            .upsert(
              {
                workspace_id: parsed.w,
                user_id: parsed.u,
                fb_user_id: me.id,
                fb_user_name: me.name,
                long_lived_token: access_token,
                token_expires_at: expiresAt,
                scope: "pages_show_list,pages_manage_metadata,pages_read_engagement,leads_retrieval,business_management",
              },
              { onConflict: "workspace_id,fb_user_id" },
            );
          if (upErr) throw upErr;

          return html("Facebook connected!", `Welcome, ${me.name}. You can close this window.`);
        } catch (e: any) {
          return html("Connection failed", e.message ?? "Unknown error", false);
        }
      },
    },
  },
});
