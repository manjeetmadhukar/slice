// Facebook Leadgen webhook receiver.
// GET = verification handshake (echo hub.challenge).
// POST = leadgen events. For each: fetch full lead via Graph, apply form routing,
//        create contact + deal in the workspace pipeline.
import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/api/public/meta/leads/webhook")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const { verifyToken } = await import("@/lib/meta-leads.server");
        const url = new URL(request.url);
        const mode = url.searchParams.get("hub.mode");
        const token = url.searchParams.get("hub.verify_token");
        const challenge = url.searchParams.get("hub.challenge");
        if (mode === "subscribe" && token && token === verifyToken()) {
          return new Response(challenge ?? "", { status: 200 });
        }
        return new Response("forbidden", { status: 403 });
      },
      POST: async ({ request }) => {
        let body: any;
        try {
          body = await request.json();
        } catch {
          return new Response("bad json", { status: 400 });
        }

        const { graphGet, normalizeLeadFields } = await import("@/lib/meta-leads.server");
        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

        const entries = body.entry ?? [];
        for (const entry of entries) {
          for (const change of entry.changes ?? []) {
            if (change.field !== "leadgen") continue;
            const v = change.value ?? {};
            const leadgenId: string = v.leadgen_id;
            const formId: string = v.form_id;
            const pageId: string = v.page_id;
            if (!leadgenId || !formId || !pageId) continue;

            // Look up page token + workspace
            const { data: pageRow } = await supabaseAdmin
              .from("meta_lead_pages")
              .select("workspace_id, page_access_token")
              .eq("page_id", pageId)
              .maybeSingle();
            if (!pageRow) continue;

            // Look up form routing
            const { data: form } = await supabaseAdmin
              .from("meta_lead_forms")
              .select(
                "id, form_name, enabled, assigned_user_id, assigned_agent_id, assigned_agent_label, default_stage_id, default_tags",
              )
              .eq("workspace_id", pageRow.workspace_id)
              .eq("form_id", formId)
              .maybeSingle();
            if (form && form.enabled === false) continue;

            // Fetch full lead
            let lead: any;
            try {
              lead = await graphGet(`/${leadgenId}`, pageRow.page_access_token, {
                fields: "id,created_time,field_data,ad_id,campaign_id,form_id",
              });
            } catch (e) {
              console.error("[meta-leads] fetch lead failed", e);
              continue;
            }
            const fields = normalizeLeadFields(lead.field_data ?? []);

            // Determine stage (required for deals)
            let stageId: string | null = form?.default_stage_id ?? null;
            if (!stageId) {
              const { data: stage } = await supabaseAdmin
                .from("pipeline_stages")
                .select("id")
                .eq("workspace_id", pageRow.workspace_id)
                .order("position")
                .limit(1)
                .maybeSingle();
              stageId = stage?.id ?? null;
            }
            if (!stageId) continue; // no pipeline → skip

            // Workspace owner is the fallback user_id for created rows
            const { data: ws } = await supabaseAdmin
              .from("workspaces")
              .select("owner_id")
              .eq("id", pageRow.workspace_id)
              .single();
            const ownerId = ws?.owner_id;
            if (!ownerId) continue;

            // Upsert contact (contacts.phone is NOT NULL)
            const phone = (fields.phone || "").replace(/\s+/g, "");
            const email = fields.email || null;
            const contactPhone = phone || `fb:${leadgenId}`;
            let contactId: string | null = null;
            if (phone) {
              const { data: id } = await supabaseAdmin.rpc("upsert_contact", {
                _workspace_id: pageRow.workspace_id,
                _name: fields.name || email || phone || "Facebook Lead",
                _phone: contactPhone,
                _email: email || undefined,
                _city: fields.city || undefined,
                _lead_source: "facebook_lead_ads",
                _user_id: ownerId,
              } as any);
              contactId = (id as any) ?? null;
            }
            if (!contactId && email) {
              const { data: existing } = await supabaseAdmin
                .from("contacts")
                .select("id")
                .eq("workspace_id", pageRow.workspace_id)
                .eq("email", email)
                .limit(1)
                .maybeSingle();
              contactId = existing?.id ?? null;
            }
            if (!contactId) {
              const { data: created } = await supabaseAdmin
                .from("contacts")
                .insert({
                  workspace_id: pageRow.workspace_id,
                  user_id: ownerId,
                  name: fields.name || email || phone || "Facebook Lead",
                  phone: contactPhone,
                  email,
                  city: fields.city ?? null,
                  lead_source: "facebook_lead_ads",
                  assigned_user_id: form?.assigned_user_id ?? null,
                  assigned_agent_id: form?.assigned_agent_id ?? null,
                  assigned_agent_label: form?.assigned_agent_label ?? null,
                })
                .select("id")
                .single();
              contactId = created?.id ?? null;
            }
            if (contactId) {
              await supabaseAdmin
                .from("contacts")
                .update({
                  assigned_user_id: form?.assigned_user_id ?? undefined,
                  assigned_agent_id: form?.assigned_agent_id ?? undefined,
                  assigned_agent_label: form?.assigned_agent_label ?? undefined,
                })
                .eq("id", contactId);
            }

            const tags = Array.isArray(form?.default_tags)
              ? (form!.default_tags as string[])
              : [];
            const dealTitle = `${fields.name || "Lead"} · ${form?.form_name || "FB Form"}`;
            await supabaseAdmin.from("deals").insert({
              workspace_id: pageRow.workspace_id,
              user_id: ownerId,
              title: dealTitle,
              contact_id: contactId,
              stage_id: stageId,
              source: "facebook_lead_ads",
              tags,
              assigned_to: form?.assigned_user_id ?? null,
              assigned_user_id: form?.assigned_user_id ?? null,
              assigned_agent_id: form?.assigned_agent_id ?? null,
              assigned_agent_label: form?.assigned_agent_label ?? null,
              notes: JSON.stringify({
                leadgen_id: leadgenId,
                form_id: formId,
                page_id: pageId,
                ad_id: lead.ad_id,
                campaign_id: lead.campaign_id,
                field_data: fields.raw,
              }),
            });

            // Bump last_lead_at
            if (form) {
              await supabaseAdmin
                .from("meta_lead_forms")
                .update({ last_lead_at: new Date().toISOString() })
                .eq("id", form.id);
            }
          }
        }
        return new Response("ok", { status: 200 });
      },
    },
  },
});
