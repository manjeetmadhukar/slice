import { createFileRoute } from "@tanstack/react-router";
import { createHmac, timingSafeEqual } from "crypto";
import { supabaseAdmin } from "@/integrations/supabase/client.server";

// Razorpay webhook: payment.captured / payment.failed
// Configure URL: https://<your-domain>/api/public/payments/razorpay
// Secret: RAZORPAY_WEBHOOK_SECRET
export const Route = createFileRoute("/api/public/payments/razorpay")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        let secret = process.env.RAZORPAY_WEBHOOK_SECRET;
        if (!secret) {
          const { data: gw } = await supabaseAdmin.from("payment_gateways").select("webhook_secret").eq("provider", "razorpay").maybeSingle();
          secret = (gw as any)?.webhook_secret || undefined;
        }
        if (!secret) return new Response("Webhook secret not configured", { status: 500 });

        const signature = request.headers.get("x-razorpay-signature") || "";
        const body = await request.text();

        const expected = createHmac("sha256", secret).update(body).digest("hex");
        try {
          if (signature.length !== expected.length ||
              !timingSafeEqual(Buffer.from(signature), Buffer.from(expected))) {
            return new Response("invalid signature", { status: 401 });
          }
        } catch {
          return new Response("invalid signature", { status: 401 });
        }

        const evt = JSON.parse(body);
        const eventType: string = evt?.event ?? "";
        const payment = evt?.payload?.payment?.entity;
        const orderId: string | undefined = payment?.order_id;
        if (!orderId) return new Response("ok", { status: 200 });

        const status =
          eventType === "payment.captured" ? "paid"
          : eventType === "payment.failed" ? "failed"
          : "created";

        const { data: tx } = await supabaseAdmin
          .from("payment_transactions")
          .select("*")
          .eq("provider", "razorpay")
          .eq("order_id", orderId)
          .maybeSingle();
        if (!tx) return new Response("ok", { status: 200 });

        await supabaseAdmin
          .from("payment_transactions")
          .update({
            status,
            payment_id: payment?.id ?? null,
            raw_event: evt,
          })
          .eq("id", tx.id);

        if (status === "paid") {
          await activatePlan(tx);
        }

        return new Response("ok", { status: 200 });
      },
    },
  },
});

async function activatePlan(tx: any) {
  if (tx.purpose === "credits") {
    const { creditAiWalletFromTransaction } = await import("@/lib/ai-credit-topup.server");
    await creditAiWalletFromTransaction(tx);
    return;
  }
  if (!tx.template_id) return;
  const { data: tpl } = await supabaseAdmin
    .from("plan_templates")
    .select("*")
    .eq("id", tx.template_id)
    .maybeSingle();
  if (!tpl) return;

  await supabaseAdmin
    .from("workspace_plans")
    .upsert(
      {
        workspace_id: tx.workspace_id,
        plan_name: tpl.name,
        features: tpl.features,
        limits: tpl.limits,
        notes: tpl.description ?? null,
        price_monthly: tpl.price_monthly ?? 0,
        price_yearly: tpl.price_yearly ?? 0,
        currency: tpl.currency ?? "INR",
        billing_interval: tx.billing_interval ?? "monthly",
        assigned_by: tx.user_id,
      },
      { onConflict: "workspace_id" },
    );
}
