import { createFileRoute } from "@tanstack/react-router";
import { createHmac, timingSafeEqual } from "crypto";
import { supabaseAdmin } from "@/integrations/supabase/client.server";

// Cashfree webhook: order.paid
// URL: https://<your-domain>/api/public/payments/cashfree
// Secret: CASHFREE_WEBHOOK_SECRET
export const Route = createFileRoute("/api/public/payments/cashfree")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        let secret = process.env.CASHFREE_WEBHOOK_SECRET;
        if (!secret) {
          const { data: gw } = await supabaseAdmin
            .from("payment_gateways")
            .select("webhook_secret")
            .eq("provider", "cashfree")
            .maybeSingle();
          secret = (gw as any)?.webhook_secret || undefined;
        }
        if (!secret) return new Response("not configured", { status: 500 });

        const sig = request.headers.get("x-webhook-signature") || "";
        const ts = request.headers.get("x-webhook-timestamp") || "";
        const body = await request.text();
        const expected = createHmac("sha256", secret).update(ts + body).digest("base64");
        try {
          if (sig.length !== expected.length ||
              !timingSafeEqual(Buffer.from(sig), Buffer.from(expected))) {
            return new Response("invalid signature", { status: 401 });
          }
        } catch {
          return new Response("invalid signature", { status: 401 });
        }

        const evt = JSON.parse(body);
        const orderId = evt?.data?.order?.order_id;
        const paymentStatus = evt?.data?.payment?.payment_status;
        if (!orderId) return new Response("ok");

        const { data: tx } = await supabaseAdmin
          .from("payment_transactions")
          .select("*").eq("provider", "cashfree").eq("order_id", orderId).maybeSingle();
        if (!tx) return new Response("ok");

        const status = paymentStatus === "SUCCESS" ? "paid" : paymentStatus === "FAILED" ? "failed" : "created";
        await supabaseAdmin.from("payment_transactions").update({
          status, payment_id: evt?.data?.payment?.cf_payment_id ?? null, raw_event: evt,
        }).eq("id", tx.id);
        if (status === "paid") await activatePlan(tx);
        return new Response("ok");
      },
    },
  },
});

async function activatePlan(tx: any) {
  if (tx.purpose === "credits") {
    const { creditAiWalletFromTransaction } = await import("@/lib/ai-credit-topup.server");
    await creditAiWalletFromTransaction(tx);
    return;
  }
  if (!tx.template_id) return;
  const { data: tpl } = await supabaseAdmin.from("plan_templates").select("*").eq("id", tx.template_id).maybeSingle();
  if (!tpl) return;
  await supabaseAdmin.from("workspace_plans").upsert({
    workspace_id: tx.workspace_id, plan_name: tpl.name, features: tpl.features, limits: tpl.limits,
    notes: tpl.description ?? null, price_monthly: tpl.price_monthly ?? 0, price_yearly: tpl.price_yearly ?? 0,
    currency: tpl.currency ?? "INR", billing_interval: tx.billing_interval ?? "monthly", assigned_by: tx.user_id,
  }, { onConflict: "workspace_id" });
}
