import { createFileRoute } from "@tanstack/react-router";
import { supabaseAdmin } from "@/integrations/supabase/client.server";

// Instamojo webhook (v2). Configure URL in Instamojo dashboard:
//   https://<your-domain>/api/public/payments/instamojo
// Note: Instamojo v2 sends a JSON body. We verify by re-fetching the payment
// from Instamojo using INSTAMOJO_AUTH_TOKEN before activating the plan, since
// Instamojo's signature scheme differs across plans.
export const Route = createFileRoute("/api/public/payments/instamojo")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const auth = process.env.INSTAMOJO_AUTH_TOKEN;
        if (!auth) return new Response("not configured", { status: 500 });

        const body = await request.json().catch(() => ({}));
        const paymentRequestId: string | undefined = body?.payment_request?.id ?? body?.id;
        const paymentId: string | undefined = body?.payments?.[0]?.id ?? body?.payment_id;
        if (!paymentRequestId) return new Response("ok");

        // Re-fetch payment request from Instamojo to verify status
        const verifyRes = await fetch(`https://api.instamojo.com/v2/payment_requests/${paymentRequestId}/`, {
          headers: { Authorization: `Bearer ${auth}` },
        });
        const verified: any = await verifyRes.json();
        if (!verifyRes.ok) return new Response("verify failed", { status: 400 });

        const pay = verified?.payments?.[0];
        const status = pay?.status === "Credit" ? "paid" : pay?.status === "Failed" ? "failed" : "created";

        const { data: tx } = await supabaseAdmin
          .from("payment_transactions")
          .select("*").eq("provider", "instamojo").eq("order_id", paymentRequestId).maybeSingle();
        if (!tx) return new Response("ok");

        await supabaseAdmin.from("payment_transactions").update({
          status, payment_id: paymentId ?? pay?.id ?? null, raw_event: verified,
        }).eq("id", tx.id);
        if (status === "paid") await activatePlan(tx);
        return new Response("ok");
      },
    },
  },
});

async function activatePlan(tx: any) {
  if (tx.purpose === "credits") {
    const { creditAiWalletFromTransaction } = await import("@/lib/ai-credit-topup.server");
    await creditAiWalletFromTransaction(tx);
    return;
  }
  if (!tx.template_id) return;
  const { data: tpl } = await supabaseAdmin.from("plan_templates").select("*").eq("id", tx.template_id).maybeSingle();
  if (!tpl) return;
  await supabaseAdmin.from("workspace_plans").upsert({
    workspace_id: tx.workspace_id, plan_name: tpl.name, features: tpl.features, limits: tpl.limits,
    notes: tpl.description ?? null, price_monthly: tpl.price_monthly ?? 0, price_yearly: tpl.price_yearly ?? 0,
    currency: tpl.currency ?? "INR", billing_interval: tx.billing_interval ?? "monthly", assigned_by: tx.user_id,
  }, { onConflict: "workspace_id" });
}
