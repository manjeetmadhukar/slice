import { createFileRoute } from "@tanstack/react-router";
import { createHmac, timingSafeEqual } from "crypto";
import { supabaseAdmin } from "@/integrations/supabase/client.server";

// Stripe webhook: checkout.session.completed
// Configure URL: https://<your-domain>/api/public/payments/stripe
// Secret: STRIPE_WEBHOOK_SECRET (whsec_...)
export const Route = createFileRoute("/api/public/payments/stripe")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        let secret = process.env.STRIPE_WEBHOOK_SECRET;
        if (!secret) {
          const { data: gw } = await supabaseAdmin.from("payment_gateways").select("webhook_secret").eq("provider", "stripe").maybeSingle();
          secret = (gw as any)?.webhook_secret || undefined;
        }
        if (!secret) return new Response("Webhook secret not configured", { status: 500 });

        const sigHeader = request.headers.get("stripe-signature") || "";
        const body = await request.text();

        // Stripe signature is "t=...,v1=..."
        const parts = Object.fromEntries(sigHeader.split(",").map((p) => p.split("=")));
        const timestamp = parts["t"];
        const v1 = parts["v1"];
        if (!timestamp || !v1) return new Response("invalid signature", { status: 401 });

        const signedPayload = `${timestamp}.${body}`;
        const expected = createHmac("sha256", secret).update(signedPayload).digest("hex");
        try {
          if (v1.length !== expected.length ||
              !timingSafeEqual(Buffer.from(v1), Buffer.from(expected))) {
            return new Response("invalid signature", { status: 401 });
          }
        } catch {
          return new Response("invalid signature", { status: 401 });
        }

        const evt = JSON.parse(body);
        if (evt.type !== "checkout.session.completed") return new Response("ok");

        const session = evt.data.object;
        const txId = session?.metadata?.tx_id;
        if (!txId) return new Response("ok");

        const { data: tx } = await supabaseAdmin
          .from("payment_transactions")
          .select("*")
          .eq("id", txId)
          .maybeSingle();
        if (!tx) return new Response("ok");

        await supabaseAdmin
          .from("payment_transactions")
          .update({
            status: "paid",
            payment_id: session.payment_intent ?? session.id,
            raw_event: evt,
          })
          .eq("id", tx.id);

        await activatePlan(tx);
        return new Response("ok");
      },
    },
  },
});

async function activatePlan(tx: any) {
  if (tx.purpose === "credits") {
    const { creditAiWalletFromTransaction } = await import("@/lib/ai-credit-topup.server");
    await creditAiWalletFromTransaction(tx);
    return;
  }
  if (!tx.template_id) return;
  const { data: tpl } = await supabaseAdmin
    .from("plan_templates")
    .select("*")
    .eq("id", tx.template_id)
    .maybeSingle();
  if (!tpl) return;
  await supabaseAdmin.from("workspace_plans").upsert(
    {
      workspace_id: tx.workspace_id,
      plan_name: tpl.name,
      features: tpl.features,
      limits: tpl.limits,
      notes: tpl.description ?? null,
      price_monthly: tpl.price_monthly ?? 0,
      price_yearly: tpl.price_yearly ?? 0,
      currency: tpl.currency ?? "INR",
      billing_interval: tx.billing_interval ?? "monthly",
      assigned_by: tx.user_id,
    },
    { onConflict: "workspace_id" },
  );
}
