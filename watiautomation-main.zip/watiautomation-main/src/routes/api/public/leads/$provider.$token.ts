import { createFileRoute } from "@tanstack/react-router";
import { supabaseAdmin } from "@/integrations/supabase/client.server";

// Inbound lead webhook for Meta Ads / WordPress / Zapier / Make.
// URL: /api/public/leads/{provider}/{token}
// Body (JSON or form-encoded): { name, phone, email, message?, source?, custom? }
// Meta Lead Ads via Zapier: map "full_name" -> name, "phone_number" -> phone, etc.

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type",
};

function normalizePhone(p: any) {
  const s = String(p ?? "").replace(/[^\d]/g, "");
  return s ? `+${s}` : "";
}

async function parseBody(request: Request): Promise<any> {
  const ct = request.headers.get("content-type") || "";
  try {
    if (ct.includes("application/json")) return await request.json();
    if (ct.includes("application/x-www-form-urlencoded") || ct.includes("multipart/form-data")) {
      const fd = await request.formData();
      const o: Record<string, any> = {};
      fd.forEach((v, k) => { o[k] = v; });
      return o;
    }
    const txt = await request.text();
    try { return JSON.parse(txt); } catch { return { raw: txt }; }
  } catch { return {}; }
}

function pick(obj: any, keys: string[]) {
  for (const k of keys) {
    const v = obj?.[k];
    if (v !== undefined && v !== null && String(v).trim()) return String(v).trim();
  }
  return "";
}

// Flatten common nested webhook formats (Elementor, Contact Form 7, WPForms, etc.)
// into a flat key/value map so pick() can find fields regardless of source.
function flattenLeadPayload(body: any): Record<string, any> {
  const out: Record<string, any> = {};
  if (!body || typeof body !== "object") return out;

  // Normalize a key: trim whitespace (Pabbly often emits "name " with a trailing space)
  const nk = (k: string) => String(k).trim();
  const setOut = (k: string, v: any) => {
    const key = nk(k);
    if (!key) return;
    out[key] = v;
    // Also expose a lowercased alias so pick() can match case-insensitively-ish
    const lower = key.toLowerCase();
    if (lower !== key && out[lower] === undefined) out[lower] = v;
  };

  // 1) Copy top-level scalar keys as-is (with trimmed keys)
  for (const [k, v] of Object.entries(body)) {
    if (v === null || v === undefined) continue;
    if (typeof v === "string" || typeof v === "number" || typeof v === "boolean") {
      setOut(k, v);
      // Elementor "form_fields[name]" style — also strip the prefix
      const m = /^form_fields\[(.+)\]$/.exec(nk(k));
      if (m) setOut(m[1], v);
    }
  }

  // 2) Elementor Pro "Advanced Data" JSON: { form, fields: { name: {value, ...}, ... } }
  if (body.fields && typeof body.fields === "object" && !Array.isArray(body.fields)) {
    for (const [key, field] of Object.entries(body.fields as Record<string, any>)) {
      if (field && typeof field === "object") {
        const val = field.value ?? field.raw_value ?? field.text ?? "";
        if (val !== "" && val !== null && val !== undefined) {
          setOut(key, val);
          if (field.title) setOut(String(field.title).toLowerCase().replace(/\s+/g, "_"), val);
        }
      } else if (field !== null && field !== undefined) {
        setOut(key, field);
      }
    }
  }

  // 4) Generic nested "data" wrapper
  if (body.data && typeof body.data === "object") {
    for (const [k, v] of Object.entries(body.data as Record<string, any>)) {
      if (typeof v === "string" || typeof v === "number") setOut(k, v);
    }
  }

  // 5) IndiaMART Push API wraps lead under "RESPONSE" (object or array of one)
  const resp = body.RESPONSE ?? body.response;
  if (resp) {
    const r = Array.isArray(resp) ? resp[0] : resp;
    if (r && typeof r === "object") {
      for (const [k, v] of Object.entries(r as Record<string, any>)) {
        if (typeof v === "string" || typeof v === "number") setOut(k, v);
      }
    }
  }

  return out;
}

// Facebook Lead Ads Testing Tool emits dummy values wrapped like
// "<test lead: dummy data for full_name>" — treat those as empty test data.
function stripTestPlaceholder(v: string): string {
  const s = String(v ?? "").trim();
  if (/^<test lead:.*>$/i.test(s)) return "";
  return s;
}

export const Route = createFileRoute("/api/public/leads/$provider/$token")({
  server: {
    handlers: {
      OPTIONS: async () => new Response(null, { status: 204, headers: corsHeaders }),
      GET: async ({ params }) => Response.json(
        { ok: true, provider: params.provider, message: "Lead intake endpoint. POST JSON { name, phone, email, message } to create a lead." },
        { headers: corsHeaders },
      ),
      POST: async ({ request, params }) => {
        const provider = String(params.provider || "").toLowerCase();
        if (!["meta", "wordpress", "generic", "indiamart"].includes(provider)) {
          return new Response(JSON.stringify({ ok: false, error: "Unknown provider" }), {
            status: 400,
            headers: { "Content-Type": "application/json", ...corsHeaders },
          });
        }

        const { data: tok } = await supabaseAdmin
          .from("lead_intake_tokens")
          .select("*")
          .eq("token", params.token)
          .eq("provider", provider)
          .maybeSingle();
        if (!tok || !tok.enabled) {
          return new Response(JSON.stringify({ ok: false, error: "Invalid or disabled token" }), {
            status: 401,
            headers: { "Content-Type": "application/json", ...corsHeaders },
          });
        }

        const rawBody = await parseBody(request);
        const body = flattenLeadPayload(rawBody);

        // Helper: log every attempt (success or failure) to integration_debug_logs
        const logDebug = async (status: number, ok: boolean, message: string, response: any) => {
          try {
            await supabaseAdmin.from("integration_debug_logs").insert({
              workspace_id: tok.workspace_id,
              provider: `lead-intake-${provider}`,
              direction: "inbound",
              event: "lead_webhook",
              status_code: status,
              ok,
              message,
              payload: rawBody,
              response,
            });
          } catch {}
        };

        // Detect Pabbly/Zapier misconfiguration: user typed the field-name placeholder
        // (e.g. "full_name", "phone_number", "email") as the literal Parameter Value
        // instead of selecting the mapped trigger field.
        const PLACEHOLDER_TOKENS = new Set([
          "full_name", "fullname", "full name",
          "first_name", "firstname", "last_name", "lastname",
          "phone_number", "phonenumber", "phone",
          "email", "email_address", "emailaddress",
          "form_name", "formname",
        ]);
        const isPlaceholder = (v: string) =>
          !!v && PLACEHOLDER_TOKENS.has(String(v).trim().toLowerCase());

        const nameRaw = stripTestPlaceholder(pick(body, [
          "name", "full_name", "fullName", "full name", "your-name", "your_name",
          "first_name", "firstname", "fname", "contact_name",
          "SENDER_NAME", "sender_name",
        ]));
        const name = (nameRaw && !isPlaceholder(nameRaw)) ? nameRaw : "Lead";
        const phoneRawValue = stripTestPlaceholder(pick(body, [
          "phone", "phone_number", "phoneNumber", "mobile", "mobile_number",
          "your-phone", "tel", "telephone", "contact", "contact_number", "whatsapp",
          "SENDER_MOBILE", "sender_mobile", "SENDER_PHONE", "sender_phone",
          "SENDER_MOBILE_ALT", "MOB",
        ]));
        const phoneRaw = isPlaceholder(phoneRawValue) ? "" : phoneRawValue;
        const phone = normalizePhone(phoneRaw);
        const emailRaw = stripTestPlaceholder(pick(body, [
          "email", "your-email", "email_address", "emailaddress",
          "SENDER_EMAIL", "sender_email", "SENDER_EMAIL_ALT",
        ]));
        const email = isPlaceholder(emailRaw) ? "" : emailRaw;
        const message = stripTestPlaceholder(pick(body, [
          "message", "your-message", "notes", "comment", "comments",
          "purpose", "purpose_of_contacting", "enquiry", "query", "subject",
          "QUERY_MESSAGE", "query_message", "SUBJECT", "QUERY_PRODUCT_NAME", "query_product_name",
        ]));

        if (!phone && !email) {
          const sentValues = Object.values(rawBody || {}).map((v) => String(v));
          const sawTestWrapper = sentValues.some((v) => /^<test lead:.*>$/i.test(v.trim()));
          const hadPlaceholder =
            isPlaceholder(phoneRawValue) || isPlaceholder(emailRaw) || isPlaceholder(nameRaw);
          const hint = sawTestWrapper
            ? "This was a Facebook Lead Ads TEST submission — Meta sends placeholder values like '<test lead: dummy data for phone_number>' which we strip. To verify end-to-end, submit a real lead (or use Meta's Lead Ads Testing Tool with real test data filled in) instead of Pabbly's 'Send Test Request'. Once a real lead is captured by Pabbly, all fields will flow through."
            : hadPlaceholder
            ? "Pabbly is sending the field NAMES (\"full_name\", \"phone_number\", \"email\") as the VALUES. Fix in Webhooks-by-Pabbly: delete each Parameter Value, press '/', and SELECT the Facebook trigger field (Full Name → name, Phone Number → phone, Email → email)."
            : "Map your form's phone/email field to a recognized key. Received keys: " + Object.keys(body).join(", ");
          const errResp = { ok: false, error: "phone or email required", hint, received: rawBody };
          await logDebug(400, false, hint, errResp);
          return new Response(
            JSON.stringify(errResp),
            { status: 400, headers: { "Content-Type": "application/json", ...corsHeaders } },
          );
        }

        // Find or create contact (upsert by normalized phone; fall back to email match)
        let contactId: string | null = null;
        if (!phone && email) {
          const { data: existing } = await supabaseAdmin
            .from("contacts")
            .select("id")
            .eq("workspace_id", tok.workspace_id)
            .eq("email", email)
            .maybeSingle();
          if (existing) contactId = existing.id;
        }
        if (!contactId && phone) {
          const { data: ws } = await supabaseAdmin
            .from("workspaces").select("owner_id").eq("id", tok.workspace_id).maybeSingle();
          const { data: id, error: cErr } = await supabaseAdmin.rpc("upsert_contact", {
            _workspace_id: tok.workspace_id,
            _name: name,
            _phone: phone,
            _email: email || undefined,
            _lead_source: provider,
            _tags: [provider === "meta" ? "Meta Ads" : provider === "wordpress" ? "WordPress" : provider === "indiamart" ? "IndiaMART" : "Web Lead"],
            _user_id: ws?.owner_id ?? undefined,
          } as any);
          if (cErr) {
            return new Response("Contact creation failed: " + cErr.message, { status: 500, headers: corsHeaders });
          }
          contactId = (id as any) ?? null;
        }
        if (!contactId) {
          // Email-only lead with no matching contact — create bare row
          const { data: ws } = await supabaseAdmin
            .from("workspaces").select("owner_id").eq("id", tok.workspace_id).maybeSingle();
          const { data: inserted, error: cErr } = await supabaseAdmin
            .from("contacts")
            .insert({
              workspace_id: tok.workspace_id,
              user_id: ws?.owner_id ?? null,
              name,
              phone: "",
              email: email || null,
              lead_source: provider,
              lead_stage: "new",
              tags: [provider === "meta" ? "Meta Ads" : provider === "wordpress" ? "WordPress" : provider === "indiamart" ? "IndiaMART" : "Web Lead"],
            } as any)
            .select("id")
            .single();
          if (cErr) {
            return new Response("Contact creation failed: " + cErr.message, { status: 500, headers: corsHeaders });
          }
          contactId = inserted!.id;
        }

        // Resolve stage
        let stageId = tok.default_stage_id as string | null;
        if (!stageId) {
          const { data: stage } = await supabaseAdmin
            .from("pipeline_stages")
            .select("id")
            .eq("workspace_id", tok.workspace_id)
            .order("position", { ascending: true })
            .limit(1)
            .maybeSingle();
          stageId = stage?.id ?? null;
        }
        if (!stageId) {
          return new Response("No pipeline stages configured", { status: 500, headers: corsHeaders });
        }

        // Create deal
        const { data: ws2 } = await supabaseAdmin
          .from("workspaces").select("owner_id").eq("id", tok.workspace_id).maybeSingle();
        const sourceLabel = provider === "meta" ? "Meta Ads" : provider === "wordpress" ? "WordPress Form" : provider === "indiamart" ? "IndiaMART" : "Web Lead";
        const { data: deal, error: dErr } = await supabaseAdmin
          .from("deals")
          .insert({
            workspace_id: tok.workspace_id,
            user_id: ws2?.owner_id ?? null,
            contact_id: contactId,
            stage_id: stageId,
            title: `${name} — ${sourceLabel}`,
            value: 0,
            currency: "INR",
            source: provider,
            notes: message || null,
            tags: [sourceLabel],
          } as any)
          .select("id")
          .single();
        if (dErr) {
          return new Response("Deal creation failed: " + dErr.message, { status: 500, headers: corsHeaders });
        }

        await supabaseAdmin.from("deal_activities").insert({
          workspace_id: tok.workspace_id,
          deal_id: deal!.id,
          user_id: null,
          type: "lead_imported",
          data: { provider, source: sourceLabel, name, phone, email, message, raw: rawBody },
        });

        await supabaseAdmin
          .from("lead_intake_tokens")
          .update({ last_used_at: new Date().toISOString() })
          .eq("id", tok.id);

        const okResp = { ok: true, contact_id: contactId, deal_id: deal!.id, source: sourceLabel, name, phone, email };
        await logDebug(200, true, `Lead created: ${name}`, okResp);
        return Response.json(okResp, { headers: corsHeaders });
      },
    },
  },
});
