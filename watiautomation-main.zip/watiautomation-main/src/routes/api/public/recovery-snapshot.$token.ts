import { createFileRoute } from "@tanstack/react-router";

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "Content-Type": "application/json", "Cache-Control": "no-store" },
  });
}

export const Route = createFileRoute("/api/public/recovery-snapshot/$token")({
  server: {
    handlers: {
      GET: async ({ request, params }) => {
        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
        const token = String(params.token || "").trim();
        const apiKey = (request.headers.get("authorization") || "").replace(/^Bearer\s+/i, "").trim();
        const workspaceId = request.headers.get("x-slice-workspace") || new URL(request.url).searchParams.get("workspace_id") || "";

        if (!token || token.length > 200 || /[,()"]/.test(token)) return json({ ok: false, error: "Invalid token" }, 400);
        if (!apiKey || !workspaceId || /[,()"]/.test(apiKey) || apiKey.length > 200) {
          return json({ ok: false, error: "Unauthorized" }, 401);
        }

        const { data: integration } = await supabaseAdmin
          .from("store_integrations")
          .select("id, workspace_id")
          .eq("workspace_id", workspaceId)
          .eq("provider", "woocommerce")
          .or(`api_key.eq.${apiKey},api_secret.eq.${apiKey}`)
          .maybeSingle();

        if (!integration) return json({ ok: false, error: "Unauthorized" }, 401);

        const { data: cart } = await supabaseAdmin
          .from("abandoned_carts")
          .select("cart_token, customer_name, customer_email, customer_phone, items, recovery_expires_at")
          .eq("integration_id", (integration as any).id)
          .or(`cart_token.eq.${token},recovery_token.eq.${token}`)
          .order("abandoned_at", { ascending: false })
          .limit(1)
          .maybeSingle();

        if (!cart) return json({ ok: false, error: "Recovery snapshot not found" }, 404);
        const expires = (cart as any).recovery_expires_at as string | null;
        if (expires && new Date(expires).getTime() < Date.now()) return json({ ok: false, error: "Recovery link expired" }, 410);

        const items = (Array.isArray((cart as any).items) ? (cart as any).items : [])
          .map((item: any) => ({
            product_id: Number(item.product_id || item.productId || 0),
            variation_id: Number(item.variation_id || item.variant_id || item.variantId || 0),
            quantity: Math.max(1, Number(item.quantity || item.qty || 1)),
            variation: item.variation && typeof item.variation === "object" ? item.variation : {},
          }))
          .filter((item: any) => item.product_id || item.variation_id);

        if (!items.length) return json({ ok: false, error: "Recovery snapshot has no items" }, 404);

        return json({
          ok: true,
          snapshot: {
            items,
            customer: {
              first_name: String((cart as any).customer_name || "").split(" ")[0] || "",
              last_name: String((cart as any).customer_name || "").split(" ").slice(1).join(" "),
              email: (cart as any).customer_email || "",
              phone: (cart as any).customer_phone || "",
            },
            saved_at: new Date().toISOString(),
          },
        });
      },
    },
  },
});