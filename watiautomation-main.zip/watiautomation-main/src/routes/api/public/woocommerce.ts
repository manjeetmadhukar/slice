// Public webhook receiver for the Slice – WooCommerce Connector plugin.
// The plugin POSTs every store event (orders, customers, carts, products) here.
// Authenticates via Bearer api_key + X-Slice-Workspace headers matched against
// store_integrations, upserts the data, fires WhatsApp templates when configured,
// and writes a row to integration_debug_logs for every step.
import { createFileRoute } from "@tanstack/react-router";
import { supabaseAdmin } from "@/integrations/supabase/client.server";
import { createHash, randomInt } from "crypto";
import { resolveTemplateParams, type FieldKey } from "@/lib/wa-template-vars.server";

const META_BASE = "https://graph.facebook.com/v21.0";

function hashOtp(code: string, workspaceId: string) {
  return createHash("sha256").update(`${workspaceId}:${code}`).digest("hex");
}

function generateOtp(length: number) {
  const n = Math.max(4, Math.min(8, Number(length) || 6));
  const min = Math.pow(10, n - 1);
  const max = Math.pow(10, n);
  return String(randomInt(min, max));
}

async function sendOtpTemplate(args: {
  workspaceId: string;
  integrationId: string;
  toPhone: string;
  templateName: string;
  language: string;
  code: string;
}) {
  const { data: settings } = await supabaseAdmin
    .from("whatsapp_settings").select("phone_number_id, access_token")
    .eq("workspace_id", args.workspaceId).maybeSingle();
  if (!settings?.phone_number_id || !settings.access_token) {
    return { ok: false, error: "WhatsApp not configured for this workspace" };
  }
  const phone = normalizeE164(args.toPhone);
  if (!phone || phone.length < 8) return { ok: false, error: "Invalid phone number" };
  const body = {
    messaging_product: "whatsapp",
    to: phone,
    type: "template",
    template: {
      name: args.templateName,
      language: { code: args.language || "en" },
      components: [
        { type: "body", parameters: [{ type: "text", text: args.code }] },
        { type: "button", sub_type: "url", index: "0", parameters: [{ type: "text", text: args.code }] },
      ],
    },
  };
  try {
    const res = await fetch(`${META_BASE}/${settings.phone_number_id}/messages`, {
      method: "POST",
      headers: { Authorization: `Bearer ${settings.access_token}`, "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    const j: any = await res.json().catch(() => ({}));
    await logEvent({
      workspace_id: args.workspaceId, integration_id: args.integrationId,
      direction: "out", event: "otp.send", ok: res.ok, status_code: res.status,
      message: res.ok ? `OTP sent to ${phone}` : (j?.error?.message || `HTTP ${res.status}`),
      payload: body, response: j,
    });
    return { ok: res.ok, status: res.status, error: res.ok ? undefined : (j?.error?.message || `HTTP ${res.status}`) };
  } catch (e: any) {
    await logEvent({ workspace_id: args.workspaceId, integration_id: args.integrationId, direction: "out", event: "otp.send", ok: false, message: String(e?.message || e), payload: body });
    return { ok: false, error: String(e?.message || e) };
  }
}

function corsHeaders() {
  return {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "POST, GET, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Slice-Workspace",
  };
}

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "Content-Type": "application/json", ...corsHeaders() },
  });
}

async function logEvent(row: {
  workspace_id: string;
  integration_id?: string | null;
  direction: "in" | "out";
  event: string;
  ok: boolean;
  status_code?: number | null;
  message?: string | null;
  payload?: unknown;
  response?: unknown;
}) {
  try {
    await supabaseAdmin.from("integration_debug_logs").insert({
      workspace_id: row.workspace_id,
      integration_id: row.integration_id ?? null,
      provider: "woocommerce",
      direction: row.direction,
      event: row.event,
      status_code: row.status_code ?? null,
      ok: row.ok,
      message: row.message ?? null,
      payload: (row.payload as any) ?? {},
      response: (row.response as any) ?? null,
    });
  } catch (e) {
    console.error("integration_debug_logs insert failed", e);
  }
}

function bumpStats(meta: any, key: string, by = 1) {
  const stats = (meta?.stats as any) || {};
  stats[key] = (stats[key] || 0) + by;
  return { ...(meta || {}), stats };
}

async function upsertByIntegrationExternal(table: "ecom_orders" | "ecom_customers", row: Record<string, unknown>) {
  const payload = row as any;
  const { data: existing, error: findError } = await supabaseAdmin
    .from(table as any)
    .select("id")
    .eq("integration_id", payload.integration_id)
    .eq("external_id", payload.external_id)
    .maybeSingle();
  if (findError) throw findError;
  const existingId = (existing as any)?.id;
  if (existingId) {
    const { error } = await supabaseAdmin.from(table as any).update(payload).eq("id", existingId);
    if (error) throw error;
    return;
  }
  const { error } = await supabaseAdmin.from(table as any).insert(payload);
  if (error) throw error;
}

async function integrationStats(workspaceId: string, integrationId: string, meta: any) {
  const [{ count: customers }, { count: orders }, { count: products }, { data: revenueRows }] = await Promise.all([
    supabaseAdmin.from("ecom_customers").select("id", { count: "exact", head: true }).eq("workspace_id", workspaceId).eq("integration_id", integrationId),
    supabaseAdmin.from("ecom_orders").select("id", { count: "exact", head: true }).eq("workspace_id", workspaceId).eq("integration_id", integrationId),
    supabaseAdmin.from("integration_debug_logs").select("id", { count: "exact", head: true }).eq("workspace_id", workspaceId).eq("integration_id", integrationId).in("event", ["product.created", "product.updated"]),
    supabaseAdmin.from("ecom_orders").select("total").eq("workspace_id", workspaceId).eq("integration_id", integrationId),
  ]);
  const revenue = (revenueRows || []).reduce((sum: number, row: any) => sum + Number(row.total || 0), 0);
  return {
    meta: { ...(meta || {}), stats: { ...((meta?.stats as any) || {}), customers: customers || 0, orders: orders || 0, products: products || 0, revenue } },
    total_revenue: revenue,
  };
}

async function findOrCreateContact(workspaceId: string, phone: string | null, name: string | null, email: string | null) {
  if (!phone) return null;
  const normalized = `+${String(phone).replace(/[^\d]/g, "")}`;
  const ownerId = await getOwnerId(workspaceId);
  if (!ownerId) return null;
  const { data: id } = await supabaseAdmin.rpc("upsert_contact", {
    _workspace_id: workspaceId,
    _name: name || normalized,
    _phone: normalized,
    _email: email || undefined,
    _lead_source: "woocommerce",
    _user_id: ownerId,
  } as any);
  return (id as any) ?? null;
}

async function getOwnerId(workspaceId: string) {
  const { data } = await supabaseAdmin.from("workspaces").select("owner_id").eq("id", workspaceId).maybeSingle();
  return data?.owner_id as string | undefined;
}

function sanitizeParam(v: unknown) {
  const s = String(v ?? "").replace(/[\r\n\t]+/g, " ").replace(/ {4,}/g, "   ").trim();
  return s.length ? s : "-";
}

function appendUrlButtonParams(out: any[], schema: any[], urlButtonValue?: string | null) {
  const buttonsComp = schema.find((c: any) => String(c?.type || "").toUpperCase() === "BUTTONS");
  const buttons = Array.isArray(buttonsComp?.buttons) ? buttonsComp.buttons : [];
  for (let i = 0; i < buttons.length; i++) {
    const btn = buttons[i];
    if (String(btn?.type || "").toUpperCase() !== "URL") continue;
    const urlTmpl = String(btn?.url || "");
    const m = urlTmpl.match(/^(.*?)\{\{\s*\d+\s*\}\}/);
    if (!m) continue;
    const prefix = m[1];
    let suffix = "";
    if (urlButtonValue) {
      if (urlButtonValue.startsWith(prefix)) {
        suffix = urlButtonValue.slice(prefix.length);
      } else {
        // The stored recovery URL doesn't share the template-button prefix
        // (e.g. legacy carts saved as /api/public/r/<token> but the button
        // is https://slice.dotscube.com/r/{{1}}). Fall back to the last URL
        // path segment — that is the recovery token in both layouts and
        // keeps the click handler working at /r/<token>.
        try {
          const u = new URL(urlButtonValue);
          const segs = u.pathname.split("/").filter(Boolean);
          suffix = segs[segs.length - 1] || "";
        } catch {
          suffix = urlButtonValue;
        }
      }
    }
    if (!suffix) {
      const ex = Array.isArray(btn?.example) ? btn.example[0] : null;
      if (ex && typeof ex === "string") suffix = ex.startsWith(prefix) ? ex.slice(prefix.length) : ex;
    }
    if (!suffix) suffix = "recover";
    out.push({ type: "button", sub_type: "url", index: String(i), parameters: [{ type: "text", text: sanitizeParam(suffix) }] });
  }
}

function getRecoveryTokenFromUrl(urlButtonValue?: string | null) {
  if (!urlButtonValue) return "";
  try {
    const u = new URL(urlButtonValue);
    return u.pathname.split("/").filter(Boolean).pop() || "";
  } catch {
    return String(urlButtonValue).split(/[?#]/)[0].split("/").filter(Boolean).pop() || "";
  }
}

function applyInlineRecoveryTokenParams(schema: any[], bodyParams: string[], urlButtonValue?: string | null) {
  const token = getRecoveryTokenFromUrl(urlButtonValue);
  if (!token) return bodyParams;
  const bodyComp = schema.find((c: any) => String(c?.type || "").toUpperCase() === "BODY");
  const text = String(bodyComp?.text || "");
  if (!text) return bodyParams;

  const next = [...bodyParams];
  const re = /(?:https?:\/\/[^\s{}]+)?\/(?:api\/public\/)?r\/\{\{\s*(\d+)\s*\}\}/gi;
  let match: RegExpExecArray | null;
  while ((match = re.exec(text)) !== null) {
    const index = Number(match[1]) - 1;
    if (index >= 0) next[index] = token;
  }
  return next;
}

function buildComponents(schemaIn: any, bodyParams: string[], variableCount?: number | null, urlButtonValue?: string | null) {
  const out: any[] = [];
  const schema = Array.isArray(schemaIn) ? schemaIn : [];
  for (const comp of schema) {
    const type = String(comp?.type || "").toUpperCase();
    if (type === "HEADER") {
      const format = String(comp?.format || "TEXT").toUpperCase();
      if (format === "TEXT") {
        const headerVars: string[] = Array.isArray(comp?.example?.header_text) ? comp.example.header_text : [];
        const hasVar = /\{\{\d+\}\}/.test(String(comp?.text || ""));
        if (hasVar) {
          out.push({ type: "header", parameters: [{ type: "text", text: sanitizeParam(headerVars[0] ?? "Update") }] });
        }
      } else if (["IMAGE", "VIDEO", "DOCUMENT"].includes(format)) {
        const link = comp?.example?.header_handle?.[0];
        if (link) {
          const key = format.toLowerCase();
          out.push({ type: "header", parameters: [{ type: key, [key]: { link } }] });
        }
      }
    }
  }
  const count = Math.max(0, Number(variableCount || 0));
  if (count) {
    const effectiveBodyParams = applyInlineRecoveryTokenParams(schema, bodyParams, urlButtonValue);
    const values = Array.from({ length: count }, (_, i) => sanitizeParam(effectiveBodyParams[i]));
    out.push({ type: "body", parameters: values.map((text) => ({ type: "text", text })) });
  }
  appendUrlButtonParams(out, schema, urlButtonValue);
  return out.length ? out : undefined;
}

function normalizeE164(raw: string, defaultCountry = "91") {
  let digits = String(raw).replace(/[^\d]/g, "");
  if (!digits) return digits;
  // If 10-digit Indian-style number, prefix default country code (most common WC case).
  if (digits.length === 10) digits = defaultCountry + digits;
  return digits;
}

function renderTemplateBody(componentsSchema: any, params: string[]): string {
  const schema = Array.isArray(componentsSchema) ? componentsSchema : [];
  const bodyComp = schema.find((c: any) => String(c?.type || "").toUpperCase() === "BODY");
  const text: string = String(bodyComp?.text || "");
  if (!text) return "";
  return text.replace(/\{\{\s*(\d+)\s*\}\}/g, (_m, idx) => {
    const i = Math.max(0, Number(idx) - 1);
    const v = params[i];
    return v != null && String(v).length ? String(v) : "";
  });
}

async function recordOutboundMessage(args: {
  workspaceId: string;
  contactPhoneDigits: string;
  contactName?: string | null;
  contactId?: string | null;
  waMessageId?: string | null;
  templateName: string;
  renderedBody?: string | null;
  status: string;
  errorMessage?: string | null;
}) {
  try {
    const contactPhone = `+${args.contactPhoneDigits}`;
    const { data: convoId } = await supabaseAdmin.rpc("resolve_conversation", {
      _workspace_id: args.workspaceId,
      _phone: contactPhone,
      _name: args.contactName || contactPhone,
      _contact_id: args.contactId ?? null,
      _last_message_at: new Date().toISOString(),
    } as any);
    if (!convoId) return;
    const convo = { id: convoId as string };
    const preview = args.renderedBody && args.renderedBody.trim().length
      ? args.renderedBody
      : `[template] ${args.templateName}`;
    const { error: msgErr } = await supabaseAdmin.from("messages").insert({
      workspace_id: args.workspaceId,
      conversation_id: convo.id,
      direction: "out",
      type: "text",
      content: preview,
      wa_message_id: args.waMessageId ?? null,
      status: args.status,
      is_automated: true,
    } as any);
    if (msgErr) console.error("recordOutboundMessage messages insert failed", msgErr);
    await supabaseAdmin.from("conversations").update({
      last_message_at: new Date().toISOString(),
      last_message_preview: preview.slice(0, 140),
    }).eq("id", convo.id);
  } catch (e) {
    console.error("recordOutboundMessage failed", e);
  }
}

async function claimAutomationRun(args: {
  workspaceId: string;
  integrationId: string;
  automationKey: string;
  targetType: string;
  targetId: string;
}) {
  const { error } = await supabaseAdmin.from("ecom_automation_runs").insert({
    workspace_id: args.workspaceId,
    integration_id: args.integrationId,
    automation_key: args.automationKey,
    target_type: args.targetType,
    target_id: args.targetId,
    ok: false,
    message: "Claimed before sending",
  } as any);
  if (!error) return true;
  if ((error as any).code === "23505") return false;
  await logEvent({
    workspace_id: args.workspaceId,
    integration_id: args.integrationId,
    direction: "out",
    event: `wa.${args.automationKey}`,
    ok: false,
    message: `Unable to claim automation run: ${error.message}`,
  });
  return false;
}

async function markAutomationRun(args: {
  workspaceId: string;
  automationKey: string;
  targetType: string;
  targetId: string;
  ok: boolean;
  message?: string | null;
}) {
  await supabaseAdmin.from("ecom_automation_runs").update({
    ok: args.ok,
    message: args.message ?? null,
    sent_at: new Date().toISOString(),
  } as any)
    .eq("workspace_id", args.workspaceId)
    .eq("automation_key", args.automationKey)
    .eq("target_type", args.targetType)
    .eq("target_id", args.targetId);
}

// Deletes an unsent claim so a follow-up webhook event (which carries the
// missing data) can claim and send instead. Only removes rows that were
// claimed but never marked as sent.
async function releaseAutomationRun(args: {
  workspaceId: string;
  automationKey: string;
  targetType: string;
  targetId: string;
}) {
  await supabaseAdmin.from("ecom_automation_runs").delete()
    .eq("workspace_id", args.workspaceId)
    .eq("automation_key", args.automationKey)
    .eq("target_type", args.targetType)
    .eq("target_id", args.targetId)
    .eq("ok", false)
    .is("sent_at", null);
}

async function sendWhatsAppTemplate(workspaceId: string, integrationId: string, toPhone: string, templateName: string, language: string, params: string[], variableCount?: number | null, componentsSchema?: any, contactName?: string | null, urlButtonValue?: string | null) {
  const { data: settings } = await supabaseAdmin
    .from("whatsapp_settings").select("phone_number_id, access_token")
    .eq("workspace_id", workspaceId).maybeSingle();
  if (!settings?.phone_number_id || !settings.access_token) {
    await logEvent({ workspace_id: workspaceId, integration_id: integrationId, direction: "out", event: `wa.${templateName}`, ok: false, message: "WhatsApp credentials missing" });
    return { ok: false, error: "WhatsApp credentials missing" };
  }
  const phone = normalizeE164(toPhone);
  if (!phone || phone.length < 8) {
    await logEvent({ workspace_id: workspaceId, integration_id: integrationId, direction: "out", event: `wa.${templateName}`, ok: false, message: `Invalid phone number: ${toPhone}` });
    return { ok: false, error: "Invalid phone number" };
  }
  const components = buildComponents(componentsSchema, params, variableCount, urlButtonValue);
  console.log(`[woocommerce] send template="${templateName}" lang=${language} vars=${variableCount} params=${JSON.stringify(params)} to=${phone}`);
  const body = {
    messaging_product: "whatsapp",
    to: phone,
    type: "template",
    template: { name: templateName, language: { code: language }, ...(components ? { components } : {}) },
  };
  try {
    const res = await fetch(`${META_BASE}/${settings.phone_number_id}/messages`, {
      method: "POST",
      headers: { Authorization: `Bearer ${settings.access_token}`, "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    const j: any = await res.json().catch(() => ({}));
    const waMessageId = j?.messages?.[0]?.id ?? null;
    await logEvent({
      workspace_id: workspaceId,
      integration_id: integrationId,
      direction: "out",
      event: `wa.${templateName}`,
      ok: res.ok,
      status_code: res.status,
      message: res.ok ? `Sent to ${phone}` : (j?.error?.message || `HTTP ${res.status}`),
      payload: body,
      response: j,
    });
    // Track outbound message so Meta delivery webhook can update real status (delivered/read/failed)
    if (res.ok && waMessageId) {
      await recordOutboundMessage({
        workspaceId,
        contactPhoneDigits: phone,
        contactName: contactName ?? null,
        waMessageId,
        templateName,
        renderedBody: renderTemplateBody(componentsSchema, params),
        status: "sent",
      });
    }
    return { ok: res.ok, response: j };
  } catch (e: any) {
    await logEvent({ workspace_id: workspaceId, integration_id: integrationId, direction: "out", event: `wa.${templateName}`, ok: false, message: String(e?.message || e), payload: body });
    return { ok: false, error: String(e?.message || e) };
  }
}

function deriveStoreName(integration: any) {
  const fromMeta = integration?.meta?.store_name || integration?.meta?.shop_name;
  if (fromMeta) return String(fromMeta);
  const url = integration?.store_url || "";
  try {
    const h = new URL(url.startsWith("http") ? url : `https://${url}`).hostname;
    return h.replace(/^www\./, "").split(".")[0] || "our store";
  } catch {
    return "our store";
  }
}

function formatMoney(currency: string | null | undefined, amount: number | null | undefined) {
  const cur = (currency || "").trim();
  const symMap: Record<string, string> = { INR: "₹", USD: "$", EUR: "€", GBP: "£", AED: "AED ", AUD: "A$", CAD: "C$" };
  const sym = symMap[cur.toUpperCase()] || (cur ? `${cur} ` : "");
  const n = Number(amount ?? 0);
  return `${sym}${n.toFixed(2)}`;
}

function looksCashOnDelivery(raw: unknown) {
  const text = String(raw || "").toLowerCase();
  return /(^|[^a-z0-9])cod([^a-z0-9]|$)|cash[\s_-]*on[\s_-]*(delivery|pickup)|(^|[^a-z0-9])cash([^a-z0-9]|$)/i.test(text);
}

const CONFIRMATION_KEYS = ["cod_verification", "order_confirmation"];

async function triggerAutomation(integration: any, eventKey: string, ctx: { phone: string | null; name?: string | null; orderNumber?: string | null; total?: number | null; currency?: string | null; recoveryUrl?: string | null; isCod?: boolean; targetType?: string; targetId?: string | number | null; items?: any[]; email?: string | null; orderStatus?: string | null; orderDate?: string | null; orderPlacedAt?: string | null; }) {
  if (!ctx.phone) {
    await logEvent({ workspace_id: integration.workspace_id, integration_id: integration.id, direction: "out", event: `wa.${eventKey}`, ok: false, message: "Skipped — order has no phone number" });
    return;
  }
  const automations = (integration.meta?.automations as any) || {};
  // For COD orders on creation/processing, prefer cod_verification over the
  // generic order_confirmation template.
  const codAliases = ctx.isCod ? ["cod_verification"] : [];
  const aliases: Record<string, string[]> = {
    order_created: [...codAliases, "order_confirmation"],
    order_processing: [...codAliases, "order_confirmation"],
    order_pending: [...codAliases, "order_confirmation"],
    order_on_hold: [...codAliases, "order_confirmation"],
    "order_on-hold": [...codAliases, "order_confirmation"],
    order_completed: ["order_shipped", "order_confirmation"],
    cart_abandoned: ["abandoned_cart"],
  };
  const keys = [eventKey, ...(aliases[eventKey] || [])];
  // Resolve the FIRST enabled key in priority order — preserves which key matched.
  let matchedKey: string | null = null;
  let conf: any = null;
  for (const k of keys) {
    const v = automations[k];
    if (v === true || v?.enabled) { matchedKey = k; conf = v; break; }
  }
  if (!conf) {
    await logEvent({ workspace_id: integration.workspace_id, integration_id: integration.id, direction: "out", event: `wa.${eventKey}`, ok: false, message: `No automation configured for "${eventKey}"${ctx.isCod ? " (COD order)" : ""}. Tried: ${keys.join(", ")}. Enable it under Integrations → ${integration.provider} → Automations.` });
    return;
  }
  const configuredName = typeof conf === "object" ? conf.template_name : null;
  let template = null as any;
  if (configuredName) {
    const { data } = await supabaseAdmin.from("templates").select("meta_template_name, language, variables_count, components, variable_mapping").eq("workspace_id", integration.workspace_id).eq("meta_template_name", configuredName).maybeSingle();
    template = data;
  }
  if (!template) {
    const { data } = await supabaseAdmin.from("templates").select("meta_template_name, language, variables_count, components, variable_mapping").eq("workspace_id", integration.workspace_id).eq("status", "APPROVED").order("created_at", { ascending: false }).limit(1).maybeSingle();
    template = data;
  }
  if (!template?.meta_template_name) {
    await logEvent({ workspace_id: integration.workspace_id, integration_id: integration.id, direction: "out", event: `wa.${eventKey}`, ok: false, message: "No approved WhatsApp template found for this automation" });
    return;
  }
  // Guard: if the configured template or automation config is COD-specific,
  // only fire it for COD orders. Prevents a `cod_order_confirmation` template
  // hooked into the generic Order Confirmation slot from spamming prepaid orders.
  const codOnlyFlag = typeof conf === "object" && (conf.cod_only === true || conf.only_cod === true);
  const nameLooksCod = looksCashOnDelivery(String(configuredName || "") + " " + String(template.meta_template_name || ""));
  if ((codOnlyFlag || nameLooksCod) && !ctx.isCod) {
    await logEvent({ workspace_id: integration.workspace_id, integration_id: integration.id, direction: "out", event: `wa.${matchedKey || eventKey}`, ok: true, message: `Skipped — COD-only template "${template.meta_template_name}" not sent for non-COD order` });
    return;
  }
  const isCart = ["cart_abandoned", "abandoned_cart"].includes(eventKey)
    || /cart|abandon/i.test(template.meta_template_name);
  const dedupeTargetType = ctx.targetType || (isCart ? "cart" : "order");
  const dedupeTargetId = String(ctx.targetId || ctx.orderNumber || ctx.recoveryUrl || ctx.phone || "").trim();
  if (!dedupeTargetId) {
    await logEvent({ workspace_id: integration.workspace_id, integration_id: integration.id, direction: "out", event: `wa.${matchedKey || eventKey}`, ok: false, message: "Skipped — missing stable event/customer id for duplicate protection" });
    return;
  }
  const automationKey = matchedKey || eventKey;

  // ---- Order-confirmation timing + duplicate guards -----------------------
  // Timing must be measured from the ORIGINAL WooCommerce order creation time,
  // never from the moment Slice detected/synced the order. A late-arriving or
  // replayed webhook for an order placed hours ago must NOT fire a "confirm
  // your order" message.
  if (!isCart && CONFIRMATION_KEYS.includes(automationKey)) {
    const maxAgeMinutes = Number(
      (typeof conf === "object" && (conf.max_age_minutes ?? conf.confirmation_window_minutes)) ?? 360,
    );
    const placedAtMs = ctx.orderPlacedAt ? new Date(ctx.orderPlacedAt).getTime() : NaN;
    if (Number.isFinite(placedAtMs) && Number.isFinite(maxAgeMinutes) && maxAgeMinutes > 0) {
      const ageMin = Math.round((Date.now() - placedAtMs) / 60000);
      if (ageMin > maxAgeMinutes) {
        await logEvent({
          workspace_id: integration.workspace_id, integration_id: integration.id,
          direction: "out", event: `wa.${automationKey}.stale`, ok: true,
          message: `Skipped ${automationKey} for order ${ctx.orderNumber || dedupeTargetId} — order was placed ${ageMin} min ago (outside the ${maxAgeMinutes} min confirmation window).`,
        });
        return;
      }
    }

    // Cross-key duplicate protection: cod_verification and order_confirmation
    // are the same customer-facing confirmation. If either already sent for
    // this order, never send the other one again.
    const { data: prior } = await supabaseAdmin
      .from("ecom_automation_runs")
      .select("automation_key, ok, sent_at")
      .eq("workspace_id", integration.workspace_id)
      .eq("integration_id", integration.id)
      .eq("target_type", dedupeTargetType)
      .eq("target_id", dedupeTargetId)
      .in("automation_key", CONFIRMATION_KEYS);
    const alreadySent = (prior ?? []).find((r: any) => r.ok === true || r.sent_at);
    if (alreadySent) {
      await logEvent({
        workspace_id: integration.workspace_id, integration_id: integration.id,
        direction: "out", event: `wa.${automationKey}`, ok: true,
        message: `Skipped duplicate confirmation for order ${ctx.orderNumber || dedupeTargetId} — "${(alreadySent as any).automation_key}" was already sent.`,
      });
      return;
    }
  }

  const claimed = await claimAutomationRun({
    workspaceId: integration.workspace_id,
    integrationId: integration.id,
    automationKey,
    targetType: dedupeTargetType,
    targetId: dedupeTargetId,
  });
  if (!claimed) {
    await logEvent({ workspace_id: integration.workspace_id, integration_id: integration.id, direction: "out", event: `wa.${automationKey}`, ok: true, message: `Skipped duplicate ${automationKey} for ${dedupeTargetType}:${dedupeTargetId}` });
    return;
  }
  const lang = (typeof conf === "object" ? conf.language : null) || template.language || "en_US";
  const storeName = deriveStoreName(integration);
  const amountStr = formatMoney(ctx.currency, ctx.total);

  // Product info from order/cart line items — {{N}} slots classified as
  // productName/productPrice resolve from here instead of falling back to
  // an unrelated field (e.g. customer name).
  const items: any[] = Array.isArray(ctx.items) ? ctx.items : [];
  let firstItem = items.find((it: any) => it && String(it.name || "").trim()) || null;
  let productName = firstItem?.name
    ? (items.length > 1 ? `${String(firstItem.name)} +${items.length - 1} more` : String(firstItem.name))
    : null;
  let productPrice = firstItem != null && (firstItem.price ?? firstItem.total) != null
    ? formatMoney(ctx.currency, Number(firstItem.price ?? firstItem.total))
    : null;

  // WooCommerce's `woocommerce_new_order` hook can fire BEFORE line items are
  // saved to the order, so `order.created` sometimes arrives with items: [].
  // Recovery attempt: pull the items from the already-synced order row (a
  // later/earlier event may have stored them).
  if (!productName && !isCart && ctx.targetId != null) {
    const { data: syncedOrder } = await supabaseAdmin
      .from("ecom_orders").select("items")
      .eq("integration_id", integration.id)
      .eq("external_id", String(ctx.targetId))
      .maybeSingle();
    const dbItems: any[] = Array.isArray((syncedOrder as any)?.items) ? (syncedOrder as any).items : [];
    const dbFirst = dbItems.find((it: any) => it && String(it.name || "").trim()) || null;
    if (dbFirst) {
      productName = dbItems.length > 1 ? `${String(dbFirst.name)} +${dbItems.length - 1} more` : String(dbFirst.name);
      if ((dbFirst.price ?? dbFirst.total) != null) {
        productPrice = formatMoney(ctx.currency, Number(dbFirst.price ?? dbFirst.total));
      }
      await logEvent({
        workspace_id: integration.workspace_id, integration_id: integration.id,
        direction: "out", event: `wa.${automationKey}.product_recovery`,
        ok: true,
        message: `Webhook payload had no line items — recovered product "${productName}" from synced order ${ctx.orderNumber || ctx.targetId}`,
      });
    }
  }

  // Smart variable resolver: inspects the template body text to map each
  // {{N}} placeholder to the right field by surrounding keywords (e.g. the
  // word "Amount:" before a placeholder → amount). Falls back to positional
  // order so existing Slice templates keep working.
  const fallbackOrder: FieldKey[] = isCart
    ? ["name", "url", "amount", "storeName"]
    : ["name", "orderNumber", "storeName", "amount"];
  const resolved = resolveTemplateParams(
    template.components,
    {
      name: ctx.name || "Customer",
      orderNumber: ctx.orderNumber || "",
      storeName,
      amount: amountStr,
      amountRaw: ctx.total ?? null,
      currency: ctx.currency || null,
      url: ctx.recoveryUrl || null,
      productName,
      productPrice,
      orderStatus: ctx.orderStatus || null,
      orderDate: ctx.orderDate || null,
      customerEmail: ctx.email || null,
      customerPhone: ctx.phone || null,
    },
    fallbackOrder,
    template.variables_count,
    (template as any).variable_mapping ?? null,
  );
  const params = resolved.params;

  // Guard: a slot explicitly mapped/classified as product data is still empty.
  // NEVER send "-" (or a wrong field) in a product-name slot.
  const emptyProductSlots = resolved.mapping.filter(
    (m) => (m.field === "productName" || m.field === "productPrice") && !String(m.value || "").trim(),
  );
  if (emptyProductSlots.length && !isCart) {
    if (eventKey === "order_created") {
      // Follow-up Woo events (checkout_processed / thankyou / status_changed)
      // fire seconds later WITH line items — release the dedupe claim so one
      // of them sends the message with real product data.
      await releaseAutomationRun({
        workspaceId: integration.workspace_id,
        automationKey,
        targetType: dedupeTargetType,
        targetId: dedupeTargetId,
      });
      await logEvent({
        workspace_id: integration.workspace_id, integration_id: integration.id,
        direction: "out", event: `wa.${automationKey}.deferred`,
        ok: false,
        message: `Deferred ${automationKey} for order ${ctx.orderNumber || dedupeTargetId}: template "${template.meta_template_name}" needs Product Name but the order.created webhook carried ${items.length} line item(s) with no usable name. Waiting for a follow-up order event with items.`,
        payload: { template: template.meta_template_name, items: ctx.items ?? null },
      });
      return;
    }
    // Last resort on non-creation events: substitute a safe fallback so the
    // customer never sees "-" — and log loudly so it can be investigated.
    for (const slot of emptyProductSlots) {
      const fb = slot.field === "productName" ? "your order" : amountStr;
      params[slot.index - 1] = fb;
      slot.value = fb;
    }
    await logEvent({
      workspace_id: integration.workspace_id, integration_id: integration.id,
      direction: "out", event: `wa.${automationKey}.product_fallback`,
      ok: false,
      message: `Order ${ctx.orderNumber || dedupeTargetId}: product data missing in webhook AND synced order — sent fallback text instead. Slots: ${emptyProductSlots.map(s => `{{${s.index}}}=${s.field}`).join(", ")}. Check the WooCommerce plugin version on the store.`,
      payload: { template: template.meta_template_name, items: ctx.items ?? null },
    });
  }

  await logEvent({
    workspace_id: integration.workspace_id, integration_id: integration.id,
    direction: "out", event: `wa.${automationKey}.mapping`,
    ok: resolved.warnings.length === 0,
    message: resolved.warnings.length
      ? `Template "${template.meta_template_name}" mapping warnings: ${resolved.warnings.join("; ")}`
      : `Template "${template.meta_template_name}" mapped ${resolved.mapping.map(m => `{{${m.index}}}=${m.field}`).join(" ")}`,
    payload: { template: template.meta_template_name, language: lang, params, mapping: resolved.mapping, warnings: resolved.warnings, ctx: { name: ctx.name, orderNumber: ctx.orderNumber, total: ctx.total, currency: ctx.currency, storeName, recoveryUrl: ctx.recoveryUrl, productName, productPrice } },
  });
  const result = await sendWhatsAppTemplate(integration.workspace_id, integration.id, ctx.phone, template.meta_template_name, lang, params, template.variables_count, template.components, ctx.name ?? null, ctx.recoveryUrl ?? null);
  await markAutomationRun({
    workspaceId: integration.workspace_id,
    automationKey,
    targetType: dedupeTargetType,
    targetId: dedupeTargetId,
    ok: !!result.ok,
    message: result.ok ? `Sent template ${template.meta_template_name}` : (result.error || "WhatsApp send failed"),
  });
}



export const Route = createFileRoute("/api/public/woocommerce")({
  server: {
    handlers: {
      OPTIONS: async () => new Response(null, { status: 204, headers: corsHeaders() }),
      GET: async () => json({ ok: true, service: "slice-woocommerce-connector", version: 2 }),
      POST: async ({ request }) => {
        const auth = request.headers.get("authorization") || "";
        const wsHeader = request.headers.get("x-slice-workspace") || "";
        const apiKey = auth.replace(/^Bearer\s+/i, "").trim();

        if (!apiKey || !wsHeader) {
          return json({ ok: false, error: "Missing credentials" }, 401);
        }
        // Reject any value that would break the PostgREST .or() filter syntax below.
        if (/[,()"]/.test(apiKey) || apiKey.length > 200) {
          return json({ ok: false, error: "Invalid API key format" }, 401);
        }

        // Accept the bearer if it matches either the consumer key or the consumer secret
        // stored on the integration. The WP plugin's "API Key" field has historically been
        // populated with either value depending on how the merchant copied it from Slice,
        // and rotating the WooCommerce REST keys in Slice would otherwise lock out the plugin.
        const { data: integration } = await supabaseAdmin
          .from("store_integrations")
          .select("*")
          .eq("workspace_id", wsHeader)
          .eq("provider", "woocommerce")
          .or(`api_key.eq.${apiKey},api_secret.eq.${apiKey}`)
          .maybeSingle();

        if (!integration) {
          await logEvent({ workspace_id: wsHeader, direction: "in", event: "auth.fail", ok: false, status_code: 401, message: "Invalid API key or workspace — update the Slice plugin with the current API Key from Integrations → WooCommerce." });
          return json({ ok: false, error: "Invalid API key or workspace. Copy the current API Key from Slice → Integrations → WooCommerce and paste it into the WordPress plugin settings." }, 401);
        }

        let body: any = {};
        try { body = await request.json(); } catch { body = {}; }
        const event: string = body?.event || "unknown";
        const data: any = body?.data || {};

        try {
          let meta = (integration.meta as any) || {};
          let updateMeta = false;

          if (event === "ping") {
            await logEvent({ workspace_id: integration.workspace_id, integration_id: integration.id, direction: "in", event, ok: true, status_code: 200, payload: body });
            return json({ ok: true, message: "pong" });
          }

          if (event === "otp.config") {
            const otpCfg = (meta?.otp as any) || {};
            return json({
              ok: true,
              otp: {
                enabled: !!otpCfg.enabled,
                only_cod: !!otpCfg.only_cod,
                length: Number(otpCfg.length || 6),
                template_configured: !!otpCfg.template_name,
              },
            });
          }

          if (event === "otp.send") {
            const otpCfg = (meta?.otp as any) || {};
            if (!otpCfg.enabled) {
              return json({ ok: false, error: "OTP is disabled for this store" }, 400);
            }
            const payment = String(data?.payment_method || data?.payment || "").toLowerCase();
            const isCod = /cod|cash|delivery/.test(payment);
            if (otpCfg.only_cod && !isCod) {
              return json({ ok: true, skipped: "not_cod" });
            }
            if (!otpCfg.template_name) {
              return json({ ok: false, error: "No OTP template configured" }, 400);
            }
            const phoneRaw = String(data?.phone || "");
            if (!phoneRaw) return json({ ok: false, error: "Phone required" }, 400);
            const phone = normalizeE164(phoneRaw);
            const length = Number(otpCfg.length || 6);
            const code = generateOtp(length);
            // throttle: max 1 per 30s, max 5 per hour
            const since30s = new Date(Date.now() - 30 * 1000).toISOString();
            const sinceHour = new Date(Date.now() - 60 * 60 * 1000).toISOString();
            const { count: recent } = await supabaseAdmin.from("otp_codes")
              .select("id", { count: "exact", head: true })
              .eq("workspace_id", integration.workspace_id).eq("phone", phone).gte("created_at", since30s);
            if ((recent || 0) > 0) return json({ ok: false, error: "Please wait before requesting another code" }, 429);
            const { count: hourly } = await supabaseAdmin.from("otp_codes")
              .select("id", { count: "exact", head: true })
              .eq("workspace_id", integration.workspace_id).eq("phone", phone).gte("created_at", sinceHour);
            if ((hourly || 0) >= 5) return json({ ok: false, error: "Too many OTP requests, try again later" }, 429);

            const sendRes = await sendOtpTemplate({
              workspaceId: integration.workspace_id,
              integrationId: integration.id,
              toPhone: phone,
              templateName: otpCfg.template_name,
              language: otpCfg.language || "en",
              code,
            });
            if (!sendRes.ok) {
              return json({ ok: false, error: sendRes.error || "Failed to send OTP" }, 502);
            }
            await supabaseAdmin.from("otp_codes").insert({
              workspace_id: integration.workspace_id,
              integration_id: integration.id,
              phone,
              code_hash: hashOtp(code, integration.workspace_id),
              expires_at: new Date(Date.now() + 10 * 60 * 1000).toISOString(),
              context: { payment_method: payment || null, order_ref: data?.order_ref || null },
            } as any);
            return json({ ok: true, sent: true, length, expires_in: 600 });
          }

          if (event === "otp.verify") {
            const phoneRaw = String(data?.phone || "");
            const code = String(data?.code || "").trim();
            if (!phoneRaw || !code) return json({ ok: false, error: "phone and code required" }, 400);
            const phone = normalizeE164(phoneRaw);
            const { data: row } = await supabaseAdmin
              .from("otp_codes").select("*")
              .eq("workspace_id", integration.workspace_id).eq("phone", phone)
              .is("consumed_at", null)
              .order("created_at", { ascending: false }).limit(1).maybeSingle();
            if (!row) {
              await logEvent({ workspace_id: integration.workspace_id, integration_id: integration.id, direction: "in", event: "otp.verify", ok: false, status_code: 400, message: "No active OTP" });
              return json({ ok: false, error: "No active code, please request a new one" }, 400);
            }
            if (new Date(row.expires_at).getTime() < Date.now()) {
              return json({ ok: false, error: "Code expired" }, 400);
            }
            if ((row.attempts ?? 0) >= 5) {
              return json({ ok: false, error: "Too many attempts" }, 429);
            }
            const match = hashOtp(code, integration.workspace_id) === row.code_hash;
            if (!match) {
              await supabaseAdmin.from("otp_codes").update({ attempts: (row.attempts ?? 0) + 1 } as any).eq("id", row.id);
              await logEvent({ workspace_id: integration.workspace_id, integration_id: integration.id, direction: "in", event: "otp.verify", ok: false, status_code: 400, message: "Invalid code" });
              return json({ ok: false, error: "Invalid code" }, 400);
            }
            await supabaseAdmin.from("otp_codes").update({ consumed_at: new Date().toISOString() } as any).eq("id", row.id);
            await logEvent({ workspace_id: integration.workspace_id, integration_id: integration.id, direction: "in", event: "otp.verify", ok: true, status_code: 200, message: `OTP verified for ${phone}` });
            return json({ ok: true, verified: true });
          }


          if (["order.created", "order.status_changed", "order.checkout_processed", "order.thankyou"].includes(event)) {
            const cust = data.customer || {};
            const phone = cust.phone || null;
            const name = [cust.first_name, cust.last_name].filter(Boolean).join(" ").trim() || cust.email || null;
            const contactId = await findOrCreateContact(integration.workspace_id, phone, name, cust.email || null);

            const orderRow: Record<string, unknown> = {
              workspace_id: integration.workspace_id,
              integration_id: integration.id,
              external_id: String(data.id),
              order_number: String(data.number ?? data.id),
              contact_id: contactId,
              customer_name: name,
              customer_phone: phone ? `+${String(phone).replace(/[^\d]/g, "")}` : null,
              total: Number(data.total ?? 0),
              currency: data.currency || "USD",
              payment_status: data.status === "completed" || data.status === "processing" ? "paid" : "pending",
              fulfillment_status: data.status === "completed" ? "fulfilled" : "unfulfilled",
              source: "woocommerce",
              placed_at: data.created_at || new Date().toISOString(),
            };
            // Woo's `woocommerce_new_order` hook can fire before line items are
            // saved — never overwrite previously-synced items with an empty array.
            if (Array.isArray(data.items) && data.items.length) {
              orderRow.items = data.items;
            }
            // Detect Cash-on-Delivery (Woo sends payment_method="cod" or a title like "Cash on delivery")
            const paymentMethod = [
              data.payment_method,
              data.payment_method_title,
              data.payment_method_id,
              data.payment,
              data.payment_gateway,
              data.gateway,
            ].filter(Boolean).join(" ");
            const isCod = looksCashOnDelivery(paymentMethod);
            (orderRow as any).cod_status = isCod ? (data.status === "completed" ? "verified" : "pending") : null;
            await upsertByIntegrationExternal("ecom_orders", orderRow);

            if (cust.id || cust.email || phone) {
              await upsertByIntegrationExternal("ecom_customers", {
                workspace_id: integration.workspace_id,
                integration_id: integration.id,
                external_id: String(cust.id || cust.email || phone),
                contact_id: contactId,
                name,
                email: cust.email || null,
                phone: phone ? `+${String(phone).replace(/[^\d]/g, "")}` : null,
                total_orders: 1,
                lifetime_value: Number(data.total ?? 0),
                last_order_at: data.created_at || new Date().toISOString(),
              });
            }

            // Purchase completed → cancel any pending abandoned-cart reminder
            // for this shopper before the 30-minute timer fires.
            try {
              const { cancelPendingCartReminders } = await import("@/lib/abandoned-carts.server");
              await cancelPendingCartReminders({
                workspaceId: integration.workspace_id,
                integrationId: integration.id,
                phone,
                email: cust.email || null,
                cartToken: String(data.cart_key ?? data.session_id ?? ""),
              });
            } catch {}

            meta = bumpStats(meta, "orders_synced");
            meta = bumpStats(meta, `events_${event.replace(".", "_")}`);
            if (isCod) meta = bumpStats(meta, "cod_orders");
            updateMeta = true;

            // Automation trigger
            const eventKey = event === "order.created" ? "order_created" : `order_${data.new_status || data.status}`;
            await triggerAutomation(integration, eventKey, {
              phone, name,
              orderNumber: String(data.number ?? data.id),
              total: Number(data.total ?? 0),
              currency: data.currency || "",
              isCod,
              targetType: "order",
              targetId: data.id ?? data.number,
              items: data.items || [],
              email: cust.email || null,
              orderStatus: String(data.new_status || data.status || "") || null,
              orderPlacedAt: data.created_at ? String(data.created_at) : null,
              orderDate: data.created_at
                ? new Date(data.created_at).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" })
                : null,
            });
          } else if (event === "customer.created" || event === "customer.updated") {
            const phone = data.phone || null;
            const name = [data.first_name, data.last_name].filter(Boolean).join(" ").trim() || data.email || null;
            await findOrCreateContact(integration.workspace_id, phone, name, data.email || null);
            await upsertByIntegrationExternal("ecom_customers", {
              workspace_id: integration.workspace_id,
              integration_id: integration.id,
              external_id: String(data.id),
              name, email: data.email || null,
              phone: phone ? `+${String(phone).replace(/[^\d]/g, "")}` : null,
            });
            meta = bumpStats(meta, "customers_synced");
            updateMeta = true;
          } else if (event === "cart.updated" || event === "cart.abandoned") {
            const c = data.customer || data.billing || {};
            const phone = data.phone || c.phone || null;
            const email = data.email || c.email || null;
            const first = data.first_name || c.first_name || "";
            const last = data.last_name || c.last_name || "";
            const name = [first, last].filter(Boolean).join(" ").trim() || email || null;
            // Stable identifier — prefer real cart/session/customer IDs, then phone/email.
            // If none exist, skip insert entirely so anonymous carts don't spam the list.
            const stableId = data.session_id ?? data.cart_key ?? data.user_id ?? data.id ?? phone ?? email ?? null;
            if (!stableId) {
              await logEvent({ workspace_id: integration.workspace_id, integration_id: integration.id, direction: "in", event, ok: true, status_code: 200, message: "Cart skipped — no session_id / phone / email to identify it", payload: data });
              return json({ ok: true, event, skipped: "anonymous_cart" });
            }
            const cartToken = String(stableId);
            const { upsertAbandonedCart, normalizeWooCommerceRecoveryUrl } = await import("@/lib/abandoned-carts.server");
            const providerRecoveryUrl = normalizeWooCommerceRecoveryUrl(
              data.recovery_url || data.checkout_url || data.cart_url || null,
              integration.store_url || body?.site_url || null,
              cartToken,
            );
            const normalizedPhone = phone ? `+${String(phone).replace(/[^\d]/g, "")}` : null;
            const contactId = phone ? await findOrCreateContact(integration.workspace_id, phone, name, email) : null;

            // Resolve our app's public base URL from the inbound request so
            // recovery links work in both preview and production.
            const reqUrl = new URL(request.url);
            const appBaseUrl = `${reqUrl.protocol}//${reqUrl.host}`;
            const cartConf = (integration as any)?.meta?.automations?.abandoned_cart;
            const delayMinutes = typeof cartConf === "object" && cartConf
              ? Number(cartConf.delay_minutes)
              : NaN;
            await upsertAbandonedCart({
              workspaceId: integration.workspace_id,
              integrationId: integration.id,
              provider: "woocommerce",
              cartToken,
              externalId: cartToken,
              contactId,
              customerName: name,
              customerEmail: email,
              customerPhone: normalizedPhone,
              total: Number(data.total ?? 0),
              currency: data.currency || "USD",
              providerRecoveryUrl,
              items: data.items || [],
              abandonedAt: data.abandoned_at || data.cart_abandoned_at || data.updated_at || null,
              appBaseUrl,
              delayMinutes: Number.isFinite(delayMinutes) ? delayMinutes : 30,
            });

            meta = bumpStats(meta, "carts_seen");
            updateMeta = true;
            if (!phone) {
              await logEvent({ workspace_id: integration.workspace_id, integration_id: integration.id, direction: "out", event: "wa.cart_abandoned", ok: false, message: "Cart has no phone number — cannot send WhatsApp reminder", payload: data });
            }
            // The WhatsApp reminder is dispatched by the scheduled
            // ecommerce-automations cron once `send_scheduled_at` is due.
            // Sending inline would ignore the configured delay.
          } else if (event === "cart.recovered") {
            // Customer completed checkout for a previously-abandoned cart.
            const cartToken = String(data.session_id ?? data.cart_key ?? data.user_id ?? "");
            if (cartToken) {
              await supabaseAdmin.from("abandoned_carts").update({
                status: "recovered", recovered_at: new Date().toISOString(),
              } as any).eq("integration_id", integration.id).eq("cart_token", cartToken);
            }
            meta = bumpStats(meta, "carts_recovered");
            updateMeta = true;
          } else if (event === "product.created" || event === "product.updated") {
            meta = bumpStats(meta, "products_synced");
            updateMeta = true;
          }

          if (updateMeta) {
            const stats = await integrationStats(integration.workspace_id, integration.id, meta);
            await supabaseAdmin.from("store_integrations").update({
              meta: stats.meta,
              total_revenue: stats.total_revenue,
              last_sync_at: new Date().toISOString(),
              status: "connected",
            }).eq("id", integration.id);
          }

          await logEvent({ workspace_id: integration.workspace_id, integration_id: integration.id, direction: "in", event, ok: true, status_code: 200, payload: body });
          return json({ ok: true, event });
        } catch (e: any) {
          await logEvent({ workspace_id: integration.workspace_id, integration_id: integration.id, direction: "in", event, ok: false, status_code: 500, message: String(e?.message || e), payload: body });
          return json({ ok: false, error: String(e?.message || e) }, 500);
        }
      },
    },
  },
});
