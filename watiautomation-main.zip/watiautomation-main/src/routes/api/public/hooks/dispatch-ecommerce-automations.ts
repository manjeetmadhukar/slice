// Scheduled dispatcher for time-based eCommerce automations:
//   • review_request    — N days after an order is fulfilled
//   • repeat_purchase   — N days after an order is fulfilled (separate window)
//   • win_back          — customer inactive for N days
//
// Real-time events (order_confirmation, order_shipped, cod_verification,
// abandoned_cart) are dispatched directly from the WooCommerce / Shopify
// webhook handlers. product_launch is manual via Campaigns.
//
// Call from pg_cron / external scheduler hourly:
//   POST /api/public/hooks/dispatch-ecommerce-automations
//   Headers: Authorization: Bearer <CRON_DISPATCH_SECRET>
import { createFileRoute } from "@tanstack/react-router";
import { supabaseAdmin } from "@/integrations/supabase/client.server";
import { resolveTemplateParams, type FieldKey } from "@/lib/wa-template-vars.server";

const META_BASE = "https://graph.facebook.com/v21.0";

function timingSafeEq(a: string, b: string): boolean {
  if (!a || !b || a.length !== b.length) return false;
  let mismatch = 0;
  for (let i = 0; i < a.length; i++) mismatch |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return mismatch === 0;
}

function authorized(request: Request): boolean {
  const header = request.headers.get("authorization") || "";
  const provided = header.startsWith("Bearer ") ? header.slice(7) : header;
  const secret = process.env.CRON_DISPATCH_SECRET;
  if (secret && provided && timingSafeEq(provided, secret)) return true;
  // Also accept the Supabase publishable/anon key via apikey header so pg_cron
  // can invoke this endpoint consistently with the other scheduled hooks.
  const apiKey = request.headers.get("apikey") || "";
  const pub = process.env.SUPABASE_PUBLISHABLE_KEY || process.env.SUPABASE_ANON_KEY || "";
  if (pub && apiKey && timingSafeEq(apiKey, pub)) return true;
  return false;
}

function sanitizeParam(v: unknown) {
  const s = String(v ?? "").replace(/[\r\n\t]+/g, " ").replace(/ {4,}/g, "   ").trim();
  return s.length ? s : "-";
}

function appendUrlButtonParams(out: any[], schema: any[], urlButtonValue?: string | null) {
  const buttonsComp = schema.find((c: any) => String(c?.type || "").toUpperCase() === "BUTTONS");
  const buttons = Array.isArray(buttonsComp?.buttons) ? buttonsComp.buttons : [];
  for (let i = 0; i < buttons.length; i++) {
    const btn = buttons[i];
    if (String(btn?.type || "").toUpperCase() !== "URL") continue;
    const urlTmpl = String(btn?.url || "");
    const m = urlTmpl.match(/^(.*?)\{\{\s*\d+\s*\}\}/);
    if (!m) continue;
    const prefix = m[1];
    let suffix = "";
    if (urlButtonValue) {
      if (urlButtonValue.startsWith(prefix)) {
        suffix = urlButtonValue.slice(prefix.length);
      } else {
        try {
          const u = new URL(urlButtonValue);
          const segs = u.pathname.split("/").filter(Boolean);
          suffix = segs[segs.length - 1] || "";
        } catch {
          suffix = urlButtonValue;
        }
      }
    }
    if (!suffix) {
      const ex = Array.isArray(btn?.example) ? btn.example[0] : null;
      if (ex && typeof ex === "string") suffix = ex.startsWith(prefix) ? ex.slice(prefix.length) : ex;
    }
    if (!suffix) suffix = "recover";
    out.push({ type: "button", sub_type: "url", index: String(i), parameters: [{ type: "text", text: sanitizeParam(suffix) }] });
  }
}

function buildComponents(schemaIn: any, bodyParams: string[], variableCount?: number | null, urlButtonValue?: string | null) {
  const out: any[] = [];
  const schema = Array.isArray(schemaIn) ? schemaIn : [];
  for (const comp of schema) {
    const type = String(comp?.type || "").toUpperCase();
    if (type === "HEADER") {
      const format = String(comp?.format || "TEXT").toUpperCase();
      if (format === "TEXT") {
        const headerVars: string[] = Array.isArray(comp?.example?.header_text) ? comp.example.header_text : [];
        if (/\{\{\d+\}\}/.test(String(comp?.text || ""))) {
          out.push({ type: "header", parameters: [{ type: "text", text: sanitizeParam(headerVars[0] ?? "Update") }] });
        }
      } else if (["IMAGE", "VIDEO", "DOCUMENT"].includes(format)) {
        const link = comp?.example?.header_handle?.[0];
        if (link) {
          const key = format.toLowerCase();
          out.push({ type: "header", parameters: [{ type: key, [key]: { link } }] });
        }
      }
    }
  }
  const count = Math.max(0, Number(variableCount || 0));
  if (count) {
    const values = Array.from({ length: count }, (_, i) => sanitizeParam(bodyParams[i]));
    out.push({ type: "body", parameters: values.map((text) => ({ type: "text", text })) });
  }
  appendUrlButtonParams(out, schema, urlButtonValue);
  return out.length ? out : undefined;
}

function normalizeE164(raw: string, defaultCountry = "91") {
  let digits = String(raw).replace(/[^\d]/g, "");
  if (!digits) return digits;
  if (digits.length === 10) digits = defaultCountry + digits;
  return digits;
}

async function logRun(args: { workspace_id: string; integration_id: string | null; automation_key: string; target_type: string; target_id: string; ok: boolean; message?: string }) {
  await supabaseAdmin.from("ecom_automation_runs").upsert({
    workspace_id: args.workspace_id,
    integration_id: args.integration_id,
    automation_key: args.automation_key,
    target_type: args.target_type,
    target_id: args.target_id,
    ok: args.ok,
    message: args.message ?? null,
  } as any, { onConflict: "workspace_id,automation_key,target_type,target_id" });
}

async function alreadySent(workspace_id: string, automation_key: string, target_type: string, target_id: string) {
  const { data } = await supabaseAdmin.from("ecom_automation_runs")
    .select("id").eq("workspace_id", workspace_id).eq("automation_key", automation_key)
    .eq("target_type", target_type).eq("target_id", target_id).maybeSingle();
  return !!data;
}

async function claimRun(workspace_id: string, integration_id: string, automation_key: string, target_type: string, target_id: string) {
  const { error } = await supabaseAdmin.from("ecom_automation_runs").insert({
    workspace_id,
    integration_id,
    automation_key,
    target_type,
    target_id,
    ok: false,
    message: "Claimed before sending",
  } as any);
  if (!error) return true;
  if ((error as any).code === "23505") return false;
  throw error;
}

async function sendTemplate(workspace_id: string, integration_id: string, automation_key: string, target: { type: string; id: string }, conf: any, ctx: { phone: string; name: string | null; orderNumber?: string | null; total?: number | null; currency?: string | null; storeName?: string | null }) {
  if (await alreadySent(workspace_id, automation_key, target.type, target.id)) return { skipped: "already_sent" };
  const { data: settings } = await supabaseAdmin.from("whatsapp_settings").select("phone_number_id, access_token").eq("workspace_id", workspace_id).maybeSingle();
  if (!settings?.phone_number_id || !settings.access_token) {
    await logRun({ workspace_id, integration_id, automation_key, target_type: target.type, target_id: target.id, ok: false, message: "WhatsApp credentials missing" });
    return { error: "wa_creds_missing" };
  }
  const configuredName = typeof conf === "object" ? conf.template_name : null;
  let template: any = null;
  if (configuredName) {
    const { data } = await supabaseAdmin.from("templates").select("meta_template_name, language, variables_count, components, variable_mapping").eq("workspace_id", workspace_id).eq("meta_template_name", configuredName).maybeSingle();
    template = data;
  }
  if (!template) {
    const { data } = await supabaseAdmin.from("templates").select("meta_template_name, language, variables_count, components, variable_mapping").eq("workspace_id", workspace_id).eq("status", "APPROVED").order("created_at", { ascending: false }).limit(1).maybeSingle();
    template = data;
  }
  if (!template?.meta_template_name) {
    await logRun({ workspace_id, integration_id, automation_key, target_type: target.type, target_id: target.id, ok: false, message: "No approved template" });
    return { error: "no_template" };
  }
  const lang = (typeof conf === "object" ? conf.language : null) || template.language || "en_US";
  const symMap: Record<string, string> = { INR: "₹", USD: "$", EUR: "€", GBP: "£" };
  const sym = symMap[(ctx.currency || "").toUpperCase()] || (ctx.currency ? `${ctx.currency} ` : "");
  const amountStr = `${sym}${Number(ctx.total ?? 0).toFixed(2)}`;
  const fallbackOrder: FieldKey[] = ["name", "orderNumber", "storeName", "amount"];
  const resolved = resolveTemplateParams(
    template.components,
    {
      name: ctx.name || "Customer",
      orderNumber: ctx.orderNumber || "",
      storeName: (ctx as any).storeName || "our store",
      amount: amountStr,
      amountRaw: ctx.total ?? null,
      currency: ctx.currency || null,
    },
    fallbackOrder,
    template.variables_count,
    (template as any).variable_mapping ?? null,
  );
  const params = resolved.params;
  const components = buildComponents(template.components, params, template.variables_count);
  console.log(`[ecom-automation] ${automation_key} template="${template.meta_template_name}" mapping=${JSON.stringify(resolved.mapping)} warnings=${JSON.stringify(resolved.warnings)}`);
  try {
    await supabaseAdmin.from("integration_debug_logs").insert({
      workspace_id, integration_id, direction: "out",
      event: `wa.${automation_key}.mapping`,
      ok: resolved.warnings.length === 0,
      message: resolved.warnings.length
        ? `Template "${template.meta_template_name}" warnings: ${resolved.warnings.join("; ")}`
        : `Template "${template.meta_template_name}" mapped ${resolved.mapping.map(m => `{{${m.index}}}=${m.field}`).join(" ")}`,
      payload: { template: template.meta_template_name, language: lang, params, mapping: resolved.mapping, warnings: resolved.warnings, ctx } as any,
    } as any);
  } catch {}
  const phone = normalizeE164(ctx.phone);
  const claimed = await claimRun(workspace_id, integration_id, automation_key, target.type, target.id);
  if (!claimed) return { skipped: "already_sent" };
  try {
    const res = await fetch(`${META_BASE}/${settings.phone_number_id}/messages`, {
      method: "POST",
      headers: { Authorization: `Bearer ${(settings as any).access_token}`, "Content-Type": "application/json" },
      body: JSON.stringify({ messaging_product: "whatsapp", to: phone, type: "template", template: { name: template.meta_template_name, language: { code: lang }, ...(components ? { components } : {}) } }),
    });
    const j: any = await res.json().catch(() => ({}));
    await logRun({ workspace_id, integration_id, automation_key, target_type: target.type, target_id: target.id, ok: res.ok, message: res.ok ? `Sent to ${phone}` : (j?.error?.message || `HTTP ${res.status}`) });
    return { ok: res.ok };
  } catch (e: any) {
    await logRun({ workspace_id, integration_id, automation_key, target_type: target.type, target_id: target.id, ok: false, message: String(e?.message || e) });
    return { error: String(e?.message || e) };
  }
}

function getAutomationConfig(integration: any, key: string): any {
  const v = (integration.meta?.automations as any)?.[key];
  return v === true ? { enabled: true } : (v && v.enabled ? v : null);
}

function daysFor(conf: any, defaultDays: number) {
  const n = Number(conf?.delay_days);
  return Number.isFinite(n) && n > 0 ? n : defaultDays;
}

function deriveStoreName(integration: any): string {
  return (integration?.meta?.store_name || integration?.meta?.shop_name
    || (integration?.shop_domain ? String(integration.shop_domain).split(".")[0] : null)
    || (integration?.store_url ? String(integration.store_url).replace(/^https?:\/\//, "").split(/[./]/)[0] : null)
    || "our store") as string;
}

async function dispatchReviewRequest(integration: any) {
  const conf = getAutomationConfig(integration, "review_request");
  if (!conf) return { skipped: "disabled" };
  const days = daysFor(conf, 3);
  const cutoff = new Date(Date.now() - days * 86400_000).toISOString();
  const storeName = deriveStoreName(integration);
  const { data: orders } = await supabaseAdmin.from("ecom_orders").select("id, external_id, customer_name, customer_phone, total, currency, order_number, placed_at, fulfillment_status").eq("workspace_id", integration.workspace_id).eq("integration_id", integration.id).eq("fulfillment_status", "fulfilled").lte("placed_at", cutoff).limit(50);
  let sent = 0;
  for (const o of orders ?? []) {
    if (!o.customer_phone) continue;
    const r = await sendTemplate(integration.workspace_id, integration.id, "review_request", { type: "order", id: o.external_id || o.id }, conf, { phone: o.customer_phone, name: o.customer_name, orderNumber: o.order_number, total: Number(o.total), currency: o.currency, storeName });
    if ((r as any).ok) sent++;
  }
  return { sent, scanned: orders?.length ?? 0 };
}

async function dispatchRepeatPurchase(integration: any) {
  const conf = getAutomationConfig(integration, "repeat_purchase");
  if (!conf) return { skipped: "disabled" };
  const days = daysFor(conf, 14);
  const cutoff = new Date(Date.now() - days * 86400_000).toISOString();
  const storeName = deriveStoreName(integration);
  const { data: orders } = await supabaseAdmin.from("ecom_orders").select("id, external_id, customer_name, customer_phone, total, currency, order_number, placed_at").eq("workspace_id", integration.workspace_id).eq("integration_id", integration.id).eq("fulfillment_status", "fulfilled").lte("placed_at", cutoff).limit(50);
  let sent = 0;
  for (const o of orders ?? []) {
    if (!o.customer_phone) continue;
    const r = await sendTemplate(integration.workspace_id, integration.id, "repeat_purchase", { type: "order", id: o.external_id || o.id }, conf, { phone: o.customer_phone, name: o.customer_name, orderNumber: o.order_number, total: Number(o.total), currency: o.currency, storeName });
    if ((r as any).ok) sent++;
  }
  return { sent, scanned: orders?.length ?? 0 };
}

async function dispatchWinBack(integration: any) {
  const conf = getAutomationConfig(integration, "win_back");
  if (!conf) return { skipped: "disabled" };
  const days = daysFor(conf, 60);
  const cutoff = new Date(Date.now() - days * 86400_000).toISOString();
  const storeName = deriveStoreName(integration);
  const { data: customers } = await supabaseAdmin.from("ecom_customers").select("id, external_id, name, phone, lifetime_value, last_order_at").eq("workspace_id", integration.workspace_id).eq("integration_id", integration.id).lte("last_order_at", cutoff).limit(50);
  let sent = 0;
  for (const c of customers ?? []) {
    if (!c.phone) continue;
    const r = await sendTemplate(integration.workspace_id, integration.id, "win_back", { type: "customer", id: c.external_id || c.id }, conf, { phone: c.phone, name: c.name, total: Number(c.lifetime_value), currency: "", storeName });
    if ((r as any).ok) sent++;
  }
  return { sent, scanned: customers?.length ?? 0 };
}

async function dispatchAbandonedCarts(integration: any) {
  const conf = getAutomationConfig(integration, "abandoned_cart");
  if (!conf) return { skipped: "disabled" };
  const nowIso = new Date().toISOString();
  // Don't blast reminders for very old carts (e.g. after a backlog/outage).
  const maxAgeIso = new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString();
  const recentCutoffIso = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString();

  // Only send once the configured delay has elapsed (send_scheduled_at <= now).
  // Filters are applied in SQL — `last_reminder_at is null` plus a non-empty
  // phone keeps already-handled and un-sendable carts out of the scan, so a
  // backlog of anonymous carts can no longer starve fresh, sendable ones.
  const { data: dueCarts } = await supabaseAdmin
    .from("abandoned_carts")
    .select("id, cart_token, customer_phone, customer_name, customer_email, total, currency, recovery_url, items, send_scheduled_at, abandoned_at, reminders_sent")
    .eq("workspace_id", integration.workspace_id)
    .eq("integration_id", integration.id)
    .eq("status", "abandoned")
    .is("last_reminder_at", null)
    .not("customer_phone", "is", null)
    .neq("customer_phone", "")
    .not("recovery_url", "is", null)
    .lte("send_scheduled_at", nowIso)
    .gte("abandoned_at", maxAgeIso)
    .order("send_scheduled_at", { ascending: true })
    .limit(50);

  // Surface recent carts that are due but unsendable (missing phone) so
  // merchants see the reason in Integrations → Debug Center. Bounded to the
  // last 24h, otherwise every cron tick re-logs the same ancient carts.
  const { data: unsendable } = await supabaseAdmin
    .from("abandoned_carts")
    .select("id, cart_token, customer_phone, recovery_url")
    .eq("workspace_id", integration.workspace_id)
    .eq("integration_id", integration.id)
    .eq("status", "abandoned")
    .is("last_reminder_at", null)
    .lte("send_scheduled_at", nowIso)
    .gte("abandoned_at", recentCutoffIso)
    .or("customer_phone.is.null,customer_phone.eq.,recovery_url.is.null")
    .limit(20);
  for (const cart of (unsendable ?? []) as any[]) {
    const reason = !cart.customer_phone
      ? "Cart has no phone number — checkout plugin did not send billing_phone"
      : "Cart has no recovery URL";
    try {
      await supabaseAdmin.from("integration_debug_logs").insert({
        workspace_id: integration.workspace_id,
        integration_id: integration.id,
        provider: integration.provider,
        direction: "out",
        event: "wa.cart_abandoned.skip",
        ok: false,
        message: `${reason} (cart ${cart.cart_token})`,
        payload: { cart_id: cart.id, cart_token: cart.cart_token, has_phone: !!cart.customer_phone, has_url: !!cart.recovery_url } as any,
      } as any);
    } catch {}
  }

  const sendable = (dueCarts ?? []) as any[];
  if (!sendable.length) return { sent: 0, scanned: 0 };


  // Carts already dispatched in an earlier run (duplicate guard rows) must be
  // stamped so they leave the queue instead of being re-scanned forever.
  const targetIds = sendable.map((c) => String(c.cart_token || c.id));
  const { data: priorRuns } = await supabaseAdmin
    .from("ecom_automation_runs")
    .select("target_id, ok")
    .eq("workspace_id", integration.workspace_id)
    .eq("automation_key", "abandoned_cart")
    .eq("target_type", "cart")
    .in("target_id", targetIds);
  const done = new Set((priorRuns ?? []).filter((r: any) => r.ok === true).map((r: any) => String(r.target_id)));

  const { triggerShopifyAutomation } = await import("@/lib/shopify.server");

  // Give a claimed reminder slot back when nothing was actually delivered, so
  // a controlled retry stays possible without allowing duplicate successes.
  const releaseCartReminder = async (workspaceId: string, phoneKey: string, cartId: string) => {
    try {
      await supabaseAdmin.rpc("release_cart_reminder", {
        _workspace_id: workspaceId,
        _phone_key: phoneKey,
        _cart_id: cartId,
      } as any);
    } catch (e: any) {
      console.error("[abandoned-cart dispatch] release failed", e?.message || e);
    }
  };


  // Contact-level duplicate protection. Stores (esp. WooCommerce + CartFlows)
  // mint a NEW cart token per session/heartbeat, so the same shopper can end
  // up with 2-4 distinct abandoned_carts rows. Per-cart idempotency alone then
  // still sends 2-4 identical WhatsApp reminders. `claim_cart_reminder` is an
  // atomic DB claim keyed on (workspace, last-10-digit phone) that allows only
  // one reminder per shopper inside the configured window.
  const capHours = Number(
    (typeof conf === "object" ? (conf.dedupe_hours ?? conf.frequency_cap_hours) : null) ?? 24,
  );
  const windowMinutes = Math.max(0, (Number.isFinite(capHours) ? capHours : 24) * 60);
  const phoneKeyOf = (v: unknown) => {
    const d = String(v ?? "").replace(/[^\d]/g, "");
    return d.length > 10 ? d.slice(-10) : d;
  };

  let sent = 0;
  for (const cart of sendable) {
    const targetId = String(cart.cart_token || cart.id);
    if (done.has(targetId)) {
      await supabaseAdmin.from("abandoned_carts")
        .update({ last_reminder_at: new Date().toISOString() } as any)
        .eq("id", cart.id);
      continue;
    }
    const phoneKey = phoneKeyOf(cart.customer_phone);
    let claimed = true;
    try {
      const { data: claimOk, error: claimErr } = await supabaseAdmin.rpc("claim_cart_reminder", {
        _workspace_id: integration.workspace_id,
        _phone_key: phoneKey,
        _cart_id: cart.id,
        _cart_token: targetId,
        _window_minutes: windowMinutes,
      } as any);
      if (claimErr) throw claimErr;
      claimed = claimOk !== false;
    } catch (e: any) {
      console.error("[abandoned-cart dispatch] claim failed", e?.message || e);
    }
    if (!claimed) {
      // Another cart for this same shopper was already reminded inside the
      // window — retire this duplicate cart and record exactly why.
      await supabaseAdmin.from("abandoned_carts")
        .update({ last_reminder_at: new Date().toISOString() } as any)
        .eq("id", cart.id);
      try {
        await supabaseAdmin.from("integration_debug_logs").insert({
          workspace_id: integration.workspace_id,
          integration_id: integration.id,
          provider: integration.provider,
          direction: "out",
          event: "wa.cart_abandoned.duplicate_skip",
          ok: true,
          message: `Duplicate abandoned-cart reminder skipped — ${cart.customer_phone} already received one within the last ${capHours}h (cart ${targetId})`,
          payload: { cart_id: cart.id, cart_token: targetId, phone_key: phoneKey, window_hours: capHours } as any,
        } as any);
      } catch {}
      console.log(`[abandoned-cart dispatch] duplicate skip phone_key=${phoneKey} cart=${targetId}`);
      continue;
    }
    try {
      // Final guard: re-read the cart immediately before sending. The shopper
      // may have completed the purchase (status -> recovered) or another cron
      // tick may have claimed it since this batch was selected.
      const { data: fresh } = await supabaseAdmin
        .from("abandoned_carts")
        .select("status, last_reminder_at, send_scheduled_at")
        .eq("id", cart.id)
        .maybeSingle();
      const dueNow = (fresh as any)?.send_scheduled_at
        ? new Date((fresh as any).send_scheduled_at).getTime() <= Date.now()
        : false;
      if (!fresh || (fresh as any).status !== "abandoned" || (fresh as any).last_reminder_at || !dueNow) {
        await releaseCartReminder(integration.workspace_id, phoneKey, cart.id);
        console.log(`[abandoned-cart dispatch] skip cart=${targetId} status=${(fresh as any)?.status ?? "gone"} due=${dueNow}`);
        continue;
      }
      // Stamp before calling Meta so an immediate failed-delivery webhook can
      // reliably find and re-queue this cart. Clear it again for API failures.
      const attemptAt = new Date().toISOString();
      await supabaseAdmin.from("abandoned_carts")
        .update({ last_reminder_at: attemptAt } as any)
        .eq("id", cart.id)
        .is("last_reminder_at", null);
      const result = await triggerShopifyAutomation(integration, "cart_abandoned", {
        phone: cart.customer_phone,
        name: cart.customer_name,
        total: Number(cart.total || 0),
        currency: cart.currency || "",
        recoveryUrl: cart.recovery_url,
        targetType: "cart",
        targetId,
        items: Array.isArray(cart.items) ? cart.items : [],
        email: cart.customer_email,
      } as any);
      if (result.ok) {
        await supabaseAdmin.from("abandoned_carts").update({
          reminders_sent: Number((cart as any).reminders_sent || 0) + 1,
        } as any).eq("id", cart.id);
        sent++;
      } else {
        // Nothing was delivered — give the slot back so a controlled retry is
        // still possible without opening the door to duplicate successes.
        await releaseCartReminder(integration.workspace_id, phoneKey, cart.id);
        await supabaseAdmin.from("abandoned_carts").update({
          last_reminder_at: null,
          send_scheduled_at: new Date(Date.now() + 2 * 60_000).toISOString(),
        } as any).eq("id", cart.id).eq("last_reminder_at", attemptAt);
      }
    } catch (e: any) {
      console.error("[abandoned-cart dispatch] error", e?.message || e);
      await releaseCartReminder(integration.workspace_id, phoneKey, cart.id);
      await supabaseAdmin.from("abandoned_carts").update({
        last_reminder_at: null,
        send_scheduled_at: new Date(Date.now() + 2 * 60_000).toISOString(),
      } as any).eq("id", cart.id);
    }
  }
  return { sent, scanned: sendable.length };
}


export const Route = createFileRoute("/api/public/hooks/dispatch-ecommerce-automations")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        if (!authorized(request)) return new Response("Forbidden", { status: 403 });
        const { data: integrations } = await supabaseAdmin.from("store_integrations").select("*").eq("status", "connected");
        const results: any[] = [];
        for (const integration of integrations ?? []) {
          try {
            const [rev, rep, win, cart] = await Promise.all([
              dispatchReviewRequest(integration),
              dispatchRepeatPurchase(integration),
              dispatchWinBack(integration),
              dispatchAbandonedCarts(integration),
            ]);
            results.push({ integration_id: integration.id, workspace_id: integration.workspace_id, review_request: rev, repeat_purchase: rep, win_back: win, abandoned_cart: cart });
          } catch (e: any) {
            results.push({ integration_id: integration.id, error: String(e?.message || e) });
          }
        }
        return new Response(JSON.stringify({ ok: true, results }), { status: 200, headers: { "Content-Type": "application/json" } });
      },
    },
  },
});
