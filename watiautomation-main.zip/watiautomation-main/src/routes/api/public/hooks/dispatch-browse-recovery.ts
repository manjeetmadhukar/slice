// Scheduled dispatcher for Browse Abandonment Recovery reminders.
//
// Called by pg_cron every minute:
//   POST /api/public/hooks/dispatch-browse-recovery
//   Headers: apikey: <SUPABASE_ANON_KEY>
//
// Picks browse_events whose dispatch_scheduled_at <= now, verifies the
// contact hasn't converted (no ecom_orders / abandoned_carts matching
// their phone since the view), mints a Slice /br/{token} short link, and
// sends a WhatsApp template via the central sendWhatsAppMessage helper.
import { createFileRoute } from "@tanstack/react-router";
import { randomBytes } from "crypto";
import { supabaseAdmin } from "@/integrations/supabase/client.server";
import { sendWhatsAppMessage } from "@/lib/whatsapp-send.server";
import { resolveTemplateParams, type FieldKey } from "@/lib/wa-template-vars.server";

function timingSafeEq(a: string, b: string): boolean {
  if (!a || !b || a.length !== b.length) return false;
  let m = 0;
  for (let i = 0; i < a.length; i++) m |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return m === 0;
}

function authorized(request: Request): boolean {
  const header = request.headers.get("authorization") || "";
  const provided = header.startsWith("Bearer ") ? header.slice(7) : header;
  const secret = process.env.CRON_DISPATCH_SECRET;
  if (secret && provided && timingSafeEq(provided, secret)) return true;
  const apiKey = request.headers.get("apikey") || "";
  const pub = process.env.SUPABASE_PUBLISHABLE_KEY || process.env.SUPABASE_ANON_KEY || "";
  if (pub && apiKey && timingSafeEq(apiKey, pub)) return true;
  return false;
}

function sanitizeParam(v: unknown) {
  const s = String(v ?? "").replace(/[\r\n\t]+/g, " ").replace(/ {4,}/g, "   ").trim();
  return s.length ? s : "-";
}

function appendUrlButtonParams(out: any[], schema: any[], urlValue?: string | null) {
  const buttonsComp = schema.find((c: any) => String(c?.type || "").toUpperCase() === "BUTTONS");
  const buttons = Array.isArray(buttonsComp?.buttons) ? buttonsComp.buttons : [];
  for (let i = 0; i < buttons.length; i++) {
    const btn = buttons[i];
    if (String(btn?.type || "").toUpperCase() !== "URL") continue;
    const urlTmpl = String(btn?.url || "");
    const m = urlTmpl.match(/^(.*?)\{\{\s*\d+\s*\}\}/);
    if (!m) continue;
    const prefix = m[1];
    let suffix = "";
    if (urlValue) {
      if (urlValue.startsWith(prefix)) suffix = urlValue.slice(prefix.length);
      else {
        try {
          const u = new URL(urlValue);
          const segs = u.pathname.split("/").filter(Boolean);
          suffix = segs[segs.length - 1] || "";
        } catch { suffix = urlValue; }
      }
    }
    if (!suffix) suffix = "view";
    out.push({ type: "button", sub_type: "url", index: String(i), parameters: [{ type: "text", text: sanitizeParam(suffix) }] });
  }
}

function buildComponents(schemaIn: any, bodyParams: string[], variableCount?: number | null, urlButtonValue?: string | null, headerImageUrl?: string | null) {
  const out: any[] = [];
  const schema = Array.isArray(schemaIn) ? schemaIn : [];
  for (const comp of schema) {
    const type = String(comp?.type || "").toUpperCase();
    if (type === "HEADER") {
      const format = String(comp?.format || "TEXT").toUpperCase();
      if (format === "TEXT") {
        if (/\{\{\d+\}\}/.test(String(comp?.text || ""))) {
          out.push({ type: "header", parameters: [{ type: "text", text: sanitizeParam(bodyParams[0] ?? "Update") }] });
        }
      } else if (["IMAGE", "VIDEO", "DOCUMENT"].includes(format)) {
        const link = (format === "IMAGE" && headerImageUrl) || comp?.example?.header_handle?.[0];
        if (link) {
          const key = format.toLowerCase();
          out.push({ type: "header", parameters: [{ type: key, [key]: { link } }] });
        }
      }
    }
  }
  const count = Math.max(0, Number(variableCount || 0));
  if (count) {
    const values = Array.from({ length: count }, (_, i) => sanitizeParam(bodyParams[i]));
    out.push({ type: "body", parameters: values.map((text) => ({ type: "text", text })) });
  }
  appendUrlButtonParams(out, schema, urlButtonValue);
  return out.length ? out : undefined;
}

function formatMinor(minor: number | null | undefined, currency: string | null | undefined) {
  const n = Number(minor || 0);
  if (!n) return "";
  const zeroDecimal = ["JPY", "KRW", "VND", "IDR"];
  const isZero = currency ? zeroDecimal.includes(currency.toUpperCase()) : false;
  const num = isZero ? n : n / 100;
  const symMap: Record<string, string> = { INR: "₹", USD: "$", EUR: "€", GBP: "£" };
  const sym = currency ? (symMap[currency.toUpperCase()] || `${currency} `) : "";
  return `${sym}${num.toFixed(isZero ? 0 : 2)}`;
}

function shortLinkBase(): string {
  const env = process.env.APP_BASE_URL;
  const raw = (env || "https://slice.dotscube.com").replace(/\/$/, "");
  try {
    const url = new URL(raw);
    const host = url.hostname.toLowerCase();
    if (host === "slice.dotscube.com" || host === "localhost" || host === "127.0.0.1") return raw;
    if (host.endsWith(".lovable.app") || host.includes("lovableproject.com")) return "https://slice.dotscube.com";
    return raw;
  } catch { return "https://slice.dotscube.com"; }
}

function stableMediaFallback(): string {
  // Use the direct published asset host. The custom domain's bot protection
  // can return 403 when Meta fetches template header media.
  return "https://watiautomation.lovable.app/slice-logo.png";
}

async function dispatchForWorkspace(workspaceId: string) {
  const { data: settings } = await supabaseAdmin
    .from("browse_recovery_settings" as any)
    .select("*").eq("workspace_id", workspaceId).maybeSingle();
  if (!settings || !(settings as any).enabled) return { skipped: "disabled" };

  const nowIso = new Date().toISOString();
  const { data: due } = await supabaseAdmin
    .from("browse_events" as any)
    .select("id, contact_id, phone, phone_normalized, product_id, product_title, product_url, product_image_url, price_minor, currency, viewed_at, dispatch_scheduled_at")
    .eq("workspace_id", workspaceId)
    .is("dispatched_at", null)
    .is("converted_at", null)
    .is("skip_reason", null)
    .not("dispatch_scheduled_at", "is", null)
    .lte("dispatch_scheduled_at", nowIso)
    .limit(50);
  if (!due?.length) return { sent: 0, scanned: 0 };

  const { data: wa } = await supabaseAdmin
    .from("whatsapp_settings")
    .select("phone_number_id, access_token")
    .eq("workspace_id", workspaceId).maybeSingle();
  if (!wa?.phone_number_id || !wa?.access_token) {
    for (const ev of due as any[]) {
      await supabaseAdmin.from("browse_events" as any)
        .update({ skip_reason: "wa_creds_missing" }).eq("id", ev.id);
    }
    return { sent: 0, scanned: due.length, skipped: "wa_creds_missing" };
  }

  const s = settings as any;
  let template: any = null;
  if (s.template_id) {
    const { data } = await supabaseAdmin.from("templates")
      .select("meta_template_name, language, variables_count, components, variable_mapping")
      .eq("id", s.template_id).maybeSingle();
    template = data;
  }
  if (!template) {
    for (const ev of due as any[]) {
      await supabaseAdmin.from("browse_events" as any)
        .update({ skip_reason: "no_template" }).eq("id", ev.id);
    }
    return { sent: 0, scanned: due.length, skipped: "no_template" };
  }

  const lang = s.template_language || template.language || "en_US";
  const base = shortLinkBase();
  let sent = 0;

  for (const ev of due as any[]) {
    if (!ev.phone_normalized || !ev.product_url) {
      await supabaseAdmin.from("browse_events" as any).update({
        skip_reason: !ev.phone_normalized ? "missing_phone" : "missing_product_url",
      }).eq("id", ev.id);
      continue;
    }

    // Conversion check: any ecom_orders for this phone since view?
    const { data: orders } = await supabaseAdmin.from("ecom_orders")
      .select("id, total, currency, placed_at")
      .eq("workspace_id", workspaceId)
      .eq("customer_phone", ev.phone)
      .gte("placed_at", ev.viewed_at)
      .limit(1);
    if (orders && orders.length) {
      const order: any = orders[0];
      await supabaseAdmin.from("browse_events" as any).update({
        converted_at: order.placed_at,
        conversion_value_minor: Math.round(Number(order.total || 0) * 100),
        currency: order.currency || ev.currency,
      }).eq("id", ev.id);
      continue;
    }

    // Mint recovery token → /br/{token}
    const token = `br_${randomBytes(14).toString("base64url")}`;
    const { error: clickErr } = await supabaseAdmin.from("browse_recovery_clicks" as any).insert({
      workspace_id: workspaceId,
      browse_event_id: ev.id,
      token,
      target_url: ev.product_url,
    });
    if (clickErr) {
      await supabaseAdmin.from("browse_events" as any)
        .update({ skip_reason: `click_insert_failed:${clickErr.message}` }).eq("id", ev.id);
      continue;
    }
    const shortUrl = `${base}/br/${encodeURIComponent(token)}`;

    // Contact name
    let contactName: string | null = null;
    if (ev.contact_id) {
      const { data: c } = await supabaseAdmin.from("contacts").select("name").eq("id", ev.contact_id).maybeSingle();
      contactName = (c as any)?.name || null;
    }

    const priceStr = formatMinor(ev.price_minor, ev.currency);
    const fallbackOrder: FieldKey[] = ["name", "productName", "productPrice", "url"];
    const resolved = resolveTemplateParams(
      template.components,
      {
        name: contactName || "there",
        productName: ev.product_title || "our product",
        productPrice: priceStr,
        amount: priceStr,
        amountRaw: ev.price_minor != null ? Number(ev.price_minor) / 100 : null,
        currency: ev.currency || null,
        url: shortUrl,
      },
      fallbackOrder,
      template.variables_count,
      template.variable_mapping ?? null,
    );

    const components = buildComponents(
      template.components,
      resolved.params,
      template.variables_count,
      shortUrl,
      ev.product_image_url || stableMediaFallback(),
    );

    const result = await sendWhatsAppMessage({
      settings: { phone_number_id: (wa as any).phone_number_id, access_token: (wa as any).access_token },
      toPhone: ev.phone_normalized,
      payload: {
        messaging_product: "whatsapp",
        type: "template",
        template: { name: template.meta_template_name, language: { code: lang }, ...(components ? { components } : {}) },
      },
      context: {
        workspaceId,
        purpose: "browse_recovery",
        contactId: ev.contact_id,
        templateName: template.meta_template_name,
        language: lang,
        messageType: "template",
      },
    });

    if (result.ok) {
      sent++;
      await supabaseAdmin.from("browse_events" as any).update({
        dispatched_at: new Date().toISOString(),
        wa_message_id: result.wa_message_id ?? null,
      }).eq("id", ev.id);
    } else {
      await supabaseAdmin.from("browse_events" as any).update({
        skip_reason: `send_failed:${result.classification?.title || result.http_status}`,
      }).eq("id", ev.id);
    }
  }

  return { sent, scanned: due.length };
}

export const Route = createFileRoute("/api/public/hooks/dispatch-browse-recovery")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        if (!authorized(request)) return new Response("Forbidden", { status: 403 });
        const { data: ws } = await supabaseAdmin
          .from("browse_recovery_settings" as any)
          .select("workspace_id").eq("enabled", true);
        const results: any[] = [];
        for (const row of (ws as any[]) ?? []) {
          try {
            const r = await dispatchForWorkspace(row.workspace_id);
            results.push({ workspace_id: row.workspace_id, ...r });
          } catch (e: any) {
            results.push({ workspace_id: row.workspace_id, error: String(e?.message || e) });
          }
        }
        return new Response(JSON.stringify({ ok: true, results }), {
          status: 200, headers: { "Content-Type": "application/json" },
        });
      },
    },
  },
});
