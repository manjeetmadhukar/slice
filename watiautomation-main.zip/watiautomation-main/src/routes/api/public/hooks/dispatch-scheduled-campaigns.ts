import { createFileRoute } from "@tanstack/react-router";
import { supabaseAdmin } from "@/integrations/supabase/client.server";
import { executeCampaign } from "@/lib/campaign-executor.server";

function timingSafeEq(a: string, b: string): boolean {
  if (!a || !b || a.length !== b.length) return false;
  let mismatch = 0;
  for (let i = 0; i < a.length; i++) mismatch |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return mismatch === 0;
}

function isProjectAnonKey(value: string): boolean {
  try {
    const [, payload] = value.split(".");
    if (!payload) return false;
    const normalized = payload.replace(/-/g, "+").replace(/_/g, "/");
    const padded = normalized.padEnd(Math.ceil(normalized.length / 4) * 4, "=");
    const json = JSON.parse(atob(padded));
    return json?.iss === "supabase" && json?.role === "anon";
  } catch {
    return false;
  }
}

function authorized(request: Request): boolean {
  const header = request.headers.get("authorization") || "";
  const provided = header.startsWith("Bearer ") ? header.slice(7) : header;
  const secret = process.env.CRON_DISPATCH_SECRET;
  if (secret && timingSafeEq(provided, secret)) return true;

  // Existing database cron jobs call this route with the backend publishable
  // key in the `apikey` header. Accept that internal cron shape too; otherwise
  // campaigns that hit the worker time budget stay in "sending" with pending
  // recipients forever because the minute-by-minute dispatcher returns 403.
  const apikey = request.headers.get("apikey") || "";
  const publishableKey = process.env.SUPABASE_PUBLISHABLE_KEY
    || process.env.VITE_SUPABASE_PUBLISHABLE_KEY
    || import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY
    || "";
  if (publishableKey && timingSafeEq(apikey, publishableKey)) return true;
  if (apikey && isProjectAnonKey(apikey)) return true;

  return false;
}


export const Route = createFileRoute("/api/public/hooks/dispatch-scheduled-campaigns")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        if (!authorized(request)) {
          return new Response("Forbidden", { status: 403 });
        }
        const now = new Date().toISOString();
        const { data: due, error } = await supabaseAdmin
          .from("campaigns")
          .select("id")
          .eq("status", "scheduled")
          .lte("scheduled_at", now)
          .limit(50);
        if (error) {
          return new Response(JSON.stringify({ ok: false, error: error.message }), {
            status: 500, headers: { "Content-Type": "application/json" },
          });
        }

        // Also resume campaigns left in "sending" with pending recipients
        // (previous run hit the worker time budget).
        const { data: stuck } = await supabaseAdmin
          .from("campaigns")
          .select("id")
          .eq("status", "sending")
          .is("completed_at", null)
          .limit(50);

        const results: any[] = [];
        for (const c of due ?? []) {
          // Claim the campaign atomically so concurrent crons don't double-send
          const { data: claimed } = await supabaseAdmin
            .from("campaigns")
            .update({ status: "sending" })
            .eq("id", c.id)
            .eq("status", "scheduled")
            .select("id").maybeSingle();
          if (!claimed) continue;
          try {
            const r = await executeCampaign(supabaseAdmin, c.id);
            results.push({ id: c.id, ...r });
          } catch (e: any) {
            results.push({ id: c.id, error: String(e?.message || e) });
            await supabaseAdmin.from("campaigns").update({
              status: "failed", completed_at: new Date().toISOString(),
            }).eq("id", c.id);
          }
        }

        // Resume stuck campaigns (already status=sending, no extra claim needed
        // because executor handles per-recipient atomic claim).
        for (const c of stuck ?? []) {
          try {
            const r = await executeCampaign(supabaseAdmin, c.id);
            results.push({ id: c.id, resumed: true, ...r });
          } catch (e: any) {
            results.push({ id: c.id, resumed: true, error: String(e?.message || e) });
          }
        }

        return new Response(JSON.stringify({ ok: true, processed: results.length, results }), {
          headers: { "Content-Type": "application/json" },
        });
      },
      GET: async ({ request }) => {
        if (!authorized(request)) return new Response("Forbidden", { status: 403 });
        return new Response("ok");
      },
    },
  },
});
