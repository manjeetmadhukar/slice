import { createFileRoute } from "@tanstack/react-router";
import { supabaseAdmin } from "@/integrations/supabase/client.server";

export const Route = createFileRoute("/api/public/pricing")({
  server: {
    handlers: {
      GET: async () => {
        const [plansRes, featuresRes, linksRes] = await Promise.all([
          supabaseAdmin
            .from("plan_templates")
            .select("id, name, description, features, limits, price_monthly, price_yearly, currency, gateway_ids, is_active, is_popular, badge_text, position")
            .eq("is_active", true)
            .order("position", { ascending: true })
            .order("price_monthly", { ascending: true }),
          supabaseAdmin
            .from("master_features")
            .select("id, name, description, category, icon, position, is_active")
            .eq("is_active", true)
            .order("position", { ascending: true }),
          supabaseAdmin
            .from("plan_template_features")
            .select("template_id, feature_id, included, custom_value"),
        ]);
        if (plansRes.error) {
          return new Response(JSON.stringify({ error: plansRes.error.message }), {
            status: 500,
            headers: { "Content-Type": "application/json" },
          });
        }
        return new Response(
          JSON.stringify({
            plans: plansRes.data ?? [],
            masterFeatures: featuresRes.data ?? [],
            planFeatures: linksRes.data ?? [],
          }),
          {
            status: 200,
            headers: { "Content-Type": "application/json", "Cache-Control": "public, max-age=60" },
          },
        );
      },
    },
  },
});
