// Shopify webhook receiver. Verifies HMAC against SHOPIFY_API_SECRET, looks up
// the integration by shop domain, and upserts orders / customers / checkouts.
import { createFileRoute } from "@tanstack/react-router";
import { supabaseAdmin } from "@/integrations/supabase/client.server";
import {
  verifyWebhookHmac, getShopifyCreds, logEvent, getAppBaseUrl,
  upsertByIntegrationExternal, mapOrderRow, mapCustomerRow, findOrCreateContact,
  triggerShopifyAutomation,
} from "@/lib/shopify.server";
import { upsertAbandonedCart } from "@/lib/abandoned-carts.server";

function bumpStats(meta: any, key: string, by = 1) {
  const stats = (meta?.stats as any) || {};
  stats[key] = (stats[key] || 0) + by;
  return { ...(meta || {}), stats };
}

function looksCashOnDelivery(raw: unknown) {
  const text = String(raw || "").toLowerCase();
  return /(^|[^a-z0-9])cod([^a-z0-9]|$)|cash[\s_-]*on[\s_-]*(delivery|pickup)|(^|[^a-z0-9])cash([^a-z0-9]|$)|(^|[^a-z0-9])manual([^a-z0-9]|$)/i.test(text);
}

export const Route = createFileRoute("/api/public/shopify/webhook")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        let creds;
        try { creds = getShopifyCreds(); } catch (e: any) { return new Response(e.message, { status: 500 }); }

        const rawBody = await request.text();
        const hmac = request.headers.get("x-shopify-hmac-sha256");
        if (!verifyWebhookHmac(rawBody, hmac, creds.apiSecret)) {
          return new Response("Invalid HMAC", { status: 401 });
        }
        const shop = request.headers.get("x-shopify-shop-domain") || "";
        const topic = request.headers.get("x-shopify-topic") || "";
        if (!shop || !topic) return new Response("Missing shop/topic", { status: 400 });

        const { data: integration } = await supabaseAdmin
          .from("store_integrations").select("*")
          .eq("provider", "shopify").eq("store_url", `https://${shop}`).maybeSingle();
        if (!integration) return new Response("Unknown shop", { status: 404 });

        let payload: any = {};
        try { payload = JSON.parse(rawBody); } catch {}

        const wsId = (integration as any).workspace_id;
        const integId = (integration as any).id;
        let meta = (integration as any).meta || {};
        let updateMeta = false;

        try {
          if (topic.startsWith("orders/")) {
            const phone = payload.phone || payload.customer?.phone || payload.shipping_address?.phone || null;
            const name = [payload.customer?.first_name, payload.customer?.last_name].filter(Boolean).join(" ").trim() || payload.customer?.email || null;
            const contactId = await findOrCreateContact(wsId, phone, name, payload.customer?.email || null);
            const row: any = mapOrderRow(wsId, integId, payload);
            row.contact_id = contactId;
            await upsertByIntegrationExternal("ecom_orders", row);
            meta = bumpStats(meta, `events_${topic.replace("/", "_")}`); updateMeta = true;

            // Purchase completed → cancel any pending abandoned-cart reminder.
            try {
              const { cancelPendingCartReminders } = await import("@/lib/abandoned-carts.server");
              await cancelPendingCartReminders({
                workspaceId: wsId,
                integrationId: integId,
                phone,
                email: payload.customer?.email || payload.email || null,
                cartToken: String(payload.checkout_token || payload.cart_token || ""),
              });
            } catch {}

            // Map Shopify topic → automation event key and dispatch WhatsApp template
            const eventKey =
              topic === "orders/create" ? "order_created" :
              topic === "orders/paid" ? "order_paid" :
              topic === "orders/fulfilled" ? "order_fulfilled" :
              topic === "orders/cancelled" ? "order_cancelled" : null;
            if (eventKey) {
              const gateways = (Array.isArray(payload.payment_gateway_names) ? payload.payment_gateway_names.join(" ") : "") + " " + String(payload.gateway || "") + " " + String(payload.processing_method || "");
              const isCod = looksCashOnDelivery(gateways);
              await triggerShopifyAutomation(integration, eventKey, {
                phone,
                name,
                orderNumber: String(payload.name || payload.order_number || payload.id),
                total: Number(payload.total_price || payload.current_total_price || 0),
                currency: payload.currency || payload.presentment_currency || "",
                isCod,
                targetType: "order",
                targetId: payload.id,
                items: payload.line_items || [],
                email: payload.customer?.email || payload.email || null,
                orderStatus: payload.financial_status || payload.fulfillment_status || null,
                orderDate: payload.created_at
                  ? new Date(payload.created_at).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" })
                  : null,
              });
            }
          } else if (topic.startsWith("customers/")) {
            const phone = payload.phone || payload.default_address?.phone || null;
            const name = [payload.first_name, payload.last_name].filter(Boolean).join(" ").trim() || payload.email || null;
            await findOrCreateContact(wsId, phone, name, payload.email || null);
            await upsertByIntegrationExternal("ecom_customers", mapCustomerRow(wsId, integId, payload));
            meta = bumpStats(meta, `events_${topic.replace("/", "_")}`); updateMeta = true;
          } else if (topic.startsWith("checkouts/")) {
            // Native Shopify abandoned-cart capture. The checkout payload
            // includes `abandoned_checkout_url` — a signed URL that restores
            // the exact cart, variants, qty, discounts and customer info for
            // ~30 days. We wrap it in a Slice short link so the WhatsApp
            // button can be tracked.
            const cartToken: string = String(payload.token || payload.cart_token || payload.id || "");
            if (cartToken && topic !== "checkouts/delete") {
              const phone = payload.phone || payload.customer?.phone || payload.shipping_address?.phone || payload.billing_address?.phone || null;
              const email = payload.email || payload.customer?.email || null;
              const name = [payload.customer?.first_name || payload.shipping_address?.first_name, payload.customer?.last_name || payload.shipping_address?.last_name].filter(Boolean).join(" ").trim() || email || null;
              const normalizedPhone = phone ? `+${String(phone).replace(/[^\d]/g, "")}` : null;
              const contactId = phone ? await findOrCreateContact(wsId, phone, name, email) : null;
              const items = (payload.line_items || []).map((li: any) => ({
                name: li.title || li.name,
                variant: li.variant_title || null,
                quantity: li.quantity,
                price: Number(li.price || 0),
                product_id: li.product_id,
                variant_id: li.variant_id,
                image_url: li.image_url || li.image?.src || null,
              }));
              const cartConf = (integration as any)?.meta?.automations?.abandoned_cart;
              const delayMinutes = typeof cartConf === "object" && cartConf
                ? Number(cartConf.delay_minutes)
                : NaN;
              const { recoveryUrl } = await upsertAbandonedCart({
                workspaceId: wsId,
                integrationId: integId,
                provider: "shopify",
                cartToken,
                externalId: String(payload.id || cartToken),
                contactId,
                customerName: name,
                customerEmail: email,
                customerPhone: normalizedPhone,
                total: Number(payload.total_price || payload.subtotal_price || 0),
                currency: payload.currency || payload.presentment_currency || "USD",
                providerRecoveryUrl: payload.abandoned_checkout_url || null,
                items,
                abandonedAt: payload.updated_at || payload.created_at || null,
                appBaseUrl: getAppBaseUrl(request),
                delayMinutes: Number.isFinite(delayMinutes) ? delayMinutes : 30,
              });
              meta = bumpStats(meta, "events_checkouts"); updateMeta = true;

              // The WhatsApp reminder is dispatched by the scheduled
              // ecommerce-automations cron once `send_scheduled_at` is due.
              // Sending inline here would ignore the configured delay and
              // ping the customer the instant they enter checkout details.
              // Recovery URL is intentionally not sent from the webhook.
              void recoveryUrl;
            } else if (cartToken && topic === "checkouts/delete") {
              // Customer completed checkout → mark recovered so we stop
              // sending reminders and so analytics can attribute revenue.
              await supabaseAdmin.from("abandoned_carts").update({
                status: "recovered", recovered_at: new Date().toISOString(),
              } as any).eq("integration_id", integId).eq("cart_token", cartToken);
              meta = bumpStats(meta, "events_checkouts_delete"); updateMeta = true;
            }
          } else if (topic === "app/uninstalled") {
            await supabaseAdmin.from("store_integrations").update({ status: "disconnected", access_token: null }).eq("id", integId);
          }

          if (updateMeta) await supabaseAdmin.from("store_integrations").update({ meta, last_sync_at: new Date().toISOString() }).eq("id", integId);

          await logEvent({ workspace_id: wsId, integration_id: integId, direction: "in", event: topic, ok: true, status_code: 200, payload });
          return new Response("ok");
        } catch (e: any) {
          await logEvent({ workspace_id: wsId, integration_id: integId, direction: "in", event: topic, ok: false, message: String(e?.message || e), payload });
          return new Response("error", { status: 500 });
        }
      },
    },
  },
});
