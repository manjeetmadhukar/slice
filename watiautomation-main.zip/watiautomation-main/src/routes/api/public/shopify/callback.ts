// Shopify OAuth callback. Verifies HMAC + state, exchanges code for an
// access_token, stores it on the integration, registers webhooks, kicks off
// an initial backfill, and redirects back to /integrations.
import { createFileRoute } from "@tanstack/react-router";
import { supabaseAdmin } from "@/integrations/supabase/client.server";
import {
  exchangeCodeForToken, getAppBaseUrl, getShopifyCreds, normalizeShopDomain,
  verifyOAuthHmac, registerWebhooks, backfillStore, logEvent, persistWebhookMeta,
} from "@/lib/shopify.server";
import { randomBytes } from "crypto";

export const Route = createFileRoute("/api/public/shopify/callback")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        let creds;
        try { creds = getShopifyCreds(); } catch (e: any) { return new Response(e.message, { status: 500 }); }
        const url = new URL(request.url);
        const params = url.searchParams;

        if (!verifyOAuthHmac(params, creds.apiSecret)) {
          return new Response("Invalid HMAC", { status: 400 });
        }
        const shop = normalizeShopDomain(params.get("shop") || "");
        const code = params.get("code");
        const stateRaw = params.get("state") || "";
        if (!shop || !code || !stateRaw) return new Response("Missing parameters", { status: 400 });

        let state: { w?: string; n?: string } = {};
        try { state = JSON.parse(Buffer.from(stateRaw, "base64url").toString("utf8")); } catch {}
        const workspaceId = state.w;
        const nonce = state.n;
        if (!workspaceId || !nonce) return new Response("Invalid state", { status: 400 });

        // Match the pending integration record
        const { data: pending } = await supabaseAdmin
          .from("store_integrations").select("*")
          .eq("workspace_id", workspaceId).eq("provider", "shopify").maybeSingle();
        if (!pending || (pending as any).meta?.oauth_nonce !== nonce) {
          return new Response("State mismatch — please start the install again from Slice.", { status: 400 });
        }

        let accessToken: string;
        let scopes: string[] = [];
        try {
          const tokenResult = await exchangeCodeForToken(shop, code);
          accessToken = tokenResult.accessToken;
          scopes = tokenResult.scopes;
        } catch (e: any) {
          await logEvent({ workspace_id: workspaceId, integration_id: (pending as any).id, direction: "in", event: "oauth.token_exchange", ok: false, message: String(e?.message || e) });
          return new Response(`Token exchange failed: ${e?.message || e}`, { status: 502 });
        }

        const webhookSecret = randomBytes(24).toString("hex");
        const meta: any = (pending as any).meta || {};
        delete meta.oauth_nonce;
        meta.shop = shop;
        meta.installed_at = new Date().toISOString();
        meta.shopify_permissions = { granted_scopes: scopes, checked_at: new Date().toISOString() };

        await supabaseAdmin.from("store_integrations").update({
          access_token: accessToken,
          api_key: creds.apiKey,
          api_secret: creds.apiSecret,
          webhook_secret: webhookSecret,
          store_url: `https://${shop}`,
          status: "connected",
          meta,
        }).eq("id", (pending as any).id);

        const base = getAppBaseUrl(request);
        const webhookUrl = `${base}/api/public/shopify/webhook?shop=${encodeURIComponent(shop)}`;

        registerWebhooks(shop, accessToken, webhookUrl, scopes).then(async (results) => {
          await persistWebhookMeta((pending as any).id, results);
          await logEvent({ workspace_id: workspaceId, integration_id: (pending as any).id, direction: "out", event: "webhooks.registered", ok: results.every((r) => r.ok), response: results });
        }).catch((e) => logEvent({ workspace_id: workspaceId, integration_id: (pending as any).id, direction: "out", event: "webhooks.registered", ok: false, message: String(e?.message || e) }));

        backfillStore(workspaceId, (pending as any).id, shop, accessToken).catch((e) =>
          logEvent({ workspace_id: workspaceId, integration_id: (pending as any).id, direction: "in", event: "sync.error", ok: false, message: String(e?.message || e) }),
        );

        await logEvent({ workspace_id: workspaceId, integration_id: (pending as any).id, direction: "in", event: "oauth.installed", ok: true, message: `Connected ${shop}` });

        return Response.redirect(`${base}/integrations?shopify=connected`, 302);
      },
    },
  },
});
