// Initiate Shopify OAuth install. Two entry points:
//   1) From inside Slice: /api/public/shopify/install?shop=...&workspace_id=<uuid>
//   2) From Shopify (App URL or custom-app install link): /api/public/shopify/install?shop=...
//      In this case there's no workspace_id. We try to reuse the workspace
//      from an existing integration for this shop; if there isn't one, we
//      redirect the merchant to /integrations?shop=... so they can pick one
//      after signing in.
import { createFileRoute } from "@tanstack/react-router";
import { supabaseAdmin } from "@/integrations/supabase/client.server";
import {
  buildAuthorizeUrl, getAppBaseUrl, getShopifyCreds, makeNonce, normalizeShopDomain,
} from "@/lib/shopify.server";

export const Route = createFileRoute("/api/public/shopify/install")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        try {
          getShopifyCreds();
        } catch (e: any) {
          return new Response(e.message, { status: 500 });
        }
        const url = new URL(request.url);
        const shop = normalizeShopDomain(url.searchParams.get("shop") || "");
        if (!shop) return new Response("Missing or invalid shop parameter", { status: 400 });

        const base = getAppBaseUrl(request);
        let workspaceId = url.searchParams.get("workspace_id");

        // Fallback when Shopify itself opens the App URL with no workspace context.
        if (!workspaceId) {
          const { data: existing } = await supabaseAdmin
            .from("store_integrations")
            .select("workspace_id")
            .eq("provider", "shopify")
            .eq("store_url", `https://${shop}`)
            .maybeSingle();
          if (existing?.workspace_id) {
            workspaceId = existing.workspace_id as string;
          } else {
            // Send the merchant into Slice to choose / create a workspace.
            return Response.redirect(`${base}/integrations?shop=${encodeURIComponent(shop)}`, 302);
          }
        }

        const nonce = makeNonce();
        const redirectUri = `${base}/api/public/shopify/callback`;

        await supabaseAdmin.from("store_integrations").upsert({
          workspace_id: workspaceId,
          user_id: (await supabaseAdmin.from("workspaces").select("owner_id").eq("id", workspaceId).maybeSingle()).data?.owner_id,
          provider: "shopify",
          store_url: `https://${shop}`,
          status: "pending",
          meta: { oauth_nonce: nonce, shop, started_at: new Date().toISOString() },
        } as any, { onConflict: "workspace_id,provider" });

        const state = Buffer.from(JSON.stringify({ w: workspaceId, n: nonce })).toString("base64url");
        return Response.redirect(buildAuthorizeUrl(shop, state, redirectUri), 302);
      },
    },
  },
});
