// Public ingestion endpoint for the Slice browse-tracking script.
// Called by public/slice-browse-tracker.js from Shopify/WooCommerce
// storefronts. Authenticates via a per-workspace token (created in the
// Browse Recovery admin UI) so the script never ships a Supabase key.
import { createFileRoute } from "@tanstack/react-router";
import { supabaseAdmin } from "@/integrations/supabase/client.server";

const CORS_HEADERS: Record<string, string> = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "content-type,authorization",
  "Access-Control-Max-Age": "86400",
};

function json(body: unknown, init: ResponseInit = {}) {
  return new Response(JSON.stringify(body), {
    ...init,
    headers: { "Content-Type": "application/json", ...CORS_HEADERS, ...(init.headers || {}) },
  });
}

function normalizePhone(raw: string | null | undefined): string | null {
  if (!raw) return null;
  const digits = String(raw).replace(/\D/g, "");
  return digits.length >= 8 ? digits : null;
}

function normalizeKey(raw: unknown): string | null {
  const key = String(raw || "").replace(/[^a-zA-Z0-9_-]/g, "").slice(0, 200);
  return key || null;
}

function toBigMinor(n: unknown, currency?: string | null): number | null {
  const num = Number(n);
  if (!Number.isFinite(num) || num < 0) return null;
  const zeroDecimal = ["JPY", "KRW", "VND", "IDR"];
  if (currency && zeroDecimal.includes(currency.toUpperCase())) return Math.round(num);
  // if the caller sent a decimal price (79.99), convert to minor units
  return Number.isInteger(num) && num > 999 ? num : Math.round(num * 100);
}

export const Route = createFileRoute("/api/public/browse-track")({
  server: {
    handlers: {
      OPTIONS: async () => new Response(null, { status: 204, headers: CORS_HEADERS }),
      POST: async ({ request }) => {
        let body: any;
        // Body may arrive as text/plain (sendBeacon simple request) — parse manually.
        try { body = JSON.parse(await request.text()); } catch { return json({ error: "invalid_json" }, { status: 400 }); }

        const token = String(body?.token || request.headers.get("authorization")?.replace(/^Bearer\s+/i, "") || "").trim();
        if (!token) return json({ error: "missing_token" }, { status: 401 });

        const { data: tok } = await supabaseAdmin
          .from("browse_tracker_tokens" as any)
          .select("id, workspace_id")
          .eq("token", token)
          .maybeSingle();
        if (!tok) return json({ error: "invalid_token" }, { status: 401 });

        const workspaceId = (tok as any).workspace_id as string;

        // Check settings
        const { data: settings } = await supabaseAdmin
          .from("browse_recovery_settings" as any)
          .select("enabled, delay_minutes, frequency_cap_hours, product_include, product_exclude, category_include, min_price_minor")
          .eq("workspace_id", workspaceId).maybeSingle();
        if (!settings || !(settings as any).enabled) {
          return json({ ok: true, ignored: "feature_disabled" });
        }

        const productId = String(body?.product_id || body?.productId || "").slice(0, 200);
        const productTitle = String(body?.product_title || body?.title || "").slice(0, 500);
        const productUrl = String(
          body?.product_url || body?.url || request.headers.get("referer") || "",
        ).slice(0, 2000);
        const productImage = String(body?.product_image_url || body?.image || "").slice(0, 2000);
        const currency = String(body?.currency || "").slice(0, 10).toUpperCase() || null;
        const priceMinor = toBigMinor(body?.price ?? body?.price_minor, currency);
        const category = body?.category ? String(body.category).slice(0, 200) : null;
        const source = String(body?.source || "web").slice(0, 40);
        const sessionKey = normalizeKey(body?.session_key || body?.sessionKey);
        const visitorKey = normalizeKey(body?.visitor_key || body?.visitorKey);
        const phone = normalizePhone(body?.phone);
        const email = body?.email ? String(body.email).slice(0, 320) : null;
        const name = body?.name ? String(body.name).slice(0, 200) : null;

        // Identification-only ping: backfill earlier anonymous views of this
        // session so they become eligible for the scheduled reminder.
        if (String(body?.type || "") === "identify" || (!productId && phone)) {
          if (!phone || (!sessionKey && !visitorKey)) return json({ ok: true, ignored: "nothing_to_identify" });

          let idContactId: string | null = null;
          const { data: existingContact } = await supabaseAdmin
            .from("contacts").select("id")
            .eq("workspace_id", workspaceId)
            .or(`phone.eq.+${phone},phone.eq.${phone}`)
            .maybeSingle();
          if (existingContact) idContactId = (existingContact as any).id;
          if (!idContactId) {
            try {
              const { data: upserted } = await supabaseAdmin.rpc("upsert_contact", {
                _workspace_id: workspaceId,
                _name: name || `+${phone}`,
                _phone: `+${phone}`,
                _email: email ?? undefined,
                _tags: ["browse_recovery"],
                _custom_fields: {},
                _city: undefined,
                _lead_source: "browse_recovery",
                _user_id: undefined,
              } as any);
              if (upserted) idContactId = String(upserted);
            } catch { /* ignore */ }
          }

          const delay = Number((settings as any).delay_minutes) || 30;
          let updateQuery = supabaseAdmin
            .from("browse_events" as any)
            .update({
              phone: `+${phone}`,
              phone_normalized: phone,
              contact_id: idContactId,
              dispatch_scheduled_at: new Date(Date.now() + delay * 60_000).toISOString(),
            })
            .eq("workspace_id", workspaceId)
            .is("phone_normalized", null)
            .is("dispatched_at", null)
            .select("id");
          if (sessionKey && visitorKey) {
            updateQuery = updateQuery.or(`session_key.eq.${sessionKey},visitor_key.eq.${visitorKey}`);
          } else if (sessionKey) {
            updateQuery = updateQuery.eq("session_key", sessionKey);
          } else {
            updateQuery = updateQuery.eq("visitor_key", visitorKey);
          }
          const { data: updated, error: upErr } = await updateQuery;
          if (upErr) return json({ error: "identify_failed", detail: upErr.message }, { status: 500 });
          return json({ ok: true, identified: (updated as any[])?.length ?? 0 });
        }

        if (!productId) return json({ error: "missing_product_id" }, { status: 400 });


        // Filters
        const s = settings as any;
        if (Array.isArray(s.product_exclude) && s.product_exclude.includes(productId)) {
          return json({ ok: true, ignored: "excluded_product" });
        }
        if (Array.isArray(s.product_include) && s.product_include.length && !s.product_include.includes(productId)) {
          return json({ ok: true, ignored: "not_in_include_list" });
        }
        if (Array.isArray(s.category_include) && s.category_include.length && (!category || !s.category_include.includes(category))) {
          return json({ ok: true, ignored: "category_not_allowed" });
        }
        if (s.min_price_minor != null && priceMinor != null && priceMinor < Number(s.min_price_minor)) {
          return json({ ok: true, ignored: "below_min_price" });
        }

        // Frequency cap: skip if this phone got any browse recovery message in the last N hours
        if (phone && s.frequency_cap_hours && Number(s.frequency_cap_hours) > 0) {
          const capSince = new Date(Date.now() - Number(s.frequency_cap_hours) * 3600_000).toISOString();
          const { data: recent } = await supabaseAdmin
            .from("browse_events" as any)
            .select("id")
            .eq("workspace_id", workspaceId)
            .eq("phone_normalized", phone)
            .not("dispatched_at", "is", null)
            .gte("dispatched_at", capSince)
            .limit(1);
          if (recent && (recent as any[]).length) {
            return json({ ok: true, ignored: "frequency_capped" });
          }
        }

        // Match/attach contact if phone known
        let contactId: string | null = null;
        if (phone) {
          const { data: existingContact } = await supabaseAdmin
            .from("contacts")
            .select("id")
            .eq("workspace_id", workspaceId)
            .or(`phone.eq.+${phone},phone.eq.${phone}`)
            .maybeSingle();
          if (existingContact) contactId = (existingContact as any).id;
          if (!contactId && name) {
            try {
              const { data: upserted } = await supabaseAdmin.rpc("upsert_contact", {
                _workspace_id: workspaceId,
                _name: name,
                _phone: `+${phone}`,
                _email: email ?? undefined,
                _tags: ["browse_recovery"],
                _custom_fields: {},
                _city: undefined,
                _lead_source: "browse_recovery",
                _user_id: undefined,
              } as any);
              if (upserted) contactId = String(upserted);
            } catch { /* ignore */ }
          }
        }

        const delayMinutes = Number((settings as any).delay_minutes) || 30;
        const scheduledAt = new Date(Date.now() + delayMinutes * 60_000).toISOString();

        const { data: inserted, error } = await supabaseAdmin
          .from("browse_events" as any)
          .insert({
            workspace_id: workspaceId,
            contact_id: contactId,
            session_key: sessionKey,
            visitor_key: visitorKey,
            phone: phone ? `+${phone}` : null,
            phone_normalized: phone,
            product_id: productId,
            product_title: productTitle || null,
            product_image_url: productImage || null,
            product_url: productUrl || "",
            price_minor: priceMinor,
            currency,
            category,
            source,
            dispatch_scheduled_at: phone ? scheduledAt : null,
          })
          .select("id")
          .single();
        if (error) return json({ error: "insert_failed", detail: error.message }, { status: 500 });

        try {
          await supabaseAdmin.from("browse_tracker_tokens" as any)
            .update({ last_used_at: new Date().toISOString() })
            .eq("id", (tok as any).id);
        } catch { /* ignore */ }

        return json({ ok: true, event_id: (inserted as any).id, scheduled: !!phone });
      },
    },
  },
});
