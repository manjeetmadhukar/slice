import { createFileRoute, Link } from "@tanstack/react-router";

export const Route = createFileRoute("/privacy")({
  component: PrivacyPage,
  head: () => ({
    meta: [
      { title: "Privacy Policy — Slice" },
      { name: "description", content: "How Slice by Dotscube collects, uses, and protects your data." },
      { property: "og:title", content: "Privacy Policy — Slice" },
      { property: "og:description", content: "How Slice by Dotscube collects, uses, and protects your data." },
      { property: "og:url", content: "/privacy" },
    ],
    links: [{ rel: "canonical", href: "/privacy" }],
  }),
});

function PrivacyPage() {
  return (
    <main className="min-h-screen bg-background">
      <div className="container mx-auto max-w-3xl px-6 py-16">
        <Link to="/" className="text-sm text-muted-foreground hover:text-foreground">← Back to home</Link>
        <h1 className="font-display text-4xl font-bold tracking-tight mt-6">Privacy Policy</h1>
        <p className="text-muted-foreground mt-2">Last updated: June 3, 2026</p>

        <div className="prose prose-neutral dark:prose-invert mt-8 max-w-none space-y-6 text-sm leading-relaxed">
          <section>
            <h2 className="text-xl font-semibold">1. Introduction</h2>
            <p>
              Slice (“we”, “our”, “us”), operated by Dotscube, provides a WhatsApp Business
              messaging platform built on the official Meta WhatsApp Business Cloud API. This
              Privacy Policy explains what information we collect, how we use it, and the choices
              you have.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold">2. Information we collect</h2>
            <ul className="list-disc pl-5 space-y-1">
              <li>Account info: name, email, phone, workspace details.</li>
              <li>Business data: contacts, conversations, templates, campaigns you create or import.</li>
              <li>Meta/WhatsApp data you authorize via Embedded Signup (WABA ID, phone number ID).</li>
              <li>Usage data: logs, device info, IP address, cookies for authentication.</li>
              <li>Billing: handled by our payment processors; we do not store full card details.</li>
            </ul>
          </section>

          <section>
            <h2 className="text-xl font-semibold">3. How we use your information</h2>
            <ul className="list-disc pl-5 space-y-1">
              <li>To provide and operate the Slice platform and your WhatsApp integration.</li>
              <li>To send, receive, and store WhatsApp messages on your behalf.</li>
              <li>To bill, support, secure, and improve the service.</li>
              <li>To comply with legal obligations and Meta platform policies.</li>
            </ul>
          </section>

          <section>
            <h2 className="text-xl font-semibold">4. Sharing</h2>
            <p>
              We share data with Meta to deliver WhatsApp messages, with infrastructure providers
              that host our platform, and with payment processors. We do not sell personal data.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold">5. Data retention</h2>
            <p>
              We retain data for as long as your account is active or as needed to provide the
              service. You can request deletion at any time — see our <Link to="/data-deletion" className="underline">User Data Deletion</Link> page.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold">6. Security</h2>
            <p>
              We use industry standard safeguards including encryption in transit, row-level
              security in our database, and access controls. No method of transmission is 100%
              secure.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold">7. Your rights</h2>
            <p>
              You may access, correct, export, or delete your personal data by contacting us at
              <a href="mailto:slice@dotscube.com" className="underline ml-1">slice@dotscube.com</a>.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold">8. Contact</h2>
            <p>
              Dotscube · <a href="mailto:slice@dotscube.com" className="underline">slice@dotscube.com</a> · +91 96022 99003
            </p>
          </section>
        </div>
      </div>
    </main>
  );
}
