import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/r/$token")({
  server: {
    handlers: {
      GET: async ({ request, params }) => {
        const { handleRecoveryRedirect } = await import("@/lib/recovery-redirect.server");
        return handleRecoveryRedirect(request, params.token);
      },
    },
  },
});
