import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useEffect, useMemo, useState } from "react";
import * as Icons from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import {
  Sparkles,
  ArrowRight,
  Check,
  ShieldCheck,
  Star,
  MessageCircle,
  Mail,
  Phone,
  Menu,
  X,
} from "lucide-react";
import { DemoRequestDialog } from "@/components/DemoRequestDialog";
import { formatPrice } from "@/components/PricingFields";
import { FEATURE_LABELS } from "@/lib/features-catalog";
import {
  PricingComparisonTable,
  type PricingPlan as ComparisonPlan,
  type MasterFeature as ComparisonMasterFeature,
  type PlanFeatureLink as ComparisonPlanLink,
} from "@/components/PricingComparisonTable";


export const Route = createFileRoute("/")({
  component: Landing,
  head: () => ({
    meta: [
      { title: "Slice — WhatsApp Business API, Inbox & Marketing Automation" },
      {
        name: "description",
        content:
          "Slice turns WhatsApp into your growth engine. Shared team inbox, marketing automation, lead management and e-commerce integrations on the official Meta WhatsApp Business API.",
      },
      { property: "og:title", content: "Slice — WhatsApp Growth Platform" },
      {
        property: "og:description",
        content:
          "Conversations, automation, campaigns and CRM — all on official WhatsApp Business API.",
      },
    ],
  }),
});

interface LandingFeature {
  id: string;
  name: string;
  description: string | null;
  icon: string;
  category: string;
}
interface LandingTestimonial {
  id: string;
  name: string;
  company: string | null;
  role: string | null;
  photo_url: string | null;
  review: string;
  rating: number;
}
interface LandingFaq {
  id: string;
  question: string;
  answer: string;
}
interface LandingPlan {
  id: string;
  name: string;
  description: string | null;
  features: Record<string, boolean>;
  limits: Record<string, number>;
  price_monthly: number;
  price_yearly: number;
  currency: string;
}

interface LandingPayload {
  features: LandingFeature[];
  testimonials: LandingTestimonial[];
  faqs: LandingFaq[];
  plans: LandingPlan[];
}

function getIcon(name: string) {
  const Lib = Icons as unknown as Record<string, React.ComponentType<{ className?: string }>>;
  return Lib[name] ?? Sparkles;
}

function useCounter(target: number, start: boolean, durationMs = 1400) {
  const [value, setValue] = useState(0);
  useEffect(() => {
    if (!start) return;
    let raf = 0;
    const t0 = performance.now();
    const tick = (t: number) => {
      const p = Math.min(1, (t - t0) / durationMs);
      setValue(Math.round(target * (1 - Math.pow(1 - p, 3))));
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [target, start, durationMs]);
  return value;
}

function Landing() {
  const [demoOpen, setDemoOpen] = useState(false);
  const [navOpen, setNavOpen] = useState(false);
  const [interval, setInterval] = useState<"monthly" | "yearly">("monthly");
  const [featureSearch, setFeatureSearch] = useState("");
  const [activeCategory, setActiveCategory] = useState<string>("All");

  const { data } = useQuery({
    queryKey: ["landing-cms"],
    queryFn: async (): Promise<LandingPayload> => {
      const res = await fetch("/api/public/landing");
      if (!res.ok) throw new Error("Failed to load");
      return res.json();
    },
  });

  const { data: pricingData } = useQuery({
    queryKey: ["public-pricing"],
    queryFn: async (): Promise<{ plans: ComparisonPlan[]; masterFeatures: ComparisonMasterFeature[]; planFeatures: ComparisonPlanLink[] }> => {
      const res = await fetch("/api/public/pricing");
      if (!res.ok) throw new Error("Failed to load pricing");
      return res.json();
    },
  });

  const features = data?.features ?? [];
  const testimonials = data?.testimonials ?? [];
  const faqs = data?.faqs ?? [];
  const plans = data?.plans ?? [];


  const categories = useMemo(() => {
    const set = new Set<string>();
    features.forEach((f) => set.add(f.category));
    return ["All", ...Array.from(set)];
  }, [features]);

  const filteredFeatures = useMemo(() => {
    return features.filter((f) => {
      const matchCat = activeCategory === "All" || f.category === activeCategory;
      const q = featureSearch.toLowerCase().trim();
      const matchSearch =
        !q ||
        f.name.toLowerCase().includes(q) ||
        (f.description ?? "").toLowerCase().includes(q) ||
        f.category.toLowerCase().includes(q);
      return matchCat && matchSearch;
    });
  }, [features, activeCategory, featureSearch]);

  return (
    <div className="min-h-screen bg-background">
      <DemoRequestDialog open={demoOpen} onOpenChange={setDemoOpen} />

      {/* ============ Header ============ */}
      <header className="sticky top-0 z-50 border-b border-border/60 bg-background/85 backdrop-blur-md">
        <div className="container mx-auto flex h-16 items-center justify-between px-4 sm:px-6">
          <Link to="/" className="flex items-center gap-2">
            <img src="/slice-logo.png" alt="Slice" className="h-14 w-auto object-contain" />
          </Link>

          <nav className="hidden items-center gap-8 md:flex">
            <a href="#home" className="text-sm font-medium text-muted-foreground hover:text-foreground">Home</a>
            <a href="#features" className="text-sm font-medium text-muted-foreground hover:text-foreground">Features</a>
            <a href="#pricing" className="text-sm font-medium text-muted-foreground hover:text-foreground">Pricing</a>
            <a href="#faq" className="text-sm font-medium text-muted-foreground hover:text-foreground">FAQ</a>
          </nav>

          <div className="hidden items-center gap-2 md:flex">
            <Button variant="ghost" size="sm" onClick={() => setDemoOpen(true)}>Book a demo</Button>
            <Link to="/signup">
              <Button size="sm" className="shadow-[var(--shadow-glow)]">
                Try for Free
              </Button>
            </Link>
          </div>

          <button
            className="grid h-10 w-10 place-items-center rounded-lg border md:hidden"
            onClick={() => setNavOpen((v) => !v)}
            aria-label="Toggle menu"
          >
            {navOpen ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
          </button>
        </div>

        {navOpen && (
          <div className="border-t bg-background md:hidden">
            <div className="container mx-auto flex flex-col gap-3 px-4 py-4">
              <a href="#features" onClick={() => setNavOpen(false)} className="text-sm font-medium">Features</a>
              <a href="#pricing" onClick={() => setNavOpen(false)} className="text-sm font-medium">Pricing</a>
              <a href="#faq" onClick={() => setNavOpen(false)} className="text-sm font-medium">FAQ</a>
              <div className="flex gap-2 pt-2">
                <Button variant="outline" className="flex-1" onClick={() => { setNavOpen(false); setDemoOpen(true); }}>
                  Book demo
                </Button>
                <Link to="/signup" className="flex-1">
                  <Button className="w-full">Try free</Button>
                </Link>
              </div>
            </div>
          </div>
        )}
      </header>

      {/* ============ Hero ============ */}
      <section id="home" className="relative overflow-hidden">
        <div className="pointer-events-none absolute inset-0 -z-10">
          <div className="absolute -top-40 left-1/2 h-[600px] w-[900px] -translate-x-1/2 rounded-full bg-[image:var(--gradient-primary)] opacity-20 blur-3xl" />
          <div className="absolute bottom-0 right-0 h-[400px] w-[400px] rounded-full bg-primary/10 blur-3xl" />
        </div>

        <div className="container mx-auto px-4 py-20 sm:px-6 lg:py-32">
          <div className="mx-auto max-w-4xl text-center">
            <Badge variant="secondary" className="rounded-full border border-primary/20 bg-primary/5 px-4 py-1.5 text-xs font-medium text-primary">
              <ShieldCheck className="mr-1.5 h-3.5 w-3.5" />
              Official Meta WhatsApp Business API Platform
            </Badge>

            <h1 className="mt-6 font-display text-4xl font-bold leading-[1.05] tracking-tight sm:text-6xl lg:text-7xl">
              Transform WhatsApp Into Your{" "}
              <span className="bg-[image:var(--gradient-primary)] bg-clip-text text-transparent">
                Growth Engine
              </span>
            </h1>

            <p className="mx-auto mt-6 max-w-2xl text-lg text-muted-foreground sm:text-xl">
              Manage conversations, automate marketing, generate leads, recover abandoned carts, and grow your
              business with the Slice WhatsApp Business API & CRM Platform.
            </p>

            <div className="mt-10 flex flex-wrap justify-center gap-3">
              <Link to="/signup">
                <Button size="lg" className="h-12 px-7 shadow-[var(--shadow-glow)]">
                  Try Free for 7 Days <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
              <Button size="lg" variant="outline" className="h-12 px-7" onClick={() => setDemoOpen(true)}>
                Book a Demo
              </Button>
            </div>

            <div className="mt-10 flex flex-wrap items-center justify-center gap-x-6 gap-y-3 text-sm text-muted-foreground">
              {[
                "Official WhatsApp API",
                "Multi-Agent Inbox",
                "Marketing Automation",
                "E-commerce Integration",
                "CRM Built-in",
              ].map((t) => (
                <span key={t} className="inline-flex items-center gap-1.5">
                  <Check className="h-4 w-4 text-success" /> {t}
                </span>
              ))}
            </div>
          </div>

          {/* Hero visual */}
          <div className="mx-auto mt-16 max-w-5xl">
            <div className="relative rounded-3xl border border-border/60 bg-card p-2 shadow-[var(--shadow-lg)]">
              <div className="rounded-2xl bg-[image:var(--gradient-subtle)] p-8 sm:p-12">
                <div className="grid gap-6 sm:grid-cols-3">
                  {[
                    { label: "Avg. delivery rate", value: "98.4%" },
                    { label: "Avg. open rate", value: "82%" },
                    { label: "Cart recovery uplift", value: "3.6x" },
                  ].map((s) => (
                    <div key={s.label} className="text-center">
                      <div className="font-display text-3xl font-bold sm:text-4xl">{s.value}</div>
                      <div className="mt-1 text-sm text-muted-foreground">{s.label}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ============ Social Proof ============ */}
      <SocialProof />

      {/* ============ Features ============ */}
      <section id="features" className="border-t bg-[image:var(--gradient-subtle)] py-20 sm:py-28">
        <div className="container mx-auto px-4 sm:px-6">
          <div className="mx-auto max-w-2xl text-center">
            <Badge variant="secondary" className="rounded-full">Everything you need</Badge>
            <h2 className="mt-4 font-display text-3xl font-bold sm:text-4xl lg:text-5xl">
              All your WhatsApp tools in one place
            </h2>
            <p className="mt-4 text-muted-foreground">
              From conversations to commerce. Every feature you'd expect on a modern growth platform — and a few you wouldn't.
            </p>
          </div>

          <div className="mx-auto mt-10 flex max-w-2xl flex-col gap-3">
            <Input
              placeholder="Search features…"
              value={featureSearch}
              onChange={(e) => setFeatureSearch(e.target.value)}
              className="h-11"
            />
            <div className="flex flex-wrap justify-center gap-2">
              {categories.map((c) => (
                <button
                  key={c}
                  onClick={() => setActiveCategory(c)}
                  className={`rounded-full px-3.5 py-1.5 text-xs font-medium transition ${
                    activeCategory === c
                      ? "bg-primary text-primary-foreground shadow-sm"
                      : "border bg-card text-muted-foreground hover:text-foreground"
                  }`}
                >
                  {c}
                </button>
              ))}
            </div>
          </div>

          <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {filteredFeatures.map((f) => {
              const Icon = getIcon(f.icon);
              return (
                <Card
                  key={f.id}
                  className="group relative overflow-hidden border bg-card/80 p-6 backdrop-blur transition hover:-translate-y-1 hover:border-primary/40 hover:shadow-[var(--shadow-md)]"
                >
                  <div className="grid h-11 w-11 place-items-center rounded-xl bg-primary/10 text-primary transition group-hover:scale-110">
                    <Icon className="h-5 w-5" />
                  </div>
                  <Badge variant="secondary" className="mt-4 text-xs">{f.category}</Badge>
                  <h3 className="mt-2 font-display text-lg font-semibold">{f.name}</h3>
                  {f.description && (
                    <p className="mt-1.5 text-sm text-muted-foreground">{f.description}</p>
                  )}
                </Card>
              );
            })}
            {filteredFeatures.length === 0 && (
              <div className="col-span-full py-12 text-center text-muted-foreground">
                No features match your search.
              </div>
            )}
          </div>
        </div>
      </section>

      {/* ============ Pricing ============ */}
      <section id="pricing" className="border-t py-20 sm:py-28">
        <div className="container mx-auto px-4 sm:px-6">
          <div className="mx-auto max-w-2xl text-center">
            <Badge variant="secondary" className="rounded-full">
              <Sparkles className="mr-1 h-3 w-3" /> Simple pricing
            </Badge>
            <h2 className="mt-4 font-display text-3xl font-bold sm:text-4xl lg:text-5xl">
              Pricing that scales with you
            </h2>
            <p className="mt-4 text-muted-foreground">
              7-day free trial on every plan. No credit card required.
            </p>

            <div className="mt-8 inline-flex rounded-full border bg-muted p-1">
              <button
                onClick={() => setInterval("monthly")}
                className={`rounded-full px-5 py-2 text-sm transition ${
                  interval === "monthly" ? "bg-background font-medium shadow-sm" : "text-muted-foreground"
                }`}
              >
                Monthly
              </button>
              <button
                onClick={() => setInterval("yearly")}
                className={`inline-flex items-center gap-2 rounded-full px-5 py-2 text-sm transition ${
                  interval === "yearly" ? "bg-background font-medium shadow-sm" : "text-muted-foreground"
                }`}
              >
                Yearly
                <span className="rounded bg-success/15 px-1.5 py-0.5 text-xs text-success">Save</span>
              </button>
            </div>
          </div>

          {plans.length === 0 ? (
            <Card className="mx-auto mt-12 max-w-xl p-10 text-center text-muted-foreground">
              No plans published yet. Plans created in the admin panel will appear here automatically.
            </Card>
          ) : pricingData && pricingData.plans.length > 0 ? (
            <div className="mt-12">
              <PricingComparisonTable
                plans={pricingData.plans}
                masterFeatures={pricingData.masterFeatures}
                planFeatures={pricingData.planFeatures}
                interval={interval}
                cta={() => (
                  <Link to="/signup">
                    <Button size="sm" className="w-full">Start 7-day free trial</Button>
                  </Link>
                )}
              />
            </div>
          ) : null}

        </div>
      </section>


      {/* ============ Testimonials ============ */}
      {testimonials.length > 0 && (
        <section className="border-t bg-[image:var(--gradient-subtle)] py-20 sm:py-28">
          <div className="container mx-auto px-4 sm:px-6">
            <div className="mx-auto max-w-2xl text-center">
              <Badge variant="secondary" className="rounded-full">Loved by teams</Badge>
              <h2 className="mt-4 font-display text-3xl font-bold sm:text-4xl">
                Real businesses, real results
              </h2>
            </div>
            <div className="mt-12 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {testimonials.map((t) => (
                <Card key={t.id} className="p-6">
                  <div className="flex items-center gap-1 text-amber-500">
                    {Array.from({ length: t.rating }).map((_, i) => (
                      <Star key={i} className="h-4 w-4 fill-current" />
                    ))}
                  </div>
                  <p className="mt-4 text-sm leading-relaxed">{t.review}</p>
                  <div className="mt-6 flex items-center gap-3 border-t pt-4">
                    <div className="grid h-10 w-10 place-items-center rounded-full bg-primary/10 font-semibold text-primary">
                      {t.photo_url ? (
                        <img src={t.photo_url} alt={t.name} className="h-10 w-10 rounded-full object-cover" />
                      ) : (
                        t.name.charAt(0)
                      )}
                    </div>
                    <div>
                      <div className="text-sm font-semibold">{t.name}</div>
                      <div className="text-xs text-muted-foreground">
                        {[t.role, t.company].filter(Boolean).join(" · ")}
                      </div>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* ============ FAQ ============ */}
      {faqs.length > 0 && (
        <section id="faq" className="border-t py-20 sm:py-28">
          <div className="container mx-auto max-w-3xl px-4 sm:px-6">
            <div className="text-center">
              <Badge variant="secondary" className="rounded-full">FAQ</Badge>
              <h2 className="mt-4 font-display text-3xl font-bold sm:text-4xl">
                Frequently asked questions
              </h2>
            </div>
            <Accordion type="single" collapsible className="mt-10 w-full">
              {faqs.map((f) => (
                <AccordionItem key={f.id} value={f.id}>
                  <AccordionTrigger className="text-left text-base font-medium">
                    {f.question}
                  </AccordionTrigger>
                  <AccordionContent className="text-sm leading-relaxed text-muted-foreground">
                    {f.answer}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </div>
        </section>
      )}

      {/* ============ CTA Banner ============ */}
      <section className="py-20">
        <div className="container mx-auto px-4 sm:px-6">
          <div className="relative overflow-hidden rounded-3xl bg-[image:var(--gradient-hero)] px-8 py-16 text-center text-primary-foreground shadow-[var(--shadow-lg)] sm:px-16">
            <div className="pointer-events-none absolute -right-20 -top-20 h-80 w-80 rounded-full bg-white/10 blur-3xl" />
            <h2 className="font-display text-3xl font-bold sm:text-4xl">
              Ready to grow with WhatsApp?
            </h2>
            <p className="mx-auto mt-3 max-w-xl text-base opacity-90">
              Join thousands of businesses already growing with Slice. Start free, no credit card required.
            </p>
            <div className="mt-8 flex flex-wrap justify-center gap-3">
              <Link to="/signup">
                <Button size="lg" variant="secondary" className="h-12 px-7">
                  Try Free for 7 Days <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
              <Button
                size="lg"
                variant="outline"
                className="h-12 border-white/40 bg-transparent px-7 text-white hover:bg-white/10 hover:text-white"
                onClick={() => setDemoOpen(true)}
              >
                Book a Demo
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* ============ Footer ============ */}
      <footer className="border-t bg-card">
        <div className="container mx-auto grid gap-10 px-4 py-14 sm:px-6 md:grid-cols-6">
          <div className="md:col-span-2">
            <div className="flex items-center gap-2">
              <img src="/slice-logo.png" alt="Slice" className="h-12 w-auto object-contain" />
            </div>
            <p className="mt-3 max-w-xs text-sm text-muted-foreground">
              The WhatsApp growth platform for modern businesses. Built on the official Meta WhatsApp Business Cloud API.
            </p>
            <div className="mt-4 space-y-1.5 text-sm">
              <a href="mailto:slice@dotscube.com" className="flex items-center gap-2 text-muted-foreground hover:text-foreground">
                <Mail className="h-4 w-4" /><span>slice@dotscube.com</span>
              </a>
              <a href="tel:+919602299003" className="flex items-center gap-2 text-muted-foreground hover:text-foreground">
                <Phone className="h-4 w-4" /><span>+91 96022 99003</span>
              </a>
            </div>
          </div>
          <FooterCol title="Product" links={[
            { label: "Features", href: "#features" },
            { label: "Pricing", href: "#pricing" },
            { label: "Integrations", href: "#features" },
          ]} />
          <FooterCol title="Company" links={[
            { label: "About", href: "#home" },
            { label: "Contact", href: "mailto:slice@dotscube.com" },
            { label: "Book demo", href: "#", onClick: () => setDemoOpen(true) },
          ]} />
          <FooterCol title="Support" links={[
            { label: "Help center", href: "mailto:slice@dotscube.com" },
            { label: "Documentation", href: "mailto:slice@dotscube.com" },
            { label: "Sign in", href: "/login", isInternal: true },
          ]} />
          <FooterCol title="Legal" links={[
            { label: "Privacy Policy", href: "/privacy", isInternal: true },
            { label: "Terms of Service", href: "/terms", isInternal: true },
            { label: "User Data Deletion", href: "/data-deletion", isInternal: true },
          ]} />
        </div>
        <div className="border-t">
          <div className="container mx-auto flex flex-col items-center justify-between gap-3 px-4 py-6 text-center text-xs text-muted-foreground sm:flex-row sm:px-6">
            <span>© 2026 Slice by Dotscube. All rights reserved.</span>
            <span>WhatsApp is a trademark of Meta Platforms, Inc.</span>
          </div>
        </div>
      </footer>
    </div>
  );
}

function FooterCol({
  title,
  links,
}: {
  title: string;
  links: { label: string; href: string; onClick?: () => void; isInternal?: boolean }[];
}) {
  return (
    <div>
      <h4 className="font-display text-sm font-semibold">{title}</h4>
      <ul className="mt-3 space-y-2 text-sm">
        {links.map((l) =>
          l.isInternal ? (
            <li key={l.label}>
              <Link to={l.href as any} className="text-muted-foreground hover:text-foreground">
                {l.label}
              </Link>
            </li>
          ) : (
            <li key={l.label}>
              <a
                href={l.href}
                onClick={(e) => {
                  if (l.onClick) {
                    e.preventDefault();
                    l.onClick();
                  }
                }}
                className="text-muted-foreground hover:text-foreground"
              >
                {l.label}
              </a>
            </li>
          ),
        )}
      </ul>
    </div>
  );
}

function SocialProof() {
  const [start, setStart] = useState(false);
  useEffect(() => {
    const obs = new IntersectionObserver(
      ([e]) => {
        if (e.isIntersecting) setStart(true);
      },
      { threshold: 0.3 },
    );
    const el = document.getElementById("social-proof");
    if (el) obs.observe(el);
    return () => obs.disconnect();
  }, []);

  const stats = [
    { value: useCounter(12500, start), suffix: "+", label: "Users worldwide" },
    { value: useCounter(48, start), suffix: "M+", label: "Messages sent" },
    { value: useCounter(2400, start), suffix: "+", label: "Active businesses" },
    { value: useCounter(98, start), suffix: "%", label: "Customer satisfaction" },
  ];

  return (
    <section id="social-proof" className="border-y bg-card">
      <div className="container mx-auto grid grid-cols-2 gap-8 px-4 py-12 sm:px-6 md:grid-cols-4">
        {stats.map((s) => (
          <div key={s.label} className="text-center">
            <div className="font-display text-3xl font-bold sm:text-4xl">
              {s.value.toLocaleString()}{s.suffix}
            </div>
            <div className="mt-1 text-xs uppercase tracking-wider text-muted-foreground sm:text-sm">
              {s.label}
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
