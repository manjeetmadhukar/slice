// Top-level short link: https://slice.dotscube.com/br/{token}
// Delegates to the browse-recovery redirector so links in WhatsApp
// templates can use a clean domain path.
import { createFileRoute } from "@tanstack/react-router";
import { supabaseAdmin } from "@/integrations/supabase/client.server";

export const Route = createFileRoute("/br/$token")({
  server: {
    handlers: {
      GET: async ({ params }) => {
        const token = String(params.token || "").trim();
        if (!token || token.length > 200) return new Response("Not found", { status: 404 });

        const { data: click } = await supabaseAdmin
          .from("browse_recovery_clicks" as any)
          .select("target_url")
          .eq("token", token)
          .maybeSingle();
        if (!click || !(click as any).target_url) {
          return new Response("This link is no longer valid.", { status: 404 });
        }

        try {
          await supabaseAdmin.from("browse_recovery_clicks" as any)
            .update({ clicked_at: new Date().toISOString() })
            .eq("token", token);
        } catch { /* ignore */ }

        return new Response(null, {
          status: 302,
          headers: { Location: (click as any).target_url, "Cache-Control": "no-store" },
        });
      },
    },
  },
});
