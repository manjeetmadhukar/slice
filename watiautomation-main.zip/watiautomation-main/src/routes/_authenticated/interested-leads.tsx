import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { MousePointerClick, Download, Search, Users, Sparkles } from "lucide-react";
import { toast } from "sonner";
import { useWorkspace } from "@/lib/workspace-context";
import { getMyAdminStatus } from "@/lib/admin.functions";
import {
  listButtonClicks,
  exportButtonClicks,
  getButtonClickFacets,
  type ButtonClickRow,
} from "@/lib/button-clicks.functions";

export const Route = createFileRoute("/_authenticated/interested-leads")({
  component: InterestedLeads,
  head: () => ({
    meta: [
      { title: "Interested Leads — Slice" },
      { name: "description", content: "Track WhatsApp template Quick Reply button clicks and export interested leads." },
      { property: "og:title", content: "Interested Leads — Slice" },
      { property: "og:description", content: "Every Quick Reply button click from your WhatsApp campaigns, searchable and exportable." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
});

const ALL = "__all__";
const PAGE_SIZE = 50;

function InterestedLeads() {
  const { currentWorkspaceId } = useWorkspace();
  const adminStatusFn = useServerFn(getMyAdminStatus);
  const listFn = useServerFn(listButtonClicks);
  const exportFn = useServerFn(exportButtonClicks);
  const facetsFn = useServerFn(getButtonClickFacets);

  const [search, setSearch] = useState("");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [campaignId, setCampaignId] = useState(ALL);
  const [templateName, setTemplateName] = useState(ALL);
  const [buttonText, setButtonText] = useState(ALL);
  const [page, setPage] = useState(1);
  const [allWorkspaces, setAllWorkspaces] = useState(false);

  const { data: adminStatus } = useQuery({
    queryKey: ["my-admin-status"],
    queryFn: () => adminStatusFn(),
    staleTime: 60_000,
  });
  const isSuperAdmin = !!adminStatus?.is_super_admin;

  const filters = useMemo(
    () => ({
      workspaceId: currentWorkspaceId,
      allWorkspaces: isSuperAdmin && allWorkspaces,
      search: search.trim() || null,
      from: from ? new Date(from).toISOString() : null,
      to: to ? new Date(`${to}T23:59:59`).toISOString() : null,
      campaignId: campaignId === ALL ? null : campaignId,
      templateName: templateName === ALL ? null : templateName,
      buttonText: buttonText === ALL ? null : buttonText,
    }),
    [currentWorkspaceId, isSuperAdmin, allWorkspaces, search, from, to, campaignId, templateName, buttonText],
  );

  const { data: facets } = useQuery({
    queryKey: ["button-click-facets", currentWorkspaceId, allWorkspaces],
    enabled: !!currentWorkspaceId,
    queryFn: () =>
      facetsFn({ data: { workspaceId: currentWorkspaceId, allWorkspaces: isSuperAdmin && allWorkspaces } }),
  });

  const { data, isLoading } = useQuery({
    queryKey: ["button-clicks", filters, page],
    enabled: !!currentWorkspaceId,
    queryFn: () => listFn({ data: { ...filters, page, pageSize: PAGE_SIZE } }),
  });

  const rows: ButtonClickRow[] = data?.rows ?? [];
  const total = data?.total ?? 0;
  const pages = Math.max(1, Math.ceil(total / PAGE_SIZE));
  const campaignName = (id: string | null) =>
    (facets?.campaigns ?? []).find((c) => c.id === id)?.name || (id ? "—" : "—");

  const interestedCount = rows.filter((r) => /interested/i.test(r.button_text || "")).length;

  async function download(kind: "csv" | "xls") {
    try {
      const res = await exportFn({ data: filters });
      const list = res.rows ?? [];
      if (!list.length) {
        toast.error("Nothing to export for the current filters");
        return;
      }
      const header = [
        "Contact Name", "WhatsApp Number", "Workspace ID", "Campaign ID", "Campaign",
        "Template Name", "Button Name", "Button Payload", "Button Type", "Clicked At",
      ];
      const body = list.map((r) => [
        r.contact_name || "",
        r.phone || "",
        r.workspace_id,
        r.campaign_id || "",
        campaignName(r.campaign_id),
        r.template_name || "",
        r.button_text || "",
        r.button_payload || "",
        r.button_type || "",
        new Date(r.clicked_at).toLocaleString(),
      ]);

      let blob: Blob;
      let ext: string;
      if (kind === "csv") {
        const csv = [header, ...body]
          .map((r) => r.map((v) => `"${String(v).replace(/"/g, '""')}"`).join(","))
          .join("\n");
        blob = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8" });
        ext = "csv";
      } else {
        const esc = (v: string) =>
          String(v).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
        const html =
          `<html xmlns:x="urn:schemas-microsoft-com:office:excel"><head><meta charset="utf-8" /></head><body><table border="1">` +
          `<tr>${header.map((h) => `<th>${esc(h)}</th>`).join("")}</tr>` +
          body.map((r) => `<tr>${r.map((c) => `<td>${esc(c)}</td>`).join("")}</tr>`).join("") +
          `</table></body></html>`;
        blob = new Blob([html], { type: "application/vnd.ms-excel" });
        ext = "xls";
      }
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `interested-leads-${new Date().toISOString().slice(0, 10)}.${ext}`;
      a.click();
      URL.revokeObjectURL(url);
    } catch (e: any) {
      toast.error(e?.message || "Export failed");
    }
  }

  function resetPage<T>(setter: (v: T) => void) {
    return (v: T) => { setter(v); setPage(1); };
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-3xl font-bold">Interested Leads</h1>
          <p className="text-sm text-muted-foreground">
            Every Quick Reply button click from your WhatsApp template messages.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" onClick={() => download("csv")}>
            <Download className="mr-2 h-4 w-4" />CSV
          </Button>
          <Button variant="outline" onClick={() => download("xls")}>
            <Download className="mr-2 h-4 w-4" />Excel
          </Button>
        </div>
      </div>

      <div className="grid gap-4 grid-cols-1 sm:grid-cols-3">
        <Card className="p-5">
          <div className="flex items-center gap-3">
            <MousePointerClick className="h-5 w-5 text-primary" />
            <div>
              <p className="text-xs text-muted-foreground">Total button clicks</p>
              <p className="text-2xl font-bold">{total}</p>
            </div>
          </div>
        </Card>
        <Card className="p-5">
          <div className="flex items-center gap-3">
            <Sparkles className="h-5 w-5 text-primary" />
            <div>
              <p className="text-xs text-muted-foreground">"Interested" on this page</p>
              <p className="text-2xl font-bold">{interestedCount}</p>
            </div>
          </div>
        </Card>
        <Card className="p-5">
          <div className="flex items-center gap-3">
            <Users className="h-5 w-5 text-primary" />
            <div>
              <p className="text-xs text-muted-foreground">Unique numbers on this page</p>
              <p className="text-2xl font-bold">{new Set(rows.map((r) => r.phone)).size}</p>
            </div>
          </div>
        </Card>
      </div>

      <Card className="p-5 space-y-4">
        <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-3">
          <div className="space-y-1.5">
            <Label className="text-xs">Search name or number</Label>
            <div className="relative">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                className="pl-8"
                placeholder="Name or WhatsApp number"
                value={search}
                onChange={(e) => { setSearch(e.target.value); setPage(1); }}
              />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label className="text-xs">From</Label>
              <Input type="date" value={from} onChange={(e) => { setFrom(e.target.value); setPage(1); }} />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs">To</Label>
              <Input type="date" value={to} onChange={(e) => { setTo(e.target.value); setPage(1); }} />
            </div>
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">Campaign</Label>
            <Select value={campaignId} onValueChange={resetPage(setCampaignId)}>
              <SelectTrigger><SelectValue placeholder="All campaigns" /></SelectTrigger>
              <SelectContent>
                <SelectItem value={ALL}>All campaigns</SelectItem>
                {(facets?.campaigns ?? []).map((c) => (
                  <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">Template</Label>
            <Select value={templateName} onValueChange={resetPage(setTemplateName)}>
              <SelectTrigger><SelectValue placeholder="All templates" /></SelectTrigger>
              <SelectContent>
                <SelectItem value={ALL}>All templates</SelectItem>
                {(facets?.templates ?? []).map((t) => (
                  <SelectItem key={t} value={t}>{t}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">Button</Label>
            <Select value={buttonText} onValueChange={resetPage(setButtonText)}>
              <SelectTrigger><SelectValue placeholder="All buttons" /></SelectTrigger>
              <SelectContent>
                <SelectItem value={ALL}>All buttons</SelectItem>
                {(facets?.buttons ?? []).map((b) => (
                  <SelectItem key={b} value={b}>{b}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          {isSuperAdmin && (
            <div className="flex items-end gap-2 pb-1">
              <Switch
                id="all-ws"
                checked={allWorkspaces}
                onCheckedChange={(v) => { setAllWorkspaces(v); setPage(1); }}
              />
              <Label htmlFor="all-ws" className="text-xs">All workspaces (super admin)</Label>
            </div>
          )}
        </div>

        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Contact</TableHead>
                <TableHead>WhatsApp number</TableHead>
                <TableHead>Button</TableHead>
                <TableHead>Payload</TableHead>
                <TableHead>Campaign</TableHead>
                <TableHead>Template</TableHead>
                <TableHead>Clicked at</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                <TableRow><TableCell colSpan={7} className="text-muted-foreground">Loading…</TableCell></TableRow>
              ) : rows.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={7} className="text-muted-foreground">
                    No button clicks yet. Clicks on Quick Reply buttons in your WhatsApp templates appear here automatically.
                  </TableCell>
                </TableRow>
              ) : rows.map((r) => (
                <TableRow key={r.id}>
                  <TableCell className="font-medium">{r.contact_name || "—"}</TableCell>
                  <TableCell>{r.phone}</TableCell>
                  <TableCell>
                    <Badge variant={/interested/i.test(r.button_text || "") ? "default" : "secondary"}>
                      {r.button_text || "Button"}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-xs text-muted-foreground">{r.button_payload || "—"}</TableCell>
                  <TableCell>{campaignName(r.campaign_id)}</TableCell>
                  <TableCell>{r.template_name || "—"}</TableCell>
                  <TableCell className="whitespace-nowrap">{new Date(r.clicked_at).toLocaleString()}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>

        <div className="flex items-center justify-between text-sm">
          <span className="text-muted-foreground">
            Page {page} of {pages} · {total} total
          </span>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" disabled={page <= 1} onClick={() => setPage((p) => p - 1)}>
              Previous
            </Button>
            <Button variant="outline" size="sm" disabled={page >= pages} onClick={() => setPage((p) => p + 1)}>
              Next
            </Button>
          </div>
        </div>
      </Card>
    </div>
  );
}
