import { createFileRoute, Link, Outlet, useRouterState } from "@tanstack/react-router";
import { List, FolderKanban } from "lucide-react";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/contacts")({
  component: ContactsLayout,
  head: () => ({ meta: [{ title: "Contacts — Slice" }] }),
});

function ContactsLayout() {
  const path = useRouterState({ select: (s) => s.location.pathname });
  const tabs = [
    { to: "/contacts", label: "List", icon: List, exact: true },
    { to: "/contacts/groups", label: "Groups", icon: FolderKanban, exact: false },
  ];
  return (
    <div className="space-y-6">
      <div className="flex gap-1 border-b">
        {tabs.map((t) => {
          const active = t.exact ? path === t.to : path.startsWith(t.to);
          return (
            <Link
              key={t.to}
              to={t.to}
              className={cn(
                "flex items-center gap-2 px-4 py-2.5 text-sm font-medium border-b-2 -mb-px transition",
                active
                  ? "border-primary text-foreground"
                  : "border-transparent text-muted-foreground hover:text-foreground",
              )}
            >
              <t.icon className="h-4 w-4" />
              {t.label}
            </Link>
          );
        })}
      </div>
      <Outlet />
    </div>
  );
}
