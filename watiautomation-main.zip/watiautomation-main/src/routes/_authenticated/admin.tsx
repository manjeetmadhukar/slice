import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useState, useMemo } from "react";
import { toast } from "sonner";
import {
  adminListUsers,
  adminListWorkspaces,
  adminUpsertPlan,
  adminSetUserSuspended,
  adminSetUserArchived,

  adminSetSuperAdmin,
  adminImpersonateUser,
  getMyAdminStatus,
  adminListPlanRequests,
  adminReviewPlanRequest,
  adminListPlanTemplates,
  adminCreatePlanTemplate,
  adminUpdatePlanTemplate,
  adminDeletePlanTemplate,
  adminAssignPlanTemplate,
  adminListPaymentGateways,
  adminUpdatePaymentGateway,
  adminListDemoRequests,
  adminSetWorkspaceTeamCreation,
  adminDeleteWorkspace,
  adminDeleteUser,

  adminSetUserMultiWorkspace,
} from "@/lib/admin.functions";


import { adminListResellers, adminUpdateReseller, regenerateCustomerLicense, setCustomerLicenseStatus } from "@/lib/reseller.functions";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import {
  Table, TableHeader, TableRow, TableHead, TableBody, TableCell,
} from "@/components/ui/table";
import { Checkbox } from "@/components/ui/checkbox";
import { Loader2, Shield, ShieldOff, Ban, CheckCircle2, Settings2, LogIn, Sparkles, Check as CheckIcon, X as XIcon, Plus, Pencil, Trash2, Library, Send, Eye, KeyRound, ExternalLink, icons as LucideIcons } from "lucide-react";
import {
  adminListMasterFeatures,
  adminCreateMasterFeature,
  adminUpdateMasterFeature,
  adminDeleteMasterFeature,
  adminReorderMasterFeatures,
  adminGetPlanFeatures,
  adminSetPlanFeatures,
  adminReorderPlans,
} from "@/lib/admin-features.functions";
import {
  DndContext,
  closestCenter,
  PointerSensor,
  useSensor,
  useSensors,
  type DragEndEvent,
} from "@dnd-kit/core";
import {
  SortableContext,
  arrayMove,
  verticalListSortingStrategy,
} from "@dnd-kit/sortable";
import { SortableItem } from "@/components/SortableItem";
import {
  PricingComparisonTable,
  type PricingPlan,
  type MasterFeature as MasterFeatureType,
  type PlanFeatureLink,
} from "@/components/PricingComparisonTable";
import { supabase } from "@/integrations/supabase/client";


export const Route = createFileRoute("/_authenticated/admin")({
  component: AdminPage,
  head: () => ({ meta: [{ title: "Super Admin — Slice" }] }),
});

import { FEATURE_CATALOG, FEATURE_LABELS, FEATURE_KEYS, LIMIT_CATALOG, PAYMENT_PROVIDERS } from "@/lib/features-catalog";
import { PricingFields, formatPrice, type PricingValue } from "@/components/PricingFields";
const LIMIT_KEYS = LIMIT_CATALOG;




function AdminPage() {
  const getStatus = useServerFn(getMyAdminStatus);
  const { data: status, isLoading } = useQuery({
    queryKey: ["my-admin-status"],
    queryFn: () => getStatus(),
  });

  if (isLoading) return <div className="p-8"><Loader2 className="h-5 w-5 animate-spin" /></div>;
  if (!status?.is_super_admin) {
    return (
      <div className="p-8">
        <h1 className="font-display text-2xl font-semibold">Forbidden</h1>
        <p className="text-muted-foreground mt-2">You need super admin permissions to access this page.</p>
      </div>
    );
  }
  return <AdminConsole />;
}

function AdminConsole() {
  const [search, setSearch] = useState("");
  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-3xl font-semibold flex items-center gap-2">
          <Shield className="h-7 w-7 text-primary" /> Super Admin
        </h1>
        <p className="text-muted-foreground">Manage users, workspaces and custom plans across the platform.</p>
      </div>

      <Tabs defaultValue="workspaces">
        <TabsList className="flex-wrap h-auto">
          <TabsTrigger value="workspaces">Workspaces & Plans</TabsTrigger>
          <TabsTrigger value="library"><Library className="h-3.5 w-3.5 mr-1" />Plan library</TabsTrigger>
          <TabsTrigger value="features"><Sparkles className="h-3.5 w-3.5 mr-1" />Feature library</TabsTrigger>
          <TabsTrigger value="preview">Pricing preview</TabsTrigger>
          <TabsTrigger value="requests">Plan requests <PendingRequestsBadge /></TabsTrigger>
          <TabsTrigger value="resellers">Resellers</TabsTrigger>
          <TabsTrigger value="users">Users</TabsTrigger>
          <TabsTrigger value="demos">Demo requests</TabsTrigger>
          <TabsTrigger value="gateways">Payment gateways</TabsTrigger>
        </TabsList>


        <TabsContent value="workspaces" className="pt-4">
          <WorkspacesTab search={search} setSearch={setSearch} />
        </TabsContent>
        <TabsContent value="library" className="pt-4">
          <PlanLibraryTab />
        </TabsContent>
        <TabsContent value="features" className="pt-4">
          <FeatureLibraryTab />
        </TabsContent>
        <TabsContent value="preview" className="pt-4">
          <PricingPreviewTab />
        </TabsContent>
        <TabsContent value="requests" className="pt-4">
          <PlanRequestsTab />
        </TabsContent>
        <TabsContent value="resellers" className="pt-4">
          <ResellersAdminTab />
        </TabsContent>
          <TabsContent value="users" className="pt-4">
          <UsersTab />
        </TabsContent>
        <TabsContent value="demos" className="pt-4">
          <DemoRequestsTab />
        </TabsContent>
        <TabsContent value="gateways" className="pt-4">
          <PaymentGatewaysTab />
        </TabsContent>
      </Tabs>


    </div>
  );
}



function PendingRequestsBadge() {
  const listFn = useServerFn(adminListPlanRequests);
  const { data } = useQuery({
    queryKey: ["admin-plan-requests"],
    queryFn: () => listFn(),
  });
  const count = (data?.requests ?? []).filter((r: any) => r.status === "pending").length;
  if (!count) return null;
  return <Badge className="ml-2" variant="default">{count}</Badge>;
}

function PlanRequestsTab() {
  const qc = useQueryClient();
  const listFn = useServerFn(adminListPlanRequests);
  const reviewFn = useServerFn(adminReviewPlanRequest);
  const { data, isLoading } = useQuery({
    queryKey: ["admin-plan-requests"],
    queryFn: () => listFn(),
  });

  const [open, setOpen] = useState<{ req: any; action: "approved" | "rejected" } | null>(null);
  const [adminNotes, setAdminNotes] = useState("");

  const reviewMut = useMutation({
    mutationFn: (v: { request_id: string; action: "approved" | "rejected"; admin_notes: string | null }) =>
      reviewFn({ data: v }),
    onSuccess: () => {
      toast.success(open?.action === "approved" ? "Plan approved & applied to workspace" : "Request rejected");
      qc.invalidateQueries({ queryKey: ["admin-plan-requests"] });
      qc.invalidateQueries({ queryKey: ["admin-workspaces"] });
      setOpen(null);
      setAdminNotes("");
    },
    onError: (e: any) => toast.error(e.message),
  });

  const requests = data?.requests ?? [];
  const pending = requests.filter((r: any) => r.status === "pending");
  const history = requests.filter((r: any) => r.status !== "pending");

  function renderRow(r: any) {
    const statusColor =
      r.status === "approved" ? "bg-emerald-100 text-emerald-800 dark:bg-emerald-900/30 dark:text-emerald-300"
      : r.status === "rejected" ? "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300"
      : "bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-300";
    const enabledFeatures = Object.entries(r.features || {}).filter(([, v]) => v).map(([k]) => k);
    return (
      <div key={r.id} className="rounded-lg border bg-card p-4 space-y-3">
        <div className="flex items-start justify-between gap-4 flex-wrap">
          <div className="min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <p className="font-semibold">{r.plan_name}</p>
              <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${statusColor}`}>{r.status}</span>
              <Badge variant="outline" className="text-xs">
                {formatPrice(Number(r.billing_interval === "yearly" ? r.price_yearly : r.price_monthly) || 0, r.currency || "INR")}
                {(Number(r.price_monthly) > 0 || Number(r.price_yearly) > 0) && `/${r.billing_interval || "monthly"}`}
              </Badge>
            </div>
            <p className="text-xs text-muted-foreground mt-0.5">
              {r.workspace?.name ?? "Unknown workspace"} · Requested by {r.requester?.full_name || r.requester?.email || "—"} · {new Date(r.created_at).toLocaleString()}
            </p>

          </div>
          {r.status === "pending" && (
            <div className="flex gap-2 shrink-0">
              <Button size="sm" variant="outline" onClick={() => { setOpen({ req: r, action: "rejected" }); setAdminNotes(""); }}>
                <XIcon className="h-3.5 w-3.5 mr-1" />Reject
              </Button>
              <Button size="sm" onClick={() => { setOpen({ req: r, action: "approved" }); setAdminNotes(""); }}>
                <CheckIcon className="h-3.5 w-3.5 mr-1" />Approve & apply
              </Button>
            </div>
          )}
        </div>
        <div className="grid sm:grid-cols-2 gap-3 text-sm">
          <div>
            <p className="text-xs uppercase text-muted-foreground tracking-wide mb-1">Features</p>
            <div className="flex flex-wrap gap-1">
              {enabledFeatures.length === 0 ? (
                <span className="text-xs text-muted-foreground">None selected</span>
              ) : enabledFeatures.map((k) => <Badge key={k} variant="secondary">{FEATURE_LABELS[k] ?? k}</Badge>)}
            </div>
          </div>
          <div>
            <p className="text-xs uppercase text-muted-foreground tracking-wide mb-1">Limits</p>
            <div className="grid grid-cols-2 gap-x-3 gap-y-0.5 text-xs">
              {Object.entries(r.limits || {}).map(([k, v]) => (
                <div key={k} className="flex justify-between">
                  <span className="text-muted-foreground capitalize">{k.replace(/_/g, " ")}</span>
                  <span className="font-medium">{Number(v) === 0 ? "Unlimited" : v as any}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
        {r.notes && <p className="text-xs"><span className="text-muted-foreground">Customer note: </span>{r.notes}</p>}
        {r.admin_notes && <p className="text-xs"><span className="text-muted-foreground">Admin note: </span>{r.admin_notes}</p>}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="rounded-lg border bg-primary/5 border-primary/30 p-4 flex items-start gap-3">
        <Sparkles className="h-5 w-5 text-primary mt-0.5" />
        <div>
          <p className="font-medium">Custom plan requests</p>
          <p className="text-sm text-muted-foreground">Approving a request will apply the requested features and limits to that workspace's plan automatically.</p>
        </div>
      </div>

      {isLoading ? (
        <div className="text-center py-8"><Loader2 className="h-5 w-5 animate-spin inline" /></div>
      ) : (
        <>
          <div className="space-y-3">
            <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide">Pending ({pending.length})</h3>
            {pending.length === 0 ? (
              <div className="rounded-lg border p-6 text-center text-sm text-muted-foreground">No pending requests.</div>
            ) : pending.map(renderRow)}
          </div>

          {history.length > 0 && (
            <div className="space-y-3">
              <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide">History</h3>
              {history.map(renderRow)}
            </div>
          )}
        </>
      )}

      <Dialog open={!!open} onOpenChange={(o) => !o && setOpen(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{open?.action === "approved" ? "Approve custom plan" : "Reject request"}</DialogTitle>
          </DialogHeader>
          {open && (
            <div className="space-y-3">
              <div className="rounded-md bg-muted/40 p-3 text-sm">
                <p className="font-medium">{open.req.plan_name}</p>
                <p className="text-xs text-muted-foreground">{open.req.workspace?.name}</p>
              </div>
              <div>
                <Label>Note for requester (optional)</Label>
                <Textarea value={adminNotes} onChange={(e) => setAdminNotes(e.target.value)} rows={3} maxLength={1000} />
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(null)}>Cancel</Button>
            <Button
              onClick={() => open && reviewMut.mutate({ request_id: open.req.id, action: open.action, admin_notes: adminNotes || null })}
              variant={open?.action === "rejected" ? "destructive" : "default"}
              disabled={reviewMut.isPending}
            >
              {reviewMut.isPending && <Loader2 className="h-4 w-4 mr-1 animate-spin" />}
              {open?.action === "approved" ? "Approve & apply" : "Reject"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function WorkspacesTab({ search, setSearch }: { search: string; setSearch: (v: string) => void }) {
  const listFn = useServerFn(adminListWorkspaces);
  const setTeamCreationFn = useServerFn(adminSetWorkspaceTeamCreation);
  const deleteWsFn = useServerFn(adminDeleteWorkspace);

  const qc = useQueryClient();
  const { data, isLoading } = useQuery({
    queryKey: ["admin-workspaces"],
    queryFn: () => listFn(),
  });
  const teamCreationMut = useMutation({
    mutationFn: (v: { workspace_id: string; allowed: boolean }) => setTeamCreationFn({ data: v }),
    onSuccess: () => {
      toast.success("Team user creation updated");
      qc.invalidateQueries({ queryKey: ["admin-workspaces"] });
    },
    onError: (e: any) => toast.error(e.message),
  });
  const deleteWsMut = useMutation({
    mutationFn: (v: { workspace_id: string }) => deleteWsFn({ data: v }),
    onSuccess: () => {
      toast.success("Workspace deleted");
      qc.invalidateQueries({ queryKey: ["admin-workspaces"] });
      qc.invalidateQueries({ queryKey: ["admin-users"] });
    },
    onError: (e: any) => toast.error(e.message),
  });


  const [editing, setEditing] = useState<any | null>(null);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return data?.workspaces ?? [];
    return (data?.workspaces ?? []).filter((w: any) =>
      w.name.toLowerCase().includes(q) || w.slug.toLowerCase().includes(q),
    );
  }, [data, search]);

  return (
    <div className="space-y-4">
      <Input placeholder="Search workspaces…" value={search} onChange={(e) => setSearch(e.target.value)} className="max-w-sm" />
      <div className="rounded-lg border bg-card">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Workspace</TableHead>
              <TableHead>Members</TableHead>
              <TableHead>Plan</TableHead>
              <TableHead>Team users</TableHead>
              <TableHead>Created</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading && (
              <TableRow><TableCell colSpan={6} className="text-center py-8"><Loader2 className="h-4 w-4 animate-spin inline" /></TableCell></TableRow>

            )}
            {!isLoading && filtered.length === 0 && (
              <TableRow><TableCell colSpan={6} className="text-center text-muted-foreground py-8">No workspaces</TableCell></TableRow>
            )}
            {filtered.map((w: any) => (
              <TableRow key={w.id}>
                <TableCell>
                  <div className="font-medium">{w.name}</div>
                  <div className="text-xs text-muted-foreground">{w.slug}</div>
                </TableCell>
                <TableCell>{w.member_count}</TableCell>
                <TableCell>
                  {w.plan ? (
                    <div className="space-y-0.5">
                      <Badge variant="secondary">{w.plan.plan_name}</Badge>
                      {(Number(w.plan.price_monthly) > 0 || Number(w.plan.price_yearly) > 0) && (
                        <div className="text-xs text-muted-foreground">
                          {formatPrice(Number(w.plan.billing_interval === "yearly" ? w.plan.price_yearly : w.plan.price_monthly), w.plan.currency || "INR")}
                          /{w.plan.billing_interval || "monthly"}
                        </div>
                      )}
                    </div>
                  ) : (
                    <span className="text-muted-foreground text-sm">No plan</span>
                  )}
                </TableCell>
                <TableCell>
                  <div className="flex items-center gap-2">
                    <Switch
                      checked={!!w.allow_team_user_creation}
                      disabled={teamCreationMut.isPending}
                      onCheckedChange={(v) => teamCreationMut.mutate({ workspace_id: w.id, allowed: v })}
                    />
                    <span className="text-xs text-muted-foreground">
                      {w.allow_team_user_creation ? "Enabled" : "Disabled"}
                    </span>
                  </div>
                </TableCell>

                <TableCell className="text-sm text-muted-foreground">
                  {new Date(w.created_at).toLocaleDateString()}
                </TableCell>

                <TableCell className="text-right">
                  <div className="flex justify-end gap-2">
                    <Button size="sm" variant="outline" onClick={() => setEditing(w)}>
                      <Settings2 className="h-3.5 w-3.5 mr-1" /> Configure
                    </Button>
                    <Button
                      size="sm"
                      variant="destructive"
                      disabled={deleteWsMut.isPending}
                      title="Permanently delete this workspace and all its data"
                      onClick={() => {
                        if (window.confirm(`Permanently delete workspace "${w.name}" and ALL of its data? This cannot be undone.`)) {
                          deleteWsMut.mutate({ workspace_id: w.id });
                        }
                      }}
                    >
                      <Trash2 className="h-3.5 w-3.5 mr-1" /> Delete
                    </Button>
                  </div>
                </TableCell>

              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      {editing && (
        <PlanEditor workspace={editing} onClose={() => setEditing(null)} />
      )}
    </div>
  );
}
function PlanEditor({ workspace, onClose }: { workspace: any; onClose: () => void }) {
  const qc = useQueryClient();
  const upsertFn = useServerFn(adminUpsertPlan);
  const existing = workspace.plan ?? {};
  const [planName, setPlanName] = useState<string>(existing.plan_name ?? "Custom");
  const [features, setFeatures] = useState<Record<string, boolean>>(() => {
    const init: Record<string, boolean> = {};
    FEATURE_KEYS.forEach((k) => { init[k] = existing.features?.[k] ?? true; });
    if (existing.features) Object.assign(init, existing.features);
    return init;
  });
  const [limits, setLimits] = useState<Record<string, number>>(() => {
    const init: Record<string, number> = {};
    LIMIT_KEYS.forEach(({ key }) => { init[key] = Number(existing.limits?.[key] ?? 0); });
    return init;
  });
  const [notes, setNotes] = useState<string>(existing.notes ?? "");
  const [pricing, setPricing] = useState<PricingValue>({
    price_monthly: Number(existing.price_monthly ?? 0),
    price_yearly: Number(existing.price_yearly ?? 0),
    currency: (existing.currency ?? "INR") as any,
  });
  const [billingInterval, setBillingInterval] = useState<"monthly" | "yearly">(existing.billing_interval ?? "monthly");
  const toLocalInput = (iso?: string | null) => {
    if (!iso) return "";
    const d = new Date(iso);
    const pad = (n: number) => String(n).padStart(2, "0");
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
  };
  const defaultStart = existing.starts_at ?? new Date().toISOString();
  const defaultEnd = existing.expires_at ?? new Date(Date.now() + (billingInterval === "yearly" ? 365 : 30) * 86_400_000).toISOString();
  const [startsAt, setStartsAt] = useState<string>(toLocalInput(defaultStart));
  const [expiresAt, setExpiresAt] = useState<string>(toLocalInput(defaultEnd));

  const mut = useMutation({
    mutationFn: () => upsertFn({ data: {
      workspace_id: workspace.id,
      plan_name: planName,
      features,
      limits,
      notes: notes || null,
      price_monthly: pricing.price_monthly,
      price_yearly: pricing.price_yearly,
      currency: pricing.currency,
      billing_interval: billingInterval,
      starts_at: startsAt ? new Date(startsAt).toISOString() : null,
      expires_at: expiresAt ? new Date(expiresAt).toISOString() : null,
    } }),

    onSuccess: () => {
      toast.success("Plan updated");
      qc.invalidateQueries({ queryKey: ["admin-workspaces"] });
      onClose();
    },
    onError: (e: any) => toast.error(e.message),
  });

  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Configure plan — {workspace.name}</DialogTitle>
        </DialogHeader>

        <div className="space-y-5">
          <div className="space-y-2">
            <Label>Plan name</Label>
            <Input value={planName} onChange={(e) => setPlanName(e.target.value)} maxLength={80} />
          </div>

          <div className="space-y-2">
            <Label>Pricing</Label>
            <PricingFields value={pricing} onChange={setPricing} />
            <div className="flex items-center gap-3 text-sm">
              <span className="text-muted-foreground">Active billing cycle:</span>
              <select
                value={billingInterval}
                onChange={(e) => setBillingInterval(e.target.value as any)}
                className="h-9 rounded-md border border-input bg-background px-2"
              >
                <option value="monthly">Monthly</option>
                <option value="yearly">Yearly</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <Label>Start date</Label>
              <Input type="datetime-local" value={startsAt} onChange={(e) => setStartsAt(e.target.value)} />
            </div>
            <div className="space-y-1">
              <Label>Expiry date</Label>
              <Input type="datetime-local" value={expiresAt} onChange={(e) => setExpiresAt(e.target.value)} />
            </div>
            <p className="col-span-2 text-xs text-muted-foreground">Leave defaults to start now and expire after one {billingInterval === "yearly" ? "year" : "month"}.</p>
          </div>




          <div className="space-y-2">
            <Label>Features</Label>
            <div className="grid grid-cols-2 gap-3 rounded-lg border p-4">
              {FEATURE_CATALOG.map(({ key: k, label }) => (
                <div key={k} className="flex items-center justify-between">
                  <span className="text-sm">{label}</span>
                  <Switch
                    checked={features[k] ?? false}
                    onCheckedChange={(v) => setFeatures((f) => ({ ...f, [k]: v }))}
                  />
                </div>
              ))}
            </div>
          </div>

          <div className="space-y-2">
            <Label>Limits</Label>
            <div className="grid grid-cols-2 gap-3 rounded-lg border p-4">
              {LIMIT_KEYS.map(({ key, label }) => (
                <div key={key} className="space-y-1">
                  <span className="text-xs text-muted-foreground">{label}</span>
                  <Input
                    type="number"
                    min={-1}
                    value={limits[key] ?? 0}
                    onChange={(e) => setLimits((l) => ({ ...l, [key]: Number(e.target.value || 0) }))}
                  />
                </div>
              ))}
            </div>
            <p className="text-xs text-muted-foreground">Set <strong>0</strong> for unlimited, <strong>-1</strong> to mark this feature as not included in the plan. Any positive number sets a fixed limit.</p>
          </div>


          <div className="space-y-2">
            <Label>Notes (internal)</Label>
            <Textarea value={notes} onChange={(e) => setNotes(e.target.value)} maxLength={1000} rows={3} />
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button onClick={() => mut.mutate()} disabled={mut.isPending}>
            {mut.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Save plan
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function UsersTab() {
  const listFn = useServerFn(adminListUsers);
  const suspendFn = useServerFn(adminSetUserSuspended);
  const archiveFn = useServerFn(adminSetUserArchived);
  const promoteFn = useServerFn(adminSetSuperAdmin);
  const impersonateFn = useServerFn(adminImpersonateUser);
  const multiWsFn = useServerFn(adminSetUserMultiWorkspace);
  const deleteUserFn = useServerFn(adminDeleteUser);
  const deleteUserMut = useMutation({
    mutationFn: (v: { user_id: string }) => deleteUserFn({ data: v }),
    onSuccess: () => {
      toast.success("User deleted");
      qc.invalidateQueries({ queryKey: ["admin-users"] });
      qc.invalidateQueries({ queryKey: ["admin-workspaces"] });
    },
    onError: (e: any) => toast.error(e.message),
  });

  const qc = useQueryClient();
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<"all" | "trial" | "active" | "suspended" | "archived">("all");
  const [impersonating, setImpersonating] = useState<string | null>(null);

  const { data, isLoading } = useQuery({
    queryKey: ["admin-users"],
    queryFn: () => listFn(),
  });

  const suspendMut = useMutation({
    mutationFn: (v: { user_id: string; suspended: boolean }) => suspendFn({ data: v }),
    onSuccess: () => { toast.success("Updated"); qc.invalidateQueries({ queryKey: ["admin-users"] }); },
    onError: (e: any) => toast.error(e.message),
  });
  const archiveMut = useMutation({
    mutationFn: (v: { user_id: string; archived: boolean }) => archiveFn({ data: v }),
    onSuccess: () => { toast.success("Updated"); qc.invalidateQueries({ queryKey: ["admin-users"] }); },
    onError: (e: any) => toast.error(e.message),
  });
  const promoteMut = useMutation({
    mutationFn: (v: { user_id: string; is_super_admin: boolean }) => promoteFn({ data: v }),
    onSuccess: () => { toast.success("Updated"); qc.invalidateQueries({ queryKey: ["admin-users"] }); },
    onError: (e: any) => toast.error(e.message),
  });
  const multiWsMut = useMutation({
    mutationFn: (v: { user_id: string; allowed: boolean }) => multiWsFn({ data: v }),
    onSuccess: () => { toast.success("Updated"); qc.invalidateQueries({ queryKey: ["admin-users"] }); },
    onError: (e: any) => toast.error(e.message),
  });

  async function handleImpersonate(user: any) {
    if (!confirm(`Sign in as ${user.email}?\n\nThis will replace your current session. You'll need to sign back in as yourself afterwards.`)) return;
    setImpersonating(user.id);
    try {
      const r: any = await impersonateFn({ data: {
        user_id: user.id,
        redirect_to: window.location.origin + "/dashboard",
      } });
      if (r.ok && r.action_link) {
        toast.success(`Signing in as ${user.email}…`);
        window.location.href = r.action_link;
      } else {
        toast.error("Failed to generate sign-in link");
      }
    } catch (e: any) {
      toast.error(e.message);
    } finally {
      setImpersonating(null);
    }
  }

  const isInTrial = (u: any) => !!u.trial_ends_at && new Date(u.trial_ends_at).getTime() > Date.now();

  const counts = useMemo(() => {
    const arr = data?.users ?? [];
    return {
      all: arr.length,
      trial: arr.filter((u: any) => isInTrial(u) && !u.is_suspended && !u.is_archived).length,
      active: arr.filter((u: any) => !u.is_suspended && !u.is_archived).length,
      suspended: arr.filter((u: any) => u.is_suspended && !u.is_archived).length,
      archived: arr.filter((u: any) => u.is_archived).length,
    };
  }, [data]);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    let arr = data?.users ?? [];
    if (statusFilter === "trial") arr = arr.filter((u: any) => isInTrial(u) && !u.is_suspended && !u.is_archived);
    else if (statusFilter === "active") arr = arr.filter((u: any) => !u.is_suspended && !u.is_archived);
    else if (statusFilter === "suspended") arr = arr.filter((u: any) => u.is_suspended && !u.is_archived);
    else if (statusFilter === "archived") arr = arr.filter((u: any) => u.is_archived);
    if (!q) return arr;
    return arr.filter((u: any) =>
      (u.email ?? "").toLowerCase().includes(q) ||
      (u.full_name ?? "").toLowerCase().includes(q) ||
      (u.phone ?? "").toLowerCase().includes(q) ||
      (u.company ?? "").toLowerCase().includes(q),
    );
  }, [data, search, statusFilter]);


  const [detail, setDetail] = useState<any>(null);

  const filterTabs: Array<{ key: typeof statusFilter; label: string }> = [
    { key: "all", label: "All" },
    { key: "trial", label: "Trial" },
    { key: "active", label: "Active" },
    { key: "suspended", label: "Suspended" },
    { key: "archived", label: "Archived" },
  ];

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-2">
        <Input placeholder="Search by name, email, phone or company…" value={search} onChange={(e) => setSearch(e.target.value)} className="max-w-md" />
        <div className="flex flex-wrap gap-1 rounded-md border bg-card p-1">
          {filterTabs.map((t) => (
            <Button
              key={t.key}
              size="sm"
              variant={statusFilter === t.key ? "default" : "ghost"}
              onClick={() => setStatusFilter(t.key)}
              className="h-8"
            >
              {t.label}
              <span className="ml-1.5 text-xs opacity-70">{(counts as any)[t.key] ?? 0}</span>
            </Button>
          ))}
        </div>
      </div>
      <div className="rounded-lg border bg-card overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>User</TableHead>
              <TableHead>Phone</TableHead>
              <TableHead>Company</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Joined</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading && (
              <TableRow><TableCell colSpan={6} className="text-center py-8"><Loader2 className="h-4 w-4 animate-spin inline" /></TableCell></TableRow>
            )}
            {!isLoading && filtered.length === 0 && (
              <TableRow><TableCell colSpan={6} className="text-center text-muted-foreground py-8">No users</TableCell></TableRow>
            )}
            {filtered.map((u: any) => (
              <TableRow key={u.id} className={u.is_archived ? "opacity-60" : ""}>
                <TableCell>
                  <div className="font-medium">{u.full_name || "—"}</div>
                  <div className="text-xs text-muted-foreground">{u.email}</div>
                </TableCell>
                <TableCell className="text-sm">{u.phone || <span className="text-muted-foreground">—</span>}</TableCell>
                <TableCell className="text-sm">{u.company || <span className="text-muted-foreground">—</span>}</TableCell>
                <TableCell className="space-x-1">
                  {u.is_super_admin && <Badge>Super Admin</Badge>}
                  {u.is_archived
                    ? <Badge variant="outline">Archived</Badge>
                    : u.is_suspended
                      ? <Badge variant="destructive">Suspended</Badge>
                      : isInTrial(u)
                        ? <Badge variant="secondary">Trial</Badge>
                        : <Badge variant="secondary">Active</Badge>}
                </TableCell>
                <TableCell className="text-sm text-muted-foreground">
                  {new Date(u.created_at).toLocaleDateString()}
                </TableCell>
                <TableCell className="text-right space-x-2 whitespace-nowrap">
                  <Button size="sm" variant="ghost" onClick={() => setDetail(u)} title="View details">
                    <Eye className="h-3.5 w-3.5 mr-1" /> View
                  </Button>
                  <Button
                    size="sm"
                    variant="secondary"
                    onClick={() => handleImpersonate(u)}
                    disabled={impersonating === u.id || u.is_suspended || u.is_archived}
                    title="Sign in as this user"
                  >
                    {impersonating === u.id ? <Loader2 className="h-3.5 w-3.5 mr-1 animate-spin" /> : <LogIn className="h-3.5 w-3.5 mr-1" />}
                    Login as
                  </Button>
                  <Button
                    size="sm"
                    variant={u.allow_multi_workspace ? "default" : "outline"}
                    onClick={() => multiWsMut.mutate({ user_id: u.id, allowed: !u.allow_multi_workspace })}
                    title="Toggle multi-workspace access"
                  >
                    {u.allow_multi_workspace ? "Multi-WS: On" : "Multi-WS: Off"}
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => promoteMut.mutate({ user_id: u.id, is_super_admin: !u.is_super_admin })}
                  >
                    {u.is_super_admin ? <><ShieldOff className="h-3.5 w-3.5 mr-1" /> Demote</> : <><Shield className="h-3.5 w-3.5 mr-1" /> Promote</>}
                  </Button>
                  <Button
                    size="sm"
                    variant={u.is_suspended ? "outline" : "destructive"}
                    onClick={() => suspendMut.mutate({ user_id: u.id, suspended: !u.is_suspended })}
                  >
                    {u.is_suspended ? <><CheckCircle2 className="h-3.5 w-3.5 mr-1" /> Reactivate</> : <><Ban className="h-3.5 w-3.5 mr-1" /> Suspend</>}
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => archiveMut.mutate({ user_id: u.id, archived: !u.is_archived })}
                    title={u.is_archived ? "Restore from archive" : "Archive this user"}
                  >
                    {u.is_archived ? "Unarchive" : "Archive"}
                  </Button>
                  <Button
                    size="sm"
                    variant="destructive"
                    disabled={deleteUserMut.isPending || u.is_super_admin}
                    title={u.is_super_admin ? "Demote this super admin before deleting" : "Permanently delete this user and their owned workspaces"}
                    onClick={() => {
                      if (window.confirm(`Permanently delete ${u.email}? This removes their account, owned workspaces and all related data. This cannot be undone.`)) {
                        deleteUserMut.mutate({ user_id: u.id });
                      }
                    }}
                  >
                    <Trash2 className="h-3.5 w-3.5 mr-1" /> Delete
                  </Button>

                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>


      <Dialog open={!!detail} onOpenChange={(o) => !o && setDetail(null)}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>User details</DialogTitle></DialogHeader>
          {detail && (
            <div className="space-y-3 text-sm">
              <DetailRow label="Full name" value={detail.full_name} />
              <DetailRow label="Work email" value={detail.email} />
              <DetailRow label="Phone" value={detail.phone} />
              <DetailRow label="Company" value={detail.company} />
              <DetailRow label="Password" value="•••••••• (securely hashed — cannot be displayed)" mono />
              <DetailRow label="User ID" value={detail.id} mono />
              <DetailRow label="Email confirmed" value={detail.email_confirmed_at ? new Date(detail.email_confirmed_at).toLocaleString() : "Not confirmed"} />
              <DetailRow label="Last sign-in" value={detail.last_sign_in_at ? new Date(detail.last_sign_in_at).toLocaleString() : "Never"} />
              <DetailRow label="Joined" value={new Date(detail.created_at).toLocaleString()} />
              <DetailRow label="Role" value={detail.is_super_admin ? "Super Admin" : "User"} />
              <DetailRow label="Status" value={detail.is_suspended ? "Suspended" : "Active"} />
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

function DetailRow({ label, value, mono }: { label: string; value: any; mono?: boolean }) {
  return (
    <div className="grid grid-cols-3 gap-3">
      <div className="text-muted-foreground">{label}</div>
      <div className={"col-span-2 break-all " + (mono ? "font-mono text-xs" : "")}>{value || <span className="text-muted-foreground">—</span>}</div>
    </div>
  );
}

function DemoRequestsTab() {
  const listFn = useServerFn(adminListDemoRequests);
  const [search, setSearch] = useState("");
  const [detail, setDetail] = useState<any>(null);
  const { data, isLoading } = useQuery({
    queryKey: ["admin-demo-requests"],
    queryFn: () => listFn(),
  });
  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    const rows = (data as any)?.requests ?? [];
    if (!q) return rows;
    return rows.filter((r: any) =>
      (r.full_name ?? "").toLowerCase().includes(q) ||
      (r.email ?? "").toLowerCase().includes(q) ||
      (r.phone ?? "").toLowerCase().includes(q) ||
      (r.company ?? "").toLowerCase().includes(q),
    );
  }, [data, search]);
  return (
    <div className="space-y-4">
      <Input placeholder="Search demos by name, email, phone or company…" value={search} onChange={(e) => setSearch(e.target.value)} className="max-w-md" />
      <div className="rounded-lg border bg-card overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Name</TableHead>
              <TableHead>Email</TableHead>
              <TableHead>Phone</TableHead>
              <TableHead>Company</TableHead>
              <TableHead>Business</TableHead>
              <TableHead>Requested</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading && (
              <TableRow><TableCell colSpan={7} className="text-center py-8"><Loader2 className="h-4 w-4 animate-spin inline" /></TableCell></TableRow>
            )}
            {!isLoading && filtered.length === 0 && (
              <TableRow><TableCell colSpan={7} className="text-center text-muted-foreground py-8">No demo requests yet</TableCell></TableRow>
            )}
            {filtered.map((r: any) => (
              <TableRow key={r.id}>
                <TableCell className="font-medium">{r.full_name}</TableCell>
                <TableCell className="text-sm">{r.email}</TableCell>
                <TableCell className="text-sm">{r.phone || <span className="text-muted-foreground">—</span>}</TableCell>
                <TableCell className="text-sm">{r.company || <span className="text-muted-foreground">—</span>}</TableCell>
                <TableCell className="text-sm">{r.business_type || <span className="text-muted-foreground">—</span>}</TableCell>
                <TableCell className="text-sm text-muted-foreground">{new Date(r.created_at).toLocaleDateString()}</TableCell>
                <TableCell className="text-right">
                  <Button size="sm" variant="ghost" onClick={() => setDetail(r)}>
                    <Eye className="h-3.5 w-3.5 mr-1" /> View
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
      <Dialog open={!!detail} onOpenChange={(o) => !o && setDetail(null)}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>Demo request</DialogTitle></DialogHeader>
          {detail && (
            <div className="space-y-3 text-sm">
              <DetailRow label="Full name" value={detail.full_name} />
              <DetailRow label="Work email" value={detail.email} />
              <DetailRow label="Phone" value={detail.phone} />
              <DetailRow label="Company" value={detail.company} />
              <DetailRow label="Business type" value={detail.business_type} />
              <DetailRow label="Message" value={detail.message} />
              <DetailRow label="Requested" value={new Date(detail.created_at).toLocaleString()} />
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}


function PlanLibraryTab() {
  const qc = useQueryClient();
  const listFn = useServerFn(adminListPlanTemplates);
  const deleteFn = useServerFn(adminDeletePlanTemplate);
  const { data, isLoading } = useQuery({
    queryKey: ["admin-plan-templates"],
    queryFn: () => listFn(),
  });
  const [editing, setEditing] = useState<any | null>(null);
  const [assigning, setAssigning] = useState<any | null>(null);
  const [creating, setCreating] = useState(false);

  const delMut = useMutation({
    mutationFn: (id: string) => deleteFn({ data: { id } }),
    onSuccess: () => {
      toast.success("Template deleted");
      qc.invalidateQueries({ queryKey: ["admin-plan-templates"] });
    },
    onError: (e: any) => toast.error(e.message),
  });

  const templates = data?.templates ?? [];

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="font-semibold">Reusable plan templates</h2>
          <p className="text-sm text-muted-foreground">Create plans once, edit them anytime, and assign to one or more workspaces.</p>
        </div>
        <Button onClick={() => setCreating(true)}><Plus className="h-4 w-4 mr-1" />New plan</Button>
      </div>

      {isLoading ? (
        <div className="text-center py-8"><Loader2 className="h-5 w-5 animate-spin inline" /></div>
      ) : templates.length === 0 ? (
        <div className="rounded-lg border p-8 text-center text-sm text-muted-foreground">
          No plans yet. Create your first reusable plan.
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {templates.map((t: any) => {
            const enabled = Object.entries(t.features || {}).filter(([, v]) => v).map(([k]) => k);
            return (
              <div key={t.id} className="rounded-lg border bg-card p-4 space-y-3">
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <p className="font-semibold truncate">{t.name}</p>
                    {!t.is_active && <Badge variant="outline" className="mt-1">Inactive</Badge>}
                  </div>
                </div>
                <div className="text-sm">
                  <span className="text-lg font-bold">{formatPrice(Number(t.price_monthly) || 0, t.currency || "INR")}</span>
                  <span className="text-xs text-muted-foreground">/mo</span>
                  {Number(t.price_yearly) > 0 && (
                    <span className="ml-2 text-xs text-muted-foreground">· {formatPrice(Number(t.price_yearly), t.currency || "INR")}/yr</span>
                  )}
                </div>
                {(t.gateway_ids?.length ?? 0) > 0 && (
                  <div className="flex flex-wrap gap-1">
                    {t.gateway_ids.map((g: string) => <Badge key={g} variant="outline" className="text-xs capitalize">{g}</Badge>)}
                  </div>
                )}
                {t.description && <p className="text-xs text-muted-foreground line-clamp-2">{t.description}</p>}
                <div>
                  <p className="text-xs uppercase text-muted-foreground tracking-wide mb-1">Features ({enabled.length})</p>
                  <div className="flex flex-wrap gap-1">
                    {enabled.slice(0, 4).map((k) => <Badge key={k} variant="secondary" className="text-xs">{FEATURE_LABELS[k] ?? k}</Badge>)}
                    {enabled.length > 4 && <Badge variant="outline" className="text-xs">+{enabled.length - 4}</Badge>}
                  </div>
                </div>

                <div className="flex gap-2 pt-2 border-t">
                  <Button size="sm" variant="outline" className="flex-1" onClick={() => setEditing(t)}>
                    <Pencil className="h-3.5 w-3.5 mr-1" />Edit
                  </Button>
                  <Button size="sm" className="flex-1" onClick={() => setAssigning(t)}>
                    <Send className="h-3.5 w-3.5 mr-1" />Assign
                  </Button>
                  <Button size="sm" variant="ghost" onClick={() => { if (confirm(`Delete "${t.name}"?`)) delMut.mutate(t.id); }}>
                    <Trash2 className="h-3.5 w-3.5 text-destructive" />
                  </Button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {(creating || editing) && (
        <PlanTemplateEditor
          template={editing}
          onClose={() => { setCreating(false); setEditing(null); }}
        />
      )}
      {assigning && (
        <AssignPlanDialog template={assigning} onClose={() => setAssigning(null)} />
      )}
    </div>
  );
}

function PlanTemplateEditor({ template, onClose }: { template: any | null; onClose: () => void }) {
  const qc = useQueryClient();
  const createFn = useServerFn(adminCreatePlanTemplate);
  const updateFn = useServerFn(adminUpdatePlanTemplate);
  const listFeaturesFn = useServerFn(adminListMasterFeatures);
  const getPlanFeaturesFn = useServerFn(adminGetPlanFeatures);
  const setPlanFeaturesFn = useServerFn(adminSetPlanFeatures);
  const isEdit = !!template;

  const [name, setName] = useState<string>(template?.name ?? "");
  const [description, setDescription] = useState<string>(template?.description ?? "");
  const [isActive, setIsActive] = useState<boolean>(template?.is_active ?? true);
  const [isPopular, setIsPopular] = useState<boolean>(template?.is_popular ?? false);
  const [badgeText, setBadgeText] = useState<string>(template?.badge_text ?? "");
  const [features, setFeatures] = useState<Record<string, boolean>>(() => {
    const init: Record<string, boolean> = {};
    FEATURE_KEYS.forEach((k) => { init[k] = template?.features?.[k] ?? false; });
    return init;
  });
  const [limits, setLimits] = useState<Record<string, number>>(() => {
    const init: Record<string, number> = {};
    LIMIT_KEYS.forEach(({ key }) => { init[key] = Number(template?.limits?.[key] ?? 0); });
    return init;
  });
  const [pricing, setPricing] = useState<PricingValue>({
    price_monthly: Number(template?.price_monthly ?? 0),
    price_yearly: Number(template?.price_yearly ?? 0),
    currency: (template?.currency ?? "INR") as any,
    gateway_ids: (template?.gateway_ids ?? []) as any,
  });

  // Master features
  const { data: masterData } = useQuery({
    queryKey: ["admin-master-features"],
    queryFn: () => listFeaturesFn(),
  });
  const masterFeatures = masterData?.features ?? [];

  const { data: existingLinksData } = useQuery({
    queryKey: ["admin-plan-features", template?.id],
    queryFn: () => getPlanFeaturesFn({ data: { template_id: template!.id } }),
    enabled: !!template?.id,
  });

  // state: featureRows keyed by feature_id -> { included, custom_value }
  const [featureRows, setFeatureRows] = useState<Record<string, { included: boolean; custom_value: string }>>({});
  // Initialize once when existingLinks load
  const [initedLinks, setInitedLinks] = useState(false);
  if (!initedLinks && (existingLinksData || !template?.id)) {
    const init: Record<string, { included: boolean; custom_value: string }> = {};
    if (existingLinksData?.rows) {
      for (const r of existingLinksData.rows) {
        init[r.feature_id] = { included: r.included, custom_value: r.custom_value ?? "" };
      }
    }
    setFeatureRows(init);
    setInitedLinks(true);
  }

  // Group master features by category
  const categories = useMemo(() => {
    const map = new Map<string, any[]>();
    for (const f of masterFeatures) {
      if (!map.has(f.category)) map.set(f.category, []);
      map.get(f.category)!.push(f);
    }
    return Array.from(map.entries());
  }, [masterFeatures]);

  const mut = useMutation({
    mutationFn: async () => {
      const payload = {
        name,
        description: description || null,
        features,
        limits,
        is_active: isActive,
        is_popular: isPopular,
        badge_text: badgeText.trim() || null,
        position: Number(template?.position ?? 0),
        price_monthly: pricing.price_monthly,
        price_yearly: pricing.price_yearly,
        currency: pricing.currency,
        gateway_ids: pricing.gateway_ids ?? [],
      };
      let templateId: string;
      if (isEdit) {
        await updateFn({ data: { id: template.id, ...payload } });
        templateId = template.id;
      } else {
        const res: any = await createFn({ data: payload });
        templateId = res.template.id;
      }
      // Persist master feature assignments
      const featuresPayload = Object.entries(featureRows)
        .filter(([, v]) => v.included || (v.custom_value && v.custom_value.trim()))
        .map(([feature_id, v]) => ({
          feature_id,
          included: v.included,
          custom_value: v.custom_value.trim() || null,
        }));
      await setPlanFeaturesFn({ data: { template_id: templateId, features: featuresPayload } });
    },
    onSuccess: () => {
      toast.success(isEdit ? "Plan updated" : "Plan created");
      qc.invalidateQueries({ queryKey: ["admin-plan-templates"] });
      qc.invalidateQueries({ queryKey: ["public-pricing"] });
      onClose();
    },
    onError: (e: any) => toast.error(e.message),
  });

  function updateRow(id: string, patch: Partial<{ included: boolean; custom_value: string }>) {
    setFeatureRows((rows) => ({
      ...rows,
      [id]: { included: rows[id]?.included ?? false, custom_value: rows[id]?.custom_value ?? "", ...patch },
    }));
  }

  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{isEdit ? "Edit plan" : "New plan"}</DialogTitle>
        </DialogHeader>
        <div className="space-y-5">
          <div className="grid sm:grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label>Name</Label>
              <Input value={name} onChange={(e) => setName(e.target.value)} maxLength={80} placeholder="e.g. Growth, Pro" />
            </div>
            <div className="space-y-2">
              <Label>Badge text (optional)</Label>
              <Input value={badgeText} onChange={(e) => setBadgeText(e.target.value)} maxLength={40} placeholder="Most popular" />
            </div>
          </div>
          <div className="space-y-2">
            <Label>Description</Label>
            <Textarea value={description} onChange={(e) => setDescription(e.target.value)} rows={2} maxLength={500} />
          </div>
          <div className="grid sm:grid-cols-2 gap-3">
            <div className="flex items-center justify-between rounded-lg border p-3">
              <div>
                <p className="text-sm font-medium">Active</p>
                <p className="text-xs text-muted-foreground">Only active plans show on the pricing page.</p>
              </div>
              <Switch checked={isActive} onCheckedChange={setIsActive} />
            </div>
            <div className="flex items-center justify-between rounded-lg border p-3">
              <div>
                <p className="text-sm font-medium">Most popular</p>
                <p className="text-xs text-muted-foreground">Show the highlight badge on pricing.</p>
              </div>
              <Switch checked={isPopular} onCheckedChange={setIsPopular} />
            </div>
          </div>
          <div className="space-y-2">
            <Label>Pricing & gateways</Label>
            <PricingFields value={pricing} onChange={setPricing} showGateways />
          </div>

          {/* Master features comparison values */}
          <div className="space-y-2">
            <Label>Plan features (master library)</Label>
            <p className="text-xs text-muted-foreground">Mark each feature as included (✓), or leave a custom value (e.g. "Unlimited", "10,000 messages"). Empty rows render as ✗ on the pricing comparison.</p>
            <div className="rounded-lg border divide-y max-h-[420px] overflow-y-auto">
              {categories.length === 0 && (
                <div className="p-4 text-sm text-muted-foreground text-center">No features in the master library yet — add some in the "Feature library" tab.</div>
              )}
              {categories.map(([cat, list]) => (
                <div key={cat} className="bg-card">
                  <div className="bg-muted/50 px-3 py-1.5 text-xs font-semibold uppercase tracking-wider">{cat}</div>
                  <div className="divide-y">
                    {list.map((f: any) => {
                      const row = featureRows[f.id] ?? { included: false, custom_value: "" };
                      return (
                        <div key={f.id} className="grid grid-cols-12 gap-2 items-center p-2 text-sm">
                          <div className="col-span-6 truncate" title={f.description ?? ""}>{f.name}</div>
                          <div className="col-span-2 flex items-center justify-center">
                            <Switch
                              checked={row.included}
                              onCheckedChange={(v) => updateRow(f.id, { included: v })}
                            />
                          </div>
                          <div className="col-span-4">
                            <Input
                              value={row.custom_value}
                              onChange={(e) => updateRow(f.id, { custom_value: e.target.value })}
                              placeholder="Custom value"
                              className="h-8 text-xs"
                              maxLength={80}
                            />
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Legacy feature toggles still drive nav/route gating */}
          <details className="space-y-2 rounded-lg border p-3">
            <summary className="text-sm font-medium cursor-pointer">App access control (advanced)</summary>
            <p className="text-xs text-muted-foreground mt-2">These flags gate which app modules workspaces on this plan can use.</p>
            <div className="grid grid-cols-2 gap-3 mt-3">
              {FEATURE_CATALOG.map(({ key: k, label }) => (
                <div key={k} className="flex items-center justify-between">
                  <span className="text-sm">{label}</span>
                  <Switch checked={features[k] ?? false} onCheckedChange={(v) => setFeatures((f) => ({ ...f, [k]: v }))} />
                </div>
              ))}
            </div>
          </details>

          <div className="space-y-2">
            <Label>Limits</Label>
            <div className="grid grid-cols-2 gap-3 rounded-lg border p-4">
              {LIMIT_KEYS.map(({ key, label }) => (
                <div key={key} className="space-y-1">
                  <span className="text-xs text-muted-foreground">{label}</span>
                  <Input type="number" min={-1} value={limits[key] ?? 0} onChange={(e) => setLimits((l) => ({ ...l, [key]: Number(e.target.value || 0) }))} />
                </div>
              ))}
            </div>
            <p className="text-xs text-muted-foreground">Set <strong>0</strong> for unlimited, <strong>-1</strong> to mark this feature as not included. Any positive number sets a fixed limit.</p>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button onClick={() => mut.mutate()} disabled={mut.isPending || !name.trim()}>
            {mut.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            {isEdit ? "Save changes" : "Create plan"}
          </Button>

        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function AssignPlanDialog({ template, onClose }: { template: any; onClose: () => void }) {
  const qc = useQueryClient();
  const listFn = useServerFn(adminListWorkspaces);
  const assignFn = useServerFn(adminAssignPlanTemplate);
  const { data, isLoading } = useQuery({
    queryKey: ["admin-workspaces"],
    queryFn: () => listFn(),
  });
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [search, setSearch] = useState("");

  const workspaces = useMemo(() => {
    const q = search.trim().toLowerCase();
    const all = data?.workspaces ?? [];
    if (!q) return all;
    return all.filter((w: any) => w.name.toLowerCase().includes(q) || w.slug.toLowerCase().includes(q));
  }, [data, search]);

  const mut = useMutation({
    mutationFn: () => assignFn({ data: { template_id: template.id, workspace_ids: Array.from(selected) } }),
    onSuccess: (res: any) => {
      toast.success(`Assigned to ${res.count} workspace${res.count === 1 ? "" : "s"}`);
      qc.invalidateQueries({ queryKey: ["admin-workspaces"] });
      onClose();
    },
    onError: (e: any) => toast.error(e.message),
  });

  function toggle(id: string) {
    setSelected((s) => {
      const next = new Set(s);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  }

  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-xl max-h-[85vh] flex flex-col">
        <DialogHeader>
          <DialogTitle>Assign "{template.name}"</DialogTitle>
        </DialogHeader>
        <div className="space-y-3 overflow-hidden flex flex-col flex-1">
          <Input placeholder="Search workspaces…" value={search} onChange={(e) => setSearch(e.target.value)} />
          <div className="text-xs text-muted-foreground">
            {selected.size} selected · Assigning will overwrite each workspace's current plan.
          </div>
          <div className="border rounded-lg overflow-y-auto flex-1 divide-y">
            {isLoading && <div className="p-6 text-center"><Loader2 className="h-4 w-4 animate-spin inline" /></div>}
            {!isLoading && workspaces.length === 0 && (
              <div className="p-6 text-center text-sm text-muted-foreground">No workspaces</div>
            )}
            {workspaces.map((w: any) => (
              <label key={w.id} className="flex items-center gap-3 p-3 hover:bg-muted/40 cursor-pointer">
                <Checkbox checked={selected.has(w.id)} onCheckedChange={() => toggle(w.id)} />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">{w.name}</p>
                  <p className="text-xs text-muted-foreground truncate">
                    {w.slug} · {w.member_count} member{w.member_count === 1 ? "" : "s"}
                    {w.plan && <> · Current: <span className="text-foreground">{w.plan.plan_name}</span></>}
                  </p>
                </div>
              </label>
            ))}
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button onClick={() => mut.mutate()} disabled={mut.isPending || selected.size === 0}>
            {mut.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Assign to {selected.size} workspace{selected.size === 1 ? "" : "s"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function PaymentGatewaysTab() {
  const qc = useQueryClient();
  const listFn = useServerFn(adminListPaymentGateways);
  const updateFn = useServerFn(adminUpdatePaymentGateway);
  const { data, isLoading } = useQuery({
    queryKey: ["admin-payment-gateways"],
    queryFn: () => listFn(),
  });

  const mut = useMutation({
    mutationFn: (v: { provider: any; is_enabled: boolean; key_id: string | null; secret_key?: string | null; webhook_secret?: string | null; meta: Record<string, any> }) =>
      updateFn({ data: v }),
    onSuccess: () => {
      toast.success("Gateway updated");
      qc.invalidateQueries({ queryKey: ["admin-payment-gateways"] });
    },
    onError: (e: any) => toast.error(e.message),
  });

  const rows = data?.gateways ?? [];
  const byProvider = new Map(rows.map((r: any) => [r.provider, r]));

  return (
    <div className="space-y-4">
      <div className="rounded-lg border bg-primary/5 border-primary/30 p-4">
        <p className="font-medium">Payment gateway configuration</p>
        <p className="text-sm text-muted-foreground">Enable a gateway and paste its App ID / Secret Key / Webhook Secret below. Leave a secret field blank to keep the previously saved value.</p>
      </div>
      <div className="grid sm:grid-cols-2 gap-4">
        {PAYMENT_PROVIDERS.map((p) => {
          const row: any = byProvider.get(p.key) ?? { provider: p.key, display_name: p.label, is_enabled: false, key_id: "", secret_key: "", webhook_secret: "", meta: {} };
          return (
            <GatewayCard key={p.key} provider={p} row={row} onSave={(v) => mut.mutate({ provider: p.key, ...v })} saving={mut.isPending} />
          );
        })}
      </div>
      {isLoading && <div className="text-center py-4"><Loader2 className="h-4 w-4 animate-spin inline" /></div>}
    </div>
  );
}

function GatewayCard({ provider, row, onSave, saving }: { provider: any; row: any; onSave: (v: { is_enabled: boolean; key_id: string | null; secret_key: string | null; webhook_secret: string | null; meta: Record<string, any> }) => void; saving: boolean }) {
  const [enabled, setEnabled] = useState<boolean>(row.is_enabled);
  const [keyId, setKeyId] = useState<string>(row.key_id ?? "");
  const [secretKey, setSecretKey] = useState<string>("");
  const [webhookSecret, setWebhookSecret] = useState<string>("");
  const hasSavedSecret = !!row.secret_key;
  const hasSavedWebhook = !!row.webhook_secret;
  return (
    <div className="rounded-lg border bg-card p-4 space-y-3">
      <div className="flex items-center justify-between">
        <div>
          <p className="font-semibold">{provider.label}</p>
          <p className="text-xs text-muted-foreground">{provider.region}</p>
        </div>
        <Switch checked={enabled} onCheckedChange={setEnabled} />
      </div>
      <div className="space-y-1">
        <Label className="text-xs">Public key / app ID</Label>
        <Input value={keyId} onChange={(e) => setKeyId(e.target.value)} placeholder={`${provider.label} key ID`} maxLength={255} />
      </div>
      <div className="space-y-1">
        <Label className="text-xs">Secret key {hasSavedSecret && <span className="text-success">(saved — leave blank to keep)</span>}</Label>
        <Input type="password" autoComplete="new-password" value={secretKey} onChange={(e) => setSecretKey(e.target.value)} placeholder={hasSavedSecret ? "••••••••" : `${provider.label} secret key`} maxLength={500} />
      </div>
      <div className="space-y-1">
        <Label className="text-xs">Webhook secret {hasSavedWebhook && <span className="text-success">(saved — leave blank to keep)</span>}</Label>
        <Input type="password" autoComplete="new-password" value={webhookSecret} onChange={(e) => setWebhookSecret(e.target.value)} placeholder={hasSavedWebhook ? "••••••••" : `${provider.label} webhook signing secret`} maxLength={500} />
      </div>
      <Button size="sm" onClick={() => onSave({ is_enabled: enabled, key_id: keyId || null, secret_key: secretKey || null, webhook_secret: webhookSecret || null, meta: row.meta ?? {} })} disabled={saving}>
        {saving && <Loader2 className="h-3.5 w-3.5 mr-1 animate-spin" />}Save
      </Button>
    </div>
  );
}


// ============================================================
// Feature Library Tab
// ============================================================

const FEATURE_CATEGORIES = [
  "WhatsApp API",
  "Inbox & Team",
  "CRM",
  "Marketing",
  "Automation",
  "AI Bots",
  "E-commerce",
  "Integrations",
  "Analytics",
  "Support",
  "Advanced Features",
];

function FeatureLibraryTab() {
  const qc = useQueryClient();
  const listFn = useServerFn(adminListMasterFeatures);
  const deleteFn = useServerFn(adminDeleteMasterFeature);
  const reorderFn = useServerFn(adminReorderMasterFeatures);

  const { data, isLoading } = useQuery({
    queryKey: ["admin-master-features"],
    queryFn: () => listFn(),
  });

  const [editing, setEditing] = useState<any | null>(null);
  const [creating, setCreating] = useState(false);
  const [filter, setFilter] = useState<string>("all");

  const features = data?.features ?? [];
  const filtered = filter === "all" ? features : features.filter((f: any) => f.category === filter);

  const grouped = useMemo(() => {
    const map = new Map<string, any[]>();
    for (const f of filtered) {
      if (!map.has(f.category)) map.set(f.category, []);
      map.get(f.category)!.push(f);
    }
    return Array.from(map.entries());
  }, [filtered]);

  const sensors = useSensors(useSensor(PointerSensor, { activationConstraint: { distance: 5 } }));

  const delMut = useMutation({
    mutationFn: (id: string) => deleteFn({ data: { id } }),
    onSuccess: () => {
      toast.success("Feature deleted");
      qc.invalidateQueries({ queryKey: ["admin-master-features"] });
      qc.invalidateQueries({ queryKey: ["public-pricing"] });
    },
    onError: (e: any) => toast.error(e.message),
  });

  const reorderMut = useMutation({
    mutationFn: (order: { id: string; position: number }[]) => reorderFn({ data: { order } }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-master-features"] });
      qc.invalidateQueries({ queryKey: ["public-pricing"] });
    },
  });

  function onDragEnd(catFeatures: any[], event: DragEndEvent) {
    const { active, over } = event;
    if (!over || active.id === over.id) return;
    const oldIndex = catFeatures.findIndex((f) => f.id === active.id);
    const newIndex = catFeatures.findIndex((f) => f.id === over.id);
    if (oldIndex < 0 || newIndex < 0) return;
    const next = arrayMove(catFeatures, oldIndex, newIndex);
    const basePos = catFeatures[0]?.position ?? 0;
    const order = next.map((f, i) => ({ id: f.id as string, position: basePos + i * 10 }));
    reorderMut.mutate(order);
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div>
          <h2 className="font-semibold">Master feature library</h2>
          <p className="text-sm text-muted-foreground">Create features once and assign them to multiple plans. Drag to reorder within a category.</p>
        </div>
        <div className="flex items-center gap-2">
          <select
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
            className="h-9 rounded-md border bg-background px-3 text-sm"
          >
            <option value="all">All categories</option>
            {FEATURE_CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
          </select>
          <Button onClick={() => setCreating(true)}><Plus className="h-4 w-4 mr-1" />New feature</Button>
        </div>
      </div>

      {isLoading ? (
        <div className="text-center py-8"><Loader2 className="h-5 w-5 animate-spin inline" /></div>
      ) : features.length === 0 ? (
        <div className="rounded-lg border p-8 text-center text-sm text-muted-foreground">
          No features yet. Create your first feature.
        </div>
      ) : (
        <div className="space-y-4">
          {grouped.map(([cat, list]) => (
            <div key={cat} className="rounded-lg border bg-card">
              <div className="px-4 py-2 border-b bg-muted/40 text-xs font-semibold uppercase tracking-wider">{cat}</div>
              <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={(e) => onDragEnd(list, e)}>
                <SortableContext items={list.map((f: any) => f.id)} strategy={verticalListSortingStrategy}>
                  <div className="divide-y">
                    {list.map((f: any) => (
                      <SortableItem key={f.id} id={f.id} className="px-3 py-2">
                        <div className="flex items-center gap-3">
                          <FeatureIconPreview name={f.icon} />
                          <div className="flex-1 min-w-0">
                            <p className="font-medium text-sm truncate">{f.name}</p>
                            {f.description && <p className="text-xs text-muted-foreground truncate">{f.description}</p>}
                          </div>
                          {!f.is_active && <Badge variant="outline" className="text-xs">Inactive</Badge>}
                          <Button size="sm" variant="ghost" onClick={() => setEditing(f)}>
                            <Pencil className="h-3.5 w-3.5" />
                          </Button>
                          <Button size="sm" variant="ghost" onClick={() => { if (confirm(`Delete "${f.name}"?`)) delMut.mutate(f.id); }}>
                            <Trash2 className="h-3.5 w-3.5 text-destructive" />
                          </Button>
                        </div>
                      </SortableItem>
                    ))}
                  </div>
                </SortableContext>
              </DndContext>
            </div>
          ))}
        </div>
      )}

      {(creating || editing) && (
        <MasterFeatureEditor
          feature={editing}
          onClose={() => { setCreating(false); setEditing(null); }}
        />
      )}
    </div>
  );
}

function FeatureIconPreview({ name }: { name: string | null }) {
  if (!name) return <div className="h-5 w-5" />;
  const Cmp = (LucideIcons as any)[name];
  if (!Cmp) return <div className="h-5 w-5" />;
  return <Cmp className="h-5 w-5 text-muted-foreground" />;
}

function MasterFeatureEditor({ feature, onClose }: { feature: any | null; onClose: () => void }) {
  const qc = useQueryClient();
  const createFn = useServerFn(adminCreateMasterFeature);
  const updateFn = useServerFn(adminUpdateMasterFeature);
  const isEdit = !!feature;

  const [name, setName] = useState(feature?.name ?? "");
  const [description, setDescription] = useState(feature?.description ?? "");
  const [category, setCategory] = useState(feature?.category ?? FEATURE_CATEGORIES[0]);
  const [icon, setIcon] = useState(feature?.icon ?? "");
  const [isActive, setIsActive] = useState(feature?.is_active ?? true);

  const mut = useMutation({
    mutationFn: async () => {
      const payload = {
        name,
        description: description || null,
        category,
        icon: icon || null,
        position: Number(feature?.position ?? 9999),
        is_active: isActive,
      };
      if (isEdit) return updateFn({ data: { id: feature.id, ...payload } });
      return createFn({ data: payload });
    },
    onSuccess: () => {
      toast.success(isEdit ? "Feature updated" : "Feature created");
      qc.invalidateQueries({ queryKey: ["admin-master-features"] });
      qc.invalidateQueries({ queryKey: ["public-pricing"] });
      onClose();
    },
    onError: (e: any) => toast.error(e.message),
  });

  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>{isEdit ? "Edit feature" : "New feature"}</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div className="space-y-2">
            <Label>Name</Label>
            <Input value={name} onChange={(e) => setName(e.target.value)} maxLength={120} placeholder="e.g. Shopify Integration" />
          </div>
          <div className="space-y-2">
            <Label>Description</Label>
            <Textarea value={description} onChange={(e) => setDescription(e.target.value)} rows={2} maxLength={500} />
          </div>
          <div className="grid sm:grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label>Category</Label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full h-9 rounded-md border bg-background px-3 text-sm"
              >
                {FEATURE_CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
            <div className="space-y-2">
              <Label>Icon (Lucide name)</Label>
              <div className="flex items-center gap-2">
                <Input value={icon} onChange={(e) => setIcon(e.target.value)} maxLength={80} placeholder="e.g. ShoppingBag" />
                <FeatureIconPreview name={icon} />
              </div>
              <p className="text-xs text-muted-foreground">See lucide.dev/icons for names.</p>
            </div>
          </div>
          <div className="flex items-center justify-between rounded-lg border p-3">
            <div>
              <p className="text-sm font-medium">Active</p>
              <p className="text-xs text-muted-foreground">Inactive features are hidden from the pricing comparison.</p>
            </div>
            <Switch checked={isActive} onCheckedChange={setIsActive} />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button onClick={() => mut.mutate()} disabled={mut.isPending || !name.trim()}>
            {mut.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            {isEdit ? "Save changes" : "Create"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ============================================================
// Pricing Preview Tab
// ============================================================

function PricingPreviewTab() {
  const [interval, setIntervalState] = useState<"monthly" | "yearly">("monthly");
  const { data, isLoading } = useQuery({
    queryKey: ["admin-pricing-preview"],
    queryFn: async () => {
      const res = await fetch("/api/public/pricing");
      if (!res.ok) throw new Error("Failed to load pricing");
      return res.json() as Promise<{ plans: PricingPlan[]; masterFeatures: MasterFeatureType[]; planFeatures: PlanFeatureLink[] }>;
    },
  });

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div>
          <h2 className="font-semibold flex items-center gap-2"><Eye className="h-4 w-4" /> Pricing page preview</h2>
          <p className="text-sm text-muted-foreground">Live preview of what visitors see on the public pricing page. Updates as you edit plans and features.</p>
        </div>
        <div className="inline-flex rounded-full border bg-muted p-1">
          <button
            onClick={() => setIntervalState("monthly")}
            className={`px-4 py-1.5 text-sm rounded-full transition ${interval === "monthly" ? "bg-background shadow-sm font-medium" : "text-muted-foreground"}`}
          >
            Monthly
          </button>
          <button
            onClick={() => setIntervalState("yearly")}
            className={`px-4 py-1.5 text-sm rounded-full transition ${interval === "yearly" ? "bg-background shadow-sm font-medium" : "text-muted-foreground"}`}
          >
            Yearly
          </button>
        </div>
      </div>

      {isLoading ? (
        <div className="text-center py-8"><Loader2 className="h-5 w-5 animate-spin inline" /></div>
      ) : !data || data.plans.length === 0 ? (
        <div className="rounded-lg border p-8 text-center text-sm text-muted-foreground">
          No active plans yet. Create plans in the Plan library to preview.
        </div>
      ) : (
        <PricingComparisonTable
          plans={data.plans}
          masterFeatures={data.masterFeatures}
          planFeatures={data.planFeatures}
          interval={interval}
          cta={() => null}
        />
      )}
    </div>
  );
}

function ResellersAdminTab() {
  const qc = useQueryClient();
  const listFn = useServerFn(adminListResellers);
  const listPlans = useServerFn(adminListPlanTemplates);
  const updateFn = useServerFn(adminUpdateReseller);
  const { data, isLoading } = useQuery({
    queryKey: ["admin-resellers"],
    queryFn: () => listFn(),
  });
  const { data: planData } = useQuery({
    queryKey: ["admin-plan-templates"],
    queryFn: () => listPlans(),
  });
  const tiers = (planData?.templates ?? []).filter((t: any) => t.is_reseller);
  const [editing, setEditing] = useState<any | null>(null);
  const [customersFor, setCustomersFor] = useState<any | null>(null);

  const accounts = data?.accounts ?? [];

  return (
    <div className="space-y-4">
      <div className="rounded-lg border bg-primary/5 border-primary/30 p-4 flex items-start gap-3">
        <Sparkles className="h-5 w-5 text-primary mt-0.5" />
        <div>
          <p className="font-medium">Reseller program control</p>
          <p className="text-sm text-muted-foreground">Manage branding, subdomain, custom domain, package and license keys for every reseller.</p>
        </div>
      </div>

      <div className="rounded-lg border bg-card">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Reseller</TableHead>
              <TableHead>Package</TableHead>
              <TableHead>Customers</TableHead>
              <TableHead>Domain</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading && (
              <TableRow><TableCell colSpan={6} className="text-center py-8"><Loader2 className="h-4 w-4 animate-spin inline" /></TableCell></TableRow>
            )}
            {!isLoading && accounts.length === 0 && (
              <TableRow><TableCell colSpan={6} className="text-center text-muted-foreground py-8">No active resellers yet.</TableCell></TableRow>
            )}
            {accounts.map((a: any) => {
              const tier = tiers.find((t: any) => t.id === a.plan_template_id);
              const baseHost = typeof window !== "undefined" ? window.location.hostname.replace(/^[^.]+\./, "") : "";
              const visitUrl = a.custom_domain
                ? `https://${a.custom_domain}`
                : a.subdomain && baseHost
                  ? `https://${a.subdomain}.${baseHost}`
                  : null;
              return (
                <TableRow key={a.workspace_id}>
                  <TableCell>
                    {visitUrl ? (
                      <a href={visitUrl} target="_blank" rel="noreferrer" className="font-medium hover:underline inline-flex items-center gap-1">
                        {a.brand_name}<ExternalLink className="h-3 w-3 opacity-60" />
                      </a>
                    ) : (
                      <div className="font-medium">{a.brand_name}</div>
                    )}
                    <div className="text-xs text-muted-foreground">{a.workspace?.name} · {a.support_email || "no email"}</div>
                  </TableCell>
                  <TableCell>
                    <Badge variant="outline">{tier?.name || "Custom"}</Badge>
                    <div className="text-xs text-muted-foreground mt-0.5">{a.commission_pct}% commission</div>
                  </TableCell>
                  <TableCell>
                    <span className="font-medium">{a.customer_count.active}</span>
                    <span className="text-xs text-muted-foreground"> / {a.max_customers === -1 ? "∞" : a.max_customers}</span>
                  </TableCell>
                  <TableCell className="text-xs">
                    {a.subdomain && baseHost && (
                      <a href={`https://${a.subdomain}.${baseHost}`} target="_blank" rel="noreferrer" className="font-mono hover:underline">{a.subdomain}.{baseHost}</a>
                    )}
                    {a.subdomain && !baseHost && <div className="font-mono">{a.subdomain}.*</div>}
                    {a.custom_domain && (
                      <a href={`https://${a.custom_domain}`} target="_blank" rel="noreferrer" className="font-mono text-primary hover:underline">{a.custom_domain}</a>
                    )}
                    {!a.subdomain && !a.custom_domain && <span className="text-muted-foreground">—</span>}
                  </TableCell>
                  <TableCell><Badge variant={a.status === "active" ? "default" : "secondary"}>{a.status}</Badge></TableCell>
                  <TableCell className="text-right">
                    {visitUrl && (
                      <Button asChild size="sm" variant="ghost">
                        <a href={visitUrl} target="_blank" rel="noreferrer"><ExternalLink className="h-3.5 w-3.5 mr-1" />Visit</a>
                      </Button>
                    )}
                    <Button size="sm" variant="ghost" onClick={() => setCustomersFor(a)}><KeyRound className="h-3.5 w-3.5 mr-1" />Licenses</Button>
                    <Button size="sm" variant="outline" onClick={() => setEditing(a)}><Pencil className="h-3.5 w-3.5 mr-1" />Edit</Button>
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </div>

      {editing && (
        <ResellerEditDialog
          account={editing}
          tiers={tiers}
          onClose={() => setEditing(null)}
          onSave={async (patch) => {
            try {
              const clean: any = { ...patch };
              if (!clean.plan_template_id) clean.plan_template_id = null;
              if (!clean.subdomain) clean.subdomain = null;
              if (!clean.custom_domain) clean.custom_domain = null;
              if (!clean.support_email) clean.support_email = null;
              await updateFn({ data: { workspace_id: editing.workspace_id, ...clean } });
              toast.success("Reseller updated");
              qc.invalidateQueries({ queryKey: ["admin-resellers"] });
              setEditing(null);
            } catch (e: any) { toast.error(e.message); }
          }}

        />
      )}

      {customersFor && (
        <ResellerLicensesDialog reseller={customersFor} onClose={() => setCustomersFor(null)} />
      )}
    </div>
  );
}

function ResellerEditDialog({ account, tiers, onClose, onSave }: { account: any; tiers: any[]; onClose: () => void; onSave: (p: any) => void }) {
  const [form, setForm] = useState({
    brand_name: account.brand_name || "",
    support_email: account.support_email || "",
    primary_color: account.primary_color || "#3b82f6",
    subdomain: account.subdomain || "",
    custom_domain: account.custom_domain || "",
    plan_template_id: account.plan_template_id || "",
    commission_pct: Number(account.commission_pct) || 20,
    max_customers: Number(account.max_customers) || 10,
    allow_custom_domain: !!account.allow_custom_domain,
    white_label: !!account.white_label,
    status: account.status || "active",
    features: (account.features as Record<string, boolean>) || {},
  });

  function toggleFeature(k: string, v: boolean) {
    setForm({ ...form, features: { ...form.features, [k]: v } });
  }

  function applyTier(id: string) {
    const t = tiers.find((x) => x.id === id);
    if (!t) return setForm({ ...form, plan_template_id: id });
    const limits = (t.limits as any) || {};
    setForm({
      ...form,
      plan_template_id: id,
      max_customers: Number(limits.reseller_max_customers ?? form.max_customers),
      features: { ...(t.features as Record<string, boolean>), ...form.features },
    });
  }

  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-3xl max-h-[85vh] overflow-y-auto">
        <DialogHeader><DialogTitle>Edit reseller — {account.brand_name}</DialogTitle></DialogHeader>
        <div className="grid gap-4">
          <div className="grid grid-cols-2 gap-3">
            <div><Label>Brand name</Label><Input value={form.brand_name} onChange={(e) => setForm({ ...form, brand_name: e.target.value })} /></div>
            <div><Label>Support email</Label><Input value={form.support_email} onChange={(e) => setForm({ ...form, support_email: e.target.value })} /></div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label>Subdomain</Label>
              <Input value={form.subdomain} onChange={(e) => setForm({ ...form, subdomain: e.target.value.toLowerCase().replace(/[^a-z0-9-]/g, "") })} placeholder="acme" />
              <p className="text-xs text-muted-foreground mt-1">Will be available at <code>{form.subdomain || "subdomain"}.yourapp.com</code>.</p>
            </div>
            <div>
              <Label>Custom domain</Label>
              <Input value={form.custom_domain} onChange={(e) => setForm({ ...form, custom_domain: e.target.value })} placeholder="app.yourbrand.com" disabled={!form.allow_custom_domain} />
              <div className="flex items-center gap-2 mt-1">
                <Switch checked={form.allow_custom_domain} onCheckedChange={(c) => setForm({ ...form, allow_custom_domain: c })} />
                <span className="text-xs text-muted-foreground">Allow custom domain</span>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div className="col-span-2">
              <Label>Reseller package</Label>
              <select className="w-full border rounded-md h-10 px-2 bg-background" value={form.plan_template_id} onChange={(e) => applyTier(e.target.value)}>
                <option value="">— Custom —</option>
                {tiers.map((t: any) => (
                  <option key={t.id} value={t.id}>{t.name} · {t.price_monthly} {t.currency}/mo</option>
                ))}
              </select>
            </div>
            <div>
              <Label>Commission %</Label>
              <Input type="number" min={0} max={100} value={form.commission_pct} onChange={(e) => setForm({ ...form, commission_pct: Number(e.target.value) })} />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label>Max customers</Label>
              <Input type="number" min={-1} value={form.max_customers} onChange={(e) => setForm({ ...form, max_customers: Number(e.target.value) })} />
              <p className="text-xs text-muted-foreground mt-1">Use -1 for unlimited.</p>
            </div>
            <div>
              <Label>Status</Label>
              <select className="w-full border rounded-md h-10 px-2 bg-background" value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value as any })}>
                <option value="active">Active</option>
                <option value="suspended">Suspended</option>
              </select>
            </div>
          </div>

          <div className="rounded-lg border p-3">
            <p className="text-sm font-medium mb-2">Features available to this reseller</p>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-1 max-h-56 overflow-y-auto">
              {FEATURE_CATALOG.map((f) => (
                <label key={f.key} className="flex items-center gap-2 text-sm py-1">
                  <Checkbox checked={!!form.features[f.key]} onCheckedChange={(c) => toggleFeature(f.key, !!c)} />
                  <span className="truncate">{f.label}</span>
                </label>
              ))}
            </div>
          </div>

          <div className="flex items-center justify-between rounded-lg border p-3">
            <div>
              <Label>White-label</Label>
              <p className="text-xs text-muted-foreground">Hide platform branding from end customers.</p>
            </div>
            <Switch checked={form.white_label} onCheckedChange={(c) => setForm({ ...form, white_label: c })} />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button onClick={() => onSave(form)}>Save changes</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function ResellerLicensesDialog({ reseller, onClose }: { reseller: any; onClose: () => void }) {
  const qc = useQueryClient();
  const regenFn = useServerFn(regenerateCustomerLicense);
  const statusFn = useServerFn(setCustomerLicenseStatus);
  const { data: customers = [], isLoading } = useQuery({
    queryKey: ["admin-reseller-customers", reseller.workspace_id],
    queryFn: async () => {
      const { data } = await supabase
        .from("reseller_customers")
        .select("*")
        .eq("reseller_workspace_id", reseller.workspace_id)
        .order("created_at", { ascending: false });
      return data ?? [];
    },
  });

  async function regen(id: string) {
    if (!confirm("Regenerate license key?")) return;
    try {
      await regenFn({ data: { customer_id: id } });
      toast.success("License key regenerated");
      qc.invalidateQueries({ queryKey: ["admin-reseller-customers", reseller.workspace_id] });
    } catch (e: any) { toast.error(e.message); }
  }
  async function setStatus(id: string, status: "active" | "revoked") {
    try {
      await statusFn({ data: { customer_id: id, status } });
      toast.success("License updated");
      qc.invalidateQueries({ queryKey: ["admin-reseller-customers", reseller.workspace_id] });
    } catch (e: any) { toast.error(e.message); }
  }

  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-3xl max-h-[85vh] overflow-y-auto">
        <DialogHeader><DialogTitle>Licenses — {reseller.brand_name}</DialogTitle></DialogHeader>
        {isLoading ? <div className="text-center py-6"><Loader2 className="h-4 w-4 animate-spin inline" /></div> : (
          <div className="divide-y">
            {customers.length === 0 && <p className="text-sm text-muted-foreground py-6 text-center">This reseller has no customers yet.</p>}
            {customers.map((c: any) => (
              <div key={c.id} className="py-3 space-y-1">
                <div className="flex items-center gap-3">
                  <div className="flex-1 min-w-0">
                    <p className="font-medium truncate">{c.customer_name}</p>
                    <p className="text-xs text-muted-foreground truncate">{c.customer_email || c.customer_phone || "—"}</p>
                  </div>
                  <Badge variant={c.license_status === "active" ? "default" : c.license_status === "revoked" ? "destructive" : "secondary"}>
                    {c.license_status || "active"}
                  </Badge>
                </div>
                <div className="flex items-center gap-2 rounded-md bg-muted/40 border px-3 py-2">
                  <KeyRound className="h-3.5 w-3.5 text-muted-foreground" />
                  <code className="text-xs font-mono flex-1 truncate">{c.license_key || "—"}</code>
                  <Button size="sm" variant="ghost" onClick={() => { navigator.clipboard.writeText(c.license_key || ""); toast.success("Copied"); }}>
                    Copy
                  </Button>
                  <Button size="sm" variant="ghost" onClick={() => regen(c.id)}>Regenerate</Button>
                  <Button size="sm" variant="ghost" onClick={() => setStatus(c.id, c.license_status === "revoked" ? "active" : "revoked")}>
                    {c.license_status === "revoked" ? "Activate" : "Revoke"}
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}
        <DialogFooter><Button variant="outline" onClick={onClose}>Close</Button></DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
