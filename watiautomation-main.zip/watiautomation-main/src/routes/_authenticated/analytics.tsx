import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useMemo } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useWorkspace } from "@/lib/workspace-context";
import { Card } from "@/components/ui/card";
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, PieChart, Pie, Cell, Legend } from "recharts";
import { BarChart3, MessageCircle, ShoppingBag, Users, TrendingUp } from "lucide-react";
import { useCurrency } from "@/lib/currency";

export const Route = createFileRoute("/_authenticated/analytics")({
  component: Analytics,
  head: () => ({ meta: [{ title: "Analytics — Slice" }] }),
});

const COLORS = ["#3b82f6", "#10b981", "#f59e0b", "#ef4444", "#8b5cf6", "#06b6d4"];

function Analytics() {
  const { currentWorkspaceId } = useWorkspace();
  const { format } = useCurrency();


  const { data: campaigns = [] } = useQuery({
    queryKey: ["analytics-campaigns", currentWorkspaceId],
    enabled: !!currentWorkspaceId,
    queryFn: async () => {
      const { data } = await supabase.from("campaigns")
        .select("name, sent_count, failed_count, delivered_count, read_count, total_count, created_at")
        .eq("workspace_id", currentWorkspaceId!).order("created_at", { ascending: false }).limit(20);
      return data ?? [];
    },
  });

  const { data: orders = [] } = useQuery({
    queryKey: ["analytics-orders", currentWorkspaceId],
    enabled: !!currentWorkspaceId,
    queryFn: async () => {
      const { data } = await supabase.from("ecom_orders").select("total, placed_at, payment_status, cod_status")
        .eq("workspace_id", currentWorkspaceId!).order("placed_at", { ascending: false }).limit(500);
      return data ?? [];
    },
  });

  const { data: carts = [] } = useQuery({
    queryKey: ["analytics-carts", currentWorkspaceId],
    enabled: !!currentWorkspaceId,
    queryFn: async () => {
      const { data } = await supabase.from("abandoned_carts").select("status, recovered_revenue, total")
        .eq("workspace_id", currentWorkspaceId!);
      return data ?? [];
    },
  });

  const { data: contactsCount = 0 } = useQuery({
    queryKey: ["analytics-contacts-count", currentWorkspaceId],
    enabled: !!currentWorkspaceId,
    queryFn: async () => {
      const { count } = await supabase.from("contacts").select("id", { count: "exact", head: true })
        .eq("workspace_id", currentWorkspaceId!);
      return count ?? 0;
    },
  });

  const messagesAgg = useMemo(() => {
    const sent = campaigns.reduce((s, c: any) => s + (c.sent_count || 0), 0);
    const delivered = campaigns.reduce((s, c: any) => s + (c.delivered_count || 0), 0);
    const read = campaigns.reduce((s, c: any) => s + (c.read_count || 0), 0);
    const failed = campaigns.reduce((s, c: any) => s + (c.failed_count || 0), 0);
    return { sent, delivered, read, failed,
      deliveredPct: sent ? Math.round((delivered / sent) * 100) : 0,
      readPct: sent ? Math.round((read / sent) * 100) : 0,
    };
  }, [campaigns]);

  const revenueTrend = useMemo(() => {
    const map = new Map<string, number>();
    for (let i = 13; i >= 0; i--) {
      const d = new Date(); d.setDate(d.getDate() - i);
      map.set(d.toISOString().slice(0, 10), 0);
    }
    orders.forEach((o: any) => {
      const key = (o.placed_at as string).slice(0, 10);
      if (map.has(key)) map.set(key, (map.get(key) || 0) + Number(o.total));
    });
    return Array.from(map.entries()).map(([date, value]) => ({
      date: date.slice(5), value,
    }));
  }, [orders]);

  const campaignChart = useMemo(() =>
    campaigns.slice(0, 8).reverse().map((c: any) => ({
      name: c.name.length > 12 ? c.name.slice(0, 12) + "…" : c.name,
      Sent: c.sent_count, Failed: c.failed_count, Read: c.read_count,
    })), [campaigns]);

  const cartRevenue = carts.reduce((s: number, c: any) => s + Number(c.recovered_revenue || 0), 0);
  const totalRevenue = orders.reduce((s: number, o: any) => s + Number(o.total || 0), 0);

  const codPie = useMemo(() => {
    const conf = orders.filter((o: any) => o.cod_status === "confirmed").length;
    const can = orders.filter((o: any) => o.cod_status === "cancelled").length;
    const pen = orders.filter((o: any) => o.cod_status === "pending").length;
    return [
      { name: "Confirmed", value: conf },
      { name: "Cancelled", value: can },
      { name: "Pending", value: pen },
    ].filter((x) => x.value > 0);
  }, [orders]);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-3xl font-bold flex items-center gap-2">
          <BarChart3 className="h-7 w-7" />Analytics
        </h1>
        <p className="text-muted-foreground">Revenue, campaigns, and customer growth</p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Kpi icon={MessageCircle} label="Messages sent" value={messagesAgg.sent.toLocaleString()} sub={`${messagesAgg.deliveredPct}% delivered`} />
        <Kpi icon={TrendingUp} label="Read rate" value={`${messagesAgg.readPct}%`} sub={`${messagesAgg.read.toLocaleString()} reads`} />
        <Kpi icon={ShoppingBag} label="Order revenue" value={format(totalRevenue)} sub={`${orders.length} orders`} />
        <Kpi icon={Users} label="Contacts" value={contactsCount.toLocaleString()} sub={`${format(cartRevenue)} cart recovered`} />
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card className="p-5">
          <p className="font-semibold mb-3">Revenue trend (last 14 days)</p>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={revenueTrend}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                <XAxis dataKey="date" className="text-xs" />
                <YAxis className="text-xs" />
                <Tooltip />
                <Line type="monotone" dataKey="value" stroke="#3b82f6" strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </Card>

        <Card className="p-5">
          <p className="font-semibold mb-3">Campaign performance</p>
          <div className="h-64">
            {campaignChart.length === 0 ? (
              <div className="h-full grid place-items-center text-sm text-muted-foreground">No campaigns yet</div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={campaignChart}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                  <XAxis dataKey="name" className="text-xs" />
                  <YAxis className="text-xs" />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="Sent" fill="#3b82f6" />
                  <Bar dataKey="Read" fill="#10b981" />
                  <Bar dataKey="Failed" fill="#ef4444" />
                </BarChart>
              </ResponsiveContainer>
            )}
          </div>
        </Card>

        <Card className="p-5">
          <p className="font-semibold mb-3">COD verification breakdown</p>
          <div className="h-64">
            {codPie.length === 0 ? (
              <div className="h-full grid place-items-center text-sm text-muted-foreground">No COD orders</div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={codPie} dataKey="value" nameKey="name" innerRadius={50} outerRadius={90} label>
                    {codPie.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                  </Pie>
                  <Tooltip />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            )}
          </div>
        </Card>

        <Card className="p-5">
          <p className="font-semibold mb-3">Delivery funnel</p>
          <div className="space-y-3">
            <Funnel label="Sent" value={messagesAgg.sent} max={messagesAgg.sent} color="#3b82f6" />
            <Funnel label="Delivered" value={messagesAgg.delivered} max={messagesAgg.sent} color="#10b981" />
            <Funnel label="Read" value={messagesAgg.read} max={messagesAgg.sent} color="#8b5cf6" />
            <Funnel label="Failed" value={messagesAgg.failed} max={messagesAgg.sent} color="#ef4444" />
          </div>
        </Card>
      </div>
    </div>
  );
}

function Kpi({ icon: Icon, label, value, sub }: any) {
  return (
    <Card className="p-5">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm text-muted-foreground">{label}</p>
          <p className="mt-1 font-display text-2xl font-bold">{value}</p>
          {sub && <p className="text-xs text-muted-foreground mt-0.5">{sub}</p>}
        </div>
        <div className="grid h-10 w-10 place-items-center rounded-lg bg-primary/10 text-primary">
          <Icon className="h-5 w-5" />
        </div>
      </div>
    </Card>
  );
}

function Funnel({ label, value, max, color }: { label: string; value: number; max: number; color: string }) {
  const pct = max > 0 ? Math.round((value / max) * 100) : 0;
  return (
    <div>
      <div className="flex justify-between text-xs mb-1">
        <span className="font-medium">{label}</span>
        <span className="text-muted-foreground">{value.toLocaleString()} ({pct}%)</span>
      </div>
      <div className="h-2 rounded-full bg-muted overflow-hidden">
        <div className="h-full rounded-full" style={{ width: `${pct}%`, background: color }} />
      </div>
    </div>
  );
}
