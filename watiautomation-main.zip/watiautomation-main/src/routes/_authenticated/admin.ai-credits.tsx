import { createFileRoute, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from "@/components/ui/table";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Coins, Search, Plus, Minus, RotateCcw, Wallet, ArrowLeft } from "lucide-react";
import {
  adminListAiCreditAccounts,
  adminAdjustAiCredits,
  adminSetLowThreshold,
  getAiCreditLedger,
} from "@/lib/ai-credits.functions";
import { AdminAiCreditPackages } from "@/components/AdminAiCreditPackages";

export const Route = createFileRoute("/_authenticated/admin/ai-credits")({
  component: AdminAiCreditsPage,
  head: () => ({ meta: [{ title: "AI Credits — Super Admin — Slice" }] }),
  errorComponent: ({ error }) => (
    <div className="p-6 text-sm text-destructive">Failed to load: {error.message}</div>
  ),
  notFoundComponent: () => <div className="p-6 text-sm">Not found.</div>,
});

type Account = {
  workspace_id: string;
  workspace_name: string;
  workspace_slug: string;
  balance: number;
  low_threshold: number;
  lifetime_added: number;
  lifetime_used: number;
  updated_at: string | null;
};

function AdminAiCreditsPage() {
  const list = useServerFn(adminListAiCreditAccounts);
  const { data: accounts, refetch, isLoading } = useQuery({
    queryKey: ["admin-ai-credit-accounts"],
    queryFn: () => list(),
  });

  const [q, setQ] = useState("");
  const filtered = useMemo(() => {
    const rows = (accounts ?? []) as Account[];
    if (!q.trim()) return rows;
    const needle = q.toLowerCase();
    return rows.filter((r) =>
      r.workspace_name?.toLowerCase().includes(needle) ||
      r.workspace_slug?.toLowerCase().includes(needle) ||
      r.workspace_id.toLowerCase().includes(needle),
    );
  }, [accounts, q]);

  const [selected, setSelected] = useState<Account | null>(null);

  const totalBalance = (accounts ?? []).reduce((n: number, r: any) => n + Number(r.balance || 0), 0);
  const totalUsed = (accounts ?? []).reduce((n: number, r: any) => n + Number(r.lifetime_used || 0), 0);

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2">
        <Link to="/admin"><Button variant="ghost" size="sm"><ArrowLeft className="h-4 w-4 mr-1" /> Back</Button></Link>
      </div>
      <div>
        <h1 className="font-display text-3xl font-bold flex items-center gap-2">
          <Coins className="h-7 w-7 text-primary" /> AI Credit Management
        </h1>
        <p className="text-muted-foreground">Manage per-workspace AI credit balances, adjustments and recharge history.</p>
      </div>

      <div className="grid gap-4 sm:grid-cols-3">
        <Card className="p-5">
          <p className="text-sm text-muted-foreground">Workspaces</p>
          <p className="mt-1 font-display text-3xl font-bold">{accounts?.length ?? 0}</p>
        </Card>
        <Card className="p-5">
          <p className="text-sm text-muted-foreground">Total balance</p>
          <p className="mt-1 font-display text-3xl font-bold tabular-nums">{totalBalance.toLocaleString()}</p>
        </Card>
        <Card className="p-5">
          <p className="text-sm text-muted-foreground">Lifetime credits used</p>
          <p className="mt-1 font-display text-3xl font-bold tabular-nums">{totalUsed.toLocaleString()}</p>
        </Card>
      </div>

      <div className="flex items-center gap-2">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input placeholder="Search workspaces…" value={q} onChange={(e) => setQ(e.target.value)} className="pl-8" />
        </div>
      </div>

      <Card>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Workspace</TableHead>
              <TableHead className="text-right">Balance</TableHead>
              <TableHead className="text-right">Used</TableHead>
              <TableHead className="text-right">Added</TableHead>
              <TableHead>Warn under</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              <TableRow><TableCell colSpan={6} className="text-center text-sm text-muted-foreground p-6">Loading…</TableCell></TableRow>
            ) : filtered.length === 0 ? (
              <TableRow><TableCell colSpan={6} className="text-center text-sm text-muted-foreground p-6">No workspaces</TableCell></TableRow>
            ) : (
              filtered.map((r) => (
                <TableRow key={r.workspace_id}>
                  <TableCell>
                    <div className="font-medium">{r.workspace_name}</div>
                    <div className="text-[11px] text-muted-foreground">{r.workspace_slug}</div>
                  </TableCell>
                  <TableCell className="text-right tabular-nums">
                    <span className={r.balance <= 0 ? "text-destructive font-medium" : r.balance < r.low_threshold ? "text-warning font-medium" : "font-medium"}>
                      {r.balance.toLocaleString()}
                    </span>
                    {r.balance <= 0 && <Badge variant="destructive" className="ml-2 text-[10px]">Exhausted</Badge>}
                  </TableCell>
                  <TableCell className="text-right tabular-nums text-muted-foreground">{r.lifetime_used.toLocaleString()}</TableCell>
                  <TableCell className="text-right tabular-nums text-muted-foreground">{r.lifetime_added.toLocaleString()}</TableCell>
                  <TableCell className="tabular-nums text-muted-foreground">{r.low_threshold.toLocaleString()}</TableCell>
                  <TableCell className="text-right">
                    <Button size="sm" variant="outline" onClick={() => setSelected(r)}>Manage</Button>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </Card>
      <AdminAiCreditPackages />


      {selected && (
        <ManageDialog
          account={selected}
          onClose={() => setSelected(null)}
          onChanged={() => { refetch(); }}
        />
      )}
    </div>
  );
}

function ManageDialog({ account, onClose, onChanged }: { account: Account; onClose: () => void; onChanged: () => void }) {
  const qc = useQueryClient();
  const adjust = useServerFn(adminAdjustAiCredits);
  const setThreshold = useServerFn(adminSetLowThreshold);
  const ledgerFn = useServerFn(getAiCreditLedger);

  const [entryType, setEntryType] = useState<"admin_add" | "admin_deduct" | "admin_reset" | "recharge">("recharge");
  const [amount, setAmount] = useState<string>("1000");
  const [notes, setNotes] = useState<string>("");
  const [lowThreshold, setLowThreshold] = useState<string>(String(account.low_threshold));

  const { data: ledger } = useQuery({
    queryKey: ["admin-ai-credit-ledger", account.workspace_id],
    queryFn: () => ledgerFn({ data: { workspace_id: account.workspace_id, limit: 50 } }),
  });

  const mutation = useMutation({
    mutationFn: async () => {
      const n = Math.max(1, parseInt(amount || "0", 10) || 1);
      const res = await adjust({ data: { workspace_id: account.workspace_id, amount: entryType === "admin_reset" ? 1 : n, entry_type: entryType, notes: notes || undefined } });
      return res;
    },
    onSuccess: () => {
      toast.success("Credits updated");
      setNotes("");
      onChanged();
      qc.invalidateQueries({ queryKey: ["admin-ai-credit-ledger", account.workspace_id] });
    },
    onError: (e: any) => toast.error(e.message || "Failed"),
  });

  const thresholdMutation = useMutation({
    mutationFn: async () => setThreshold({ data: { workspace_id: account.workspace_id, low_threshold: Math.max(0, parseInt(lowThreshold || "0", 10) || 0) } }),
    onSuccess: () => { toast.success("Threshold updated"); onChanged(); },
    onError: (e: any) => toast.error(e.message || "Failed"),
  });

  return (
    <Dialog open onOpenChange={(v) => { if (!v) onClose(); }}>
      <DialogContent className="max-w-3xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Wallet className="h-5 w-5" /> {account.workspace_name}
          </DialogTitle>
        </DialogHeader>

        <div className="grid gap-4 sm:grid-cols-3 text-sm">
          <Card className="p-3"><p className="text-xs text-muted-foreground">Balance</p><p className="font-bold text-xl tabular-nums">{account.balance.toLocaleString()}</p></Card>
          <Card className="p-3"><p className="text-xs text-muted-foreground">Lifetime used</p><p className="font-bold text-xl tabular-nums">{account.lifetime_used.toLocaleString()}</p></Card>
          <Card className="p-3"><p className="text-xs text-muted-foreground">Lifetime added</p><p className="font-bold text-xl tabular-nums">{account.lifetime_added.toLocaleString()}</p></Card>
        </div>

        <Tabs defaultValue="adjust" className="mt-2">
          <TabsList>
            <TabsTrigger value="adjust">Adjust</TabsTrigger>
            <TabsTrigger value="history">History</TabsTrigger>
            <TabsTrigger value="settings">Settings</TabsTrigger>
          </TabsList>

          <TabsContent value="adjust" className="space-y-3 pt-3">
            <div className="grid gap-3 sm:grid-cols-2">
              <div>
                <Label>Action</Label>
                <Select value={entryType} onValueChange={(v: any) => setEntryType(v)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="recharge">Recharge (add)</SelectItem>
                    <SelectItem value="admin_add">Admin add</SelectItem>
                    <SelectItem value="admin_deduct">Admin deduct</SelectItem>
                    <SelectItem value="admin_reset">Reset to zero</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              {entryType !== "admin_reset" && (
                <div>
                  <Label>Amount</Label>
                  <Input type="number" min={1} value={amount} onChange={(e) => setAmount(e.target.value)} />
                </div>
              )}
            </div>
            <div>
              <Label>Notes (optional)</Label>
              <Textarea value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Reason, invoice reference, etc." rows={2} />
            </div>
            <div className="flex justify-end">
              <Button onClick={() => mutation.mutate()} disabled={mutation.isPending}>
                {entryType === "admin_reset" ? <RotateCcw className="h-4 w-4 mr-2" /> : entryType === "admin_deduct" ? <Minus className="h-4 w-4 mr-2" /> : <Plus className="h-4 w-4 mr-2" />}
                Apply
              </Button>
            </div>
          </TabsContent>

          <TabsContent value="history" className="pt-3">
            <div className="max-h-80 overflow-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Date</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Feature / Model</TableHead>
                    <TableHead className="text-right">Delta</TableHead>
                    <TableHead className="text-right">Balance</TableHead>
                    <TableHead>Notes</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {(ledger ?? []).length === 0 ? (
                    <TableRow><TableCell colSpan={6} className="text-center text-sm text-muted-foreground p-4">No activity yet</TableCell></TableRow>
                  ) : (
                    (ledger ?? []).map((row: any) => (
                      <TableRow key={row.id}>
                        <TableCell className="text-xs">{new Date(row.created_at).toLocaleString()}</TableCell>
                        <TableCell><Badge variant="outline" className="text-[10px]">{row.entry_type}</Badge></TableCell>
                        <TableCell className="text-xs">{row.feature ? `${row.feature}${row.model ? ` · ${row.model}` : ""}` : "—"}</TableCell>
                        <TableCell className={`text-right tabular-nums ${Number(row.delta) < 0 ? "text-destructive" : Number(row.delta) > 0 ? "text-success" : ""}`}>
                          {Number(row.delta) > 0 ? "+" : ""}{Number(row.delta).toLocaleString()}
                        </TableCell>
                        <TableCell className="text-right tabular-nums">{Number(row.balance_after).toLocaleString()}</TableCell>
                        <TableCell className="text-xs text-muted-foreground truncate max-w-[180px]">{row.notes || ""}</TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          </TabsContent>

          <TabsContent value="settings" className="space-y-3 pt-3">
            <div>
              <Label>Low-balance warning threshold</Label>
              <Input type="number" min={0} value={lowThreshold} onChange={(e) => setLowThreshold(e.target.value)} />
              <p className="text-xs text-muted-foreground mt-1">Workspaces see a "Low" warning when balance drops below this value.</p>
            </div>
            <div className="flex justify-end">
              <Button onClick={() => thresholdMutation.mutate()} disabled={thresholdMutation.isPending}>Save</Button>
            </div>
          </TabsContent>
        </Tabs>

        <DialogFooter>
          <Button variant="ghost" onClick={onClose}>Close</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
