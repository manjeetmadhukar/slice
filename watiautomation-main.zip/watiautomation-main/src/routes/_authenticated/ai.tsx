import { createFileRoute, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Sparkles, TrendingUp, Flame, Snowflake, Thermometer, ArrowRight } from "lucide-react";
import { useWorkspace } from "@/lib/workspace-context";
import { getAiDashboardStats } from "@/lib/ai-insights.functions";
import { AiUsageCostNotice } from "@/components/AiUsageCostNotice";


export const Route = createFileRoute("/_authenticated/ai")({
  component: AiDashboard,
  head: () => ({ meta: [{ title: "AI Insights — Slice" }] }),
  errorComponent: ({ error }) => (
    <div className="p-6 text-sm text-destructive">Failed to load AI dashboard: {error.message}</div>
  ),
  notFoundComponent: () => <div className="p-6 text-sm">Not found.</div>,
});

function AiDashboard() {
  const { currentWorkspaceId } = useWorkspace();
  const fn = useServerFn(getAiDashboardStats);
  const { data, isLoading } = useQuery({
    queryKey: ["ai-dashboard", currentWorkspaceId],
    enabled: !!currentWorkspaceId,
    queryFn: () => fn({ data: { workspace_id: currentWorkspaceId! } }),
  });

  if (isLoading) return <div className="p-6 text-sm text-muted-foreground">Loading AI insights…</div>;

  const sentimentEntries = Object.entries(data?.sentiment ?? {}).sort((a, b) => b[1] - a[1]);
  const intentEntries = Object.entries(data?.intent ?? {}).sort((a, b) => b[1] - a[1]).slice(0, 6);

  return (
    <div className="space-y-8">
      <div>
        <h1 className="font-display text-3xl font-bold flex items-center gap-2">
          <Sparkles className="h-7 w-7 text-primary" /> AI Insights
        </h1>
        <p className="text-muted-foreground">Message analysis & lead quality over the last 30 days</p>
      </div>

      <AiUsageCostNotice compact />


      <div className="grid gap-4 sm:grid-cols-4">
        <StatCard label="Messages analyzed" value={data?.total ?? 0} icon={Sparkles} />
        <StatCard label="Avg. conversion likelihood" value={`${data?.avgConversion ?? 0}%`} icon={TrendingUp} />
        <StatCard label="Hot leads" value={data?.buckets.hot ?? 0} icon={Flame} tone="text-destructive" />
        <StatCard label="Warm leads" value={data?.buckets.warm ?? 0} icon={Thermometer} tone="text-warning" />
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <Card className="p-5">
          <h2 className="font-display text-lg font-semibold mb-4">Sentiment</h2>
          <BreakdownBars entries={sentimentEntries} colorize={sentimentColor} />
        </Card>
        <Card className="p-5">
          <h2 className="font-display text-lg font-semibold mb-4">Top intents</h2>
          <BreakdownBars entries={intentEntries} />
        </Card>
      </div>

      <div>
        <h2 className="font-display text-xl font-semibold mb-4">Lead quality</h2>
        <Card className="divide-y">
          {(data?.contacts ?? []).length === 0 ? (
            <div className="p-8 text-center text-sm text-muted-foreground">
              No AI-analyzed leads yet. Messages flowing through the inbox will appear here once analyzed.
            </div>
          ) : (
            (data?.contacts ?? []).map((c: any) => {
              const conf = Number(c.ai_confidence ?? 0);
              const bucket = conf >= 0.7 ? "hot" : conf >= 0.4 ? "warm" : "cold";
              return (
                <Link
                  key={c.id}
                  to="/ai/$contactId"
                  params={{ contactId: c.id }}
                  className="flex items-center justify-between p-4 hover:bg-muted/40 transition"
                >
                  <div className="min-w-0">
                    <p className="font-medium truncate">{c.name || c.phone}</p>
                    <p className="text-xs text-muted-foreground truncate">
                      {c.ai_last_intent ? `Intent: ${c.ai_last_intent}` : "No intent yet"} · {c.phone}
                    </p>
                  </div>
                  <div className="flex items-center gap-3 shrink-0">
                    <BucketBadge bucket={bucket} />
                    <span className="text-xs text-muted-foreground tabular-nums">
                      {Math.round(conf * 100)}%
                    </span>
                    <ArrowRight className="h-4 w-4 text-muted-foreground" />
                  </div>
                </Link>
              );
            })
          )}
        </Card>
      </div>
    </div>
  );
}

function StatCard({ icon: Icon, label, value, tone }: any) {
  return (
    <Card className="p-5">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm text-muted-foreground">{label}</p>
          <p className="mt-1 font-display text-3xl font-bold">{value}</p>
        </div>
        <Icon className={`h-6 w-6 ${tone ?? "text-primary"}`} />
      </div>
    </Card>
  );
}

function BreakdownBars({
  entries,
  colorize,
}: {
  entries: [string, number][];
  colorize?: (key: string) => string;
}) {
  const max = Math.max(1, ...entries.map(([, v]) => v));
  if (entries.length === 0) {
    return <p className="text-sm text-muted-foreground">No data yet.</p>;
  }
  return (
    <div className="space-y-2">
      {entries.map(([k, v]) => (
        <div key={k} className="space-y-1">
          <div className="flex items-center justify-between text-xs">
            <span className="capitalize">{k}</span>
            <span className="tabular-nums text-muted-foreground">{v}</span>
          </div>
          <div className="h-2 rounded-full bg-secondary overflow-hidden">
            <div
              className={`h-full ${colorize ? colorize(k) : "bg-primary"}`}
              style={{ width: `${(v / max) * 100}%` }}
            />
          </div>
        </div>
      ))}
    </div>
  );
}

function sentimentColor(k: string) {
  if (k === "positive") return "bg-success";
  if (k === "negative") return "bg-destructive";
  if (k === "neutral") return "bg-muted-foreground/60";
  return "bg-primary";
}

function BucketBadge({ bucket }: { bucket: "hot" | "warm" | "cold" }) {
  if (bucket === "hot")
    return (
      <Badge className="bg-destructive/15 text-destructive border-destructive/30">
        <Flame className="h-3 w-3 mr-1" /> Hot
      </Badge>
    );
  if (bucket === "warm")
    return (
      <Badge className="bg-warning/15 text-warning border-warning/30">
        <Thermometer className="h-3 w-3 mr-1" /> Warm
      </Badge>
    );
  return (
    <Badge variant="outline">
      <Snowflake className="h-3 w-3 mr-1" /> Cold
    </Badge>
  );
}
