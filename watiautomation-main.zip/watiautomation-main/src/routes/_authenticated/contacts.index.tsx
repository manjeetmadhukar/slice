import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useMemo, useState } from "react";
import { z } from "zod";
import { supabase } from "@/integrations/supabase/client";
import { useWorkspace } from "@/lib/workspace-context";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useServerFn } from "@tanstack/react-start";
import { launchCampaign } from "@/lib/whatsapp.functions";
import { startConversations } from "@/lib/inbox.functions";
import { toast } from "sonner";
import { parseContactsCsv } from "@/lib/csv-import";
import {
  Plus,
  Trash2,
  Upload,
  Search,
  Download,
  Filter,
  X,
  Save,
  Bookmark,
  MoreHorizontal,
  Pencil,
  Send,
  FolderPlus,
  MessageSquarePlus,
} from "lucide-react";

export const Route = createFileRoute("/_authenticated/contacts/")({
  component: Contacts,
});

const schema = z.object({
  name: z.string().trim().min(1).max(120),
  phone: z
    .string()
    .trim()
    .regex(/^\+?[\d\s\-()]{7,20}$/, "Invalid phone")
    .max(20),
  email: z.string().trim().email().max(255).optional().or(z.literal("")),
  tags: z.string().max(500).optional(),
});

type CustomField = { key: string; value: string };

function csvEscape(v: any) {
  if (v == null) return "";
  const s = String(v);
  return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

function Contacts() {
  const qc = useQueryClient();
  const navigate = useNavigate();
  const startChatFn = useServerFn(startConversations);
  const { currentWorkspaceId } = useWorkspace();
  const [search, setSearch] = useState("");
  const [tagFilter, setTagFilter] = useState<string[]>([]);
  const [open, setOpen] = useState(false);
  const [importOpen, setImportOpen] = useState(false);
  const [saveSegOpen, setSaveSegOpen] = useState(false);
  const [segName, setSegName] = useState("");
  const [form, setForm] = useState({ name: "", phone: "", email: "", tags: "" });
  const [customFields, setCustomFields] = useState<CustomField[]>([]);
  const [csv, setCsv] = useState("");
  const [editContact, setEditContact] = useState<any | null>(null);
  const [sendContact, setSendContact] = useState<any | null>(null);
  const [groupContact, setGroupContact] = useState<any | null>(null);
  const [chatBusyId, setChatBusyId] = useState<string | null>(null);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [bulkConfirmOpen, setBulkConfirmOpen] = useState(false);
  const [bulkDeleting, setBulkDeleting] = useState(false);
  const [visibleCount, setVisibleCount] = useState(500);
  const [newGroupOpen, setNewGroupOpen] = useState(false);
  const [newGroupName, setNewGroupName] = useState("");
  const [creatingGroup, setCreatingGroup] = useState(false);

  const { data: contacts = [] } = useQuery({
    queryKey: ["contacts", currentWorkspaceId, search, tagFilter.join(",")],
    enabled: !!currentWorkspaceId,
    queryFn: async () => {
      // PostgREST caps rows per request (1000). Page through everything.
      const pageSize = 1000;
      const all: any[] = [];
      for (let from = 0; ; from += pageSize) {
        let q = supabase
          .from("contacts")
          .select("*")
          .eq("workspace_id", currentWorkspaceId!)
          .order("created_at", { ascending: false });
        if (search)
          q = q.or(`name.ilike.%${search}%,phone.ilike.%${search}%,email.ilike.%${search}%`);
        if (tagFilter.length) q = q.overlaps("tags", tagFilter);
        const { data, error } = await q.range(from, from + pageSize - 1);
        if (error) throw error;
        all.push(...(data ?? []));
        if (!data || data.length < pageSize) break;
      }
      return all;
    },

  });

  const { data: segments = [] } = useQuery({
    queryKey: ["segments", currentWorkspaceId],
    enabled: !!currentWorkspaceId,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("contact_segments")
        .select("*")
        .eq("workspace_id", currentWorkspaceId!)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data;
    },
  });

  const allTags = useMemo(() => {
    const s = new Set<string>();
    contacts.forEach((c: any) => (c.tags || []).forEach((t: string) => s.add(t)));
    return Array.from(s).sort();
  }, [contacts]);

  async function add() {
    if (!currentWorkspaceId) return;
    const p = schema.safeParse(form);
    if (!p.success) return toast.error(p.error.issues[0].message);
    const { data: u } = await supabase.auth.getUser();
    const tags = form.tags
      ? form.tags
          .split(",")
          .map((t) => t.trim())
          .filter(Boolean)
      : [];
    const cf: Record<string, string> = {};
    customFields.forEach((f) => {
      if (f.key.trim()) cf[f.key.trim()] = f.value;
    });
    const { error } = await supabase.rpc("upsert_contact", {
      _workspace_id: currentWorkspaceId,
      _name: p.data.name,
      _phone: p.data.phone,
      _email: p.data.email || undefined,
      _tags: tags,
      _custom_fields: cf,
      _user_id: u.user!.id,
    });
    if (error) return toast.error(error.message);
    toast.success("Contact added");
    setForm({ name: "", phone: "", email: "", tags: "" });
    setCustomFields([]);
    setOpen(false);
    qc.invalidateQueries({ queryKey: ["contacts"] });
  }

  async function importCsv() {
    if (!currentWorkspaceId) return;
    const { data: u } = await supabase.auth.getUser();
    const parsed = parseContactsCsv(csv);
    const rows = parsed.map((r) => ({ name: r.name, phone: r.phone, email: r.email || undefined }));
    if (!rows.length) return toast.error("No valid rows");
    const { error } = await supabase.rpc("upsert_contacts_bulk", {
      _workspace_id: currentWorkspaceId,
      _user_id: u.user!.id,
      _rows: rows as any,
    });
    if (error) return toast.error(error.message);
    toast.success(`Imported ${rows.length} contacts`);
    setCsv("");
    setImportOpen(false);
    qc.invalidateQueries({ queryKey: ["contacts"] });
  }

  function exportCsv() {
    if (!contacts.length) return toast.error("No contacts to export");
    const cfKeys = new Set<string>();
    contacts.forEach((c: any) => Object.keys(c.custom_fields || {}).forEach((k) => cfKeys.add(k)));
    const cfCols = Array.from(cfKeys);
    const header = ["name", "phone", "email", "tags", ...cfCols];
    const rows = contacts.map((c: any) => [
      c.name,
      c.phone,
      c.email ?? "",
      (c.tags || []).join("|"),
      ...cfCols.map((k) => c.custom_fields?.[k] ?? ""),
    ]);
    const csvText = [header, ...rows].map((r) => r.map(csvEscape).join(",")).join("\n");
    const blob = new Blob([csvText], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `contacts-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success(`Exported ${contacts.length} contacts`);
  }

  async function saveSegment() {
    if (!currentWorkspaceId) return;
    if (!segName.trim()) return toast.error("Name required");
    const { data: u } = await supabase.auth.getUser();
    const { error } = await supabase.from("contact_segments").insert({
      workspace_id: currentWorkspaceId,
      user_id: u.user!.id,
      name: segName.trim(),
      tags_any: tagFilter,
      search: search || null,
    });
    if (error) return toast.error(error.message);
    toast.success("Segment saved");
    setSegName("");
    setSaveSegOpen(false);
    qc.invalidateQueries({ queryKey: ["segments"] });
  }

  function applySegment(s: any) {
    setSearch(s.search || "");
    setTagFilter(s.tags_any || []);
  }

  async function deleteSegment(id: string) {
    const { error } = await supabase.from("contact_segments").delete().eq("id", id);
    if (error) return toast.error(error.message);
    qc.invalidateQueries({ queryKey: ["segments"] });
  }

  async function del(id: string) {
    const { error } = await supabase.from("contacts").delete().eq("id", id);
    if (error) return toast.error(error.message);
    setSelected((prev) => {
      const n = new Set(prev);
      n.delete(id);
      return n;
    });
    qc.invalidateQueries({ queryKey: ["contacts"] });
  }

  async function bulkDelete() {
    if (!currentWorkspaceId || selected.size === 0) return;
    setBulkDeleting(true);
    const ids = Array.from(selected);
    const chunkSize = 200;
    let failed = 0;
    try {
      for (let i = 0; i < ids.length; i += chunkSize) {
        const chunk = ids.slice(i, i + chunkSize);
        const { error } = await supabase
          .from("contacts")
          .delete()
          .eq("workspace_id", currentWorkspaceId)
          .in("id", chunk);
        if (error) failed += chunk.length;
      }
      if (failed === 0) toast.success(`Deleted ${ids.length} contacts`);
      else if (failed < ids.length) toast.warning(`Deleted ${ids.length - failed}; ${failed} failed`);
      else toast.error("Failed to delete contacts");
      setSelected(new Set());
      setBulkConfirmOpen(false);
      qc.invalidateQueries({ queryKey: ["contacts"] });
    } finally {
      setBulkDeleting(false);
    }
  }

  function toggleSelect(id: string, checked: boolean) {
    setSelected((prev) => {
      const n = new Set(prev);
      if (checked) n.add(id);
      else n.delete(id);
      return n;
    });
  }

  function toggleSelectAllVisible(checked: boolean) {
    setSelected((prev) => {
      const n = new Set(prev);
      if (checked) contacts.forEach((c: any) => n.add(c.id));
      else contacts.forEach((c: any) => n.delete(c.id));
      return n;
    });
  }

  async function chatWith(contact: any) {
    if (!currentWorkspaceId) return;
    setChatBusyId(contact.id);
    try {
      const r: any = await startChatFn({
        data: { workspace_id: currentWorkspaceId, contact_ids: [contact.id], group_ids: [] },
      });
      if (!r?.ok || !r.first_conversation_id) return toast.error("Could not open chat");
      toast.success("Chat ready");
      navigate({ to: "/inbox", search: { conversation: r.first_conversation_id } as any });
    } catch (e: any) {
      toast.error(e.message || "Could not open chat");
    } finally {
      setChatBusyId(null);
    }
  }

  useEffect(() => {
    setVisibleCount(500);
  }, [search, tagFilter, currentWorkspaceId]);

  async function createGroupFromSelected() {
    if (!currentWorkspaceId || selected.size === 0) return;
    const name = newGroupName.trim();
    if (!name) return toast.error("Group name required");
    setCreatingGroup(true);
    try {
      const { data: u } = await supabase.auth.getUser();
      const { data: group, error } = await supabase
        .from("contact_groups")
        .insert({ workspace_id: currentWorkspaceId, user_id: u.user!.id, name })
        .select("id")
        .single();
      if (error || !group) return toast.error(error?.message || "Could not create group");
      const ids = Array.from(selected);
      const chunkSize = 500;
      let failed = 0;
      for (let i = 0; i < ids.length; i += chunkSize) {
        const rows = ids.slice(i, i + chunkSize).map((id) => ({
          group_id: group.id,
          contact_id: id,
          workspace_id: currentWorkspaceId,
        }));
        const { error: mErr } = await supabase.from("contact_group_members").insert(rows);
        if (mErr) failed += rows.length;
      }
      if (failed) toast.warning(`Group created; ${failed} contacts could not be added`);
      else toast.success(`Group "${name}" created with ${ids.length} contacts`);
      setNewGroupName("");
      setNewGroupOpen(false);
      qc.invalidateQueries({ queryKey: ["contact_groups"] });
    } finally {
      setCreatingGroup(false);
    }
  }

  function toggleTag(t: string) {
    setTagFilter((prev) => (prev.includes(t) ? prev.filter((x) => x !== t) : [...prev, t]));
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-3xl font-bold">Contacts</h1>
          <p className="text-muted-foreground">{contacts.length} contacts</p>
        </div>
        <div className="flex gap-2 flex-wrap">
          <Button variant="outline" onClick={exportCsv}>
            <Download className="mr-2 h-4 w-4" />
            Export
          </Button>
          <Dialog open={importOpen} onOpenChange={setImportOpen}>
            <DialogTrigger asChild>
              <Button variant="outline">
                <Upload className="mr-2 h-4 w-4" />
                Import CSV
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Import contacts</DialogTitle>
              </DialogHeader>
              <p className="text-sm text-muted-foreground">
                Upload a <code>.csv</code> file or paste rows below. Format:{" "}
                <code>name,phone,email</code> per line. Phone in international format (e.g.
                +14155551234). A header row is allowed and will be skipped.{" "}
                <a
                  href="/contacts-sample.csv"
                  download
                  className="text-primary underline underline-offset-2"
                >
                  Download sample CSV
                </a>
                .
              </p>
              <Input
                type="file"
                accept=".csv,text/csv"
                onChange={async (e) => {
                  const f = e.target.files?.[0];
                  if (!f) return;
                  if (f.size > 5 * 1024 * 1024) return toast.error("File too large (max 5MB)");
                  const text = await f.text();
                  setCsv(text);
                  toast.success(`Loaded ${f.name}`);
                }}
              />
              <Textarea
                rows={8}
                value={csv}
                onChange={(e) => setCsv(e.target.value)}
                placeholder="Jane Doe,+14155551234,jane@example.com"
              />
              <DialogFooter>
                <Button onClick={importCsv}>Import</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Add contact
              </Button>
            </DialogTrigger>
            <DialogContent className="max-h-[85vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>New contact</DialogTitle>
              </DialogHeader>
              <div className="space-y-3">
                <div>
                  <Label>Name</Label>
                  <Input
                    value={form.name}
                    onChange={(e) => setForm({ ...form, name: e.target.value })}
                  />
                </div>
                <div>
                  <Label>Phone (international)</Label>
                  <Input
                    placeholder="+14155551234"
                    value={form.phone}
                    onChange={(e) => setForm({ ...form, phone: e.target.value })}
                  />
                </div>
                <div>
                  <Label>Email (optional)</Label>
                  <Input
                    type="email"
                    value={form.email}
                    onChange={(e) => setForm({ ...form, email: e.target.value })}
                  />
                </div>
                <div>
                  <Label>Tags (comma-separated)</Label>
                  <Input
                    placeholder="vip, lead"
                    value={form.tags}
                    onChange={(e) => setForm({ ...form, tags: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label>Custom fields</Label>
                    <Button
                      type="button"
                      size="sm"
                      variant="ghost"
                      onClick={() => setCustomFields([...customFields, { key: "", value: "" }])}
                    >
                      <Plus className="h-3 w-3 mr-1" />
                      Add field
                    </Button>
                  </div>
                  {customFields.map((f, i) => (
                    <div key={i} className="flex gap-2">
                      <Input
                        placeholder="Field name"
                        value={f.key}
                        onChange={(e) => {
                          const c = [...customFields];
                          c[i].key = e.target.value;
                          setCustomFields(c);
                        }}
                      />
                      <Input
                        placeholder="Value"
                        value={f.value}
                        onChange={(e) => {
                          const c = [...customFields];
                          c[i].value = e.target.value;
                          setCustomFields(c);
                        }}
                      />
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        onClick={() => setCustomFields(customFields.filter((_, x) => x !== i))}
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                </div>
              </div>
              <DialogFooter>
                <Button onClick={add}>Save</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <div className="grid gap-3 md:grid-cols-[1fr_auto]">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            className="pl-9"
            placeholder="Search by name, phone, or email"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        <Dialog open={saveSegOpen} onOpenChange={setSaveSegOpen}>
          <DialogTrigger asChild>
            <Button variant="outline" disabled={!search && !tagFilter.length}>
              <Save className="mr-2 h-4 w-4" />
              Save as segment
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Save segment</DialogTitle>
            </DialogHeader>
            <div className="space-y-3">
              <div>
                <Label>Name</Label>
                <Input
                  value={segName}
                  onChange={(e) => setSegName(e.target.value)}
                  placeholder="VIP leads"
                />
              </div>
              <p className="text-sm text-muted-foreground">
                Filters: {search && <span>search "{search}"</span>}
                {tagFilter.length > 0 && (
                  <span>
                    {" "}
                    {search && "·"} tags: {tagFilter.join(", ")}
                  </span>
                )}
              </p>
            </div>
            <DialogFooter>
              <Button onClick={saveSegment}>Save</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {allTags.length > 0 && (
        <div className="flex items-center gap-2 flex-wrap">
          <Filter className="h-4 w-4 text-muted-foreground" />
          {allTags.map((t) => (
            <button
              key={t}
              onClick={() => toggleTag(t)}
              className={`text-xs px-2.5 py-1 rounded-full border transition ${
                tagFilter.includes(t)
                  ? "bg-primary text-primary-foreground border-primary"
                  : "bg-background hover:bg-muted"
              }`}
            >
              {t}
            </button>
          ))}
          {tagFilter.length > 0 && (
            <button
              onClick={() => setTagFilter([])}
              className="text-xs text-muted-foreground hover:text-foreground"
            >
              Clear
            </button>
          )}
        </div>
      )}

      {segments.length > 0 && (
        <div className="flex items-center gap-2 flex-wrap">
          <Bookmark className="h-4 w-4 text-muted-foreground" />
          <span className="text-xs text-muted-foreground">Segments:</span>
          {segments.map((s: any) => (
            <div
              key={s.id}
              className="group inline-flex items-center gap-1 rounded-full bg-accent/40 pl-2.5 pr-1 py-0.5 text-xs"
            >
              <button onClick={() => applySegment(s)} className="hover:text-primary">
                {s.name}
              </button>
              <button
                onClick={() => deleteSegment(s.id)}
                className="opacity-0 group-hover:opacity-100 transition"
              >
                <X className="h-3 w-3" />
              </button>
            </div>
          ))}
        </div>
      )}

      <Card className="divide-y">
        {contacts.length === 0 ? (
          <div className="p-12 text-center text-muted-foreground">No contacts match</div>
        ) : (
          <>
            <div className="p-3 flex items-center justify-between gap-3 bg-muted/40">
              <label className="flex items-center gap-2 text-sm cursor-pointer select-none">
                <Checkbox
                  checked={
                    contacts.length > 0 && contacts.every((c: any) => selected.has(c.id))
                  }
                  onCheckedChange={(v) => toggleSelectAllVisible(Boolean(v))}
                />
                <span className="text-muted-foreground">
                  {selected.size > 0
                    ? `${selected.size} selected`
                    : `Select all (${contacts.length})`}
                </span>
              </label>
              <div className="flex items-center gap-2">
                {selected.size > 0 && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setSelected(new Set())}
                  >
                    Clear
                  </Button>
                )}
                <Button
                  variant="outline"
                  size="sm"
                  disabled={selected.size === 0}
                  onClick={() => setNewGroupOpen(true)}
                >
                  <FolderPlus className="h-4 w-4 mr-2" />
                  Create group
                </Button>
                <Button
                  variant="destructive"
                  size="sm"
                  disabled={selected.size === 0}
                  onClick={() => setBulkConfirmOpen(true)}
                >
                  <Trash2 className="h-4 w-4 mr-2" />
                  Delete selected
                </Button>
              </div>
            </div>
            {contacts.slice(0, visibleCount).map((c: any) => {
              const cfEntries = Object.entries(c.custom_fields || {});
              const isChecked = selected.has(c.id);
              return (
                <div key={c.id} className="p-4 flex items-center justify-between gap-3">
                  <div className="flex items-start gap-3 min-w-0 flex-1">
                    <Checkbox
                      className="mt-1"
                      checked={isChecked}
                      onCheckedChange={(v) => toggleSelect(c.id, Boolean(v))}
                    />
                    <div className="min-w-0">
                      <p className="font-medium truncate">{c.name}</p>
                      <p className="text-sm text-muted-foreground">
                        {c.phone}
                        {c.email ? ` · ${c.email}` : ""}
                      </p>
                      {c.tags?.length > 0 && (
                        <div className="flex gap-1 mt-1.5 flex-wrap">
                          {c.tags.map((t: string) => (
                            <span
                              key={t}
                              className="text-xs px-2 py-0.5 rounded bg-primary/10 text-primary"
                            >
                              {t}
                            </span>
                          ))}
                        </div>
                      )}
                      {cfEntries.length > 0 && (
                        <div className="flex gap-2 mt-1.5 flex-wrap text-xs text-muted-foreground">
                          {cfEntries.map(([k, v]) => (
                            <span key={k} className="px-1.5 py-0.5 rounded bg-muted">
                              <b className="font-medium">{k}:</b> {String(v)}
                            </span>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center gap-1">
                    <Button
                      variant="ghost"
                      size="icon"
                      title="Open chat"
                      disabled={chatBusyId === c.id}
                      onClick={() => chatWith(c)}
                    >
                      <MessageSquarePlus className="h-4 w-4" />
                    </Button>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon">
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => setEditContact(c)}>
                          <Pencil className="h-4 w-4 mr-2" />
                          Edit
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => setGroupContact(c)}>
                          <FolderPlus className="h-4 w-4 mr-2" />
                          Add to group
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => setSendContact(c)}>
                          <Send className="h-4 w-4 mr-2" />
                          Send template
                        </DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem
                          onClick={() => del(c.id)}
                          className="text-destructive focus:text-destructive"
                        >
                          <Trash2 className="h-4 w-4 mr-2" />
                          Delete
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </div>
              );
            })}
            {contacts.length > visibleCount && (
              <div className="p-4 flex justify-center">
                <Button variant="outline" size="sm" onClick={() => setVisibleCount((n) => n + 500)}>
                  Load more ({contacts.length - visibleCount} remaining)
                </Button>
              </div>
            )}
          </>

        )}
      </Card>

      <Dialog open={newGroupOpen} onOpenChange={setNewGroupOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Create group from {selected.size} contacts</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <div>
              <Label>Group name</Label>
              <Input
                value={newGroupName}
                onChange={(e) => setNewGroupName(e.target.value)}
                placeholder="e.g. Diwali campaign"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setNewGroupOpen(false)} disabled={creatingGroup}>
              Cancel
            </Button>
            <Button onClick={createGroupFromSelected} disabled={creatingGroup}>
              {creatingGroup ? "Creating…" : "Create group"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={bulkConfirmOpen} onOpenChange={setBulkConfirmOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete {selected.size} contacts?</DialogTitle>
          </DialogHeader>
          <p className="text-sm text-muted-foreground">
            This permanently deletes the selected contacts. Related conversations, deals, and
            messages will remain but will no longer be linked to a contact. This cannot be
            undone.
          </p>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setBulkConfirmOpen(false)}
              disabled={bulkDeleting}
            >
              Cancel
            </Button>
            <Button variant="destructive" onClick={bulkDelete} disabled={bulkDeleting}>
              {bulkDeleting ? "Deleting…" : `Delete ${selected.size}`}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>


      {editContact && (
        <EditContactDialog
          contact={editContact}
          onClose={() => {
            setEditContact(null);
            qc.invalidateQueries({ queryKey: ["contacts"] });
          }}
        />
      )}
      {sendContact && (
        <SendTemplateDialog contact={sendContact} onClose={() => setSendContact(null)} />
      )}
      {groupContact && (
        <AddToGroupDialog contact={groupContact} onClose={() => setGroupContact(null)} />
      )}
    </div>
  );
}

function EditContactDialog({ contact, onClose }: { contact: any; onClose: () => void }) {
  const [form, setForm] = useState({
    name: contact.name ?? "",
    phone: contact.phone ?? "",
    email: contact.email ?? "",
    tags: (contact.tags || []).join(", "),
  });
  const [customFields, setCustomFields] = useState<CustomField[]>(
    Object.entries(contact.custom_fields || {}).map(([key, value]) => ({
      key,
      value: String(value),
    })),
  );

  async function save() {
    const p = schema.safeParse(form);
    if (!p.success) return toast.error(p.error.issues[0].message);
    const tags = form.tags
      ? form.tags
          .split(",")
          .map((t: string) => t.trim())
          .filter(Boolean)
      : [];
    const cf: Record<string, string> = {};
    customFields.forEach((f) => {
      if (f.key.trim()) cf[f.key.trim()] = f.value;
    });
    const { error } = await supabase
      .from("contacts")
      .update({
        name: p.data.name,
        phone: p.data.phone,
        email: p.data.email || null,
        tags,
        custom_fields: cf,
      })
      .eq("id", contact.id);
    if (error) return toast.error(error.message);
    toast.success("Contact updated");
    onClose();
  }

  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Edit contact</DialogTitle>
        </DialogHeader>
        <div className="space-y-3">
          <div>
            <Label>Name</Label>
            <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
          </div>
          <div>
            <Label>Phone (international)</Label>
            <Input
              value={form.phone}
              onChange={(e) => setForm({ ...form, phone: e.target.value })}
            />
          </div>
          <div>
            <Label>Email (optional)</Label>
            <Input
              type="email"
              value={form.email}
              onChange={(e) => setForm({ ...form, email: e.target.value })}
            />
          </div>
          <div>
            <Label>Tags (comma-separated)</Label>
            <Input value={form.tags} onChange={(e) => setForm({ ...form, tags: e.target.value })} />
          </div>
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label>Custom fields</Label>
              <Button
                type="button"
                size="sm"
                variant="ghost"
                onClick={() => setCustomFields([...customFields, { key: "", value: "" }])}
              >
                <Plus className="h-3 w-3 mr-1" />
                Add field
              </Button>
            </div>
            {customFields.map((f, i) => (
              <div key={i} className="flex gap-2">
                <Input
                  placeholder="Field name"
                  value={f.key}
                  onChange={(e) => {
                    const c = [...customFields];
                    c[i].key = e.target.value;
                    setCustomFields(c);
                  }}
                />
                <Input
                  placeholder="Value"
                  value={f.value}
                  onChange={(e) => {
                    const c = [...customFields];
                    c[i].value = e.target.value;
                    setCustomFields(c);
                  }}
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  onClick={() => setCustomFields(customFields.filter((_, x) => x !== i))}
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
            ))}
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={save}>Save changes</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function SendTemplateDialog({ contact, onClose }: { contact: any; onClose: () => void }) {
  const { currentWorkspaceId } = useWorkspace();
  const launch = useServerFn(launchCampaign);
  const [templateId, setTemplateId] = useState<string>("");
  const [vars, setVars] = useState<string[]>([]);
  const [busy, setBusy] = useState(false);

  const { data: templates = [] } = useQuery({
    queryKey: ["templates-approved", currentWorkspaceId],
    enabled: !!currentWorkspaceId,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("templates")
        .select("id, meta_template_name, language, status, variables_count, body")
        .eq("workspace_id", currentWorkspaceId!)
        .order("meta_template_name");
      if (error) throw error;
      return data;
    },
  });

  const selected = templates.find((t: any) => t.id === templateId);

  useEffect(() => {
    if (selected) setVars(Array(selected.variables_count || 0).fill(""));
  }, [templateId]);

  async function send() {
    if (!currentWorkspaceId || !selected) return;
    if (selected.status !== "APPROVED") return toast.error("Template not approved by Meta yet");
    setBusy(true);
    try {
      const res: any = await launch({
        data: {
          workspace_id: currentWorkspaceId,
          name: `Direct to ${contact.name}`,
          template_id: selected.id,
          contact_ids: [contact.id],
          variables: vars,
        },
      });
      if (res?.sent) toast.success("Template sent");
      else toast.error("Failed to send");
      onClose();
    } catch (e: any) {
      toast.error(e.message || "Failed");
    } finally {
      setBusy(false);
    }
  }

  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Send template to {contact.name}</DialogTitle>
        </DialogHeader>
        <div className="space-y-3">
          <p className="text-sm text-muted-foreground">{contact.phone}</p>
          <div>
            <Label>Template</Label>
            <Select value={templateId} onValueChange={setTemplateId}>
              <SelectTrigger>
                <SelectValue placeholder="Choose a template" />
              </SelectTrigger>
              <SelectContent>
                {templates.length === 0 && (
                  <div className="p-3 text-sm text-muted-foreground">
                    No templates. Create one in Templates.
                  </div>
                )}
                {templates.map((t: any) => (
                  <SelectItem key={t.id} value={t.id}>
                    {t.meta_template_name} · {t.language}{" "}
                    {t.status !== "APPROVED" && (
                      <span className="text-muted-foreground">({t.status})</span>
                    )}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          {selected && (
            <div className="rounded-md bg-muted p-3 text-sm whitespace-pre-wrap">
              {selected.body}
            </div>
          )}
          {selected && selected.variables_count > 0 && (
            <div className="space-y-2">
              <Label>Variables</Label>
              {vars.map((v, i) => (
                <Input
                  key={i}
                  placeholder={`{{${i + 1}}}`}
                  value={v}
                  onChange={(e) => {
                    const c = [...vars];
                    c[i] = e.target.value;
                    setVars(c);
                  }}
                />
              ))}
            </div>
          )}
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={send} disabled={busy || !templateId}>
            {busy ? "Sending…" : "Send"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function AddToGroupDialog({ contact, onClose }: { contact: any; onClose: () => void }) {
  const { currentWorkspaceId } = useWorkspace();
  const qc = useQueryClient();
  const [busy, setBusy] = useState(false);

  const { data: groups = [] } = useQuery({
    queryKey: ["contact_groups", currentWorkspaceId],
    enabled: !!currentWorkspaceId,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("contact_groups")
        .select("id, name")
        .eq("workspace_id", currentWorkspaceId!)
        .order("name");
      if (error) throw error;
      return data;
    },
  });

  const { data: memberOf = [] } = useQuery({
    queryKey: ["contact_member_of", contact.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("contact_group_members")
        .select("group_id")
        .eq("contact_id", contact.id);
      if (error) throw error;
      return data.map((m: any) => m.group_id);
    },
  });

  const memberSet = useMemo(() => new Set(memberOf), [memberOf]);

  async function toggle(groupId: string, checked: boolean) {
    if (!currentWorkspaceId) return;
    setBusy(true);
    try {
      if (checked) {
        const { error } = await supabase.from("contact_group_members").insert({
          group_id: groupId,
          contact_id: contact.id,
          workspace_id: currentWorkspaceId,
        });
        if (error) return toast.error(error.message);
      } else {
        const { error } = await supabase
          .from("contact_group_members")
          .delete()
          .eq("group_id", groupId)
          .eq("contact_id", contact.id);
        if (error) return toast.error(error.message);
      }
      qc.invalidateQueries({ queryKey: ["contact_member_of", contact.id] });
      qc.invalidateQueries({ queryKey: ["contact_groups"] });
    } finally {
      setBusy(false);
    }
  }

  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Add {contact.name} to groups</DialogTitle>
        </DialogHeader>
        {groups.length === 0 ? (
          <p className="text-sm text-muted-foreground p-4 text-center">
            No groups yet. Create one in Contacts → Groups.
          </p>
        ) : (
          <div className="max-h-80 overflow-auto divide-y rounded-md border">
            {groups.map((g: any) => {
              const inGroup = memberSet.has(g.id);
              return (
                <label
                  key={g.id}
                  className="flex items-center gap-3 p-3 cursor-pointer hover:bg-accent/50"
                >
                  <Checkbox
                    checked={inGroup}
                    disabled={busy}
                    onCheckedChange={(v) => toggle(g.id, Boolean(v))}
                  />
                  <span className="text-sm font-medium">{g.name}</span>
                </label>
              );
            })}
          </div>
        )}
        <DialogFooter>
          <Button onClick={onClose}>Done</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
