import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useWorkspace } from "@/lib/workspace-context";
import { buildRemarketingAudience } from "@/lib/remarketing.functions";
import { launchCampaign } from "@/lib/whatsapp.functions";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { Target, Users, Send, Loader2, Sparkles, Upload } from "lucide-react";

export const Route = createFileRoute("/_authenticated/remarketing")({
  component: RemarketingPage,
  head: () => ({ meta: [{ title: "Remarketing — Slice" }] }),
});

type FilterType =
  | "no_reply_days"
  | "engaged_days"
  | "inactive_days"
  | "campaign_status"
  | "has_tags"
  | "no_conversation";

const PRESETS: { id: FilterType; title: string; desc: string; icon: any }[] = [
  { id: "no_reply_days", title: "Didn't reply in X days", desc: "Contacts whose last reply is older than N days", icon: Target },
  { id: "engaged_days", title: "Replied recently", desc: "Engaged contacts who messaged you in last N days", icon: Sparkles },
  { id: "inactive_days", title: "Inactive contacts", desc: "No conversation activity in last N days", icon: Users },
  { id: "campaign_status", title: "Previous campaign outcome", desc: "Recipients of a past campaign by status", icon: Send },
  { id: "has_tags", title: "By tags", desc: "Contacts that match any of these tags", icon: Target },
  { id: "no_conversation", title: "Never messaged", desc: "Contacts that never had a conversation", icon: Users },
];

function RemarketingPage() {
  const navigate = useNavigate();
  const { currentWorkspaceId } = useWorkspace();
  const buildFn = useServerFn(buildRemarketingAudience);
  const launchFn = useServerFn(launchCampaign);

  const [type, setType] = useState<FilterType>("no_reply_days");
  const [days, setDays] = useState(7);
  const [tagsInput, setTagsInput] = useState("");
  const [campaignId, setCampaignId] = useState("");
  const [recipientStatus, setRecipientStatus] = useState<string>("sent");

  const [audience, setAudience] = useState<any[]>([]);
  const [building, setBuilding] = useState(false);

  const [name, setName] = useState("");
  const [templateId, setTemplateId] = useState("");
  const [variables, setVariables] = useState<string[]>([]);
  const [headerMediaUrl, setHeaderMediaUrl] = useState("");
  const [uploadingMedia, setUploadingMedia] = useState(false);
  const [launching, setLaunching] = useState(false);

  const { data: templates = [] } = useQuery({
    queryKey: ["rem-templates", currentWorkspaceId],
    enabled: !!currentWorkspaceId,
    queryFn: async () =>
      (await supabase.from("templates").select("*")
        .eq("workspace_id", currentWorkspaceId!)
        .eq("status", "APPROVED")).data ?? [],
  });

  const { data: campaigns = [] } = useQuery({
    queryKey: ["rem-campaigns", currentWorkspaceId],
    enabled: !!currentWorkspaceId,
    queryFn: async () =>
      (await supabase.from("campaigns").select("id,name,created_at")
        .eq("workspace_id", currentWorkspaceId!)
        .order("created_at", { ascending: false }).limit(50)).data ?? [],
  });

  const template = templates.find((t: any) => t.id === templateId);
  const headerComp = Array.isArray(template?.components)
    ? (template.components as any[]).find((c: any) => String(c?.type).toUpperCase() === "HEADER")
    : null;
  const headerFormat = String(headerComp?.format || "").toUpperCase();
  const headerNeedsMedia = ["IMAGE", "VIDEO", "DOCUMENT"].includes(headerFormat);

  async function uploadHeaderMedia(file: File) {
    if (!currentWorkspaceId) return;

    if (headerFormat === "IMAGE" && !file.type.startsWith("image/")) {
      return toast.error("Please upload an image file");
    }
    if (headerFormat === "VIDEO" && !file.type.startsWith("video/")) {
      return toast.error("Please upload a video file");
    }

    setUploadingMedia(true);
    try {
      const ext = file.name.split(".").pop() || headerFormat.toLowerCase();
      const path = `${currentWorkspaceId}/campaign-headers/${crypto.randomUUID()}.${ext}`;
      const { error } = await supabase.storage.from("chat-media").upload(path, file, {
        contentType: file.type || "application/octet-stream",
        upsert: false,
      });
      if (error) throw error;

      const { data } = supabase.storage.from("chat-media").getPublicUrl(path);
      setHeaderMediaUrl(data.publicUrl);
      toast.success(`${headerFormat.toLowerCase()} uploaded`);
    } catch (err: any) {
      toast.error(err.message || "Upload failed");
    } finally {
      setUploadingMedia(false);
    }
  }

  async function build() {
    if (!currentWorkspaceId) return;
    setBuilding(true);
    try {
      const tags = tagsInput.split(",").map((s) => s.trim()).filter(Boolean);
      const res = await buildFn({
        data: {
          workspace_id: currentWorkspaceId,
          type,
          days: ["no_reply_days", "engaged_days", "inactive_days"].includes(type) ? days : undefined,
          tags: type === "has_tags" ? tags : undefined,
          campaign_id: type === "campaign_status" ? campaignId : undefined,
          recipient_status: type === "campaign_status" ? (recipientStatus as any) : undefined,
        },
      });
      setAudience(res.contacts);
      toast.success(`Found ${res.contacts.length} contact(s)`);
    } catch (e: any) {
      toast.error(e.message);
    } finally {
      setBuilding(false);
    }
  }

  async function launch() {
    if (!currentWorkspaceId) return;
    if (!name.trim()) return toast.error("Name your campaign");
    if (!templateId) return toast.error("Pick a template");
    if (audience.length === 0) return toast.error("Build an audience first");
    const varsCount = template?.variables_count ?? 0;

    // Auto-fill support: {{1}} defaults to each recipient's contact / WhatsApp
    // profile name when left blank, and any variable already mapped to a
    // per-recipient field (customer_name/phone/email) or a static value is
    // resolved server-side. Strip literal `{{N}}` placeholders the user may
    // have typed so the executor treats them as empty and auto-fills.
    const mapping: Array<{ index: number; field: string; static_value?: string }> =
      Array.isArray(template?.variable_mapping) ? (template!.variable_mapping as any[]) : [];
    const AUTO = new Set(["customer_name", "customer_phone", "customer_email", "static_text"]);
    const cleaned = Array.from({ length: varsCount }).map((_, i) => {
      const raw = String(variables[i] ?? "").trim();
      return /^\{\{\s*\d+\s*\}\}$/.test(raw) ? "" : raw;
    });
    for (let i = 0; i < varsCount; i++) {
      const entry = mapping.find((e) => Number(e?.index) === i + 1);
      const autoFilled = (entry && AUTO.has(entry.field)) || (!entry && i === 0);
      if (!autoFilled && !cleaned[i]) {
        return toast.error(`Fill value for {{${i + 1}}}`);
      }
    }
    if (headerNeedsMedia) {
      if (!headerMediaUrl.trim()) return toast.error(`This template header requires a ${headerFormat.toLowerCase()}`);
      try { new URL(headerMediaUrl); } catch { return toast.error("Header media URL is invalid"); }
    }

    setLaunching(true);
    try {
      const res = await launchFn({
        data: {
          workspace_id: currentWorkspaceId,
          name,
          template_id: templateId,
          contact_ids: audience.map((c) => c.id),
          variables: cleaned,
          ...(headerNeedsMedia ? { header_media_url: headerMediaUrl.trim() } : {}),
        },
      });

      toast.success(`Remarketing sent: ${res.sent} delivered, ${res.failed} failed`);
      navigate({ to: "/campaigns" });
    } catch (e: any) {
      toast.error(e.message);
    } finally {
      setLaunching(false);
    }
  }

  return (
    <div className="space-y-6 max-w-5xl">
      <div>
        <h1 className="font-display text-3xl font-bold">Remarketing</h1>
        <p className="text-muted-foreground">Re-engage contacts based on their activity</p>
      </div>

      <Card className="p-6 space-y-5">
        <Label>1. Choose an audience</Label>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {PRESETS.map((p) => {
            const active = type === p.id;
            return (
              <button
                key={p.id}
                onClick={() => { setType(p.id); setAudience([]); }}
                className={`text-left rounded-lg border p-3 transition hover:bg-accent ${active ? "border-primary bg-accent" : ""}`}
              >
                <div className="flex items-center gap-2 mb-1">
                  <p.icon className="h-4 w-4 text-primary" />
                  <span className="font-medium text-sm">{p.title}</span>
                </div>
                <p className="text-xs text-muted-foreground">{p.desc}</p>
              </button>
            );
          })}
        </div>

        <div className="grid gap-4 sm:grid-cols-2">
          {["no_reply_days", "engaged_days", "inactive_days"].includes(type) && (
            <div className="space-y-2">
              <Label>Number of days</Label>
              <Input type="number" min={1} max={365} value={days} onChange={(e) => setDays(Number(e.target.value) || 1)} />
            </div>
          )}
          {type === "has_tags" && (
            <div className="space-y-2 sm:col-span-2">
              <Label>Tags (comma-separated)</Label>
              <Input value={tagsInput} onChange={(e) => setTagsInput(e.target.value)} placeholder="vip, lead, abandoned-cart" />
            </div>
          )}
          {type === "campaign_status" && (
            <>
              <div className="space-y-2">
                <Label>Campaign</Label>
                <Select value={campaignId} onValueChange={setCampaignId}>
                  <SelectTrigger><SelectValue placeholder="Pick a campaign" /></SelectTrigger>
                  <SelectContent>
                    {campaigns.length === 0 ? (
                      <div className="px-3 py-2 text-sm text-muted-foreground">No campaigns yet</div>
                    ) : campaigns.map((c: any) => (
                      <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Recipient status</Label>
                <Select value={recipientStatus} onValueChange={setRecipientStatus}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="sent">Sent</SelectItem>
                    <SelectItem value="delivered">Delivered</SelectItem>
                    <SelectItem value="read">Read</SelectItem>
                    <SelectItem value="failed">Failed</SelectItem>
                    <SelectItem value="pending">Pending</SelectItem>
                    <SelectItem value="suppressed">Meta suppressed</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </>
          )}
        </div>

        <Button onClick={build} disabled={building} variant="secondary">
          {building ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Target className="mr-2 h-4 w-4" />}
          Build audience
        </Button>

        {audience.length > 0 && (
          <div className="rounded-lg border p-3">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium">Audience preview</span>
              <Badge variant="secondary">{audience.length} contact(s)</Badge>
            </div>
            <div className="max-h-48 overflow-y-auto divide-y text-sm">
              {audience.slice(0, 100).map((c: any) => (
                <div key={c.id} className="py-1.5 flex justify-between">
                  <span>{c.name}</span>
                  <span className="text-muted-foreground">{c.phone}</span>
                </div>
              ))}
              {audience.length > 100 && (
                <div className="py-1.5 text-xs text-muted-foreground">+ {audience.length - 100} more…</div>
              )}
            </div>
          </div>
        )}
      </Card>

      <Card className="p-6 space-y-5">
        <Label>2. Send a template</Label>
        <div className="space-y-2">
          <Label>Campaign name</Label>
          <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Win-back February" maxLength={120} />
        </div>
        <div className="space-y-2">
          <Label>Template</Label>
          <Select value={templateId} onValueChange={(v) => { setTemplateId(v); setVariables([]); setHeaderMediaUrl(""); }}>
            <SelectTrigger><SelectValue placeholder="Pick an approved template" /></SelectTrigger>
            <SelectContent>
              {templates.length === 0 ? (
                <div className="px-3 py-2 text-sm text-muted-foreground">
                  No approved templates. <Link to="/templates" className="text-primary underline">Sync first</Link>
                </div>
              ) : templates.map((t: any) => (
                <SelectItem key={t.id} value={t.id}>{t.meta_template_name} ({t.language})</SelectItem>
              ))}
            </SelectContent>
          </Select>
          {template?.body && (
            <div className="mt-3 p-3 rounded-lg bg-secondary/50 border text-sm whitespace-pre-wrap">{template.body}</div>
          )}
        </div>
        {template && headerNeedsMedia && (
          <div className="space-y-2">
            <Label>Header {headerFormat.toLowerCase()} URL</Label>
            <div className="flex flex-col gap-2 sm:flex-row">
              <Input
                type="url"
                placeholder={
                  headerFormat === "IMAGE"
                    ? "https://example.com/banner.jpg"
                    : headerFormat === "VIDEO"
                    ? "https://example.com/video.mp4"
                    : "https://example.com/file.pdf"
                }
                value={headerMediaUrl}
                onChange={(e) => setHeaderMediaUrl(e.target.value)}
              />
              <Button
                type="button"
                variant="outline"
                disabled={uploadingMedia}
                onClick={() => document.getElementById("remarketing-header-media-upload")?.click()}
                className="shrink-0"
              >
                {uploadingMedia ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Upload className="mr-2 h-4 w-4" />}
                {uploadingMedia ? "Uploading" : "Upload"}
              </Button>
              <input
                id="remarketing-header-media-upload"
                type="file"
                className="hidden"
                accept={
                  headerFormat === "IMAGE"
                    ? "image/*"
                    : headerFormat === "VIDEO"
                    ? "video/*"
                    : ".pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.txt"
                }
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (file) void uploadHeaderMedia(file);
                  e.target.value = "";
                }}
              />
            </div>
            <p className="text-xs text-muted-foreground">
              This Meta template requires a {headerFormat.toLowerCase()} header for every remarketing send.
            </p>
          </div>
        )}
        {template && template.variables_count > 0 && (
          <div className="space-y-2">
            <Label>Variables</Label>
            {Array.from({ length: template.variables_count }).map((_, i) => (
              <Input
                key={i}
                placeholder={`{{${i + 1}}}`}
                value={variables[i] || ""}
                onChange={(e) => {
                  const next = [...variables];
                  next[i] = e.target.value;
                  setVariables(next);
                }}
              />
            ))}
          </div>
        )}

        <div className="flex justify-end">
          <Button onClick={launch} disabled={launching || uploadingMedia || audience.length === 0} className="shadow-[var(--shadow-glow)]">
            {launching ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Send className="mr-2 h-4 w-4" />}
            Send to {audience.length} contact(s)
          </Button>
        </div>
      </Card>
    </div>
  );
}
