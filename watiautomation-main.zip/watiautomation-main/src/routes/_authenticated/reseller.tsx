import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useWorkspace } from "@/lib/workspace-context";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger } from "@/components/ui/dialog";
import { Switch } from "@/components/ui/switch";
import { toast } from "sonner";
import { useServerFn } from "@tanstack/react-start";
import { getMyAdminStatus } from "@/lib/admin.functions";
import { Sparkles, Check, X, Plus, Trash2, Users, Globe, Palette, Upload, KeyRound, Copy, RefreshCw, Ban, Loader2 } from "lucide-react";
import { updateMyResellerBranding, regenerateCustomerLicense, setCustomerLicenseStatus, signResellerLogoUrl } from "@/lib/reseller.functions";

export const Route = createFileRoute("/_authenticated/reseller")({
  component: ResellerPage,
  head: () => ({ meta: [{ title: "Reseller Program — Slice" }] }),
});

function ResellerPage() {
  const { currentWorkspaceId } = useWorkspace();
  const getStatus = useServerFn(getMyAdminStatus);
  const { data: adminStatus } = useQuery({
    queryKey: ["my-admin-status"],
    queryFn: () => getStatus(),
    staleTime: 60_000,
  });
  const isSuper = !!adminStatus?.is_super_admin;

  const { data: account } = useQuery({
    queryKey: ["reseller-account", currentWorkspaceId],
    enabled: !!currentWorkspaceId,
    queryFn: async () => {
      const { data } = await supabase.from("reseller_accounts").select("*").eq("workspace_id", currentWorkspaceId!).maybeSingle();
      return data;
    },
  });

  const { data: myApp } = useQuery({
    queryKey: ["reseller-app", currentWorkspaceId],
    enabled: !!currentWorkspaceId,
    queryFn: async () => {
      const { data } = await supabase
        .from("reseller_applications")
        .select("*")
        .eq("workspace_id", currentWorkspaceId!)
        .order("created_at", { ascending: false })
        .limit(1)
        .maybeSingle();
      return data;
    },
  });

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-3xl font-bold flex items-center gap-2">
          <Sparkles className="h-7 w-7" />Reseller Program
        </h1>
        <p className="text-muted-foreground">Resell with your own brand. Onboard customers, set prices, earn commissions.</p>
      </div>

      <Tabs defaultValue={isSuper ? "queue" : (account ? "dashboard" : "apply")} className="space-y-4">
        <TabsList>
          {!account && <TabsTrigger value="apply">Apply</TabsTrigger>}
          {account && <TabsTrigger value="dashboard">Dashboard</TabsTrigger>}
          {account && <TabsTrigger value="branding">White-label</TabsTrigger>}
          {account && <TabsTrigger value="customers">Customers</TabsTrigger>}
          {isSuper && <TabsTrigger value="queue">Admin · Applications</TabsTrigger>}
        </TabsList>

        {!account && (
          <TabsContent value="apply"><ApplySection app={myApp} workspaceId={currentWorkspaceId} /></TabsContent>
        )}
        {account && (
          <>
            <TabsContent value="dashboard"><DashboardSection account={account} /></TabsContent>
            <TabsContent value="branding"><BrandingSection account={account} /></TabsContent>
            <TabsContent value="customers"><CustomersSection account={account} /></TabsContent>
          </>
        )}
        {isSuper && <TabsContent value="queue"><AdminQueue /></TabsContent>}
      </Tabs>
    </div>
  );
}

function ApplySection({ app, workspaceId }: { app: any; workspaceId: string | null }) {
  const qc = useQueryClient();
  const { data: tiers = [] } = useQuery({
    queryKey: ["reseller-tiers"],
    queryFn: async () => {
      const { data } = await supabase.from("plan_templates").select("*").eq("is_reseller", true).eq("is_active", true).order("price_monthly");
      return data ?? [];
    },
  });
  const [form, setForm] = useState({
    business_name: "",
    brand_name: "",
    contact_email: "",
    contact_phone: "",
    website: "",
    country: "",
    requested_plan_template_id: "",
    notes: "",
  });

  async function submit() {
    if (!workspaceId) return;
    if (!form.business_name.trim()) return toast.error("Business name required");
    const { data: u } = await supabase.auth.getUser();
    if (!u.user) return;
    const { error } = await supabase.from("reseller_applications").insert({
      ...form,
      requested_plan_template_id: form.requested_plan_template_id || null,
      workspace_id: workspaceId,
      applicant_id: u.user.id,
    });
    if (error) return toast.error(error.message);
    toast.success("Application submitted");
    qc.invalidateQueries({ queryKey: ["reseller-app"] });
  }

  if (app && app.status === "pending") {
    return (
      <Card className="p-8 text-center">
        <Badge className="mb-3">Pending review</Badge>
        <p className="font-medium">Your reseller application is being reviewed.</p>
        <p className="text-sm text-muted-foreground mt-1">We'll notify you once a super admin approves it.</p>
      </Card>
    );
  }
  if (app && app.status === "rejected") {
    return (
      <Card className="p-8 text-center">
        <Badge variant="destructive" className="mb-3">Rejected</Badge>
        <p className="font-medium">Your application was not approved.</p>
        {app.admin_notes && <p className="text-sm text-muted-foreground mt-1">{app.admin_notes}</p>}
      </Card>
    );
  }

  return (
    <Card className="p-6 max-w-2xl">
      <h2 className="font-semibold text-lg mb-1">Apply to become a reseller</h2>
      <p className="text-sm text-muted-foreground mb-4">Tell us about your business. A super admin will review your application.</p>
      <div className="grid gap-3">
        <div className="grid grid-cols-2 gap-3">
          <div><Label>Business name *</Label><Input value={form.business_name} onChange={(e) => setForm({ ...form, business_name: e.target.value })} /></div>
          <div><Label>Brand name (white-label)</Label><Input value={form.brand_name} onChange={(e) => setForm({ ...form, brand_name: e.target.value })} /></div>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div><Label>Contact email</Label><Input type="email" value={form.contact_email} onChange={(e) => setForm({ ...form, contact_email: e.target.value })} /></div>
          <div><Label>Contact phone</Label><Input value={form.contact_phone} onChange={(e) => setForm({ ...form, contact_phone: e.target.value })} /></div>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div><Label>Website</Label><Input value={form.website} onChange={(e) => setForm({ ...form, website: e.target.value })} placeholder="https://" /></div>
          <div><Label>Country</Label><Input value={form.country} onChange={(e) => setForm({ ...form, country: e.target.value })} /></div>
        </div>
        <div>
          <Label>Reseller tier you're interested in</Label>
          <Select value={form.requested_plan_template_id} onValueChange={(v) => setForm({ ...form, requested_plan_template_id: v })}>
            <SelectTrigger><SelectValue placeholder="Select a tier" /></SelectTrigger>
            <SelectContent>
              {tiers.map((t: any) => (
                <SelectItem key={t.id} value={t.id}>{t.name} — ₹{Number(t.price_monthly).toLocaleString()}/mo</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label>Why do you want to become a reseller?</Label>
          <Textarea value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} rows={4} />
        </div>
        <Button onClick={submit} className="w-fit">Submit application</Button>
      </div>
    </Card>
  );
}

function DashboardSection({ account }: { account: any }) {
  const { data: customers = [] } = useQuery({
    queryKey: ["reseller-customers", account.workspace_id],
    queryFn: async () => {
      const { data } = await supabase.from("reseller_customers").select("*").eq("reseller_workspace_id", account.workspace_id);
      return data ?? [];
    },
  });
  const totalCommission = customers.reduce((s: number, c: any) => s + Number(c.commission_amount || 0), 0);
  const totalRevenue = customers.reduce((s: number, c: any) => s + Number(c.monthly_price || 0), 0);
  const active = customers.filter((c: any) => c.status === "active").length;

  return (
    <div className="space-y-4">
      <div className="grid gap-4 sm:grid-cols-4">
        <Stat label="Brand" value={account.brand_name} icon={<Palette className="h-4 w-4" />} />
        <Stat label="Active customers" value={`${active} / ${account.max_customers === -1 ? "∞" : account.max_customers}`} icon={<Users className="h-4 w-4" />} />
        <Stat label="Monthly revenue" value={`₹${totalRevenue.toLocaleString()}`} />
        <Stat label={`Commission (${account.commission_pct}%)`} value={`₹${totalCommission.toLocaleString()}`} />
      </div>
      <Card className="p-5">
        <p className="text-sm font-medium mb-2">Your reseller account</p>
        <div className="grid sm:grid-cols-2 gap-3 text-sm">
          <Row label="Status" value={<Badge>{account.status}</Badge>} />
          <Row label="White-label" value={account.white_label ? "Enabled" : "Disabled"} />
          <Row label="Custom domain" value={account.custom_domain || (account.allow_custom_domain ? "Not set" : "Not in plan")} />
          <Row label="Support email" value={account.support_email || "—"} />
        </div>
      </Card>
    </div>
  );
}

function Stat({ label, value, icon }: { label: string; value: any; icon?: React.ReactNode }) {
  return (
    <Card className="p-4">
      <div className="text-xs text-muted-foreground flex items-center gap-1">{icon}{label}</div>
      <div className="text-xl font-bold mt-1 truncate">{value}</div>
    </Card>
  );
}

function Row({ label, value }: { label: string; value: any }) {
  return (
    <div className="flex items-center justify-between border-b pb-2 last:border-0">
      <span className="text-muted-foreground">{label}</span>
      <span className="font-medium">{value}</span>
    </div>
  );
}

function BrandingSection({ account }: { account: any }) {
  const qc = useQueryClient();
  const saveFn = useServerFn(updateMyResellerBranding);
  const signFn = useServerFn(signResellerLogoUrl);
  const [uploading, setUploading] = useState(false);
  const [logoPreview, setLogoPreview] = useState<string | null>(null);
  const [form, setForm] = useState({
    brand_name: account.brand_name || "",
    primary_color: account.primary_color || "#3b82f6",
    support_email: account.support_email || "",
    custom_domain: account.custom_domain || "",
    white_label: account.white_label,
    logo_path: account.logo_path || null,
  });

  // Resolve signed preview for stored logo
  useEffect(() => {
    if (form.logo_path) {
      signFn({ data: { path: form.logo_path } }).then((r) => setLogoPreview(r.url)).catch(() => {});
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function handleLogoUpload(file: File) {
    if (!file) return;
    if (file.size > 2 * 1024 * 1024) return toast.error("Logo must be under 2MB");
    setUploading(true);
    try {
      const ext = file.name.split(".").pop() || "png";
      const path = `${account.workspace_id}/logo-${Date.now()}.${ext}`;
      const { error } = await supabase.storage.from("reseller-logos").upload(path, file, {
        cacheControl: "3600", upsert: false, contentType: file.type,
      });
      if (error) throw error;
      // delete old logo
      if (form.logo_path) {
        await supabase.storage.from("reseller-logos").remove([form.logo_path]).catch(() => {});
      }
      const signed = await signFn({ data: { path } });
      setLogoPreview(signed.url);
      setForm((f) => ({ ...f, logo_path: path }));
      toast.success("Logo uploaded");
    } catch (e: any) {
      toast.error(e.message || "Upload failed");
    } finally {
      setUploading(false);
    }
  }

  async function save() {
    try {
      await saveFn({ data: { workspace_id: account.workspace_id, ...form } });
      toast.success("Branding saved");
      qc.invalidateQueries({ queryKey: ["reseller-account"] });
    } catch (e: any) {
      toast.error(e.message);
    }
  }

  const previewHost = typeof window !== "undefined" ? window.location.hostname.replace(/^[^.]+\./, "") : "yourapp.com";

  return (
    <div className="grid lg:grid-cols-3 gap-6 max-w-5xl">
      <Card className="p-6 lg:col-span-2">
        <h2 className="font-semibold text-lg mb-1 flex items-center gap-2"><Globe className="h-5 w-5" />White-label settings</h2>
        <p className="text-sm text-muted-foreground mb-4">How your customers see your branded experience.</p>
        <div className="grid gap-4">
          <div className="grid grid-cols-2 gap-3">
            <div><Label>Brand name</Label><Input value={form.brand_name} onChange={(e) => setForm({ ...form, brand_name: e.target.value })} /></div>
            <div><Label>Support email</Label><Input type="email" value={form.support_email} onChange={(e) => setForm({ ...form, support_email: e.target.value })} /></div>
          </div>

          <div>
            <Label>Brand logo</Label>
            <div className="flex items-center gap-3 mt-1">
              <div className="h-16 w-16 rounded-lg border bg-muted/30 flex items-center justify-center overflow-hidden">
                {logoPreview ? (
                  <img src={logoPreview} alt="Logo" className="h-full w-full object-contain" />
                ) : (
                  <Palette className="h-5 w-5 text-muted-foreground" />
                )}
              </div>
              <div className="flex-1 space-y-1">
                <label className="inline-flex items-center gap-2 cursor-pointer">
                  <Button type="button" size="sm" variant="outline" disabled={uploading} asChild>
                    <span>
                      {uploading ? <Loader2 className="h-3.5 w-3.5 mr-1 animate-spin" /> : <Upload className="h-3.5 w-3.5 mr-1" />}
                      {form.logo_path ? "Replace logo" : "Upload logo"}
                    </span>
                  </Button>
                  <input
                    type="file"
                    accept="image/png,image/jpeg,image/svg+xml,image/webp"
                    className="hidden"
                    onChange={(e) => e.target.files?.[0] && handleLogoUpload(e.target.files[0])}
                  />
                </label>
                <p className="text-xs text-muted-foreground">PNG, JPG, SVG or WebP up to 2 MB. Square works best.</p>
              </div>
              {form.logo_path && (
                <Button size="sm" variant="ghost" onClick={async () => {
                  if (form.logo_path) await supabase.storage.from("reseller-logos").remove([form.logo_path]).catch(() => {});
                  setForm((f) => ({ ...f, logo_path: null })); setLogoPreview(null);
                }}>
                  <Trash2 className="h-3.5 w-3.5" />
                </Button>
              )}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label>Primary color</Label>
              <div className="flex gap-2">
                <Input type="color" value={form.primary_color} onChange={(e) => setForm({ ...form, primary_color: e.target.value })} className="w-16 h-10 p-1" />
                <Input value={form.primary_color} onChange={(e) => setForm({ ...form, primary_color: e.target.value })} />
              </div>
            </div>
            <div>
              <Label>Subdomain</Label>
              <div className="flex items-center gap-1">
                <Input value={account.subdomain || ""} disabled placeholder="assigned by admin" />
                <span className="text-xs text-muted-foreground whitespace-nowrap">.{previewHost}</span>
              </div>
              <p className="text-xs text-muted-foreground mt-1">Set by a super admin.</p>
            </div>
          </div>

          <div>
            <Label>Custom domain {!account.allow_custom_domain && <span className="text-xs text-muted-foreground">(not in plan)</span>}</Label>
            <Input
              value={form.custom_domain || ""}
              disabled={!account.allow_custom_domain}
              onChange={(e) => setForm({ ...form, custom_domain: e.target.value })}
              placeholder="app.yourbrand.com"
            />
            {account.allow_custom_domain && (
              <p className="text-xs text-muted-foreground mt-1">
                After saving, point a CNAME from <code className="font-mono">{form.custom_domain || "app.yourbrand.com"}</code> to <code className="font-mono">{previewHost}</code>. SSL is provisioned automatically.
              </p>
            )}
          </div>

          <div className="flex items-center justify-between rounded-lg border p-3">
            <div>
              <Label>Enable white-label</Label>
              <p className="text-xs text-muted-foreground">Hide our branding from your customers' experience.</p>
            </div>
            <Switch checked={form.white_label} onCheckedChange={(c) => setForm({ ...form, white_label: c })} />
          </div>
          <Button onClick={save} className="w-fit">Save branding</Button>
        </div>
      </Card>

      <Card className="p-5">
        <p className="text-xs uppercase text-muted-foreground tracking-wide mb-2">Live preview</p>
        <div
          className="rounded-lg border p-4 text-center"
          style={{ background: `linear-gradient(135deg, ${form.primary_color}15, transparent)`, borderColor: `${form.primary_color}40` }}
        >
          {logoPreview ? (
            <img src={logoPreview} alt="logo" className="h-12 mx-auto object-contain mb-2" />
          ) : (
            <div className="h-12 w-12 rounded-lg mx-auto mb-2" style={{ background: form.primary_color }} />
          )}
          <p className="font-semibold">{form.brand_name || "Your brand"}</p>
          <p className="text-xs text-muted-foreground">{account.subdomain ? `${account.subdomain}.${previewHost}` : "subdomain pending"}</p>
          {form.custom_domain && account.allow_custom_domain && (
            <p className="text-xs mt-1" style={{ color: form.primary_color }}>{form.custom_domain}</p>
          )}
        </div>
      </Card>
    </div>
  );
}

function CustomersSection({ account }: { account: any }) {
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const { data: customers = [] } = useQuery({
    queryKey: ["reseller-customers", account.workspace_id],
    queryFn: async () => {
      const { data } = await supabase.from("reseller_customers").select("*").eq("reseller_workspace_id", account.workspace_id).order("created_at", { ascending: false });
      return data ?? [];
    },
  });

  async function remove(id: string) {
    if (!confirm("Remove this customer?")) return;
    const { error } = await supabase.from("reseller_customers").delete().eq("id", id);
    if (error) return toast.error(error.message);
    toast.success("Removed");
    qc.invalidateQueries({ queryKey: ["reseller-customers"] });
  }

  const limitReached = account.max_customers !== -1 && customers.length >= account.max_customers;

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <p className="text-sm text-muted-foreground">{customers.length} {account.max_customers === -1 ? "" : `of ${account.max_customers}`} customers</p>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild><Button disabled={limitReached}><Plus className="h-4 w-4 mr-1" />Add customer</Button></DialogTrigger>
          <AddCustomerDialog account={account} onSaved={() => { setOpen(false); qc.invalidateQueries({ queryKey: ["reseller-customers"] }); }} />
        </Dialog>
      </div>
      {customers.length === 0 ? (
        <Card className="p-8 text-center text-sm text-muted-foreground">No customers yet. Onboard your first customer to start earning commissions.</Card>
      ) : (
        <Card className="divide-y">
          {customers.map((c: any) => (
            <div key={c.id} className="p-4 space-y-2">
              <div className="flex items-center gap-4">
                <div className="flex-1 min-w-0">
                  <p className="font-medium truncate">{c.customer_name}</p>
                  <p className="text-xs text-muted-foreground truncate">{c.customer_email || c.customer_phone}</p>
                </div>
                <div className="text-right">
                  <p className="text-sm font-medium">{c.currency} {Number(c.monthly_price).toLocaleString()}/mo</p>
                  <p className="text-xs text-muted-foreground">Commission: {c.currency} {Number(c.commission_amount).toLocaleString()}</p>
                </div>
                <Badge variant={c.status === "active" ? "default" : "secondary"}>{c.status}</Badge>
                <Button size="sm" variant="ghost" onClick={() => remove(c.id)}><Trash2 className="h-3.5 w-3.5" /></Button>
              </div>
              <LicenseKeyRow customer={c} />
            </div>
          ))}
        </Card>
      )}
    </div>
  );
}

function LicenseKeyRow({ customer }: { customer: any }) {
  const qc = useQueryClient();
  const regenFn = useServerFn(regenerateCustomerLicense);
  const statusFn = useServerFn(setCustomerLicenseStatus);
  const [busy, setBusy] = useState(false);
  const key = customer.license_key || "—";
  const status = customer.license_status || "active";
  const expiresAt = customer.license_expires_at ? new Date(customer.license_expires_at).toLocaleDateString() : null;
  const isRevoked = status === "revoked";

  async function copy() {
    if (!customer.license_key) return;
    await navigator.clipboard.writeText(customer.license_key);
    toast.success("License key copied");
  }
  async function regen() {
    if (!confirm("Regenerate license key? The old key will stop working.")) return;
    setBusy(true);
    try {
      await regenFn({ data: { customer_id: customer.id } });
      toast.success("New license key issued");
      qc.invalidateQueries({ queryKey: ["reseller-customers"] });
    } catch (e: any) { toast.error(e.message); } finally { setBusy(false); }
  }
  async function toggleStatus() {
    setBusy(true);
    try {
      await statusFn({ data: { customer_id: customer.id, status: isRevoked ? "active" : "revoked" } });
      toast.success(isRevoked ? "License re-activated" : "License revoked");
      qc.invalidateQueries({ queryKey: ["reseller-customers"] });
    } catch (e: any) { toast.error(e.message); } finally { setBusy(false); }
  }

  return (
    <div className="flex items-center gap-2 rounded-md bg-muted/40 border px-3 py-2">
      <KeyRound className="h-3.5 w-3.5 text-muted-foreground" />
      <code className="text-xs font-mono flex-1 truncate" title={key}>{key}</code>
      <Badge variant={isRevoked ? "destructive" : status === "expired" ? "secondary" : "default"} className="text-[10px]">{status}</Badge>
      {expiresAt && <span className="text-xs text-muted-foreground">exp {expiresAt}</span>}
      <Button size="sm" variant="ghost" onClick={copy} title="Copy"><Copy className="h-3.5 w-3.5" /></Button>
      <Button size="sm" variant="ghost" onClick={regen} disabled={busy} title="Regenerate"><RefreshCw className="h-3.5 w-3.5" /></Button>
      <Button size="sm" variant="ghost" onClick={toggleStatus} disabled={busy} title={isRevoked ? "Re-activate" : "Revoke"}>
        {isRevoked ? <Check className="h-3.5 w-3.5" /> : <Ban className="h-3.5 w-3.5" />}
      </Button>
    </div>
  );
}

function AddCustomerDialog({ account, onSaved }: { account: any; onSaved: () => void }) {
  const [form, setForm] = useState({
    customer_name: "",
    customer_email: "",
    customer_phone: "",
    monthly_price: "0",
    currency: "INR",
  });

  async function save() {
    if (!form.customer_name.trim()) return toast.error("Name required");
    const price = Number(form.monthly_price) || 0;
    const commission = +(price * Number(account.commission_pct) / 100).toFixed(2);
    const { error } = await supabase.from("reseller_customers").insert({
      reseller_workspace_id: account.workspace_id,
      customer_name: form.customer_name,
      customer_email: form.customer_email || null,
      customer_phone: form.customer_phone || null,
      monthly_price: price,
      currency: form.currency,
      commission_amount: commission,
    });
    if (error) return toast.error(error.message);
    toast.success("Customer added");
    onSaved();
  }

  return (
    <DialogContent>
      <DialogHeader><DialogTitle>Onboard a customer</DialogTitle></DialogHeader>
      <div className="grid gap-3">
        <div><Label>Customer name *</Label><Input value={form.customer_name} onChange={(e) => setForm({ ...form, customer_name: e.target.value })} /></div>
        <div className="grid grid-cols-2 gap-3">
          <div><Label>Email</Label><Input type="email" value={form.customer_email} onChange={(e) => setForm({ ...form, customer_email: e.target.value })} /></div>
          <div><Label>Phone</Label><Input value={form.customer_phone} onChange={(e) => setForm({ ...form, customer_phone: e.target.value })} /></div>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div><Label>Monthly price</Label><Input type="number" value={form.monthly_price} onChange={(e) => setForm({ ...form, monthly_price: e.target.value })} /></div>
          <div>
            <Label>Currency</Label>
            <Select value={form.currency} onValueChange={(v) => setForm({ ...form, currency: v })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="INR">INR</SelectItem>
                <SelectItem value="USD">USD</SelectItem>
                <SelectItem value="AED">AED</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        <p className="text-xs text-muted-foreground">Commission ({account.commission_pct}%): {form.currency} {(Number(form.monthly_price || 0) * Number(account.commission_pct) / 100).toFixed(2)}</p>
      </div>
      <DialogFooter><Button onClick={save}>Add</Button></DialogFooter>
    </DialogContent>
  );
}

function AdminQueue() {
  const qc = useQueryClient();
  const { data: apps = [] } = useQuery({
    queryKey: ["all-reseller-apps"],
    queryFn: async () => {
      const { data } = await supabase.from("reseller_applications").select("*").order("created_at", { ascending: false });
      return data ?? [];
    },
  });
  const { data: tiers = [] } = useQuery({
    queryKey: ["reseller-tiers-admin"],
    queryFn: async () => {
      const { data } = await supabase.from("plan_templates").select("*").eq("is_reseller", true);
      return data ?? [];
    },
  });

  async function approve(app: any) {
    const tier = tiers.find((t: any) => t.id === app.requested_plan_template_id);
    const maxCust = (tier?.limits as any)?.reseller_max_customers ?? 10;
    const { data: u } = await supabase.auth.getUser();
    const { error: e1 } = await supabase.from("reseller_accounts").upsert({
      workspace_id: app.workspace_id,
      brand_name: app.brand_name || app.business_name,
      support_email: app.contact_email,
      plan_template_id: app.requested_plan_template_id,
      max_customers: maxCust,
      allow_custom_domain: maxCust !== 10,
      approved_by: u.user?.id,
      status: "active",
    });
    if (e1) return toast.error(e1.message);
    await supabase.from("reseller_applications").update({
      status: "approved",
      reviewed_by: u.user?.id,
      reviewed_at: new Date().toISOString(),
    }).eq("id", app.id);
    toast.success("Reseller approved");
    qc.invalidateQueries({ queryKey: ["all-reseller-apps"] });
  }

  async function reject(app: any) {
    const notes = prompt("Reason for rejection (optional)") || "";
    const { data: u } = await supabase.auth.getUser();
    const { error } = await supabase.from("reseller_applications").update({
      status: "rejected",
      reviewed_by: u.user?.id,
      reviewed_at: new Date().toISOString(),
      admin_notes: notes,
    }).eq("id", app.id);
    if (error) return toast.error(error.message);
    toast.success("Rejected");
    qc.invalidateQueries({ queryKey: ["all-reseller-apps"] });
  }

  if (apps.length === 0) return <Card className="p-8 text-center text-sm text-muted-foreground">No reseller applications yet.</Card>;

  return (
    <Card className="divide-y">
      {apps.map((a: any) => (
        <div key={a.id} className="p-4">
          <div className="flex items-start justify-between gap-4">
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-2">
                <p className="font-medium">{a.business_name}</p>
                <Badge variant={a.status === "approved" ? "default" : a.status === "rejected" ? "destructive" : "secondary"}>{a.status}</Badge>
              </div>
              <p className="text-xs text-muted-foreground">{a.contact_email} · {a.website || "no website"} · {a.country}</p>
              {a.brand_name && <p className="text-xs">Brand: <span className="font-medium">{a.brand_name}</span></p>}
              <p className="text-xs mt-1">Tier: {tiers.find((t: any) => t.id === a.requested_plan_template_id)?.name || "—"}</p>
              {a.notes && <p className="text-sm mt-2 text-muted-foreground">{a.notes}</p>}
            </div>
            {a.status === "pending" && (
              <div className="flex gap-1">
                <Button size="sm" onClick={() => approve(a)}><Check className="h-4 w-4 mr-1" />Approve</Button>
                <Button size="sm" variant="outline" onClick={() => reject(a)}><X className="h-4 w-4 mr-1" />Reject</Button>
              </div>
            )}
          </div>
        </div>
      ))}
    </Card>
  );
}
