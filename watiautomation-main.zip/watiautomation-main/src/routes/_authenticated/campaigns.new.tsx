import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { launchCampaign, scheduleCampaign } from "@/lib/whatsapp.functions";
import { useWorkspace } from "@/lib/workspace-context";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Switch } from "@/components/ui/switch";
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/select";
import { toast } from "sonner";
import { ArrowLeft, Send, Loader2, Clock, Upload, Sparkles } from "lucide-react";
import { fieldByKey, type VariableMappingEntry } from "@/lib/wa-template-fields";

// Customer-scoped fields are auto-resolved per recipient at send time
// (from the contact row). The sender doesn't type a value for these.
const AUTO_PER_RECIPIENT = new Set(["customer_name", "customer_phone", "customer_email"]);

export const Route = createFileRoute("/_authenticated/campaigns/new")({
  component: NewCampaign,
  head: () => ({ meta: [{ title: "New campaign — Slice" }] }),
});


function NewCampaign() {
  const navigate = useNavigate();
  const { currentWorkspaceId } = useWorkspace();
  const launchFn = useServerFn(launchCampaign);
  const scheduleFn = useServerFn(scheduleCampaign);
  const [name, setName] = useState("");
  const [templateId, setTemplateId] = useState<string>("");
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [groupFilter, setGroupFilter] = useState<string>("");
  const [variables, setVariables] = useState<string[]>([]);
  const [headerMediaUrl, setHeaderMediaUrl] = useState<string>("");
  const [uploadingMedia, setUploadingMedia] = useState(false);
  const [loading, setLoading] = useState(false);
  const [scheduleLater, setScheduleLater] = useState(false);
  const [scheduleAt, setScheduleAt] = useState<string>("");


  const { data: templates = [] } = useQuery({
    queryKey: ["templates-approved", currentWorkspaceId],
    enabled: !!currentWorkspaceId,
    queryFn: async () =>
      (await supabase.from("templates").select("*")
        .eq("workspace_id", currentWorkspaceId!)
        .eq("status", "APPROVED")).data ?? [],
  });

  const { data: contacts = [] } = useQuery({
    queryKey: ["contacts-all", currentWorkspaceId],
    enabled: !!currentWorkspaceId,
    queryFn: async () => {
      // Paginate: PostgREST caps responses at 1000 rows. Without this, group
      // members whose contact rows fall past the first 1000 (by name order)
      // are missing from the recipient list even though they're selected.
      const PAGE = 1000;
      const all: { id: string; name: string; phone: string }[] = [];
      for (let from = 0; ; from += PAGE) {
        const { data, error } = await supabase
          .from("contacts")
          .select("id,name,phone")
          .eq("workspace_id", currentWorkspaceId!)
          .order("name")
          .range(from, from + PAGE - 1);
        if (error) throw error;
        const rows = data ?? [];
        all.push(...rows);
        if (rows.length < PAGE) break;
      }
      return all;
    },
  });

  const { data: groups = [] } = useQuery({
    queryKey: ["contact-groups-all", currentWorkspaceId],
    enabled: !!currentWorkspaceId,
    queryFn: async () =>
      (await supabase.from("contact_groups").select("id,name")
        .eq("workspace_id", currentWorkspaceId!)
        .order("name")).data ?? [],
  });

  const { data: groupMembers = [] } = useQuery({
    queryKey: ["contact-group-members-all", currentWorkspaceId],
    enabled: !!currentWorkspaceId,
    queryFn: async () => {
      // Paginate: PostgREST caps responses at 1000 rows, and workspaces with
      // many groups can easily exceed that — causing some groups to appear
      // empty in the campaign recipient selector.
      const PAGE = 1000;
      const all: { group_id: string; contact_id: string }[] = [];
      for (let from = 0; ; from += PAGE) {
        const { data, error } = await supabase
          .from("contact_group_members")
          .select("group_id,contact_id")
          .eq("workspace_id", currentWorkspaceId!)
          .range(from, from + PAGE - 1);
        if (error) throw error;
        const rows = data ?? [];
        all.push(...rows);
        if (rows.length < PAGE) break;
      }
      return all;
    },
  });

  function selectGroup(groupId: string) {
    if (!groupId) return;
    const ids = groupMembers.filter((m: any) => m.group_id === groupId).map((m: any) => m.contact_id);
    if (ids.length === 0) {
      toast.info("This group has no contacts");
      return;
    }
    setGroupFilter(groupId);
    setSelected(new Set(ids));
    const g = groups.find((x: any) => x.id === groupId);
    toast.success(`Showing ${ids.length} contact(s) from "${g?.name}"`);
  }

  function clearGroupFilter() {
    setGroupFilter("");
    setSelected(new Set());
  }

  const visibleContacts = useMemo(() => {
    if (!groupFilter) return contacts;
    const ids = new Set(
      groupMembers.filter((m: any) => m.group_id === groupFilter).map((m: any) => m.contact_id),
    );
    return contacts.filter((c: any) => ids.has(c.id));
  }, [contacts, groupMembers, groupFilter]);

  const template = useMemo(() => templates.find((t: any) => t.id === templateId), [templates, templateId]);

  const headerInfo = useMemo(() => {
    const comps: any[] = Array.isArray(template?.components) ? (template!.components as any[]) : [];
    const h: any = comps.find((c: any) => String(c?.type).toUpperCase() === "HEADER");
    const format = String(h?.format || "").toUpperCase();
    if (["IMAGE", "VIDEO", "DOCUMENT"].includes(format)) {
      return { needsMedia: true, format: format as "IMAGE" | "VIDEO" | "DOCUMENT" };
    }
    return { needsMedia: false, format: "" as const };
  }, [template]);

  function toggle(id: string) {
    const next = new Set(selected);
    next.has(id) ? next.delete(id) : next.add(id);
    setSelected(next);
  }

  function toggleAll() {
    if (selected.size === visibleContacts.length) setSelected(new Set());
    else setSelected(new Set(visibleContacts.map((c: any) => c.id)));
  }

  async function uploadHeaderMedia(file: File) {
    if (!currentWorkspaceId) return;

    const expectedType = headerInfo.format.toLowerCase();
    if (headerInfo.format === "IMAGE" && !file.type.startsWith("image/")) {
      return toast.error("Please upload an image file");
    }
    if (headerInfo.format === "VIDEO" && !file.type.startsWith("video/")) {
      return toast.error("Please upload a video file");
    }

    // WhatsApp Cloud API media size limits (Meta error #131053 if exceeded)
    const sizeLimits: Record<string, { bytes: number; label: string }> = {
      IMAGE: { bytes: 5 * 1024 * 1024, label: "5 MB" },
      VIDEO: { bytes: 16 * 1024 * 1024, label: "16 MB" },
      DOCUMENT: { bytes: 100 * 1024 * 1024, label: "100 MB" },
    };
    const limit = sizeLimits[headerInfo.format];
    if (limit && file.size > limit.bytes) {
      return toast.error(
        `${headerInfo.format} too large (${(file.size / 1024 / 1024).toFixed(1)} MB). WhatsApp limit is ${limit.label}. Please compress and retry.`,
      );
    }
    if (headerInfo.format === "VIDEO" && !/mp4|3gpp/i.test(file.type)) {
      return toast.error("WhatsApp only accepts MP4 (H.264 + AAC) or 3GPP video. Please re-encode and retry.");
    }


    setUploadingMedia(true);
    try {
      const ext = file.name.split(".").pop() || expectedType;
      const path = `${currentWorkspaceId}/campaign-headers/${crypto.randomUUID()}.${ext}`;
      const { error } = await supabase.storage.from("chat-media").upload(path, file, {
        contentType: file.type || "application/octet-stream",
        upsert: false,
      });
      if (error) throw error;

      const { data } = supabase.storage.from("chat-media").getPublicUrl(path);
      setHeaderMediaUrl(data.publicUrl);
      toast.success(`${headerInfo.format.toLowerCase()} uploaded`);
    } catch (err: any) {
      toast.error(err.message || "Upload failed");
    } finally {
      setUploadingMedia(false);
    }
  }

  async function launch() {
    if (!currentWorkspaceId) return;
    if (!name.trim()) return toast.error("Name your campaign");
    if (!templateId) return toast.error("Pick a template");
    if (selected.size === 0) return toast.error("Select at least one contact");
    const varsCount = template?.variables_count ?? 0;
    const mapping: VariableMappingEntry[] = Array.isArray(template?.variable_mapping)
      ? (template!.variable_mapping as unknown as VariableMappingEntry[])
      : [];
    for (let i = 0; i < varsCount; i++) {
      const entry = mapping.find((e: any) => Number(e?.index) === i + 1);
      const isAuto = entry && AUTO_PER_RECIPIENT.has(entry.field);
      const isLockedStatic = entry?.field === "static_text" && (entry?.static_value ?? "").trim().length > 0;
      // {{1}} auto-fills from the recipient's contact name (their WhatsApp
      // profile name) when unmapped and left blank — skip the "required" check.
      const isFirstAutoName = !entry && i === 0;
      if (isAuto || isLockedStatic || isFirstAutoName) continue;
      if (!(variables[i] || "").trim()) return toast.error(`Fill value for {{${i + 1}}}`);
    }

    if (headerInfo.needsMedia) {
      if (!headerMediaUrl.trim()) {
        return toast.error(`This template's header requires a ${headerInfo.format.toLowerCase()} URL`);
      }
      try { new URL(headerMediaUrl); } catch { return toast.error("Header media URL is invalid"); }
    }

    let scheduledISO: string | null = null;
    if (scheduleLater) {
      if (!scheduleAt) return toast.error("Pick a date & time");
      const d = new Date(scheduleAt);
      if (isNaN(d.getTime())) return toast.error("Invalid date");
      if (d.getTime() <= Date.now()) return toast.error("Scheduled time must be in the future");
      scheduledISO = d.toISOString();
    }

    setLoading(true);
    try {
      // Normalize variables so the server always receives a string per slot.
      // Missing slots (auto-filled or untyped) become "" — a bare {{N}}
      // placeholder the user typed also becomes "" so the executor auto-fills.
      // Sending `undefined` here fails z.array(z.string()) validation on the
      // server and surfaces as a generic "Bad Request" toast.
      const cleanedVariables = Array.from({ length: varsCount }).map((_, i) => {
        const raw = String(variables[i] ?? "").trim();
        return /^\{\{\s*\d+\s*\}\}$/.test(raw) ? "" : raw;
      });
      const isFullGroupSelection = !!groupFilter
        && visibleContacts.length > 0
        && selected.size === visibleContacts.length
        && visibleContacts.every((c: any) => selected.has(c.id));
      const payload = {
        workspace_id: currentWorkspaceId,
        name,
        template_id: templateId,
        contact_ids: isFullGroupSelection ? [] : Array.from(selected),
        ...(isFullGroupSelection ? { group_id: groupFilter } : {}),
        variables: cleanedVariables,
        ...(headerInfo.needsMedia ? { header_media_url: headerMediaUrl.trim() } : {}),
      };
      if (scheduledISO) {
        await scheduleFn({ data: { ...payload, scheduled_at: scheduledISO } });
        toast.success(`Campaign scheduled for ${new Date(scheduledISO).toLocaleString()}`);
      } else {
        const res = await launchFn({ data: payload });
        toast.success(`Campaign sent: ${res.sent} delivered, ${res.failed} failed`);
      }
      navigate({ to: "/campaigns" });
    } catch (e: any) {
      toast.error(e.message);
    } finally {
      setLoading(false);
    }
  }

  return (

    <div className="space-y-6 max-w-4xl">
      <Link to="/campaigns" className="inline-flex items-center text-sm text-muted-foreground hover:text-foreground">
        <ArrowLeft className="mr-1 h-4 w-4" /> Back to campaigns
      </Link>

      <div>
        <h1 className="font-display text-3xl font-bold">New campaign</h1>
        <p className="text-muted-foreground">Send a template to selected contacts</p>
      </div>

      <Card className="p-6 space-y-5">
        <div className="space-y-2">
          <Label>Campaign name</Label>
          <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Black Friday outreach" maxLength={120} />
        </div>

        <div className="space-y-2">
          <Label>Template</Label>
          <Select value={templateId} onValueChange={(v) => { setTemplateId(v); setVariables([]); setHeaderMediaUrl(""); }}>
            <SelectTrigger><SelectValue placeholder="Pick a template" /></SelectTrigger>
            <SelectContent>
              {templates.length === 0 ? (
                <div className="px-3 py-2 text-sm text-muted-foreground">
                  No approved templates. <Link to="/templates" className="text-primary underline">Sync first</Link>
                </div>
              ) : templates.map((t: any) => (
                <SelectItem key={t.id} value={t.id}>{t.meta_template_name} ({t.language})</SelectItem>
              ))}
            </SelectContent>
          </Select>

          {template?.body && (
            <div className="mt-3 p-3 rounded-lg bg-secondary/50 border text-sm whitespace-pre-wrap">{template.body}</div>
          )}
        </div>

        {template && template.variables_count > 0 && (() => {
          const mapping: VariableMappingEntry[] = Array.isArray(template.variable_mapping)
            ? (template.variable_mapping as unknown as VariableMappingEntry[])
            : [];
          return (
            <div className="space-y-2">
              <Label>Variables</Label>
              {Array.from({ length: template.variables_count }).map((_, i) => {
                const entry = mapping.find((e: any) => Number(e?.index) === i + 1);
                const field = entry ? fieldByKey(entry.field) : null;
                const isAuto = !!entry && AUTO_PER_RECIPIENT.has(entry.field);
                const isStatic = entry?.field === "static_text";
                const lockedStatic = isStatic && (entry?.static_value ?? "").trim().length > 0;

                if (isAuto && field) {
                  return (
                    <div key={i} className="flex items-center gap-2 rounded-md border bg-muted/40 px-3 py-2 text-sm">
                      <Sparkles className="h-4 w-4 text-primary shrink-0" />
                      <span className="font-mono text-xs text-muted-foreground">{`{{${i + 1}}}`}</span>
                      <span>→</span>
                      <span className="font-medium">{field.label}</span>
                      <span className="ml-auto text-xs text-muted-foreground">Auto-filled per recipient</span>
                    </div>
                  );
                }
                if (lockedStatic) {
                  return (
                    <div key={i} className="flex items-center gap-2 rounded-md border bg-muted/40 px-3 py-2 text-sm">
                      <span className="font-mono text-xs text-muted-foreground">{`{{${i + 1}}}`}</span>
                      <span>→</span>
                      <span className="truncate">{entry!.static_value}</span>
                      <span className="ml-auto text-xs text-muted-foreground">Static (from template)</span>
                    </div>
                  );
                }
                // {{1}} auto-fills from the recipient's WhatsApp profile /
                // contact name unless the sender types an override.
                const isFirstAutoName = !entry && i === 0;
                return (
                  <div key={i} className="space-y-1">
                    {isFirstAutoName && (
                      <div className="flex items-center gap-2 rounded-md border bg-muted/40 px-3 py-2 text-sm">
                        <Sparkles className="h-4 w-4 text-primary shrink-0" />
                        <span className="font-mono text-xs text-muted-foreground">{`{{1}}`}</span>
                        <span>→</span>
                        <span className="font-medium">Customer name</span>
                        <span className="ml-auto text-xs text-muted-foreground">Auto-filled from contact (WhatsApp profile) name</span>
                      </div>
                    )}
                    <Input
                      placeholder={
                        isFirstAutoName
                          ? "Optional override (leave blank to use each contact's name)"
                          : field ? `${field.label} (e.g. ${field.sample || "value"})` : `{{${i + 1}}}`
                      }
                      value={variables[i] || ""}
                      onChange={(e) => {
                        const next = [...variables];
                        next[i] = e.target.value;
                        setVariables(next);
                      }}
                    />
                    {field && !isFirstAutoName && (
                      <p className="text-xs text-muted-foreground">
                        <span className="font-mono">{`{{${i + 1}}}`}</span> → {field.label} (same value for every recipient)
                      </p>
                    )}
                  </div>
                );
              })}
            </div>
          );
        })()}

        {template && headerInfo.needsMedia && (
          <div className="space-y-2">
            <Label>
              Header {headerInfo.format.toLowerCase()} URL
            </Label>
            <div className="flex flex-col gap-2 sm:flex-row">
              <Input
                type="url"
                placeholder={
                  headerInfo.format === "IMAGE"
                    ? "https://example.com/banner.jpg"
                    : headerInfo.format === "VIDEO"
                    ? "https://example.com/video.mp4"
                    : "https://example.com/file.pdf"
                }
                value={headerMediaUrl}
                onChange={(e) => setHeaderMediaUrl(e.target.value)}
              />
              <Button
                type="button"
                variant="outline"
                disabled={uploadingMedia}
                onClick={() => document.getElementById("campaign-header-media-upload")?.click()}
                className="shrink-0"
              >
                {uploadingMedia ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Upload className="mr-2 h-4 w-4" />}
                {uploadingMedia ? "Uploading" : "Upload"}
              </Button>
              <input
                id="campaign-header-media-upload"
                type="file"
                className="hidden"
                accept={
                  headerInfo.format === "IMAGE"
                    ? "image/*"
                    : headerInfo.format === "VIDEO"
                    ? "video/*"
                    : ".pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.txt"
                }
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (file) void uploadHeaderMedia(file);
                  e.target.value = "";
                }}
              />
            </div>
            <p className="text-xs text-muted-foreground">
              This template's header is a {headerInfo.format.toLowerCase()}. Upload the file or paste a public URL — it will be sent with every message.
            </p>
          </div>
        )}

        <div className="border-t pt-5 space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <Label className="flex items-center gap-2">
                <Clock className="h-4 w-4" /> Schedule for later
              </Label>
              <p className="text-xs text-muted-foreground mt-0.5">
                Queue this campaign and send it automatically at a future time.
              </p>
            </div>
            <Switch checked={scheduleLater} onCheckedChange={setScheduleLater} />
          </div>
          {scheduleLater && (
            <Input
              type="datetime-local"
              value={scheduleAt}
              onChange={(e) => setScheduleAt(e.target.value)}
              min={new Date(Date.now() + 60_000).toISOString().slice(0, 16)}
            />
          )}
        </div>
      </Card>


      <Card className="p-6">
        <div className="flex flex-wrap items-center justify-between gap-3 mb-3">
          <Label>Recipients ({selected.size} selected)</Label>
          <div className="flex items-center gap-2">
            <Select value={groupFilter} onValueChange={selectGroup}>
              <SelectTrigger className="w-56">
                <SelectValue placeholder="Filter by group…" />
              </SelectTrigger>
              <SelectContent>
                {groups.length === 0 ? (
                  <div className="px-3 py-2 text-sm text-muted-foreground">
                    No groups. <Link to="/contacts/groups" className="text-primary underline">Create one</Link>
                  </div>
                ) : groups.map((g: any) => {
                  const count = groupMembers.filter((m: any) => m.group_id === g.id).length;
                  return (
                    <SelectItem key={g.id} value={g.id}>{g.name} ({count})</SelectItem>
                  );
                })}
              </SelectContent>
            </Select>
            {groupFilter && (
              <Button variant="ghost" size="sm" onClick={clearGroupFilter}>
                Show all
              </Button>
            )}
            <Button variant="ghost" size="sm" onClick={toggleAll}>
              {selected.size === visibleContacts.length && visibleContacts.length > 0 ? "Deselect all" : "Select all"}
            </Button>
          </div>
        </div>
        {groupFilter && (
          <p className="text-xs text-muted-foreground mb-2">
            Showing contacts from “{groups.find((g: any) => g.id === groupFilter)?.name}” only.
          </p>
        )}
        <div className="max-h-96 overflow-y-auto divide-y rounded-lg border">
          {visibleContacts.length === 0 ? (
            <div className="p-6 text-center text-sm text-muted-foreground">
              {groupFilter ? "No contacts in this group." : (<>No contacts. <Link to="/contacts" className="text-primary underline">Add some</Link></>)}
            </div>
          ) : visibleContacts.map((c: any) => (
            <label key={c.id} className="flex items-center gap-3 p-3 hover:bg-muted/50 cursor-pointer">
              <Checkbox checked={selected.has(c.id)} onCheckedChange={() => toggle(c.id)} />
              <div className="flex-1">
                <p className="text-sm font-medium">{c.name}</p>
                <p className="text-xs text-muted-foreground">{c.phone}</p>
              </div>
            </label>
          ))}
        </div>

      </Card>

      <div className="flex justify-end gap-3">
        <Link to="/campaigns"><Button variant="outline">Cancel</Button></Link>
        <Button onClick={launch} disabled={loading || uploadingMedia} className="shadow-[var(--shadow-glow)]">
          {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : scheduleLater ? <Clock className="mr-2 h-4 w-4" /> : <Send className="mr-2 h-4 w-4" />}
          {scheduleLater ? `Schedule campaign (${selected.size})` : `Launch campaign (${selected.size})`}
        </Button>

      </div>
    </div>
  );
}
