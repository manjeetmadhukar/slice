import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import {
  BarChart, Bar, LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer,
  CartesianGrid, PieChart, Pie, Cell, Legend,
} from "recharts";
import {
  ArrowLeft, Send, CheckCheck, Check, Eye, XCircle, Clock, Download, Info, Play, MousePointerClick,
} from "lucide-react";
import { Tooltip as UITooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { resumeCampaign } from "@/lib/whatsapp.functions";
import { getCampaignButtonStats } from "@/lib/button-clicks.functions";
import { isMetaSuppressedDelivery } from "@/lib/whatsapp-delivery-status";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/campaigns/$id")({
  component: CampaignReport,
  head: () => ({ meta: [{ title: "Campaign report — Slice" }] }),
});

const COLORS = ["#3b82f6", "#10b981", "#8b5cf6", "#ef4444", "#f59e0b", "#06b6d4"];

function CampaignReport() {
  const { id } = Route.useParams();
  const [filter, setFilter] = useState<"all" | "sent" | "delivered" | "read" | "failed" | "suppressed" | "pending">("all");
  const [search, setSearch] = useState("");

  const { data: campaign } = useQuery({
    queryKey: ["campaign", id],
    queryFn: async () => {
      const { data, error } = await supabase.from("campaigns").select("*").eq("id", id).maybeSingle();
      if (error) throw error;
      return data;
    },
  });

  const buttonStatsFn = useServerFn(getCampaignButtonStats);
  const { data: buttonStats } = useQuery({
    queryKey: ["campaign-button-stats", id],
    queryFn: () => buttonStatsFn({ data: { campaignId: id } }),
  });

  const { data: recipients = [] } = useQuery({
    queryKey: ["campaign-recipients-full", id],
    queryFn: async () => {
      const { data } = await supabase
        .from("campaign_recipients")
        .select("phone,name,status,error,message_id,sent_at,delivered_at,read_at")
        .eq("campaign_id", id)
        .limit(5000);
      return data ?? [];
    },
  });

  const stats = useMemo(() => {
    const total = recipients.length;
    const sent = recipients.filter((r: any) => r.sent_at || ["sent", "delivered", "read"].includes(r.status)).length;
    const delivered = recipients.filter((r: any) => r.delivered_at || ["delivered", "read"].includes(r.status)).length;
    const read = recipients.filter((r: any) => r.read_at || r.status === "read").length;
    const failed = recipients.filter((r: any) => r.status === "failed" && !isMetaSuppressedDelivery(r)).length;
    const suppressed = recipients.filter((r: any) => isMetaSuppressedDelivery(r)).length;
    const pending = recipients.filter((r: any) => r.status === "pending").length;
    return {
      total, sent, delivered, read, failed, suppressed, pending,
      deliveryRate: sent ? Math.round((delivered / sent) * 100) : 0,
      readRate: delivered ? Math.round((read / delivered) * 100) : 0,
      failureRate: total ? Math.round((failed / total) * 100) : 0,
      suppressionRate: total ? Math.round((suppressed / total) * 100) : 0,
    };
  }, [recipients]);

  const hourlyTrend = useMemo(() => {
    const map = new Map<string, { hour: string; sent: number; delivered: number; read: number }>();
    recipients.forEach((r: any) => {
      const ts = r.sent_at || r.delivered_at;
      if (!ts) return;
      const d = new Date(ts);
      const key = `${d.getMonth() + 1}/${d.getDate()} ${d.getHours()}h`;
      if (!map.has(key)) map.set(key, { hour: key, sent: 0, delivered: 0, read: 0 });
      const b = map.get(key)!;
      if (r.sent_at) b.sent++;
      if (r.delivered_at) b.delivered++;
      if (r.read_at) b.read++;
    });
    return Array.from(map.values()).slice(-24);
  }, [recipients]);

  const statusPie = useMemo(() => ([
    { name: "Read", value: stats.read },
    { name: "Delivered (not read)", value: Math.max(0, stats.delivered - stats.read) },
    { name: "Sent (not delivered)", value: Math.max(0, stats.sent - stats.delivered - stats.suppressed - stats.failed) },
    { name: "Failed", value: stats.failed },
    { name: "Meta suppressed", value: stats.suppressed },
    { name: "Pending", value: stats.pending },
  ].filter((x) => x.value > 0)), [stats]);

  const errorBreakdown = useMemo(() => {
    const m = new Map<string, number>();
    recipients.filter((r: any) => (r.status === "failed" || isMetaSuppressedDelivery(r)) && r.error).forEach((r: any) => {
      const key = (r.error as string).slice(0, 80);
      m.set(key, (m.get(key) || 0) + 1);
    });
    return Array.from(m.entries()).map(([error, count]) => ({ error, count })).sort((a, b) => b.count - a.count).slice(0, 10);
  }, [recipients]);

  const avgDeliverySec = useMemo(() => {
    const diffs = recipients
      .filter((r: any) => r.sent_at && r.delivered_at)
      .map((r: any) => (new Date(r.delivered_at).getTime() - new Date(r.sent_at).getTime()) / 1000);
    if (!diffs.length) return null;
    return Math.round(diffs.reduce((a: number, b: number) => a + b, 0) / diffs.length);
  }, [recipients]);

  const avgReadSec = useMemo(() => {
    const diffs = recipients
      .filter((r: any) => r.delivered_at && r.read_at)
      .map((r: any) => (new Date(r.read_at).getTime() - new Date(r.delivered_at).getTime()) / 1000);
    if (!diffs.length) return null;
    return Math.round(diffs.reduce((a: number, b: number) => a + b, 0) / diffs.length);
  }, [recipients]);

  const filtered = useMemo(() => {
    return recipients.filter((r: any) => {
      if (filter !== "all") {
        if (filter === "read" && !r.read_at) return false;
        if (filter === "delivered" && !r.delivered_at) return false;
        if (filter === "sent" && !r.sent_at) return false;
        if (filter === "failed" && (r.status !== "failed" || isMetaSuppressedDelivery(r))) return false;
        if (filter === "suppressed" && !isMetaSuppressedDelivery(r)) return false;
        if (filter === "pending" && r.status !== "pending") return false;
      }
      if (search) {
        const q = search.toLowerCase();
        if (!(r.phone?.toLowerCase().includes(q) || r.name?.toLowerCase().includes(q))) return false;
      }
      return true;
    });
  }, [recipients, filter, search]);

  function exportCSV() {
    const rows = [
      ["phone", "name", "status", "sent_at", "delivered_at", "read_at", "error", "message_id"],
      ...recipients.map((r: any) => [
        r.phone, r.name || "", r.status, r.sent_at || "", r.delivered_at || "", r.read_at || "", r.error || "", r.message_id || "",
      ]),
    ];
    const csv = rows.map((r) => r.map((v) => `"${String(v).replace(/"/g, '""')}"`).join(",")).join("\n");
    const url = URL.createObjectURL(new Blob([csv], { type: "text/csv" }));
    const a = document.createElement("a");
    a.href = url; a.download = `${campaign?.name || "campaign"}-report.csv`; a.click();
    URL.revokeObjectURL(url);
  }

  if (!campaign) {
    return <div className="text-muted-foreground">Loading campaign…</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div className="flex items-center gap-3">
          <Link to="/campaigns"><Button variant="ghost" size="icon"><ArrowLeft className="h-4 w-4" /></Button></Link>
          <div>
            <h1 className="font-display text-3xl font-bold">{campaign.name}</h1>
            <p className="text-sm text-muted-foreground">
              Template: <span className="font-medium">{campaign.template_name}</span> · {new Date(campaign.created_at).toLocaleString()}
              {" · "}
              <Badge variant="secondary">{campaign.status}</Badge>
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {(campaign.status === "sending" || campaign.status === "failed") && stats.pending > 0 ? (
            <ResumeButton campaignId={campaign.id} workspaceId={campaign.workspace_id} />
          ) : null}
          <Button variant="outline" onClick={exportCSV}><Download className="mr-2 h-4 w-4" />Export CSV</Button>
        </div>
      </div>

      <div className="grid gap-4 grid-cols-2 lg:grid-cols-4 xl:grid-cols-7">
        <Kpi icon={Send} label="Total" value={stats.total} />
        <Kpi icon={Check} label="Sent" value={stats.sent} />
        <Kpi icon={CheckCheck} label="Delivered" value={stats.delivered} sub={`${stats.deliveryRate}%`} />
        <Kpi icon={Eye} label="Read" value={stats.read} sub={`${stats.readRate}% of delivered`} info="WhatsApp only reports a read event when the recipient has enabled 'Read receipts' in their privacy settings. Many users (especially in India) turn blue ticks off, so actual open rates are typically much higher than what Meta exposes here." />
        <Kpi icon={XCircle} label="Failed" value={stats.failed} sub={`${stats.failureRate}%`} tone="destructive" info="Only real send/API failures are counted here. Meta marketing suppressions are shown separately because Meta accepted the send and later blocked delivery by policy/user limits." />
        <Kpi icon={Info} label="Meta suppressed" value={stats.suppressed} sub={`${stats.suppressionRate}%`} tone="warning" info="WhatsApp/Meta suppressed these accepted marketing messages, usually because of per-user marketing limits (#131049), experiments (#130472), or recipient opt-out (#131050). Slice cannot force delivery for these recipients; wait at least 24 hours and use more engaged opt-in audiences." />
        <Kpi icon={Clock} label="Pending" value={stats.pending} />
        <Kpi
          icon={MousePointerClick}
          label="Interested clicks"
          value={buttonStats?.interested ?? 0}
          sub={`${stats.sent ? Math.round(((buttonStats?.interested ?? 0) / stats.sent) * 100) : 0}% of sent`}
          info="Number of recipients who tapped an 'Interested' Quick Reply button on this campaign's template. See CRM → Interested Leads for the full list."
        />
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card className="p-5">
          <p className="font-semibold mb-3">Delivery funnel</p>
          <div className="space-y-3">
            <Funnel label="Total recipients" value={stats.total} max={stats.total} color="#64748b" />
            <Funnel label="Sent" value={stats.sent} max={stats.total} color="#3b82f6" />
            <Funnel label="Delivered" value={stats.delivered} max={stats.total} color="#10b981" />
            <Funnel label="Read" value={stats.read} max={stats.total} color="#8b5cf6" />
            <Funnel label="Meta suppressed" value={stats.suppressed} max={stats.total} color="#f59e0b" />
            <Funnel label="Failed" value={stats.failed} max={stats.total} color="#ef4444" />
          </div>
          <div className="mt-5 grid grid-cols-2 gap-3 text-xs text-muted-foreground">
            <div className="rounded-md bg-muted/40 p-3">
              <p className="font-medium text-foreground">Avg time to deliver</p>
              <p className="mt-0.5">{avgDeliverySec != null ? formatDuration(avgDeliverySec) : "—"}</p>
            </div>
            <div className="rounded-md bg-muted/40 p-3">
              <p className="font-medium text-foreground">Avg time to read</p>
              <p className="mt-0.5">{avgReadSec != null ? formatDuration(avgReadSec) : "—"}</p>
            </div>
          </div>
        </Card>

        <Card className="p-5">
          <p className="font-semibold mb-3">Status breakdown</p>
          <div className="h-64">
            {statusPie.length === 0 ? (
              <div className="h-full grid place-items-center text-sm text-muted-foreground">No data yet</div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={statusPie} dataKey="value" nameKey="name" innerRadius={50} outerRadius={90} label>
                    {statusPie.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                  </Pie>
                  <Tooltip />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            )}
          </div>
        </Card>

        <Card className="p-5 lg:col-span-2">
          <p className="font-semibold mb-3">Activity over time</p>
          <div className="h-64">
            {hourlyTrend.length === 0 ? (
              <div className="h-full grid place-items-center text-sm text-muted-foreground">No activity yet</div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={hourlyTrend}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                  <XAxis dataKey="hour" className="text-xs" />
                  <YAxis className="text-xs" />
                  <Tooltip />
                  <Legend />
                  <Line type="monotone" dataKey="sent" stroke="#3b82f6" strokeWidth={2} dot={false} />
                  <Line type="monotone" dataKey="delivered" stroke="#10b981" strokeWidth={2} dot={false} />
                  <Line type="monotone" dataKey="read" stroke="#8b5cf6" strokeWidth={2} dot={false} />
                </LineChart>
              </ResponsiveContainer>
            )}
          </div>
        </Card>

        {(buttonStats?.byButton?.length ?? 0) > 0 && (
          <Card className="p-5 lg:col-span-2">
            <p className="font-semibold mb-3">Quick Reply button clicks</p>
            <div className="flex flex-wrap gap-2">
              {(buttonStats?.byButton ?? []).map((b) => (
                <Badge key={b.button} variant="secondary" className="text-sm">
                  {b.button}: {b.count}
                </Badge>
              ))}
            </div>
            <p className="mt-3 text-xs text-muted-foreground">
              {buttonStats?.total ?? 0} total clicks from {buttonStats?.uniqueContacts ?? 0} unique contacts.
            </p>
          </Card>
        )}

        {errorBreakdown.length > 0 && (
          <Card className="p-5 lg:col-span-2">
            <p className="font-semibold mb-3">Top delivery issues</p>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={errorBreakdown} layout="vertical" margin={{ left: 40 }}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                  <XAxis type="number" className="text-xs" />
                  <YAxis type="category" dataKey="error" width={300} className="text-xs" />
                  <Tooltip />
                  <Bar dataKey="count" fill="#ef4444" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </Card>
        )}
      </div>

      <Card className="p-5">
        <div className="flex items-center justify-between gap-3 flex-wrap mb-4">
          <p className="font-semibold">Recipients ({filtered.length.toLocaleString()})</p>
          <div className="flex items-center gap-2 flex-wrap">
            <Input
              placeholder="Search phone or name…"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-56 h-9"
            />
            {(["all", "sent", "delivered", "read", "failed", "suppressed", "pending"] as const).map((f) => (
              <Button
                key={f}
                size="sm"
                variant={filter === f ? "default" : "outline"}
                onClick={() => setFilter(f)}
                className="capitalize"
              >
                {f}
              </Button>
            ))}
          </div>
        </div>
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Phone</TableHead>
                <TableHead>Name</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Sent</TableHead>
                <TableHead>Delivered</TableHead>
                <TableHead>Read</TableHead>
                <TableHead>Error</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.slice(0, 500).map((r: any, i) => (
                <TableRow key={i}>
                  <TableCell className="font-mono text-xs">{r.phone}</TableCell>
                  <TableCell className="text-sm">{r.name || "—"}</TableCell>
                  <TableCell>
                    <Badge variant={(r.status === "failed" && !isMetaSuppressedDelivery(r)) ? "destructive" : "secondary"} className="capitalize">
                      {isMetaSuppressedDelivery(r) ? "meta suppressed" : r.status}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-xs text-muted-foreground">{fmtTime(r.sent_at)}</TableCell>
                  <TableCell className="text-xs text-muted-foreground">{fmtTime(r.delivered_at)}</TableCell>
                  <TableCell className="text-xs text-muted-foreground">{fmtTime(r.read_at)}</TableCell>
                  <TableCell className="text-xs text-destructive max-w-[280px] truncate" title={r.error || ""}>{r.error || "—"}</TableCell>
                </TableRow>
              ))}
              {filtered.length === 0 && (
                <TableRow><TableCell colSpan={7} className="text-center text-sm text-muted-foreground py-10">No recipients match this filter</TableCell></TableRow>
              )}
            </TableBody>
          </Table>
        </div>
        {filtered.length > 500 && (
          <p className="text-xs text-muted-foreground mt-3">Showing first 500 of {filtered.length.toLocaleString()} — use Export CSV for the full list.</p>
        )}
      </Card>
    </div>
  );
}

function Kpi({ icon: Icon, label, value, sub, tone, info }: any) {
  return (
    <Card className="p-4">
      <div className="flex items-center justify-between gap-2">
        <div className="min-w-0">
          <div className="flex items-center gap-1">
            <p className="text-xs text-muted-foreground">{label}</p>
            {info && (
              <TooltipProvider delayDuration={100}>
                <UITooltip>
                  <TooltipTrigger asChild>
                    <button type="button" className="text-muted-foreground/70 hover:text-foreground">
                      <Info className="h-3 w-3" />
                    </button>
                  </TooltipTrigger>
                  <TooltipContent side="bottom" className="max-w-xs text-xs leading-relaxed">
                    {info}
                  </TooltipContent>
                </UITooltip>
              </TooltipProvider>
            )}
          </div>
          <p className="mt-0.5 font-display text-2xl font-bold">{Number(value).toLocaleString()}</p>
          {sub && <p className="text-xs text-muted-foreground mt-0.5">{sub}</p>}
        </div>
        <div className={`grid h-9 w-9 place-items-center rounded-lg ${tone === "destructive" ? "bg-destructive/10 text-destructive" : tone === "warning" ? "bg-amber-500/10 text-amber-600" : "bg-primary/10 text-primary"}`}>
          <Icon className="h-4 w-4" />
        </div>
      </div>
    </Card>
  );
}

function Funnel({ label, value, max, color }: { label: string; value: number; max: number; color: string }) {
  const pct = max > 0 ? Math.round((value / max) * 100) : 0;
  return (
    <div>
      <div className="flex justify-between text-xs mb-1">
        <span className="font-medium">{label}</span>
        <span className="text-muted-foreground">{value.toLocaleString()} ({pct}%)</span>
      </div>
      <div className="h-2 rounded-full bg-muted overflow-hidden">
        <div className="h-full rounded-full transition-all" style={{ width: `${pct}%`, background: color }} />
      </div>
    </div>
  );
}

function ResumeButton({ campaignId, workspaceId }: { campaignId: string; workspaceId: string }) {
  const qc = useQueryClient();
  const resume = useServerFn(resumeCampaign);
  const [busy, setBusy] = useState(false);
  return (
    <Button
      disabled={busy}
      onClick={async () => {
        setBusy(true);
        try {
          const r = await resume({ data: { campaign_id: campaignId, workspace_id: workspaceId } });
          toast.success(`Resumed: ${r.sent} sent, ${r.failed} failed this pass`);
          qc.invalidateQueries({ queryKey: ["campaign", campaignId] });
          qc.invalidateQueries({ queryKey: ["campaign-recipients-full", campaignId] });
        } catch (e: any) {
          toast.error(e?.message || "Resume failed");
        } finally {
          setBusy(false);
        }
      }}
    >
      <Play className="mr-2 h-4 w-4" />
      {busy ? "Resuming…" : "Resume sending"}
    </Button>
  );
}

function fmtTime(ts: string | null) {
  if (!ts) return "—";
  const d = new Date(ts);
  return `${d.toLocaleDateString([], { month: "short", day: "numeric" })} ${d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}`;
}

function formatDuration(sec: number) {
  if (sec < 60) return `${sec}s`;
  if (sec < 3600) return `${Math.round(sec / 60)}m`;
  return `${(sec / 3600).toFixed(1)}h`;
}
