import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import { listBots, createBot, deleteBot, toggleBot, duplicateBot } from "@/lib/bots.functions";
import { useWorkspace } from "@/lib/workspace-context";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Bot, Plus, Pencil, Trash2, Copy } from "lucide-react";
import { toast } from "sonner";
import { AiUsageCostNotice } from "@/components/AiUsageCostNotice";


export const Route = createFileRoute("/_authenticated/bots/")({
  component: BotsPage,
  head: () => ({ meta: [{ title: "AI Bots — Slice" }] }),
});

function BotsPage() {
  const qc = useQueryClient();
  const navigate = useNavigate();
  const { currentWorkspaceId } = useWorkspace();
  const listFn = useServerFn(listBots);
  const createFn = useServerFn(createBot);
  const deleteFn = useServerFn(deleteBot);
  const toggleFn = useServerFn(toggleBot);
  const dupFn = useServerFn(duplicateBot);
  const [newOpen, setNewOpen] = useState(false);
  const [name, setName] = useState("");

  const { data: bots = [] } = useQuery({
    queryKey: ["bots", currentWorkspaceId],
    queryFn: () => listFn({ data: { workspace_id: currentWorkspaceId! } }),
    enabled: !!currentWorkspaceId,
  });

  async function create() {
    if (!name.trim() || !currentWorkspaceId) return;
    try {
      const r = await createFn({ data: { workspace_id: currentWorkspaceId, name: name.trim() } });
      setNewOpen(false); setName("");
      navigate({ to: "/bots/$id", params: { id: r.id } });
    } catch (e: any) { toast.error(e.message); }
  }

  async function onDelete(id: string) {
    if (!confirm("Delete this bot?")) return;
    await deleteFn({ data: { id } });
    qc.invalidateQueries({ queryKey: ["bots", currentWorkspaceId] });
  }
  async function onToggle(id: string, enabled: boolean) {
    await toggleFn({ data: { id, enabled } });
    qc.invalidateQueries({ queryKey: ["bots", currentWorkspaceId] });
  }
  async function onDup(id: string) {
    const r = await dupFn({ data: { id } });
    qc.invalidateQueries({ queryKey: ["bots", currentWorkspaceId] });
    navigate({ to: "/bots/$id", params: { id: r.id } });
  }

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h1 className="text-3xl font-display font-bold flex items-center gap-2">
            <Bot className="h-7 w-7 text-primary" /> AI Bots
          </h1>
          <p className="text-muted-foreground mt-1">Build conversational flows with a drag-and-drop canvas.</p>
        </div>
        <Button onClick={() => setNewOpen(true)}><Plus className="h-4 w-4 mr-1.5" /> New bot</Button>
      </div>

      <AiUsageCostNotice />


      {bots.length === 0 ? (
        <Card className="p-12 text-center">
          <Bot className="h-12 w-12 mx-auto text-muted-foreground mb-3" />
          <h3 className="font-semibold text-lg">No bots yet</h3>
          <p className="text-sm text-muted-foreground mt-1">Create your first AI bot to automate WhatsApp conversations.</p>
          <Button className="mt-4" onClick={() => setNewOpen(true)}><Plus className="h-4 w-4 mr-1.5" /> New bot</Button>
        </Card>
      ) : (
        <div className="grid gap-3">
          {bots.map((b: any) => (
            <Card key={b.id} className="p-4 flex items-center gap-4">
              <div className="grid h-10 w-10 place-items-center rounded-lg bg-primary/10 text-primary shrink-0">
                <Bot className="h-5 w-5" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <h3 className="font-semibold truncate">{b.name}</h3>
                  {b.enabled ? <Badge>Active</Badge> : <Badge variant="outline">Disabled</Badge>}
                  <Badge variant="secondary">{(b.triggers?.length ?? 0)} trigger{(b.triggers?.length ?? 0) === 1 ? "" : "s"}</Badge>
                </div>
                {b.description && <p className="text-sm text-muted-foreground mt-1 truncate">{b.description}</p>}
              </div>
              <div className="flex items-center gap-1">
                <Switch checked={b.enabled} onCheckedChange={(v) => onToggle(b.id, v)} />
                <Button asChild size="icon" variant="ghost"><Link to="/bots/$id" params={{ id: b.id }}><Pencil className="h-4 w-4" /></Link></Button>
                <Button size="icon" variant="ghost" onClick={() => onDup(b.id)}><Copy className="h-4 w-4" /></Button>
                <Button size="icon" variant="ghost" onClick={() => onDelete(b.id)}><Trash2 className="h-4 w-4 text-destructive" /></Button>
              </div>
            </Card>
          ))}
        </div>
      )}

      <Dialog open={newOpen} onOpenChange={setNewOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>New bot</DialogTitle></DialogHeader>
          <div className="space-y-2">
            <Label>Name</Label>
            <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Lead qualification bot" maxLength={120} />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setNewOpen(false)}>Cancel</Button>
            <Button onClick={create} disabled={!name.trim()}>Create</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
