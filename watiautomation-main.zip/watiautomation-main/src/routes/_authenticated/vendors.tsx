import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useWorkspace } from "@/lib/workspace-context";
import { useCurrency } from "@/lib/currency";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { Store, Plus, Globe, Mail, Phone, Check, Star, Trash2, Pencil, Package } from "lucide-react";

export const Route = createFileRoute("/_authenticated/vendors")({
  component: VendorsPage,
  head: () => ({ meta: [{ title: "Vendors — Slice" }] }),
});

function VendorsPage() {
  const qc = useQueryClient();
  const { currentWorkspaceId } = useWorkspace();
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [vendorOpen, setVendorOpen] = useState(false);
  const [editingVendor, setEditingVendor] = useState<any>(null);

  const { data: vendors = [] } = useQuery({
    queryKey: ["vendors", currentWorkspaceId],
    enabled: !!currentWorkspaceId,
    queryFn: async () => {
      const { data, error } = await supabase.from("vendors").select("*")
        .eq("workspace_id", currentWorkspaceId!).order("created_at", { ascending: false });
      if (error) throw error;
      return data;
    },
  });

  const { data: plans = [] } = useQuery({
    queryKey: ["vendor-plans", currentWorkspaceId],
    enabled: !!currentWorkspaceId,
    queryFn: async () => {
      const { data, error } = await supabase.from("vendor_plans").select("*")
        .eq("workspace_id", currentWorkspaceId!).order("position");
      if (error) throw error;
      return data;
    },
  });

  const selected = vendors.find((v: any) => v.id === selectedId) ?? vendors[0];
  const selectedPlans = plans.filter((p: any) => p.vendor_id === selected?.id);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-3xl font-bold flex items-center gap-2">
            <Store className="h-7 w-7" />Vendors
          </h1>
          <p className="text-muted-foreground">Manage your vendor catalog with plans, features, and pricing</p>
        </div>
        <Dialog open={vendorOpen} onOpenChange={(o) => { setVendorOpen(o); if (!o) setEditingVendor(null); }}>
          <DialogTrigger asChild>
            <Button><Plus className="h-4 w-4 mr-1" />Add vendor</Button>
          </DialogTrigger>
          <VendorDialog
            vendor={editingVendor}
            workspaceId={currentWorkspaceId}
            onSaved={() => { setVendorOpen(false); setEditingVendor(null); qc.invalidateQueries({ queryKey: ["vendors"] }); }}
          />
        </Dialog>
      </div>

      {vendors.length === 0 ? (
        <Card className="p-12 text-center">
          <Store className="h-12 w-12 mx-auto text-muted-foreground/40 mb-3" />
          <p className="font-medium">No vendors yet</p>
          <p className="text-sm text-muted-foreground">Add your first vendor to start building your catalog.</p>
        </Card>
      ) : (
        <div className="grid gap-4 lg:grid-cols-[280px_1fr]">
          <div className="space-y-2">
            {vendors.map((v: any) => {
              const count = plans.filter((p: any) => p.vendor_id === v.id).length;
              const active = selected?.id === v.id;
              return (
                <button
                  key={v.id}
                  onClick={() => setSelectedId(v.id)}
                  className={`w-full text-left p-3 rounded-lg border transition ${active ? "border-primary bg-primary/5" : "hover:bg-muted/50"}`}
                >
                  <div className="flex items-center gap-2">
                    {v.logo_url ? (
                      <img src={v.logo_url} alt="" className="h-8 w-8 rounded object-cover" />
                    ) : (
                      <div className="h-8 w-8 rounded bg-primary/10 text-primary grid place-items-center text-xs font-semibold">
                        {v.name.charAt(0).toUpperCase()}
                      </div>
                    )}
                    <div className="min-w-0 flex-1">
                      <p className="font-medium truncate">{v.name}</p>
                      <p className="text-xs text-muted-foreground truncate">{v.category || "Uncategorized"} · {count} plan{count !== 1 ? "s" : ""}</p>
                    </div>
                  </div>
                </button>
              );
            })}
          </div>

          {selected && (
            <VendorDetail
              vendor={selected}
              plans={selectedPlans}
              workspaceId={currentWorkspaceId}
              onEdit={() => { setEditingVendor(selected); setVendorOpen(true); }}
              onChanged={() => qc.invalidateQueries({ queryKey: ["vendor-plans"] })}
              onDeleted={() => { setSelectedId(null); qc.invalidateQueries({ queryKey: ["vendors"] }); qc.invalidateQueries({ queryKey: ["vendor-plans"] }); }}
            />
          )}
        </div>
      )}
    </div>
  );
}

function VendorDialog({ vendor, workspaceId, onSaved }: any) {
  const [form, setForm] = useState({
    name: vendor?.name || "",
    category: vendor?.category || "",
    description: vendor?.description || "",
    website: vendor?.website || "",
    logo_url: vendor?.logo_url || "",
    contact_email: vendor?.contact_email || "",
    contact_phone: vendor?.contact_phone || "",
    status: vendor?.status || "active",
  });

  async function save() {
    if (!workspaceId) return;
    if (!form.name.trim()) return toast.error("Name required");
    const { data: u } = await supabase.auth.getUser();
    const payload: any = { ...form, workspace_id: workspaceId, user_id: u.user!.id, updated_at: new Date().toISOString() };
    const { error } = vendor
      ? await supabase.from("vendors").update(payload).eq("id", vendor.id)
      : await supabase.from("vendors").insert(payload);
    if (error) return toast.error(error.message);
    toast.success(vendor ? "Vendor updated" : "Vendor added");
    onSaved();
  }

  return (
    <DialogContent>
      <DialogHeader><DialogTitle>{vendor ? "Edit vendor" : "Add vendor"}</DialogTitle></DialogHeader>
      <div className="grid gap-3">
        <div className="grid grid-cols-2 gap-3">
          <div>
            <Label>Name *</Label>
            <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
          </div>
          <div>
            <Label>Category</Label>
            <Input value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} placeholder="SaaS, Logistics…" />
          </div>
        </div>
        <div>
          <Label>Description</Label>
          <Textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} rows={3} />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <Label>Website</Label>
            <Input value={form.website} onChange={(e) => setForm({ ...form, website: e.target.value })} placeholder="https://" />
          </div>
          <div>
            <Label>Logo URL</Label>
            <Input value={form.logo_url} onChange={(e) => setForm({ ...form, logo_url: e.target.value })} placeholder="https://…/logo.png" />
          </div>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <Label>Contact email</Label>
            <Input value={form.contact_email} onChange={(e) => setForm({ ...form, contact_email: e.target.value })} />
          </div>
          <div>
            <Label>Contact phone</Label>
            <Input value={form.contact_phone} onChange={(e) => setForm({ ...form, contact_phone: e.target.value })} />
          </div>
        </div>
        <div>
          <Label>Status</Label>
          <Select value={form.status} onValueChange={(v) => setForm({ ...form, status: v })}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="active">Active</SelectItem>
              <SelectItem value="inactive">Inactive</SelectItem>
              <SelectItem value="pending">Pending</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
      <DialogFooter><Button onClick={save}>Save</Button></DialogFooter>
    </DialogContent>
  );
}

function VendorDetail({ vendor, plans, workspaceId, onEdit, onChanged, onDeleted }: any) {
  const { currency } = useCurrency();
  const [planOpen, setPlanOpen] = useState(false);
  const [editingPlan, setEditingPlan] = useState<any>(null);

  async function deleteVendor() {
    if (!confirm(`Delete ${vendor.name}? This also removes all its plans.`)) return;
    const { error } = await supabase.from("vendors").delete().eq("id", vendor.id);
    if (error) return toast.error(error.message);
    toast.success("Vendor deleted");
    onDeleted();
  }

  async function deletePlan(id: string) {
    if (!confirm("Delete this plan?")) return;
    const { error } = await supabase.from("vendor_plans").delete().eq("id", id);
    if (error) return toast.error(error.message);
    toast.success("Plan deleted");
    onChanged();
  }

  return (
    <div className="space-y-4">
      <Card className="p-5">
        <div className="flex items-start gap-4">
          {vendor.logo_url ? (
            <img src={vendor.logo_url} alt="" className="h-14 w-14 rounded-lg object-cover" />
          ) : (
            <div className="h-14 w-14 rounded-lg bg-primary/10 text-primary grid place-items-center text-xl font-bold">
              {vendor.name.charAt(0).toUpperCase()}
            </div>
          )}
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <h2 className="font-display text-2xl font-bold">{vendor.name}</h2>
              <Badge variant={vendor.status === "active" ? "default" : "secondary"}>{vendor.status}</Badge>
              {vendor.category && <Badge variant="outline">{vendor.category}</Badge>}
            </div>
            {vendor.description && <p className="text-sm text-muted-foreground mt-1">{vendor.description}</p>}
            <div className="flex flex-wrap gap-3 mt-2 text-xs text-muted-foreground">
              {vendor.website && <a href={vendor.website} target="_blank" rel="noreferrer" className="flex items-center gap-1 hover:text-primary"><Globe className="h-3 w-3" />{vendor.website}</a>}
              {vendor.contact_email && <span className="flex items-center gap-1"><Mail className="h-3 w-3" />{vendor.contact_email}</span>}
              {vendor.contact_phone && <span className="flex items-center gap-1"><Phone className="h-3 w-3" />{vendor.contact_phone}</span>}
            </div>
          </div>
          <div className="flex gap-1">
            <Button size="sm" variant="outline" onClick={onEdit}><Pencil className="h-3.5 w-3.5" /></Button>
            <Button size="sm" variant="outline" onClick={deleteVendor}><Trash2 className="h-3.5 w-3.5" /></Button>
          </div>
        </div>
      </Card>

      <div className="flex items-center justify-between">
        <h3 className="font-semibold flex items-center gap-2"><Package className="h-4 w-4" />Plans ({plans.length})</h3>
        <Dialog open={planOpen} onOpenChange={(o) => { setPlanOpen(o); if (!o) setEditingPlan(null); }}>
          <DialogTrigger asChild>
            <Button size="sm" variant="outline"><Plus className="h-3.5 w-3.5 mr-1" />Add plan</Button>
          </DialogTrigger>
          <PlanDialog
            plan={editingPlan}
            vendorId={vendor.id}
            workspaceId={workspaceId}
            defaultCurrency={currency}
            position={plans.length}
            onSaved={() => { setPlanOpen(false); setEditingPlan(null); onChanged(); }}
          />
        </Dialog>
      </div>

      {plans.length === 0 ? (
        <Card className="p-8 text-center text-sm text-muted-foreground">No plans yet. Add your first plan to define pricing tiers and features.</Card>
      ) : (
        <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
          {plans.map((p: any) => (
            <Card key={p.id} className={`p-4 relative ${p.is_popular ? "border-primary shadow-md" : ""}`}>
              {p.is_popular && (
                <Badge className="absolute -top-2 left-4 gap-1"><Star className="h-3 w-3" />Popular</Badge>
              )}
              <div className="flex items-start justify-between">
                <div>
                  <p className="font-semibold">{p.name}</p>
                  {p.description && <p className="text-xs text-muted-foreground mt-0.5">{p.description}</p>}
                </div>
                <div className="flex gap-1">
                  <button onClick={() => { setEditingPlan(p); setPlanOpen(true); }} className="text-muted-foreground hover:text-foreground">
                    <Pencil className="h-3.5 w-3.5" />
                  </button>
                  <button onClick={() => deletePlan(p.id)} className="text-muted-foreground hover:text-destructive">
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </div>
              </div>
              <div className="mt-3 mb-3">
                <span className="text-2xl font-bold">{new Intl.NumberFormat(undefined, { style: "currency", currency: p.currency || "USD", maximumFractionDigits: 0 }).format(Number(p.price))}</span>
                <span className="text-xs text-muted-foreground">/{p.billing_interval}</span>
              </div>
              <ul className="space-y-1.5 text-sm">
                {(p.features || []).map((f: string, i: number) => (
                  <li key={i} className="flex items-start gap-2">
                    <Check className="h-4 w-4 text-primary shrink-0 mt-0.5" />
                    <span>{f}</span>
                  </li>
                ))}
              </ul>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}

function PlanDialog({ plan, vendorId, workspaceId, defaultCurrency, position, onSaved }: any) {
  const [form, setForm] = useState({
    name: plan?.name || "",
    description: plan?.description || "",
    price: plan?.price?.toString() || "0",
    currency: plan?.currency || defaultCurrency || "USD",
    billing_interval: plan?.billing_interval || "monthly",
    features: (plan?.features || []).join("\n"),
    is_popular: plan?.is_popular || false,
  });

  async function save() {
    if (!form.name.trim()) return toast.error("Plan name required");
    const features = form.features.split("\n").map((s: string) => s.trim()).filter(Boolean);
    const payload: any = {
      workspace_id: workspaceId,
      vendor_id: vendorId,
      name: form.name,
      description: form.description || null,
      price: Number(form.price) || 0,
      currency: form.currency,
      billing_interval: form.billing_interval,
      features,
      is_popular: form.is_popular,
      position: plan?.position ?? position,
    };
    const { error } = plan
      ? await supabase.from("vendor_plans").update(payload).eq("id", plan.id)
      : await supabase.from("vendor_plans").insert(payload);
    if (error) return toast.error(error.message);
    toast.success(plan ? "Plan updated" : "Plan added");
    onSaved();
  }

  return (
    <DialogContent>
      <DialogHeader><DialogTitle>{plan ? "Edit plan" : "Add plan"}</DialogTitle></DialogHeader>
      <div className="grid gap-3">
        <div>
          <Label>Plan name *</Label>
          <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Starter, Pro, Enterprise…" />
        </div>
        <div>
          <Label>Short description</Label>
          <Input value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
        </div>
        <div className="grid grid-cols-3 gap-3">
          <div>
            <Label>Price</Label>
            <Input type="number" value={form.price} onChange={(e) => setForm({ ...form, price: e.target.value })} />
          </div>
          <div>
            <Label>Currency</Label>
            <Select value={form.currency} onValueChange={(v) => setForm({ ...form, currency: v })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="USD">USD</SelectItem>
                <SelectItem value="INR">INR</SelectItem>
                <SelectItem value="AED">AED</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label>Interval</Label>
            <Select value={form.billing_interval} onValueChange={(v) => setForm({ ...form, billing_interval: v })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="monthly">monthly</SelectItem>
                <SelectItem value="yearly">yearly</SelectItem>
                <SelectItem value="quarterly">quarterly</SelectItem>
                <SelectItem value="one-time">one-time</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        <div>
          <Label>Features (one per line)</Label>
          <Textarea
            value={form.features}
            onChange={(e) => setForm({ ...form, features: e.target.value })}
            rows={5}
            placeholder={"Unlimited messages\nPriority support\n5 team members"}
          />
        </div>
        <div className="flex items-center justify-between rounded-lg border p-3">
          <div>
            <Label>Mark as popular</Label>
            <p className="text-xs text-muted-foreground">Highlight this plan in the catalog</p>
          </div>
          <Switch checked={form.is_popular} onCheckedChange={(c) => setForm({ ...form, is_popular: c })} />
        </div>
      </div>
      <DialogFooter><Button onClick={save}>Save</Button></DialogFooter>
    </DialogContent>
  );
}
