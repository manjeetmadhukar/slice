import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useWorkspace } from "@/lib/workspace-context";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger, DialogDescription } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { ShoppingBag, Plus, Package, AlertTriangle, CheckCircle2, XCircle, Send, MessageSquare, Filter, X, Search } from "lucide-react";
import { cn, fmtIST } from "@/lib/utils";
import { useCurrency } from "@/lib/currency";
import { useServerFn } from "@tanstack/react-start";
import { sendTestWhatsApp } from "@/lib/integrations.functions";

export const Route = createFileRoute("/_authenticated/orders")({
  component: OrdersPage,
  head: () => ({ meta: [{ title: "Orders — Slice" }] }),
});

type Tab = "all" | "cod" | "abandoned" | "customers";

function OrdersPage() {
  const qc = useQueryClient();
  const { currency, format } = useCurrency();
  const { currentWorkspaceId } = useWorkspace();
  const [tab, setTab] = useState<Tab>("all");
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({
    order_number: "", customer_name: "", customer_phone: "", total: "", payment_status: "pending", cod_status: "",
  });
  const [tmplDialog, setTmplDialog] = useState<{ open: boolean; cart: any | null; templateId: string; sending: boolean }>({
    open: false, cart: null, templateId: "", sending: false,
  });
  const [detailCart, setDetailCart] = useState<any | null>(null);
  const [filters, setFilters] = useState({
    range: "all" as "all" | "today" | "7d" | "30d" | "month" | "year" | "custom",
    year: "all",
    from: "",
    to: "",
    q: "",
    status: "all",
  });
  const sendTpl = useServerFn(sendTestWhatsApp);

  const { data: templates = [] } = useQuery({
    queryKey: ["approved-templates", currentWorkspaceId],
    enabled: !!currentWorkspaceId,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("templates")
        .select("id, meta_template_name, language, status")
        .eq("workspace_id", currentWorkspaceId!)
        .eq("status", "APPROVED")
        .order("meta_template_name", { ascending: true });
      if (error) throw error;
      return data;
    },
  });

  const { data: orders = [] } = useQuery({
    queryKey: ["ecom-orders", currentWorkspaceId, tab],
    enabled: !!currentWorkspaceId && (tab === "all" || tab === "cod"),
    queryFn: async () => {
      let q = supabase.from("ecom_orders").select("*").eq("workspace_id", currentWorkspaceId!);
      if (tab === "cod") q = q.not("cod_status", "is", null);
      const { data, error } = await q.order("placed_at", { ascending: false }).limit(200);
      if (error) throw error;
      return data;
    },
  });

  const { data: abandoned = [] } = useQuery({
    queryKey: ["abandoned-carts", currentWorkspaceId],
    enabled: !!currentWorkspaceId && tab === "abandoned",
    queryFn: async () => {
      const { data, error } = await supabase.from("abandoned_carts").select("*")
        .eq("workspace_id", currentWorkspaceId!).order("abandoned_at", { ascending: false }).limit(200);
      if (error) throw error;
      return data;
    },
  });

  const { data: customers = [] } = useQuery({
    queryKey: ["ecom-customers", currentWorkspaceId],
    enabled: !!currentWorkspaceId && tab === "customers",
    queryFn: async () => {
      const { data, error } = await supabase.from("ecom_customers").select("*")
        .eq("workspace_id", currentWorkspaceId!).order("lifetime_value", { ascending: false }).limit(200);
      if (error) throw error;
      return data;
    },
  });

  // Workspace-wide analytics — independent of currently active tab so cards
  // stay accurate everywhere and refresh live via realtime subscriptions.
  const { data: statsData } = useQuery({
    queryKey: ["commerce-stats", currentWorkspaceId],
    enabled: !!currentWorkspaceId,
    refetchOnWindowFocus: true,
    queryFn: async () => {
      const [ordersRes, cartsRes] = await Promise.all([
        supabase.from("ecom_orders")
          .select("total,payment_status,cod_status")
          .eq("workspace_id", currentWorkspaceId!)
          .limit(5000),
        supabase.from("abandoned_carts")
          .select("status,total,recovered_revenue")
          .eq("workspace_id", currentWorkspaceId!)
          .limit(5000),
      ]);
      const os = (ordersRes.data as any[]) || [];
      const cs = (cartsRes.data as any[]) || [];
      const recoveredCarts = cs.filter((c) => c.status === "recovered");
      return {
        revenue: os
          .filter((o) => o.payment_status === "paid" || o.cod_status === "confirmed")
          .reduce((s, o) => s + Number(o.total || 0), 0),
        codPending: os.filter((o) => o.cod_status === "pending").length,
        codConfirmed: os.filter((o) => o.cod_status === "confirmed").length,
        recoveredRevenue: recoveredCarts.reduce(
          (s, c) => s + Number(c.recovered_revenue || c.total || 0), 0),
        recoveredCount: recoveredCarts.length,
        abandonedOpen: cs.filter((c) => c.status !== "recovered").length,
      };
    },
  });

  // Realtime: auto-refresh stats + lists whenever an order or cart changes
  // (COD confirm, new webhook, cart recovered, etc.).
  useEffect(() => {
    if (!currentWorkspaceId) return;
    const channel = supabase
      .channel(`commerce-${currentWorkspaceId}`)
      .on("postgres_changes",
        { event: "*", schema: "public", table: "ecom_orders", filter: `workspace_id=eq.${currentWorkspaceId}` },
        () => {
          qc.invalidateQueries({ queryKey: ["commerce-stats", currentWorkspaceId] });
          qc.invalidateQueries({ queryKey: ["ecom-orders", currentWorkspaceId] });
        })
      .on("postgres_changes",
        { event: "*", schema: "public", table: "abandoned_carts", filter: `workspace_id=eq.${currentWorkspaceId}` },
        () => {
          qc.invalidateQueries({ queryKey: ["commerce-stats", currentWorkspaceId] });
          qc.invalidateQueries({ queryKey: ["abandoned-carts", currentWorkspaceId] });
        })
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [currentWorkspaceId, qc]);

  const stats = {
    total: statsData?.revenue ?? 0,
    codPending: statsData?.codPending ?? 0,
    codConfirmed: statsData?.codConfirmed ?? 0,
    recovered: statsData?.recoveredRevenue ?? 0,
    recoveredCount: statsData?.recoveredCount ?? 0,
    abandonedOpen: statsData?.abandonedOpen ?? 0,
  };

  async function createOrder() {
    if (!currentWorkspaceId) return;
    const { data: u } = await supabase.auth.getUser();
    const { error } = await supabase.from("ecom_orders").insert({
      workspace_id: currentWorkspaceId,
      order_number: form.order_number || `ORD-${Date.now()}`,
      customer_name: form.customer_name,
      customer_phone: form.customer_phone,
      total: Number(form.total) || 0,
      currency,
      payment_status: form.payment_status,
      cod_status: form.cod_status || null,
      source: "manual",
    });
    if (error) return toast.error(error.message);
    toast.success("Order added");
    setOpen(false);
    setForm({ order_number: "", customer_name: "", customer_phone: "", total: "", payment_status: "pending", cod_status: "" });
    qc.invalidateQueries({ queryKey: ["ecom-orders"] });
    qc.invalidateQueries({ queryKey: ["commerce-stats", currentWorkspaceId] });
  }

  async function updateCod(id: string, status: string) {
    const { error } = await supabase.from("ecom_orders").update({ cod_status: status }).eq("id", id);
    if (error) return toast.error(error.message);
    toast.success(`COD marked ${status}`);
    qc.invalidateQueries({ queryKey: ["ecom-orders"] });
    qc.invalidateQueries({ queryKey: ["commerce-stats", currentWorkspaceId] });
  }

  async function markRecovered(id: string, total: number) {
    const { error } = await supabase.from("abandoned_carts")
      .update({ status: "recovered", recovered_at: new Date().toISOString(), recovered_revenue: total })
      .eq("id", id);
    if (error) return toast.error(error.message);
    toast.success("Marked recovered");
    qc.invalidateQueries({ queryKey: ["abandoned-carts"] });
    qc.invalidateQueries({ queryKey: ["commerce-stats", currentWorkspaceId] });
  }

  async function sendTemplateToCart() {
    const cart = tmplDialog.cart;
    if (!cart || !currentWorkspaceId || !tmplDialog.templateId) return;
    const phone = cart.customer_phone;
    if (!phone) return toast.error("This cart has no phone number");
    setTmplDialog((s) => ({ ...s, sending: true }));
    try {
        const res: any = await sendTpl({ data: { workspace_id: currentWorkspaceId, phone, template_id: tmplDialog.templateId, cart_id: cart.id } });
      if (!res?.ok) {
        toast.error(res?.error || "Failed to send template");
      } else {
        toast.success("Template sent");
        await supabase.from("abandoned_carts")
          .update({ reminders_sent: (Number(cart.reminders_sent) || 0) + 1, last_reminder_at: new Date().toISOString() })
          .eq("id", cart.id);
        qc.invalidateQueries({ queryKey: ["abandoned-carts"] });
        setTmplDialog({ open: false, cart: null, templateId: "", sending: false });
        return;
      }
    } catch (e: any) {
      toast.error(e?.message || "Failed to send");
    }
    setTmplDialog((s) => ({ ...s, sending: false }));
  }

  const dateBounds = useMemo(() => computeBounds(filters), [filters]);
  const yearOptions = useMemo(() => {
    const now = new Date().getFullYear();
    return Array.from({ length: 6 }, (_, i) => String(now - i));
  }, []);
  const filteredOrders = useMemo(() =>
    applyFilters(orders, "placed_at", filters, dateBounds, (o: any) =>
      [o.order_number, o.customer_name, o.customer_phone, o.customer_email].filter(Boolean).join(" ").toLowerCase(),
      (o: any) => o.payment_status || o.cod_status,
    ), [orders, filters, dateBounds]);
  const filteredAbandoned = useMemo(() =>
    applyFilters(abandoned, "abandoned_at", filters, dateBounds, (a: any) =>
      [a.customer_name, a.customer_phone, a.customer_email].filter(Boolean).join(" ").toLowerCase(),
      (a: any) => a.status,
    ), [abandoned, filters, dateBounds]);
  const filteredCustomers = useMemo(() =>
    applyFilters(customers, "created_at", filters, dateBounds, (c: any) =>
      [c.name, c.email, c.phone].filter(Boolean).join(" ").toLowerCase(),
      () => "all",
    ), [customers, filters, dateBounds]);

  const activeFilterCount =
    (filters.range !== "all" ? 1 : 0) +
    (filters.year !== "all" ? 1 : 0) +
    (filters.q ? 1 : 0) +
    (filters.status !== "all" ? 1 : 0);

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-3xl font-bold flex items-center gap-2">
            <ShoppingBag className="h-7 w-7" />Commerce
          </h1>
          <p className="text-muted-foreground">Orders, COD verification, and cart recovery</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild><Button><Plus className="mr-2 h-4 w-4" />Add order</Button></DialogTrigger>
          <DialogContent>
            <DialogHeader><DialogTitle>New order</DialogTitle></DialogHeader>
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div><Label>Order #</Label><Input value={form.order_number} onChange={(e) => setForm({ ...form, order_number: e.target.value })} /></div>
                <div><Label>Total</Label><Input type="number" value={form.total} onChange={(e) => setForm({ ...form, total: e.target.value })} /></div>
              </div>
              <div><Label>Customer name</Label><Input value={form.customer_name} onChange={(e) => setForm({ ...form, customer_name: e.target.value })} /></div>
              <div><Label>Customer phone</Label><Input value={form.customer_phone} onChange={(e) => setForm({ ...form, customer_phone: e.target.value })} placeholder="+14155551234" /></div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label>Payment</Label>
                  <Select value={form.payment_status} onValueChange={(v) => setForm({ ...form, payment_status: v })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="pending">Pending</SelectItem>
                      <SelectItem value="paid">Paid</SelectItem>
                      <SelectItem value="failed">Failed</SelectItem>
                      <SelectItem value="refunded">Refunded</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>COD status</Label>
                  <Select value={form.cod_status} onValueChange={(v) => setForm({ ...form, cod_status: v })}>
                    <SelectTrigger><SelectValue placeholder="Not COD" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="pending">Pending verification</SelectItem>
                      <SelectItem value="confirmed">Confirmed</SelectItem>
                      <SelectItem value="cancelled">Cancelled</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>
            <DialogFooter><Button onClick={createOrder}>Save</Button></DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid gap-4 sm:grid-cols-3">
        <Card className="p-5">
          <p className="text-sm text-muted-foreground">Order revenue</p>
          <p className="mt-1 font-display text-3xl font-bold">{format(stats.total)}</p>
          <p className="mt-1 text-xs text-muted-foreground">Paid + COD confirmed</p>
        </Card>
        <Card className="p-5">
          <p className="text-sm text-muted-foreground">COD pending</p>
          <p className="mt-1 font-display text-3xl font-bold">{stats.codPending}</p>
          <p className="mt-1 text-xs text-muted-foreground">
            {stats.codConfirmed} confirmed · live
          </p>
        </Card>
        <Card className="p-5">
          <p className="text-sm text-muted-foreground">Cart recovered</p>
          <p className="mt-1 font-display text-3xl font-bold">{format(stats.recovered)}</p>
          <p className="mt-1 text-xs text-muted-foreground">
            {stats.recoveredCount} recovered · {stats.abandonedOpen} open
          </p>
        </Card>
      </div>

      <Tabs value={tab} onValueChange={(v) => setTab(v as Tab)}>
        <TabsList>
          <TabsTrigger value="all">All orders</TabsTrigger>
          <TabsTrigger value="cod">COD verification</TabsTrigger>
          <TabsTrigger value="abandoned">Abandoned carts</TabsTrigger>
          <TabsTrigger value="customers">Customers</TabsTrigger>
        </TabsList>
      </Tabs>

      <Card className="p-3">
        <div className="flex flex-wrap items-center gap-2">
          <div className="flex items-center gap-1 text-xs text-muted-foreground pr-1">
            <Filter className="h-3.5 w-3.5" />Filters
          </div>
          <div className="relative">
            <Search className="absolute left-2 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
            <Input value={filters.q} onChange={(e) => setFilters((f) => ({ ...f, q: e.target.value }))}
              placeholder="Search name, phone, email…" className="h-9 pl-7 w-56" />
          </div>
          <Select value={filters.range} onValueChange={(v: any) => setFilters((f) => ({ ...f, range: v }))}>
            <SelectTrigger className="h-9 w-[140px]"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All time</SelectItem>
              <SelectItem value="today">Today</SelectItem>
              <SelectItem value="7d">Last 7 days</SelectItem>
              <SelectItem value="30d">Last 30 days</SelectItem>
              <SelectItem value="month">This month</SelectItem>
              <SelectItem value="year">This year</SelectItem>
              <SelectItem value="custom">Custom range</SelectItem>
            </SelectContent>
          </Select>
          <Select value={filters.year} onValueChange={(v) => setFilters((f) => ({ ...f, year: v }))}>
            <SelectTrigger className="h-9 w-[110px]"><SelectValue placeholder="Year" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Any year</SelectItem>
              {yearOptions.map((y) => <SelectItem key={y} value={y}>{y}</SelectItem>)}
            </SelectContent>
          </Select>
          {(tab === "all" || tab === "cod") && (
            <Select value={filters.status} onValueChange={(v) => setFilters((f) => ({ ...f, status: v }))}>
              <SelectTrigger className="h-9 w-[150px]"><SelectValue placeholder="Status" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Any status</SelectItem>
                <SelectItem value="paid">Paid</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="failed">Failed</SelectItem>
                <SelectItem value="refunded">Refunded</SelectItem>
                <SelectItem value="confirmed">COD confirmed</SelectItem>
                <SelectItem value="cancelled">COD cancelled</SelectItem>
              </SelectContent>
            </Select>
          )}
          {tab === "abandoned" && (
            <Select value={filters.status} onValueChange={(v) => setFilters((f) => ({ ...f, status: v }))}>
              <SelectTrigger className="h-9 w-[150px]"><SelectValue placeholder="Status" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Any status</SelectItem>
                <SelectItem value="abandoned">Abandoned</SelectItem>
                <SelectItem value="recovered">Recovered</SelectItem>
              </SelectContent>
            </Select>
          )}
          {filters.range === "custom" && (
            <>
              <Input type="date" value={filters.from} onChange={(e) => setFilters((f) => ({ ...f, from: e.target.value }))} className="h-9 w-[150px]" />
              <span className="text-xs text-muted-foreground">to</span>
              <Input type="date" value={filters.to} onChange={(e) => setFilters((f) => ({ ...f, to: e.target.value }))} className="h-9 w-[150px]" />
            </>
          )}
          {activeFilterCount > 0 && (
            <Button size="sm" variant="ghost" className="h-9"
              onClick={() => setFilters({ range: "all", year: "all", from: "", to: "", q: "", status: "all" })}>
              <X className="h-3.5 w-3.5 mr-1" />Clear ({activeFilterCount})
            </Button>
          )}
          <span className="ml-auto text-xs text-muted-foreground">
            {tab === "abandoned" ? filteredAbandoned.length : tab === "customers" ? filteredCustomers.length : filteredOrders.length} results
          </span>
        </div>
      </Card>

      {(tab === "all" || tab === "cod") && (
        <Card className="divide-y overflow-hidden">
          {filteredOrders.length === 0 ? (
            <div className="p-12 text-center text-sm text-muted-foreground">No orders</div>
          ) : filteredOrders.map((o: any) => (
            <div key={o.id} className="p-4 flex flex-wrap items-center gap-3">
              <Package className="h-5 w-5 text-muted-foreground shrink-0" />
              <div className="flex-1 min-w-0">
                <p className="font-medium truncate">{o.order_number} · {o.customer_name || o.customer_phone}</p>
                <p className="text-xs text-muted-foreground">
                  {fmtIST(o.placed_at)} · {fmtMoney(o.total, o.currency, format)}
                </p>
              </div>
              <span className={cn("text-xs px-2 py-1 rounded-full",
                o.payment_status === "paid" ? "bg-green-100 text-green-700" :
                o.payment_status === "failed" ? "bg-destructive/10 text-destructive" : "bg-muted")}>
                {o.payment_status}
              </span>
              {o.cod_status && (
                <span className={cn("text-xs px-2 py-1 rounded-full",
                  o.cod_status === "confirmed" ? "bg-green-100 text-green-700" :
                  o.cod_status === "cancelled" ? "bg-destructive/10 text-destructive" : "bg-amber-100 text-amber-700")}>
                  COD: {o.cod_status}
                </span>
              )}
              {o.cod_status === "pending" && (
                <div className="flex gap-1">
                  <Button size="sm" variant="outline" onClick={() => updateCod(o.id, "confirmed")}>
                    <CheckCircle2 className="h-3.5 w-3.5 mr-1" />Confirm
                  </Button>
                  <Button size="sm" variant="outline" onClick={() => updateCod(o.id, "cancelled")}>
                    <XCircle className="h-3.5 w-3.5 mr-1" />Cancel
                  </Button>
                </div>
              )}
            </div>
          ))}
        </Card>
      )}

      {tab === "abandoned" && (
        <Card className="divide-y">
          {filteredAbandoned.length === 0 ? (
            <div className="p-12 text-center text-sm text-muted-foreground">No abandoned carts</div>
          ) : filteredAbandoned.map((a: any) => (
            <div key={a.id} className="p-4 flex flex-wrap items-center gap-3 hover:bg-muted/40 cursor-pointer transition-colors"
              onClick={() => setDetailCart(a)}>
              <AlertTriangle className="h-5 w-5 text-amber-600 shrink-0" />
              <div className="flex-1 min-w-0">
                <p className="font-medium truncate">{a.customer_name || a.customer_phone || a.customer_email || "Anonymous"}</p>
                <p className="text-xs text-muted-foreground">
                  {fmtMoney(a.total, a.currency, format)} · abandoned {fmtIST(a.abandoned_at)} · {a.reminders_sent} reminders sent
                </p>
              </div>
              <span className={cn("text-xs px-2 py-1 rounded-full",
                a.status === "recovered" ? "bg-green-100 text-green-700" : "bg-amber-100 text-amber-700")}>
                {a.status}
              </span>
              {a.customer_phone && a.status !== "recovered" && (
                <Button size="sm" variant="outline"
                  onClick={(e) => { e.stopPropagation(); setTmplDialog({ open: true, cart: a, templateId: "", sending: false }); }}>
                  <MessageSquare className="h-3.5 w-3.5 mr-1" />Send template
                </Button>
              )}
              {a.status !== "recovered" && (
                <>
                  {(a.recovery_url || a.checkout_url) && (
                    <Button size="sm" variant="outline" asChild onClick={(e) => e.stopPropagation()}>
                      <a href={a.recovery_url || a.checkout_url} target="_blank" rel="noreferrer"><Send className="h-3.5 w-3.5 mr-1" />Checkout</a>
                    </Button>
                  )}
                  <Button size="sm" onClick={(e) => { e.stopPropagation(); markRecovered(a.id, Number(a.total)); }}>Mark recovered</Button>
                </>
              )}
            </div>
          ))}
        </Card>
      )}

      <Dialog open={!!detailCart} onOpenChange={(o) => !o && setDetailCart(null)}>
        <DialogContent className="w-[calc(100vw-2rem)] sm:max-w-lg max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="break-words pr-6">{detailCart?.customer_name || detailCart?.customer_phone || detailCart?.customer_email || "Anonymous cart"}</DialogTitle>
            <DialogDescription>Abandoned cart details</DialogDescription>
          </DialogHeader>
          {detailCart && (
            <div className="space-y-3 text-sm">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="min-w-0"><p className="text-muted-foreground text-xs">Phone</p><p className="font-medium break-all">{detailCart.customer_phone || "—"}</p></div>
                <div className="min-w-0"><p className="text-muted-foreground text-xs">Email</p><p className="font-medium break-all">{detailCart.customer_email || "—"}</p></div>
                <div className="min-w-0"><p className="text-muted-foreground text-xs">Total</p><p className="font-medium">{fmtMoney(detailCart.total, detailCart.currency, format)}</p></div>
                <div className="min-w-0"><p className="text-muted-foreground text-xs">Abandoned</p><p className="font-medium break-words">{fmtIST(detailCart.abandoned_at)}</p></div>
                <div className="min-w-0"><p className="text-muted-foreground text-xs">Reminders sent</p><p className="font-medium">{detailCart.reminders_sent ?? 0}</p></div>
                <div className="min-w-0"><p className="text-muted-foreground text-xs">Status</p><p className="font-medium">{detailCart.status}</p></div>
              </div>
              {Array.isArray(detailCart.items) && detailCart.items.length > 0 && (
                <div>
                  <p className="text-muted-foreground text-xs mb-1">Items</p>
                  <div className="border rounded-md divide-y max-h-52 sm:max-h-60 overflow-auto">
                    {detailCart.items.map((it: any, idx: number) => (
                      <div key={idx} className="p-2 flex justify-between gap-3">
                        <span className="min-w-0 break-words line-clamp-2 text-xs sm:text-sm">{it.name || it.title || it.product_name || `Item ${idx + 1}`}</span>
                        <span className="text-muted-foreground shrink-0">×{it.quantity ?? it.qty ?? 1}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {(detailCart.recovery_url || detailCart.checkout_url) && (
                <Button variant="outline" asChild className="w-full">
                  <a href={detailCart.recovery_url || detailCart.checkout_url} target="_blank" rel="noreferrer">Open checkout link</a>
                </Button>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>

      {tab === "customers" && (
        <Card className="divide-y">
          {filteredCustomers.length === 0 ? (
            <div className="p-12 text-center text-sm text-muted-foreground">No customers synced</div>
          ) : filteredCustomers.map((c: any) => (
            <div key={c.id} className="p-4 flex flex-wrap items-center gap-3">
              <div className="h-10 w-10 rounded-full bg-primary/10 text-primary grid place-items-center font-semibold">
                {(c.name || c.email || "?").charAt(0).toUpperCase()}
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-medium truncate">{c.name || c.email || c.phone}</p>
                <p className="text-xs text-muted-foreground">{c.email}{c.phone ? ` · ${c.phone}` : ""}</p>
              </div>
              <div className="text-right">
                <p className="font-semibold">{format(c.lifetime_value)}</p>
                <p className="text-xs text-muted-foreground">{c.total_orders} orders</p>
              </div>
            </div>
          ))}
        </Card>
      )}

      <Dialog open={tmplDialog.open} onOpenChange={(o) => !tmplDialog.sending && setTmplDialog((s) => ({ ...s, open: o }))}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Send WhatsApp template</DialogTitle>
            <DialogDescription>
              {tmplDialog.cart ? `To ${tmplDialog.cart.customer_name || tmplDialog.cart.customer_phone}` : ""}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-2">
            <Label>Approved template</Label>
            <Select value={tmplDialog.templateId} onValueChange={(v) => setTmplDialog((s) => ({ ...s, templateId: v }))}>
              <SelectTrigger><SelectValue placeholder={templates.length ? "Choose a template" : "No approved templates"} /></SelectTrigger>
              <SelectContent>
                {templates.map((t: any) => (
                  <SelectItem key={t.id} value={t.id}>{t.meta_template_name} · {t.language}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setTmplDialog({ open: false, cart: null, templateId: "", sending: false })} disabled={tmplDialog.sending}>Cancel</Button>
            <Button onClick={sendTemplateToCart} disabled={!tmplDialog.templateId || tmplDialog.sending}>
              {tmplDialog.sending ? "Sending…" : "Send"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function fmtMoney(value: any, code: string | null | undefined, fallback: (n: any) => string) {
  if (!code) return fallback(value);
  try {
    const num = Number(value ?? 0);
    return new Intl.NumberFormat(undefined, {
      style: "currency",
      currency: code,
      maximumFractionDigits: num % 1 === 0 ? 0 : 2,
    }).format(num);
  } catch {
    return fallback(value);
  }
}

type FilterState = { range: string; year: string; from: string; to: string; q: string; status: string };

function computeBounds(f: FilterState): { start: number | null; end: number | null } {
  const now = new Date();
  const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
  switch (f.range) {
    case "today": return { start: startOfToday, end: startOfToday + 86400000 };
    case "7d": return { start: now.getTime() - 7 * 86400000, end: null };
    case "30d": return { start: now.getTime() - 30 * 86400000, end: null };
    case "month": return { start: new Date(now.getFullYear(), now.getMonth(), 1).getTime(), end: null };
    case "year": return { start: new Date(now.getFullYear(), 0, 1).getTime(), end: null };
    case "custom": return {
      start: f.from ? new Date(f.from).getTime() : null,
      end: f.to ? new Date(f.to).getTime() + 86400000 : null,
    };
    default: return { start: null, end: null };
  }
}

function applyFilters<T extends Record<string, any>>(
  rows: T[],
  dateField: string,
  f: FilterState,
  bounds: { start: number | null; end: number | null },
  searchable: (row: T) => string,
  statusOf: (row: T) => string | null | undefined,
): T[] {
  const q = f.q.trim().toLowerCase();
  return rows.filter((r) => {
    const raw = r[dateField];
    const ts = raw ? new Date(raw).getTime() : NaN;
    if (!Number.isNaN(ts)) {
      if (bounds.start !== null && ts < bounds.start) return false;
      if (bounds.end !== null && ts >= bounds.end) return false;
      if (f.year !== "all" && new Date(ts).getFullYear() !== Number(f.year)) return false;
    } else if (bounds.start !== null || bounds.end !== null || f.year !== "all") {
      return false;
    }
    if (q && !searchable(r).includes(q)) return false;
    if (f.status !== "all") {
      const s = String(statusOf(r) || "").toLowerCase();
      if (s !== f.status.toLowerCase()) return false;
    }
    return true;
  });
}
