import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useWorkspace } from "@/lib/workspace-context";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Users, FileText, Send, CheckCircle2, AlertCircle, ArrowRight, Sparkles, Clock } from "lucide-react";
import { AiCreditWidget } from "@/components/AiCreditWidget";

export const Route = createFileRoute("/_authenticated/dashboard")({
  component: Dashboard,
  head: () => ({ meta: [{ title: "Dashboard — Slice" }] }),
});

function Dashboard() {
  const { currentWorkspaceId } = useWorkspace();
  const { data: stats } = useQuery({
    queryKey: ["dashboard-stats", currentWorkspaceId],
    enabled: !!currentWorkspaceId,
    queryFn: async () => {
      const ws = currentWorkspaceId!;
      const [contacts, templates, campaigns, settings] = await Promise.all([
        supabase.from("contacts").select("id", { count: "exact", head: true }).eq("workspace_id", ws),
        supabase.from("templates").select("id", { count: "exact", head: true }).eq("workspace_id", ws),
        supabase.from("campaigns").select("id,name,status,sent_count,failed_count,total_count,created_at")
          .eq("workspace_id", ws).order("created_at", { ascending: false }).limit(5),
        supabase.from("whatsapp_settings").select("verified,display_name,business_phone")
          .eq("workspace_id", ws).maybeSingle(),
      ]);
      return {
        contacts: contacts.count ?? 0,
        templates: templates.count ?? 0,
        campaigns: campaigns.data ?? [],
        settings: settings.data,
      };
    },
  });

  const verified = stats?.settings?.verified;

  return (
    <div className="space-y-8">
      <div>
        <h1 className="font-display text-3xl font-bold">Dashboard</h1>
        <p className="text-muted-foreground">Overview of your WhatsApp messaging activity</p>
      </div>

      <TrialBanner />


      {!verified && (
        <Card className="border-warning/40 bg-warning/5 p-5 flex items-start gap-4">
          <AlertCircle className="h-5 w-5 text-warning shrink-0 mt-0.5" />
          <div className="flex-1">
            <p className="font-medium">Connect your Meta WhatsApp Business account</p>
            <p className="text-sm text-muted-foreground">Add your Phone Number ID, WABA ID, and access token to start sending.</p>
          </div>
          <Link to="/settings"><Button size="sm">Open settings <ArrowRight className="ml-1.5 h-3.5 w-3.5" /></Button></Link>
        </Card>
      )}

      {verified && (
        <Card className="p-5 flex items-center gap-4 border-success/30 bg-success/5">
          <div className="grid h-10 w-10 place-items-center rounded-lg bg-success text-success-foreground">
            <CheckCircle2 className="h-5 w-5" />
          </div>
          <div>
            <p className="font-medium">{stats?.settings?.display_name || "Business connected"}</p>
            <p className="text-sm text-muted-foreground">{stats?.settings?.business_phone}</p>
          </div>
        </Card>
      )}

      {currentWorkspaceId && <AiCreditWidget workspaceId={currentWorkspaceId} />}

      <div className="grid gap-4 sm:grid-cols-3">
        <StatCard icon={Users} label="Contacts" value={stats?.contacts ?? 0} to="/contacts" />
        <StatCard icon={FileText} label="Templates" value={stats?.templates ?? 0} to="/templates" />
        <StatCard icon={Send} label="Campaigns" value={stats?.campaigns?.length ?? 0} to="/campaigns" />
      </div>

      <div>
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-display text-xl font-semibold">Recent campaigns</h2>
          <Link to="/campaigns"><Button variant="ghost" size="sm">View all</Button></Link>
        </div>
        <Card className="divide-y">
          {(stats?.campaigns ?? []).length === 0 ? (
            <div className="p-8 text-center text-sm text-muted-foreground">
              No campaigns yet. <Link to="/campaigns" className="text-primary hover:underline">Create your first →</Link>
            </div>
          ) : (
            stats?.campaigns.map((c: any) => (
              <div key={c.id} className="p-4 flex items-center justify-between">
                <div>
                  <p className="font-medium">{c.name}</p>
                  <p className="text-xs text-muted-foreground">
                    {c.sent_count}/{c.total_count} sent · {c.failed_count} failed
                  </p>
                </div>
                <span className="text-xs px-2 py-1 rounded-full bg-secondary text-secondary-foreground">{c.status}</span>
              </div>
            ))
          )}
        </Card>
      </div>
    </div>
  );
}

function StatCard({ icon: Icon, label, value, to }: any) {
  return (
    <Link to={to}>
      <Card className="p-5 hover:shadow-[var(--shadow-md)] transition">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-muted-foreground">{label}</p>
            <p className="mt-1 font-display text-3xl font-bold">{value}</p>
          </div>
          <div className="grid h-10 w-10 place-items-center rounded-lg bg-primary/10 text-primary">
            <Icon className="h-5 w-5" />
          </div>
        </div>
      </Card>
    </Link>
  );
}

function TrialBanner() {
  const { data } = useQuery({
    queryKey: ["my-trial"],
    queryFn: async () => {
      const { data: u } = await supabase.auth.getUser();
      if (!u.user) return null;
      const { data: p } = await supabase
        .from("profiles")
        .select("trial_started_at, trial_ends_at, is_super_admin")
        .eq("id", u.user.id)
        .maybeSingle();
      return p;
    },
  });
  const { currentWorkspaceId } = useWorkspace();
  const isSuperAdmin = !!data?.is_super_admin;
  const { data: plan } = useQuery({
    queryKey: ["my-active-plan", currentWorkspaceId],
    enabled: !!currentWorkspaceId && !isSuperAdmin,
    queryFn: async () => {
      const { data } = await supabase
        .from("workspace_plans")
        .select("plan_name, expires_at, billing_interval")
        .eq("workspace_id", currentWorkspaceId!)
        .maybeSingle();
      return data;
    },
  });

  // Super admin manages plans for everyone — don't show their own expiry banner.
  if (isSuperAdmin) return null;
  const fmt = (d: Date) => d.toLocaleString(undefined, { dateStyle: "medium", timeStyle: "short" });

  // If a paid plan is assigned and still active, show its expiry instead of the trial banner.
  if (plan?.plan_name && plan.expires_at && new Date(plan.expires_at).getTime() > Date.now()) {
    const end = new Date(plan.expires_at);
    const daysLeft = Math.ceil((end.getTime() - Date.now()) / 86_400_000);
    return (
      <Card className="flex items-start gap-4 border-primary/30 bg-primary/5 p-5">
        <Sparkles className="mt-0.5 h-5 w-5 shrink-0 text-primary" />
        <div className="flex-1">
          <p className="font-medium">
            {plan.plan_name} plan · {daysLeft} {daysLeft === 1 ? "day" : "days"} remaining
          </p>
          <p className="text-sm text-muted-foreground">
            Expires <span className="font-medium text-foreground">{fmt(end)}</span>
          </p>
        </div>
        <p className="text-sm text-muted-foreground shrink-0">Plan changes are managed by your workspace admin.</p>
      </Card>
    );
  }

  if (!data?.trial_ends_at) return null;
  const end = new Date(data.trial_ends_at);
  const start = data.trial_started_at ? new Date(data.trial_started_at) : null;
  const msLeft = end.getTime() - Date.now();
  const daysLeft = Math.ceil(msLeft / (1000 * 60 * 60 * 24));

  if (msLeft <= 0) {
    return (
      <Card className="flex items-start gap-4 border-destructive/40 bg-destructive/5 p-5">
        <Clock className="mt-0.5 h-5 w-5 shrink-0 text-destructive" />
        <div className="flex-1">
          <p className="font-medium">Your free trial has ended</p>
          <p className="text-sm text-muted-foreground">
            Expired on <span className="font-medium text-foreground">{fmt(end)}</span>. Upgrade to restore access to all features.
          </p>
        </div>
        <Link to="/subscription"><Button size="sm">Upgrade now <ArrowRight className="ml-1.5 h-3.5 w-3.5" /></Button></Link>
      </Card>
    );
  }
  return (
    <Card className="flex items-start gap-4 border-primary/30 bg-primary/5 p-5">
      <Sparkles className="mt-0.5 h-5 w-5 shrink-0 text-primary" />
      <div className="flex-1">
        <p className="font-medium">
          {daysLeft} {daysLeft === 1 ? "day" : "days"} left in your free trial
        </p>
        <p className="text-sm text-muted-foreground">
          {start && <>Started {fmt(start)} · </>}Expires <span className="font-medium text-foreground">{fmt(end)}</span>
        </p>
      </div>
      <Link to="/subscription"><Button size="sm" variant="outline">View plans</Button></Link>
    </Card>
  );
}


