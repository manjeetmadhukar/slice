import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import { Loader2, Plus, Pencil, Trash2, ArrowLeft, Sparkles, MessageSquare, HelpCircle, Mail } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/admin/cms")({
  component: CmsPage,
  head: () => ({ meta: [{ title: "Landing CMS — Slice Admin" }] }),
});

function CmsPage() {
  const { data: me, isLoading } = useQuery({
    queryKey: ["my-profile"],
    queryFn: async () => {
      const { data: u } = await supabase.auth.getUser();
      if (!u.user) return null;
      const { data } = await supabase.from("profiles").select("is_super_admin").eq("id", u.user.id).maybeSingle();
      return data;
    },
  });

  if (isLoading) return <div className="p-8"><Loader2 className="h-5 w-5 animate-spin" /></div>;
  if (!me?.is_super_admin) {
    return (
      <div className="p-8">
        <h1 className="font-display text-2xl font-semibold">Forbidden</h1>
        <p className="text-muted-foreground">Super admin access required.</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <Link to="/admin" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground">
            <ArrowLeft className="h-3.5 w-3.5" /> Back to admin
          </Link>
          <h1 className="mt-1 font-display text-3xl font-semibold">Landing page CMS</h1>
          <p className="text-muted-foreground">Manage features, testimonials, FAQs and demo requests shown on the public site.</p>
        </div>
      </div>

      <Tabs defaultValue="features" className="space-y-4">
        <TabsList>
          <TabsTrigger value="features"><Sparkles className="mr-1.5 h-4 w-4" /> Features</TabsTrigger>
          <TabsTrigger value="testimonials"><MessageSquare className="mr-1.5 h-4 w-4" /> Testimonials</TabsTrigger>
          <TabsTrigger value="faqs"><HelpCircle className="mr-1.5 h-4 w-4" /> FAQs</TabsTrigger>
          <TabsTrigger value="demos"><Mail className="mr-1.5 h-4 w-4" /> Demo requests</TabsTrigger>
        </TabsList>
        <TabsContent value="features"><FeaturesTab /></TabsContent>
        <TabsContent value="testimonials"><TestimonialsTab /></TabsContent>
        <TabsContent value="faqs"><FaqsTab /></TabsContent>
        <TabsContent value="demos"><DemosTab /></TabsContent>
      </Tabs>
    </div>
  );
}

// ============ Features ============
type FeatureRow = {
  id: string; name: string; description: string | null; icon: string; category: string; position: number; is_active: boolean;
};
function FeaturesTab() {
  const qc = useQueryClient();
  const { data } = useQuery({
    queryKey: ["cms-features"],
    queryFn: async () => {
      const { data, error } = await supabase.from("landing_features").select("*").order("position");
      if (error) throw error;
      return data as FeatureRow[];
    },
  });
  const [edit, setEdit] = useState<Partial<FeatureRow> | null>(null);

  const save = useMutation({
    mutationFn: async (f: Partial<FeatureRow>) => {
      if (!f.name) throw new Error("Name required");
      const payload = { name: f.name, description: f.description ?? null, icon: f.icon || "Sparkles", category: f.category || "General", position: f.position ?? 0, is_active: f.is_active ?? true };
      if (f.id) {
        const { error } = await supabase.from("landing_features").update(payload).eq("id", f.id);
        if (error) throw error;
      } else {
        const { error } = await supabase.from("landing_features").insert(payload);
        if (error) throw error;
      }
    },
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["cms-features"] }); setEdit(null); toast.success("Saved"); },
    onError: (e: any) => toast.error(e.message),
  });
  const del = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("landing_features").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["cms-features"] }); toast.success("Deleted"); },
  });

  return (
    <Card className="p-5">
      <div className="mb-4 flex items-center justify-between">
        <h3 className="font-display text-lg font-semibold">Features ({data?.length ?? 0})</h3>
        <Button size="sm" onClick={() => setEdit({})}><Plus className="mr-1.5 h-4 w-4" /> New feature</Button>
      </div>
      <div className="grid gap-2">
        {data?.map((f) => (
          <div key={f.id} className="flex items-center gap-3 rounded-lg border p-3">
            <div className="flex-1">
              <div className="flex items-center gap-2">
                <span className="font-medium">{f.name}</span>
                <Badge variant="secondary" className="text-xs">{f.category}</Badge>
                {!f.is_active && <Badge variant="outline" className="text-xs">Inactive</Badge>}
              </div>
              {f.description && <p className="text-xs text-muted-foreground">{f.description}</p>}
            </div>
            <span className="text-xs text-muted-foreground">#{f.position}</span>
            <Button size="sm" variant="ghost" onClick={() => setEdit(f)}><Pencil className="h-4 w-4" /></Button>
            <Button size="sm" variant="ghost" onClick={() => { if (confirm("Delete?")) del.mutate(f.id); }}><Trash2 className="h-4 w-4" /></Button>
          </div>
        ))}
      </div>

      <Dialog open={edit !== null} onOpenChange={(o) => !o && setEdit(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>{edit?.id ? "Edit feature" : "New feature"}</DialogTitle></DialogHeader>
          {edit && (
            <div className="space-y-3">
              <div><Label>Name</Label><Input value={edit.name ?? ""} onChange={(e) => setEdit({ ...edit, name: e.target.value })} /></div>
              <div><Label>Description</Label><Textarea rows={2} value={edit.description ?? ""} onChange={(e) => setEdit({ ...edit, description: e.target.value })} /></div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label>Icon (Lucide name)</Label>
                  <Input value={edit.icon ?? "Sparkles"} onChange={(e) => setEdit({ ...edit, icon: e.target.value })} placeholder="MessageCircle" />
                </div>
                <div><Label>Category</Label><Input value={edit.category ?? ""} onChange={(e) => setEdit({ ...edit, category: e.target.value })} placeholder="Marketing" /></div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div><Label>Position</Label><Input type="number" value={edit.position ?? 0} onChange={(e) => setEdit({ ...edit, position: Number(e.target.value) })} /></div>
                <div className="flex items-end gap-2"><Switch checked={edit.is_active ?? true} onCheckedChange={(v) => setEdit({ ...edit, is_active: v })} /><Label>Active</Label></div>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setEdit(null)}>Cancel</Button>
            <Button onClick={() => edit && save.mutate(edit)} disabled={save.isPending}>
              {save.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />} Save
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  );
}

// ============ Testimonials ============
type TestimonialRow = {
  id: string; name: string; company: string | null; role: string | null; photo_url: string | null;
  review: string; rating: number; position: number; is_active: boolean;
};
function TestimonialsTab() {
  const qc = useQueryClient();
  const { data } = useQuery({
    queryKey: ["cms-testimonials"],
    queryFn: async () => {
      const { data, error } = await supabase.from("landing_testimonials").select("*").order("position");
      if (error) throw error;
      return data as TestimonialRow[];
    },
  });
  const [edit, setEdit] = useState<Partial<TestimonialRow> | null>(null);
  const save = useMutation({
    mutationFn: async (t: Partial<TestimonialRow>) => {
      if (!t.name || !t.review) throw new Error("Name and review required");
      const payload = { name: t.name, company: t.company ?? null, role: t.role ?? null, photo_url: t.photo_url ?? null, review: t.review, rating: t.rating ?? 5, position: t.position ?? 0, is_active: t.is_active ?? true };
      if (t.id) { const { error } = await supabase.from("landing_testimonials").update(payload).eq("id", t.id); if (error) throw error; }
      else { const { error } = await supabase.from("landing_testimonials").insert(payload); if (error) throw error; }
    },
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["cms-testimonials"] }); setEdit(null); toast.success("Saved"); },
    onError: (e: any) => toast.error(e.message),
  });
  const del = useMutation({
    mutationFn: async (id: string) => { const { error } = await supabase.from("landing_testimonials").delete().eq("id", id); if (error) throw error; },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["cms-testimonials"] }),
  });

  return (
    <Card className="p-5">
      <div className="mb-4 flex items-center justify-between">
        <h3 className="font-display text-lg font-semibold">Testimonials ({data?.length ?? 0})</h3>
        <Button size="sm" onClick={() => setEdit({})}><Plus className="mr-1.5 h-4 w-4" /> New</Button>
      </div>
      <div className="grid gap-2">
        {data?.map((t) => (
          <div key={t.id} className="flex items-center gap-3 rounded-lg border p-3">
            <div className="flex-1">
              <div className="font-medium">{t.name} <span className="text-xs text-muted-foreground">· {t.company}</span></div>
              <p className="line-clamp-1 text-xs text-muted-foreground">{t.review}</p>
            </div>
            <Button size="sm" variant="ghost" onClick={() => setEdit(t)}><Pencil className="h-4 w-4" /></Button>
            <Button size="sm" variant="ghost" onClick={() => { if (confirm("Delete?")) del.mutate(t.id); }}><Trash2 className="h-4 w-4" /></Button>
          </div>
        ))}
      </div>

      <Dialog open={edit !== null} onOpenChange={(o) => !o && setEdit(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>{edit?.id ? "Edit testimonial" : "New testimonial"}</DialogTitle></DialogHeader>
          {edit && (
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div><Label>Name</Label><Input value={edit.name ?? ""} onChange={(e) => setEdit({ ...edit, name: e.target.value })} /></div>
                <div><Label>Company</Label><Input value={edit.company ?? ""} onChange={(e) => setEdit({ ...edit, company: e.target.value })} /></div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div><Label>Role</Label><Input value={edit.role ?? ""} onChange={(e) => setEdit({ ...edit, role: e.target.value })} /></div>
                <div><Label>Photo URL</Label><Input value={edit.photo_url ?? ""} onChange={(e) => setEdit({ ...edit, photo_url: e.target.value })} /></div>
              </div>
              <div><Label>Review</Label><Textarea rows={3} value={edit.review ?? ""} onChange={(e) => setEdit({ ...edit, review: e.target.value })} /></div>
              <div className="grid grid-cols-3 gap-3">
                <div><Label>Rating</Label><Input type="number" min={1} max={5} value={edit.rating ?? 5} onChange={(e) => setEdit({ ...edit, rating: Number(e.target.value) })} /></div>
                <div><Label>Position</Label><Input type="number" value={edit.position ?? 0} onChange={(e) => setEdit({ ...edit, position: Number(e.target.value) })} /></div>
                <div className="flex items-end gap-2"><Switch checked={edit.is_active ?? true} onCheckedChange={(v) => setEdit({ ...edit, is_active: v })} /><Label>Active</Label></div>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setEdit(null)}>Cancel</Button>
            <Button onClick={() => edit && save.mutate(edit)} disabled={save.isPending}>{save.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}Save</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  );
}

// ============ FAQs ============
type FaqRow = { id: string; question: string; answer: string; position: number; is_active: boolean };
function FaqsTab() {
  const qc = useQueryClient();
  const { data } = useQuery({
    queryKey: ["cms-faqs"],
    queryFn: async () => {
      const { data, error } = await supabase.from("landing_faqs").select("*").order("position");
      if (error) throw error;
      return data as FaqRow[];
    },
  });
  const [edit, setEdit] = useState<Partial<FaqRow> | null>(null);
  const save = useMutation({
    mutationFn: async (f: Partial<FaqRow>) => {
      if (!f.question || !f.answer) throw new Error("Question and answer required");
      const payload = { question: f.question, answer: f.answer, position: f.position ?? 0, is_active: f.is_active ?? true };
      if (f.id) { const { error } = await supabase.from("landing_faqs").update(payload).eq("id", f.id); if (error) throw error; }
      else { const { error } = await supabase.from("landing_faqs").insert(payload); if (error) throw error; }
    },
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["cms-faqs"] }); setEdit(null); toast.success("Saved"); },
    onError: (e: any) => toast.error(e.message),
  });
  const del = useMutation({
    mutationFn: async (id: string) => { const { error } = await supabase.from("landing_faqs").delete().eq("id", id); if (error) throw error; },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["cms-faqs"] }),
  });

  return (
    <Card className="p-5">
      <div className="mb-4 flex items-center justify-between">
        <h3 className="font-display text-lg font-semibold">FAQs ({data?.length ?? 0})</h3>
        <Button size="sm" onClick={() => setEdit({})}><Plus className="mr-1.5 h-4 w-4" /> New</Button>
      </div>
      <div className="grid gap-2">
        {data?.map((f) => (
          <div key={f.id} className="flex items-center gap-3 rounded-lg border p-3">
            <div className="flex-1">
              <div className="font-medium">{f.question}</div>
              <p className="line-clamp-1 text-xs text-muted-foreground">{f.answer}</p>
            </div>
            <Button size="sm" variant="ghost" onClick={() => setEdit(f)}><Pencil className="h-4 w-4" /></Button>
            <Button size="sm" variant="ghost" onClick={() => { if (confirm("Delete?")) del.mutate(f.id); }}><Trash2 className="h-4 w-4" /></Button>
          </div>
        ))}
      </div>

      <Dialog open={edit !== null} onOpenChange={(o) => !o && setEdit(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>{edit?.id ? "Edit FAQ" : "New FAQ"}</DialogTitle></DialogHeader>
          {edit && (
            <div className="space-y-3">
              <div><Label>Question</Label><Input value={edit.question ?? ""} onChange={(e) => setEdit({ ...edit, question: e.target.value })} /></div>
              <div><Label>Answer</Label><Textarea rows={4} value={edit.answer ?? ""} onChange={(e) => setEdit({ ...edit, answer: e.target.value })} /></div>
              <div className="grid grid-cols-2 gap-3">
                <div><Label>Position</Label><Input type="number" value={edit.position ?? 0} onChange={(e) => setEdit({ ...edit, position: Number(e.target.value) })} /></div>
                <div className="flex items-end gap-2"><Switch checked={edit.is_active ?? true} onCheckedChange={(v) => setEdit({ ...edit, is_active: v })} /><Label>Active</Label></div>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setEdit(null)}>Cancel</Button>
            <Button onClick={() => edit && save.mutate(edit)} disabled={save.isPending}>{save.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}Save</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  );
}

// ============ Demo Requests ============
function DemosTab() {
  const { data } = useQuery({
    queryKey: ["cms-demos"],
    queryFn: async () => {
      const { data, error } = await supabase.from("demo_requests").select("*").order("created_at", { ascending: false });
      if (error) throw error;
      return data;
    },
  });
  return (
    <Card className="p-5">
      <h3 className="mb-4 font-display text-lg font-semibold">Demo requests ({data?.length ?? 0})</h3>
      <div className="grid gap-2">
        {data?.map((d: any) => (
          <div key={d.id} className="rounded-lg border p-3 text-sm">
            <div className="flex items-center justify-between">
              <div className="font-medium">{d.full_name} <span className="text-muted-foreground">· {d.email}</span></div>
              <span className="text-xs text-muted-foreground">{new Date(d.created_at).toLocaleString()}</span>
            </div>
            <div className="mt-1 text-xs text-muted-foreground">
              {[d.phone, d.company, d.business_type].filter(Boolean).join(" · ")}
            </div>
            {d.message && <p className="mt-2 text-sm">{d.message}</p>}
          </div>
        ))}
        {(!data || data.length === 0) && <p className="text-sm text-muted-foreground">No requests yet.</p>}
      </div>
    </Card>
  );
}
