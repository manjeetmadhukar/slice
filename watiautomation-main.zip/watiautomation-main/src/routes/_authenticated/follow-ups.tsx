import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useWorkspace } from "@/lib/workspace-context";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";
import { Plus, Bell, Check, Clock, User, Trash2, AlertTriangle } from "lucide-react";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/follow-ups")({
  component: FollowUps,
  head: () => ({ meta: [{ title: "Follow-ups — Slice" }] }),
});

type Filter = "pending" | "overdue" | "completed";

function FollowUps() {
  const qc = useQueryClient();
  const { currentWorkspaceId } = useWorkspace();
  const [open, setOpen] = useState(false);
  const [filter, setFilter] = useState<Filter>("pending");
  const [form, setForm] = useState({
    title: "", notes: "", contact_id: "", due_at: "", assigned_to: "", type: "manual",
  });

  const { data: followUps = [] } = useQuery({
    queryKey: ["follow-ups", currentWorkspaceId, filter],
    enabled: !!currentWorkspaceId,
    queryFn: async () => {
      let q = supabase.from("follow_ups").select("*, contacts(name, phone)")
        .eq("workspace_id", currentWorkspaceId!);
      const now = new Date().toISOString();
      if (filter === "pending") q = q.eq("status", "pending").gte("due_at", now);
      else if (filter === "overdue") q = q.eq("status", "pending").lt("due_at", now);
      else q = q.eq("status", "completed");
      const { data, error } = await q.order("due_at", { ascending: filter !== "completed" });
      if (error) throw error;
      return data;
    },
  });

  const { data: contacts = [] } = useQuery({
    queryKey: ["contacts-light", currentWorkspaceId],
    enabled: !!currentWorkspaceId,
    queryFn: async () => {
      const { data } = await supabase.from("contacts").select("id, name, phone")
        .eq("workspace_id", currentWorkspaceId!).order("name").limit(500);
      return data ?? [];
    },
  });

  const { data: members = [] } = useQuery({
    queryKey: ["ws-members-fu", currentWorkspaceId],
    enabled: !!currentWorkspaceId,
    queryFn: async () => {
      const { data } = await supabase.from("workspace_members").select("user_id")
        .eq("workspace_id", currentWorkspaceId!);
      const ids = (data ?? []).map((m: any) => m.user_id);
      const { data: profiles } = await supabase.from("profiles").select("id, full_name, email").in("id", ids);
      return profiles ?? [];
    },
  });

  async function create() {
    if (!currentWorkspaceId || !form.title.trim() || !form.due_at) {
      return toast.error("Title and due date required");
    }
    const { data: u } = await supabase.auth.getUser();
    const { error } = await supabase.from("follow_ups").insert({
      workspace_id: currentWorkspaceId,
      user_id: u.user!.id,
      title: form.title.trim(),
      notes: form.notes || null,
      contact_id: form.contact_id || null,
      due_at: new Date(form.due_at).toISOString(),
      assigned_to: form.assigned_to || u.user!.id,
      type: form.type,
    });
    if (error) return toast.error(error.message);
    toast.success("Follow-up created");
    setOpen(false);
    setForm({ title: "", notes: "", contact_id: "", due_at: "", assigned_to: "", type: "manual" });
    qc.invalidateQueries({ queryKey: ["follow-ups"] });
  }

  async function complete(id: string) {
    const { error } = await supabase.from("follow_ups")
      .update({ status: "completed", completed_at: new Date().toISOString() }).eq("id", id);
    if (error) return toast.error(error.message);
    qc.invalidateQueries({ queryKey: ["follow-ups"] });
  }

  async function del(id: string) {
    const { error } = await supabase.from("follow_ups").delete().eq("id", id);
    if (error) return toast.error(error.message);
    qc.invalidateQueries({ queryKey: ["follow-ups"] });
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-3xl font-bold flex items-center gap-2">
            <Bell className="h-7 w-7" />Follow-ups
          </h1>
          <p className="text-muted-foreground">Stay on top of every lead</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild><Button><Plus className="mr-2 h-4 w-4" />New follow-up</Button></DialogTrigger>
          <DialogContent>
            <DialogHeader><DialogTitle>New follow-up</DialogTitle></DialogHeader>
            <div className="space-y-3">
              <div><Label>Title</Label><Input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="Call back about pricing" /></div>
              <div><Label>Notes</Label><Textarea rows={2} value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} /></div>
              <div>
                <Label>Contact</Label>
                <Select value={form.contact_id} onValueChange={(v) => setForm({ ...form, contact_id: v })}>
                  <SelectTrigger><SelectValue placeholder="Select contact" /></SelectTrigger>
                  <SelectContent>
                    {contacts.map((c: any) => <SelectItem key={c.id} value={c.id}>{c.name} · {c.phone}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div><Label>Due</Label><Input type="datetime-local" value={form.due_at} onChange={(e) => setForm({ ...form, due_at: e.target.value })} /></div>
                <div>
                  <Label>Assign to</Label>
                  <Select value={form.assigned_to} onValueChange={(v) => setForm({ ...form, assigned_to: v })}>
                    <SelectTrigger><SelectValue placeholder="Me" /></SelectTrigger>
                    <SelectContent>
                      {members.map((m: any) => <SelectItem key={m.id} value={m.id}>{m.full_name || m.email}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>
            <DialogFooter><Button onClick={create}>Create</Button></DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <Tabs value={filter} onValueChange={(v) => setFilter(v as Filter)}>
        <TabsList>
          <TabsTrigger value="pending"><Clock className="h-3.5 w-3.5 mr-1.5" />Upcoming</TabsTrigger>
          <TabsTrigger value="overdue"><AlertTriangle className="h-3.5 w-3.5 mr-1.5" />Overdue</TabsTrigger>
          <TabsTrigger value="completed"><Check className="h-3.5 w-3.5 mr-1.5" />Completed</TabsTrigger>
        </TabsList>
      </Tabs>

      <Card className="divide-y">
        {followUps.length === 0 ? (
          <div className="p-12 text-center text-sm text-muted-foreground">No {filter} follow-ups</div>
        ) : followUps.map((f: any) => {
          const overdue = filter === "overdue";
          return (
            <div key={f.id} className="p-4 flex items-center gap-3">
              <div className={cn("h-9 w-9 rounded-full grid place-items-center shrink-0",
                overdue ? "bg-destructive/10 text-destructive" : f.status === "completed" ? "bg-green-100 text-green-700" : "bg-primary/10 text-primary")}>
                {f.status === "completed" ? <Check className="h-4 w-4" /> : overdue ? <AlertTriangle className="h-4 w-4" /> : <Clock className="h-4 w-4" />}
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-medium truncate">{f.title}</p>
                <p className="text-xs text-muted-foreground flex flex-wrap gap-x-3">
                  <span>{new Date(f.due_at).toLocaleString()}</span>
                  {f.contacts && <span className="flex items-center gap-0.5"><User className="h-3 w-3" />{f.contacts.name}</span>}
                  <span className="capitalize">· {f.type}</span>
                </p>
                {f.notes && <p className="text-sm text-muted-foreground mt-1">{f.notes}</p>}
              </div>
              {f.status === "pending" && (
                <Button size="sm" variant="outline" onClick={() => complete(f.id)}>
                  <Check className="h-3.5 w-3.5 mr-1" />Done
                </Button>
              )}
              <Button size="icon" variant="ghost" onClick={() => del(f.id)}>
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          );
        })}
      </Card>
    </div>
  );
}
