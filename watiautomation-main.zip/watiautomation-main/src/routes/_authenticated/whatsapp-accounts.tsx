import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { supabase } from "@/integrations/supabase/client";
import { useWorkspace } from "@/lib/workspace-context";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";
import { Plus, RefreshCw, Trash2, CheckCircle2, AlertTriangle, MessageCircle, Smartphone, Activity, Webhook, Loader2, KeyRound } from "lucide-react";
import {
  syncWhatsAppAccount,
  setActiveWhatsAppAccount,
  disconnectWhatsAppAccount,
  registerWhatsAppPhoneNumber,
} from "@/lib/whatsapp-accounts.functions";

export const Route = createFileRoute("/_authenticated/whatsapp-accounts")({
  component: WhatsAppAccountsPage,
});

type Account = {
  id: string;
  business_name: string | null;
  display_name: string | null;
  phone_number: string | null;
  phone_number_id: string;
  waba_id: string;
  quality_rating: string | null;
  messaging_tier: string | null;
  display_name_status: string | null;
  status: string;
  webhook_status: string;
  webhook_last_event_at: string | null;
  sync_status: string;
  last_synced_at: string | null;
  last_error: string | null;
  is_active: boolean;
  connected_at: string;
};

function qualityColor(q: string | null) {
  switch ((q || "").toUpperCase()) {
    case "GREEN": return "bg-emerald-500/15 text-emerald-600 border-emerald-500/30";
    case "YELLOW": return "bg-amber-500/15 text-amber-600 border-amber-500/30";
    case "RED": return "bg-rose-500/15 text-rose-600 border-rose-500/30";
    default: return "bg-muted text-muted-foreground";
  }
}

function statusBadge(s: string) {
  const map: Record<string, string> = {
    connected: "bg-emerald-500/15 text-emerald-600 border-emerald-500/30",
    pending: "bg-amber-500/15 text-amber-600 border-amber-500/30",
    disconnected: "bg-muted text-muted-foreground",
    error: "bg-rose-500/15 text-rose-600 border-rose-500/30",
  };
  return map[s] ?? "bg-muted text-muted-foreground";
}

function WhatsAppAccountsPage() {
  const { current } = useWorkspace();
  const wsId = current?.workspace_id;
  const [accounts, setAccounts] = useState<Account[]>([]);
  const [loading, setLoading] = useState(true);
  const [busyId, setBusyId] = useState<string | null>(null);

  const syncFn = useServerFn(syncWhatsAppAccount);
  const activateFn = useServerFn(setActiveWhatsAppAccount);
  const disconnectFn = useServerFn(disconnectWhatsAppAccount);
  const registerFn = useServerFn(registerWhatsAppPhoneNumber);

  async function refresh() {
    if (!wsId) return;
    setLoading(true);
    const { data, error } = await supabase
      .from("whatsapp_accounts")
      .select("*")
      .eq("workspace_id", wsId)
      .order("connected_at", { ascending: false });
    if (error) toast.error(error.message);
    setAccounts((data as Account[]) || []);
    setLoading(false);
  }

  useEffect(() => { refresh(); }, [wsId]);

  const active = useMemo(() => accounts.find((a) => a.is_active) ?? accounts[0], [accounts]);

  async function handleSync(id: string) {
    setBusyId(id);
    try {
      const r = await syncFn({ data: { account_id: id } });
      if ((r as any).ok) toast.success(`Synced. ${(r as any).template_count ?? 0} templates updated.`);
      else toast.error((r as any).error || "Sync failed");
      await refresh();
    } catch (e: any) { toast.error(e.message); }
    finally { setBusyId(null); }
  }

  async function handleActivate(id: string) {
    setBusyId(id);
    try {
      await activateFn({ data: { account_id: id } });
      toast.success("Set as active number");
      await refresh();
    } catch (e: any) { toast.error(e.message); }
    finally { setBusyId(null); }
  }

  async function handleDisconnect(id: string) {
    if (!confirm("Disconnect this WhatsApp number? You can reconnect anytime.")) return;
    setBusyId(id);
    try {
      await disconnectFn({ data: { account_id: id } });
      toast.success("Disconnected");
      await refresh();
    } catch (e: any) { toast.error(e.message); }
    finally { setBusyId(null); }
  }

  async function handleRegister(id: string) {
    setBusyId(id);
    try {
      const r: any = await registerFn({ data: { account_id: id } });
      if (r.ok) toast.success(`Phone registered with Cloud API (PIN ${r.pin})`);
      else toast.error(r.error || "Registration failed");
      await refresh();
    } catch (e: any) { toast.error(e.message); }
    finally { setBusyId(null); }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-3xl font-display font-bold tracking-tight">WhatsApp Accounts</h1>
          <p className="text-muted-foreground mt-1">
            Connect your existing WhatsApp Business numbers and manage health, sync, and webhooks.
          </p>
        </div>
        <Button asChild size="lg" className="gap-2">
          <Link to="/whatsapp-setup"><Plus className="h-4 w-4" /> Connect WhatsApp Number</Link>
        </Button>
      </div>

      {/* Top status cards */}
      <div className="grid gap-4 md:grid-cols-4">
        <StatCard icon={Smartphone} label="Connected Numbers" value={String(accounts.length)} />
        <StatCard icon={CheckCircle2} label="Active Number" value={active?.phone_number ?? "—"} />
        <StatCard icon={Activity} label="Quality" value={(active?.quality_rating || "—").toString()} />
        <StatCard icon={Webhook} label="Webhook" value={active?.webhook_status ?? "—"} />
      </div>

      <Tabs defaultValue="numbers">
        <TabsList>
          <TabsTrigger value="numbers">Connected Numbers</TabsTrigger>
          <TabsTrigger value="health">Health & Quality</TabsTrigger>
          <TabsTrigger value="webhook">Webhook</TabsTrigger>
        </TabsList>

        <TabsContent value="numbers" className="space-y-4">
          {loading ? (
            <div className="flex items-center justify-center py-12 text-muted-foreground">
              <Loader2 className="h-5 w-5 animate-spin mr-2" /> Loading…
            </div>
          ) : accounts.length === 0 ? (
            <EmptyState />
          ) : (
            <Card>
              <CardContent className="p-0">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Business</TableHead>
                      <TableHead>Number</TableHead>
                      <TableHead>WABA ID</TableHead>
                      <TableHead>Quality</TableHead>
                      <TableHead>Tier</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Connected</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {accounts.map((a) => (
                      <TableRow key={a.id}>
                        <TableCell>
                          <div className="font-medium">{a.business_name || a.display_name || "—"}</div>
                          <div className="text-xs text-muted-foreground">{a.display_name}</div>
                        </TableCell>
                        <TableCell className="font-mono text-sm">{a.phone_number || "—"}</TableCell>
                        <TableCell className="font-mono text-xs text-muted-foreground">{a.waba_id}</TableCell>
                        <TableCell><Badge variant="outline" className={qualityColor(a.quality_rating)}>{a.quality_rating || "—"}</Badge></TableCell>
                        <TableCell className="text-sm">{a.messaging_tier?.replace("TIER_", "") || "—"}</TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Badge variant="outline" className={statusBadge(a.status)}>{a.status}</Badge>
                            {a.is_active && <Badge variant="secondary" className="gap-1"><CheckCircle2 className="h-3 w-3" /> Active</Badge>}
                          </div>
                        </TableCell>
                        <TableCell className="text-xs text-muted-foreground">
                          {new Date(a.connected_at).toLocaleDateString()}
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-1">
                            <Button size="sm" variant="ghost" onClick={() => handleSync(a.id)} disabled={busyId === a.id} title="Sync from Meta">
                              {busyId === a.id ? <Loader2 className="h-4 w-4 animate-spin" /> : <RefreshCw className="h-4 w-4" />}
                            </Button>
                            <Button size="sm" variant="outline" onClick={() => handleRegister(a.id)} disabled={busyId === a.id} title="Register with Cloud API (fixes #133010)" className="gap-1">
                              <KeyRound className="h-3.5 w-3.5" /> Register
                            </Button>
                            {!a.is_active && (
                              <Button size="sm" variant="outline" onClick={() => handleActivate(a.id)} disabled={busyId === a.id}>
                                Set Active
                              </Button>
                            )}
                            <Button size="sm" variant="ghost" onClick={() => handleDisconnect(a.id)} disabled={busyId === a.id}>
                              <Trash2 className="h-4 w-4 text-rose-500" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="health" className="space-y-4">
          {accounts.length === 0 ? (
            <EmptyState />
          ) : (
            <div className="grid gap-4 md:grid-cols-2">
              {accounts.map((a) => (
                <Card key={a.id}>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-base">{a.business_name || a.display_name || a.phone_number}</CardTitle>
                      <Badge variant="outline" className={qualityColor(a.quality_rating)}>{a.quality_rating || "—"}</Badge>
                    </div>
                    <CardDescription className="font-mono">{a.phone_number}</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-3 text-sm">
                    <HealthRow label="Messaging Tier" value={a.messaging_tier || "—"} />
                    <HealthRow label="Display Name" value={a.display_name_status || "—"} />
                    <HealthRow label="Webhook" value={a.webhook_status} />
                    <HealthRow label="Last Synced" value={a.last_synced_at ? new Date(a.last_synced_at).toLocaleString() : "Never"} />
                    {a.last_error && (
                      <div className="flex items-start gap-2 rounded-md bg-rose-500/10 border border-rose-500/20 p-2 text-rose-600 text-xs">
                        <AlertTriangle className="h-4 w-4 mt-0.5 shrink-0" />
                        <span>{a.last_error}</span>
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="webhook" className="space-y-4">
          <WebhookSetupPanel accounts={accounts} />
        </TabsContent>
      </Tabs>

    </div>
  );
}

function StatCard({ icon: Icon, label, value }: { icon: any; label: string; value: string }) {
  return (
    <Card>
      <CardContent className="p-4 flex items-center gap-3">
        <div className="grid h-10 w-10 place-items-center rounded-lg bg-primary/10 text-primary">
          <Icon className="h-5 w-5" />
        </div>
        <div className="min-w-0">
          <div className="text-xs uppercase tracking-wide text-muted-foreground">{label}</div>
          <div className="font-semibold truncate">{value}</div>
        </div>
      </CardContent>
    </Card>
  );
}

function HealthRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between border-b last:border-b-0 pb-2 last:pb-0">
      <span className="text-muted-foreground">{label}</span>
      <span className="font-medium">{value}</span>
    </div>
  );
}

function EmptyState() {
  return (
    <Card>
      <CardContent className="py-12 text-center space-y-4">
        <div className="mx-auto grid h-16 w-16 place-items-center rounded-2xl bg-emerald-500/10 text-emerald-600">
          <MessageCircle className="h-8 w-8" />
        </div>
        <div>
          <h3 className="text-lg font-semibold">No WhatsApp number connected yet</h3>
          <p className="text-muted-foreground text-sm mt-1 max-w-md mx-auto">
            Connect in one click using Meta's official Embedded Signup — no tokens or IDs to copy.
          </p>
        </div>
        <Button asChild size="lg" className="gap-2">
          <Link to="/whatsapp-setup"><Plus className="h-4 w-4" /> Connect WhatsApp Number</Link>
        </Button>
      </CardContent>
    </Card>
  );
}


function WebhookSetupPanel({ accounts }: { accounts: Account[] }) {
  return (
    <div className="space-y-4">
      <Card className="border-emerald-500/30 bg-emerald-500/5">
        <CardContent className="p-4 flex gap-3 text-sm">
          <CheckCircle2 className="h-5 w-5 text-emerald-600 shrink-0 mt-0.5" />
          <div className="space-y-1">
            <p className="font-medium">Webhook is managed automatically</p>
            <p className="text-muted-foreground">
              When you connect a WhatsApp number, we automatically subscribe it to our webhook and
              sync your templates and phone info. New messages flow into your Inbox in real time —
              no manual setup required.
            </p>
            <p className="text-muted-foreground">
              Note: Meta's Cloud API does not provide message history. Only conversations that start
              <span className="font-medium"> after </span> connection will appear.
            </p>
          </div>
        </CardContent>
      </Card>

      {accounts.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2"><Webhook className="h-4 w-4" /> Per-number status</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-3 md:grid-cols-2">
              {accounts.map((a) => (
                <div key={a.id} className="flex items-center justify-between rounded-md border p-3">
                  <div>
                    <div className="font-medium">{a.phone_number}</div>
                    <div className="text-xs text-muted-foreground">
                      Last event: {a.webhook_last_event_at ? new Date(a.webhook_last_event_at).toLocaleString() : "—"}
                    </div>
                  </div>
                  <Badge variant="outline" className={a.webhook_status === "subscribed" || a.webhook_status === "verified" ? qualityColor("GREEN") : a.webhook_status === "error" ? qualityColor("RED") : qualityColor("YELLOW")}>
                    {a.webhook_status}
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
