import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useWorkspace } from "@/lib/workspace-context";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { CheckCircle2, ShieldCheck, MessageCircle, ArrowRight } from "lucide-react";

export const Route = createFileRoute("/_authenticated/settings")({
  component: Settings,
  head: () => ({ meta: [{ title: "Settings — Slice" }] }),
});

function Settings() {
  const { currentWorkspaceId } = useWorkspace();

  const { data } = useQuery({
    queryKey: ["settings", currentWorkspaceId],
    enabled: !!currentWorkspaceId,
    queryFn: async () => {
      const { data } = await supabase.from("whatsapp_settings").select("*")
        .eq("workspace_id", currentWorkspaceId!)
        .maybeSingle();
      return data;
    },
  });

  const connected = !!data?.verified;

  return (
    <div className="space-y-8 max-w-3xl">
      <div>
        <h1 className="font-display text-3xl font-bold">Settings</h1>
        <p className="text-muted-foreground">Your WhatsApp Business connection</p>
      </div>

      <Card className="p-6 space-y-5">
        <div className="flex items-start gap-3">
          <ShieldCheck className="h-5 w-5 text-primary mt-1" />
          <div>
            <h2 className="font-display text-lg font-semibold">WhatsApp Business Account</h2>
            <p className="text-sm text-muted-foreground">
              Connections are managed automatically through Meta's official Embedded Signup. No tokens or IDs to copy.
            </p>
          </div>
        </div>

        {connected ? (
          <div className="rounded-lg border border-success/30 bg-success/5 p-4 flex items-center gap-3">
            <CheckCircle2 className="h-5 w-5 text-success" />
            <div className="flex-1">
              <p className="font-medium">{data?.display_name || "Connected"}</p>
              <p className="text-sm text-muted-foreground">{data?.business_phone}</p>
            </div>
            <Button asChild variant="outline" size="sm">
              <Link to="/whatsapp-accounts">Manage accounts <ArrowRight className="ml-1 h-3.5 w-3.5" /></Link>
            </Button>
          </div>
        ) : (
          <div className="rounded-lg border border-dashed p-6 text-center space-y-3">
            <div className="mx-auto grid h-12 w-12 place-items-center rounded-xl bg-primary/10 text-primary">
              <MessageCircle className="h-6 w-6" />
            </div>
            <div>
              <p className="font-medium">No WhatsApp number connected</p>
              <p className="text-sm text-muted-foreground">Connect in one click using Meta's Embedded Signup.</p>
            </div>
            <Button asChild size="lg">
              <Link to="/whatsapp-setup">Connect WhatsApp</Link>
            </Button>
          </div>
        )}
      </Card>
    </div>
  );
}
