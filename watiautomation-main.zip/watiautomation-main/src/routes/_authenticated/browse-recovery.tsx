import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useWorkspace } from "@/lib/workspace-context";
import {
  getBrowseSettings,
  saveBrowseSettings,
  createBrowseTrackerToken,
  revokeBrowseTrackerToken,
  getBrowseAnalytics,
  getBrowseEvents,
} from "@/lib/browse-recovery.functions";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { toast } from "sonner";
import { Copy, Trash2, Eye, Send, MousePointerClick, ShoppingBag, Sparkles, ExternalLink } from "lucide-react";
import { BrowseRecoveryTemplateGuide } from "@/components/BrowseRecoveryTemplateGuide";


export const Route = createFileRoute("/_authenticated/browse-recovery")({
  component: BrowseRecoveryPage,
  head: () => ({
    meta: [
      { title: "Browse Recovery — Slice" },
      { name: "description", content: "Send WhatsApp reminders to visitors who browsed products but didn't buy." },
      { property: "og:title", content: "Browse Recovery — Slice" },
      { property: "og:description", content: "Send WhatsApp reminders to visitors who browsed products but didn't buy." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "twitter:title", content: "Browse Recovery — Slice" },
      { name: "twitter:description", content: "Send WhatsApp reminders to visitors who browsed products but didn't buy." },
    ],
  }),
});

const DELAY_OPTIONS = [
  { label: "5 min", value: 5 },
  { label: "15 min", value: 15 },
  { label: "30 min", value: 30 },
  { label: "1 hour", value: 60 },
  { label: "2 hours", value: 120 },
  { label: "6 hours", value: 360 },
  { label: "24 hours", value: 1440 },
];

function BrowseRecoveryPage() {
  const { currentWorkspaceId } = useWorkspace() as any;
  const workspaceId = currentWorkspaceId as string | null;
  const qc = useQueryClient();

  const getSettings = useServerFn(getBrowseSettings);
  const saveSettings = useServerFn(saveBrowseSettings);
  const getAnalytics = useServerFn(getBrowseAnalytics);
  const getEvents = useServerFn(getBrowseEvents);
  const createToken = useServerFn(createBrowseTrackerToken);
  const revokeToken = useServerFn(revokeBrowseTrackerToken);

  const settingsQ = useQuery({
    queryKey: ["browse-settings", workspaceId],
    queryFn: () => getSettings({ data: { workspace_id: workspaceId } }),
    enabled: !!workspaceId,
  });

  const analyticsQ = useQuery({
    queryKey: ["browse-analytics", workspaceId],
    queryFn: () => getAnalytics({ data: { workspace_id: workspaceId, days: 30 } }),
    enabled: !!workspaceId,
  });

  const eventsQ = useQuery({
    queryKey: ["browse-events", workspaceId],
    queryFn: () => getEvents({ data: { workspace_id: workspaceId, limit: 50 } }),
    enabled: !!workspaceId,
  });

  const templatesQ = useQuery({
    queryKey: ["approved-templates", workspaceId],
    enabled: !!workspaceId,
    queryFn: async () => {
      const { data } = await supabase.from("templates")
        .select("id, meta_template_name, language, status")
        .eq("workspace_id", workspaceId!)
        .order("meta_template_name");
      return (data ?? []).filter((t: any) => String(t.status || "").toUpperCase() === "APPROVED");
    },
  });

  const s = settingsQ.data?.settings as any;
  const [enabled, setEnabled] = useState(false);
  const [delay, setDelay] = useState<number>(30);
  const [templateId, setTemplateId] = useState<string>("");
  const [lang, setLang] = useState<string>("en_US");
  const [freqCap, setFreqCap] = useState<number>(24);
  const [prodInclude, setProdInclude] = useState("");
  const [prodExclude, setProdExclude] = useState("");
  const [catInclude, setCatInclude] = useState("");
  const [minPrice, setMinPrice] = useState<string>("");
  const [selectedEvent, setSelectedEvent] = useState<any | null>(null);

  useEffect(() => {
    if (s) {
      setEnabled(!!s.enabled);
      setDelay(Number(s.delay_minutes) || 30);
      setTemplateId(s.template_id || "");
      setLang(s.template_language || "en_US");
      setFreqCap(Number(s.frequency_cap_hours ?? 24));
      setProdInclude(Array.isArray(s.product_include) ? s.product_include.join(", ") : "");
      setProdExclude(Array.isArray(s.product_exclude) ? s.product_exclude.join(", ") : "");
      setCatInclude(Array.isArray(s.category_include) ? s.category_include.join(", ") : "");
      setMinPrice(s.min_price_minor != null ? String(Number(s.min_price_minor) / 100) : "");
    }
  }, [s]);

  const saveM = useMutation({
    mutationFn: async () => {
      const parseList = (v: string) => v.split(",").map((x) => x.trim()).filter(Boolean);
      const min = minPrice ? Math.round(Number(minPrice) * 100) : null;
      return saveSettings({ data: {
        workspace_id: workspaceId,
        enabled, delay_minutes: delay,
        template_id: templateId || null,
        template_language: lang,
        frequency_cap_hours: freqCap,
        product_include: parseList(prodInclude),
        product_exclude: parseList(prodExclude),
        category_include: parseList(catInclude),
        min_price_minor: min,
      } });
    },
    onSuccess: () => {
      toast.success("Browse recovery settings saved");
      qc.invalidateQueries({ queryKey: ["browse-settings", workspaceId] });
    },
    onError: (e: any) => toast.error(e?.message || "Failed to save"),
  });

  const createTokenM = useMutation({
    mutationFn: (label: string) => createToken({ data: { workspace_id: workspaceId, label } }),
    onSuccess: () => {
      toast.success("Tracker token created");
      qc.invalidateQueries({ queryKey: ["browse-settings", workspaceId] });
    },
    onError: (e: any) => toast.error(e?.message || "Failed"),
  });

  const revokeM = useMutation({
    mutationFn: (id: string) => revokeToken({ data: { workspace_id: workspaceId, id } }),
    onSuccess: () => {
      toast.success("Token revoked");
      qc.invalidateQueries({ queryKey: ["browse-settings", workspaceId] });
    },
  });

  const analytics = analyticsQ.data as any;
  const revenue = useMemo(() => {
    if (!analytics) return "";
    const n = Number(analytics.revenue_minor || 0) / 100;
    const sym = analytics.currency === "INR" ? "₹" : analytics.currency === "USD" ? "$" : analytics.currency ? `${analytics.currency} ` : "";
    return `${sym}${n.toFixed(2)}`;
  }, [analytics]);

  return (
    <div className="p-4 md:p-6 space-y-6 max-w-6xl">
      <div className="flex items-center gap-2">
        <Sparkles className="w-5 h-5 text-primary" />
        <h1 className="text-2xl font-semibold">Browse Recovery</h1>
        <div className="ml-auto"><BrowseRecoveryTemplateGuide /></div>
      </div>

      <p className="text-sm text-muted-foreground -mt-4">
        Send WhatsApp reminders to identified visitors who browsed a product but didn't add to cart or purchase.
      </p>

      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        <Card className="p-4"><div className="text-xs text-muted-foreground flex items-center gap-1"><Eye className="w-3 h-3" />Views (30d)</div><div className="text-2xl font-semibold">{analytics?.views ?? 0}</div></Card>
        <Card className="p-4"><div className="text-xs text-muted-foreground flex items-center gap-1"><Send className="w-3 h-3" />Messages sent</div><div className="text-2xl font-semibold">{analytics?.sent ?? 0}</div></Card>
        <Card className="p-4"><div className="text-xs text-muted-foreground flex items-center gap-1"><MousePointerClick className="w-3 h-3" />Clicks</div><div className="text-2xl font-semibold">{analytics?.clicks ?? 0}</div></Card>
        <Card className="p-4"><div className="text-xs text-muted-foreground flex items-center gap-1"><ShoppingBag className="w-3 h-3" />Conversions</div><div className="text-2xl font-semibold">{analytics?.converted ?? 0}</div></Card>
        <Card className="p-4"><div className="text-xs text-muted-foreground">Recovered revenue</div><div className="text-2xl font-semibold">{revenue || "—"}</div></Card>
      </div>

      <Tabs defaultValue="settings">
        <TabsList>
          <TabsTrigger value="settings">Settings</TabsTrigger>
          <TabsTrigger value="install">Install</TabsTrigger>
          <TabsTrigger value="activity">Recent activity</TabsTrigger>
        </TabsList>

        <TabsContent value="settings" className="space-y-4">
          <Card className="p-4 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <div className="font-medium">Enable browse recovery</div>
                <div className="text-xs text-muted-foreground">When off, no reminders will be sent.</div>
              </div>
              <Switch checked={enabled} onCheckedChange={setEnabled} />
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <Label>Send reminder after</Label>
                <Select value={String(delay)} onValueChange={(v) => setDelay(Number(v))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {DELAY_OPTIONS.map((o) => (
                      <SelectItem key={o.value} value={String(o.value)}>{o.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label>WhatsApp template</Label>
                <Select value={templateId} onValueChange={setTemplateId}>
                  <SelectTrigger><SelectValue placeholder="Select an approved template" /></SelectTrigger>
                  <SelectContent>
                    {(templatesQ.data ?? []).map((t: any) => (
                      <SelectItem key={t.id} value={t.id}>{t.meta_template_name} ({t.language})</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <div className="text-xs text-muted-foreground mt-1">
                  Include a URL button pointing to <code>https://slice.dotscube.com/br/&#123;&#123;1&#125;&#125;</code> and use body variables for the visitor's name, product name and price.
                </div>
              </div>

              <div>
                <Label>Template language</Label>
                <Input value={lang} onChange={(e) => setLang(e.target.value)} placeholder="en_US" />
              </div>

              <div>
                <Label>Frequency cap (hours)</Label>
                <Input type="number" min={0} value={freqCap} onChange={(e) => setFreqCap(Number(e.target.value) || 0)} />
                <div className="text-xs text-muted-foreground mt-1">Don't message the same visitor more than once within this window.</div>
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <Label>Include products (IDs, comma-separated)</Label>
                <Textarea rows={2} value={prodInclude} onChange={(e) => setProdInclude(e.target.value)} placeholder="Leave blank to track all products" />
              </div>
              <div>
                <Label>Exclude products (IDs, comma-separated)</Label>
                <Textarea rows={2} value={prodExclude} onChange={(e) => setProdExclude(e.target.value)} />
              </div>
              <div>
                <Label>Only these categories (comma-separated)</Label>
                <Input value={catInclude} onChange={(e) => setCatInclude(e.target.value)} />
              </div>
              <div>
                <Label>Minimum product price</Label>
                <Input type="number" min={0} step="0.01" value={minPrice} onChange={(e) => setMinPrice(e.target.value)} />
              </div>
            </div>

            <div className="flex justify-end">
              <Button onClick={() => saveM.mutate()} disabled={saveM.isPending}>Save settings</Button>
            </div>
          </Card>
        </TabsContent>

        <TabsContent value="install" className="space-y-4">
          <TokensCard
            tokens={settingsQ.data?.tokens ?? []}
            onCreate={(label) => createTokenM.mutate(label)}
            onRevoke={(id) => revokeM.mutate(id)}
          />
        </TabsContent>

        <TabsContent value="activity" className="space-y-2">
          <Card className="p-0 overflow-hidden">
            <div className="p-3 text-sm text-muted-foreground">Latest tracked product views</div>
            <div className="divide-y">
              {(eventsQ.data?.events ?? []).map((e: any) => (
                <Button key={e.id} variant="ghost" className="h-auto w-full justify-start rounded-none p-3 text-left font-normal" onClick={() => setSelectedEvent(e)}>
                  {e.product_image_url && <img src={e.product_image_url} alt="" className="w-10 h-10 rounded object-cover" />}
                  <div className="flex-1 min-w-0">
                    <div className="truncate font-medium">{e.product_title || e.product_id}</div>
                    <div className="text-xs text-muted-foreground truncate">
                      {e.phone || "anonymous"} · viewed {new Date(e.viewed_at).toLocaleString()}
                    </div>
                  </div>
                  {e.converted_at ? <Badge>Converted</Badge>
                    : e.dispatched_at ? <Badge variant="secondary">Reminder sent</Badge>
                    : e.skip_reason ? <Badge variant="destructive" title={e.skip_reason}>Skipped</Badge>
                    : e.dispatch_scheduled_at ? <Badge variant="outline">Scheduled</Badge>
                    : <Badge variant="outline">Anonymous</Badge>}
                </Button>
              ))}
              {(!eventsQ.data?.events || eventsQ.data.events.length === 0) && (
                <div className="p-6 text-center text-sm text-muted-foreground">No product views tracked yet. Install the tracker script on your store.</div>
              )}
            </div>
          </Card>
        </TabsContent>
      </Tabs>
      <EventDetailsDialog event={selectedEvent} onOpenChange={(open) => { if (!open) setSelectedEvent(null); }} />
    </div>
  );
}

function EventDetailsDialog({ event, onOpenChange }: { event: any | null; onOpenChange: (open: boolean) => void }) {
  const contact = Array.isArray(event?.contact) ? event.contact[0] : event?.contact;
  const rows = [
    ["Status", event?.converted_at ? "Converted" : event?.dispatched_at ? "Reminder sent" : event?.skip_reason ? `Skipped: ${event.skip_reason}` : event?.dispatch_scheduled_at ? "Scheduled" : "Anonymous"],
    ["Phone", event?.phone || "Not captured"],
    ["Contact", contact?.name || "Not linked"],
    ["Viewed", event?.viewed_at ? new Date(event.viewed_at).toLocaleString() : "—"],
    ["Scheduled", event?.dispatch_scheduled_at ? new Date(event.dispatch_scheduled_at).toLocaleString() : "Not scheduled"],
    ["Sent", event?.dispatched_at ? new Date(event.dispatched_at).toLocaleString() : "Not sent"],
    ["Session", event?.session_key || "—"],
    ["Visitor", event?.visitor_key || "—"],
    ["Message ID", event?.wa_message_id || "—"],
  ];
  return (
    <Dialog open={!!event} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader><DialogTitle>{event?.product_title || event?.product_id || "Tracked activity"}</DialogTitle></DialogHeader>
        <div className="space-y-3 text-sm">
          <div className="grid gap-2">
            {rows.map(([label, value]) => (
              <div key={label} className="grid grid-cols-3 gap-3">
                <div className="text-muted-foreground">{label}</div>
                <div className="col-span-2 break-words">{value}</div>
              </div>
            ))}
          </div>
          {event?.product_url && (
            <Button variant="outline" size="sm" asChild>
              <a href={event.product_url} target="_blank" rel="noreferrer"><ExternalLink className="w-4 h-4" />Open product</a>
            </Button>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}

function TokensCard({ tokens, onCreate, onRevoke }: { tokens: any[]; onCreate: (label: string) => void; onRevoke: (id: string) => void }) {
  const [label, setLabel] = useState("");
  const primary = tokens[0]?.token || "YOUR_TRACKER_TOKEN";
  const snippet = `<script>window.SliceBrowseRecovery = { token: "${primary}" };</script>
<script src="https://slice.dotscube.com/slice-browse-tracker.js" defer></script>`;
  const identify = `SliceBrowseRecovery.identify({ phone: "+919812345678", name: "Ali" });`;

  return (
    <div className="space-y-4">
      <Card className="p-4 space-y-3">
        <div className="font-medium">Tracker tokens</div>
        <div className="text-xs text-muted-foreground">Create one token per storefront. The token authenticates the tracking script — treat it like an API key.</div>
        <div className="flex gap-2">
          <Input placeholder="e.g. Main store" value={label} onChange={(e) => setLabel(e.target.value)} />
          <Button onClick={() => { onCreate(label || "Storefront"); setLabel(""); }}>Create token</Button>
        </div>
        <div className="divide-y">
          {tokens.map((t) => (
            <div key={t.id} className="flex items-center gap-2 py-2 text-sm">
              <div className="flex-1 min-w-0">
                <div className="truncate font-mono text-xs">{t.token}</div>
                <div className="text-xs text-muted-foreground">{t.label || "Untitled"} · created {new Date(t.created_at).toLocaleDateString()}{t.last_used_at ? ` · last used ${new Date(t.last_used_at).toLocaleDateString()}` : ""}</div>
              </div>
              <Button size="sm" variant="ghost" onClick={() => { navigator.clipboard.writeText(t.token); toast.success("Copied"); }}><Copy className="w-4 h-4" /></Button>
              <Button size="sm" variant="ghost" onClick={() => onRevoke(t.id)}><Trash2 className="w-4 h-4 text-destructive" /></Button>
            </div>
          ))}
        </div>
      </Card>

      <Card className="p-4 space-y-3">
        <div className="font-medium">Install snippet</div>
        <div className="text-xs text-muted-foreground">Paste this in your Shopify theme <code>theme.liquid</code> before <code>&lt;/head&gt;</code>, or in WooCommerce via a header snippet.</div>
        <pre className="bg-muted p-3 rounded text-xs whitespace-pre-wrap">{snippet}</pre>
        <Button size="sm" variant="outline" onClick={() => { navigator.clipboard.writeText(snippet); toast.success("Copied"); }}>Copy snippet</Button>

        <div className="text-sm font-medium mt-4">Identify visitors</div>
        <div className="text-xs text-muted-foreground">Call this whenever the visitor's phone becomes known (checkout, login, WhatsApp opt-in). Reminders only send to identified visitors.</div>
        <pre className="bg-muted p-3 rounded text-xs whitespace-pre-wrap">{identify}</pre>
      </Card>
    </div>
  );
}
