import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Sparkles, Loader2 } from "lucide-react";
import { useWorkspace } from "@/lib/workspace-context";
import { getAiSettings, updateAiSettings } from "@/lib/ai-insights.functions";
import { AiUsageCostNotice } from "@/components/AiUsageCostNotice";


export const Route = createFileRoute("/_authenticated/ai-settings")({
  component: AiSettingsPage,
  head: () => ({ meta: [{ title: "AI Settings — Slice" }] }),
  errorComponent: ({ error }) => (
    <div className="p-6 text-sm text-destructive">Failed to load: {error.message}</div>
  ),
  notFoundComponent: () => <div className="p-6 text-sm">Not found.</div>,
});

const MODELS = [
  { value: "google/gemini-2.5-flash", label: "Gemini 2.5 Flash (fast & cheap)" },
  { value: "google/gemini-2.5-pro", label: "Gemini 2.5 Pro (higher quality)" },
  { value: "openai/gpt-5-mini", label: "GPT-5 Mini" },
  { value: "openai/gpt-5", label: "GPT-5 (best)" },
];

const TONES = ["friendly", "professional", "concise", "enthusiastic", "empathetic"];
const LANGS = ["en", "hi", "es", "fr", "ar", "pt"];

function AiSettingsPage() {
  const { currentWorkspaceId, role } = useWorkspace();
  const qc = useQueryClient();
  const getFn = useServerFn(getAiSettings);
  const updFn = useServerFn(updateAiSettings);

  const { data, isLoading } = useQuery({
    queryKey: ["ai-settings", currentWorkspaceId],
    enabled: !!currentWorkspaceId,
    queryFn: () => getFn({ data: { workspace_id: currentWorkspaceId! } }),
  });

  const [model, setModel] = useState("google/gemini-2.5-flash");
  const [tone, setTone] = useState("friendly");
  const [language, setLanguage] = useState("en");
  const [prompt, setPrompt] = useState("");
  const [enabled, setEnabled] = useState(true);

  useEffect(() => {
    if (data) {
      setModel(data.model || "google/gemini-2.5-flash");
      setTone(data.tone || "friendly");
      setLanguage(data.language_preference || "en");
      setPrompt(data.system_prompt || "");
      setEnabled(data.enabled ?? true);
    }
  }, [data]);

  const mut = useMutation({
    mutationFn: () =>
      updFn({
        data: {
          workspace_id: currentWorkspaceId!,
          model,
          tone,
          language_preference: language,
          system_prompt: prompt,
          enabled,
        },
      }),
    onSuccess: () => {
      toast.success("AI settings saved");
      qc.invalidateQueries({ queryKey: ["ai-settings", currentWorkspaceId] });
    },
    onError: (e: any) => toast.error(e.message || "Failed to save"),
  });

  const canEdit = role === "owner" || role === "admin";

  if (isLoading) return <div className="p-6 text-sm text-muted-foreground">Loading…</div>;

  return (
    <div className="space-y-6 max-w-3xl">
      <div>
        <h1 className="font-display text-3xl font-bold flex items-center gap-2">
          <Sparkles className="h-7 w-7 text-primary" /> AI Settings
        </h1>
        <p className="text-muted-foreground">
          Configure the AI assistant model, tone and system prompt for this workspace.
        </p>
      </div>

      <AiUsageCostNotice />


      {!canEdit && (
        <Card className="border-warning/40 bg-warning/5 p-4 text-sm">
          You need owner or admin role to change AI settings.
        </Card>
      )}

      <Card className="p-6 space-y-5">
        <div className="flex items-center justify-between">
          <div>
            <Label className="font-medium">AI assistant enabled</Label>
            <p className="text-xs text-muted-foreground">When off, automatic AI analysis and replies are paused.</p>
          </div>
          <Switch checked={enabled} onCheckedChange={setEnabled} disabled={!canEdit} />
        </div>

        <div className="grid gap-4 sm:grid-cols-3">
          <div className="space-y-2 sm:col-span-3">
            <Label>Model</Label>
            <Select value={model} onValueChange={setModel} disabled={!canEdit}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {MODELS.map((m) => (
                  <SelectItem key={m.value} value={m.value}>{m.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Tone</Label>
            <Select value={tone} onValueChange={setTone} disabled={!canEdit}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {TONES.map((t) => (
                  <SelectItem key={t} value={t} className="capitalize">{t}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Language</Label>
            <Select value={language} onValueChange={setLanguage} disabled={!canEdit}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {LANGS.map((l) => (
                  <SelectItem key={l} value={l}>{l.toUpperCase()}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

        </div>

        <div className="space-y-2">
          <Label>System prompt</Label>
          <Textarea
            rows={10}
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            disabled={!canEdit}
            placeholder="You are Slice, a helpful WhatsApp assistant for our business. Always reply in the customer's language. Be concise, friendly, and never make up prices…"
            className="font-mono text-sm"
          />
          <p className="text-xs text-muted-foreground">
            Used for AI analysis and assisted replies. Keep it under 8000 characters.
          </p>
        </div>

        <div className="flex justify-end">
          <Button onClick={() => mut.mutate()} disabled={!canEdit || mut.isPending}>
            {mut.isPending && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
            Save settings
          </Button>
        </div>
      </Card>
    </div>
  );
}
