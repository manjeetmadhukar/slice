import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useWorkspace } from "@/lib/workspace-context";
import { sendInboxMessage } from "@/lib/inbox.functions";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Checkbox } from "@/components/ui/checkbox";
import { toast } from "sonner";
import {
  Search,
  Send,
  StickyNote,
  Tag,
  UserCog,
  CheckCircle2,
  Clock,
  X,
  Plus,
  MessageSquarePlus,
  Paperclip,
  Smile,
  Check,
  CheckCheck,
  AlertCircle,
  Briefcase,
  Users as UsersIcon,
  CalendarClock,
  Bell,
  BellOff,
  Phone,
  Video,
  MoreVertical,
  ArrowLeft,
  Filter,
  Info,
  MessageCircle,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { startConversations, syncContactConversations, sendInboxMedia, sendInboxReaction, sendInboxTemplate } from "@/lib/inbox.functions";
import { FileText, Reply, SmilePlus, Copy as CopyIcon, Forward as ForwardIcon, Pin, Star, NotebookPen, CheckSquare, Flag, Trash2, PinOff, StarOff } from "lucide-react";
import {
  ContextMenu,
  ContextMenuContent,
  ContextMenuItem,
  ContextMenuSeparator,
  ContextMenuTrigger,
} from "@/components/ui/context-menu";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

import EmojiPicker, { EmojiStyle, Theme } from "emoji-picker-react";
import { Label } from "@/components/ui/label";

export const Route = createFileRoute("/_authenticated/inbox")({
  component: InboxPage,
  head: () => ({ meta: [{ title: "Inbox — Slice" }] }),
});

type Status = "open" | "pending" | "resolved";

// ---------- Visual helpers ----------
const AVATAR_PALETTE = [
  "bg-emerald-500", "bg-teal-500", "bg-cyan-500", "bg-sky-500",
  "bg-indigo-500", "bg-violet-500", "bg-fuchsia-500", "bg-pink-500",
  "bg-rose-500", "bg-orange-500", "bg-amber-500", "bg-lime-500",
];
function avatarColor(seed: string) {
  let h = 0;
  for (let i = 0; i < seed.length; i++) h = (h * 31 + seed.charCodeAt(i)) | 0;
  return AVATAR_PALETTE[Math.abs(h) % AVATAR_PALETTE.length];
}
function initials(name: string) {
  const parts = (name || "?").trim().split(/\s+/).slice(0, 2);
  return parts.map((p) => p[0]?.toUpperCase() || "").join("") || "?";
}
function Avatar({ name, size = 40 }: { name: string; size?: number }) {
  return (
    <div
      className={cn(
        "grid place-items-center rounded-full text-white font-semibold shrink-0",
        avatarColor(name || "?"),
      )}
      style={{ width: size, height: size, fontSize: size * 0.4 }}
    >
      {initials(name || "?")}
    </div>
  );
}
function formatListTime(iso?: string | null) {
  if (!iso) return "";
  const d = new Date(iso);
  const now = new Date();
  const sameDay = d.toDateString() === now.toDateString();
  const y = new Date(now); y.setDate(now.getDate() - 1);
  if (sameDay) return d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  if (d.toDateString() === y.toDateString()) return "Yesterday";
  const week = (now.getTime() - d.getTime()) / 86400000 < 7;
  if (week) return d.toLocaleDateString([], { weekday: "short" });
  return d.toLocaleDateString([], { day: "2-digit", month: "2-digit", year: "2-digit" });
}
function dateLabel(iso: string) {
  const d = new Date(iso);
  const now = new Date();
  const sameDay = d.toDateString() === now.toDateString();
  const y = new Date(now); y.setDate(now.getDate() - 1);
  if (sameDay) return "Today";
  if (d.toDateString() === y.toDateString()) return "Yesterday";
  return d.toLocaleDateString([], { weekday: "long", day: "2-digit", month: "long", year: "numeric" });
}
function displayPreview(value?: string | null) {
  return String(value || "").trim() === "[button]" ? "Button reply" : value;
}

function InboxPage() {
  const qc = useQueryClient();
  const { currentWorkspaceId } = useWorkspace();
  const syncContactsFn = useServerFn(syncContactConversations);
  const [status, setStatus] = useState<Status>("open");
  const [search, setSearch] = useState("");
  const [readFilter, setReadFilter] = useState<"all" | "unread" | "read">("all");

  const [agentFilter, setAgentFilter] = useState<string>("all");
  const [labelFilter, setLabelFilter] = useState<string>("all");
  const [infoOpen, setInfoOpen] = useState(false);
  const [selectedId, setSelectedId] = useState<string | null>(() =>
    typeof window === "undefined"
      ? null
      : new URLSearchParams(window.location.search).get("conversation"),
  );
  // True only when the user explicitly opened the chat (list click, notification,
  // deep link) — auto-selecting the first chat must not mark it as read.
  const [openedByUser, setOpenedByUser] = useState<boolean>(() =>
    typeof window !== "undefined" &&
    !!new URLSearchParams(window.location.search).get("conversation"),
  );
  const openConversation = useCallback((id: string | null) => {
    setOpenedByUser(!!id);
    setSelectedId(id);
  }, []);

  const [me, setMe] = useState<string | null>(null);
  const syncedWorkspaceRef = useRef<string | null>(null);

  useEffect(() => {
    supabase.auth.getUser().then((r) => setMe(r.data.user?.id ?? null));
  }, []);

  const { data: members = [] } = useQuery({
    queryKey: ["ws-members", currentWorkspaceId],
    enabled: !!currentWorkspaceId,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("workspace_members")
        .select("user_id, role")
        .eq("workspace_id", currentWorkspaceId!);
      if (error) throw error;
      const ids = (data ?? []).map((m) => m.user_id);
      const { data: profiles } = await supabase
        .from("profiles")
        .select("id, full_name, email")
        .in("id", ids);
      return (data ?? []).map((m) => {
        const p = profiles?.find((x) => x.id === m.user_id);
        return {
          user_id: m.user_id,
          role: m.role,
          name: p?.full_name || p?.email || m.user_id.slice(0, 8),
        };
      });
    },
  });

  const { data: conversations = [] } = useQuery({
    queryKey: ["conversations", currentWorkspaceId, status, search, readFilter, agentFilter, labelFilter],
    enabled: !!currentWorkspaceId,
    queryFn: async () => {
      let q = supabase
        .from("conversations")
        .select("*")
        .eq("workspace_id", currentWorkspaceId!)
        .eq("status", status)
        .order("last_message_at", { ascending: false });
      if (search)
        q = q.or(
          `contact_name.ilike.%${search}%,contact_phone.ilike.%${search}%,last_message_preview.ilike.%${search}%`,
        );
      if (readFilter === "unread") q = q.gt("unread_count", 0);
      else if (readFilter === "read") q = q.eq("unread_count", 0);
      if (agentFilter === "me" && me) q = q.eq("assigned_to", me);
      else if (agentFilter === "unassigned") q = q.is("assigned_to", null);
      else if (agentFilter !== "all") q = q.eq("assigned_to", agentFilter);
      if (labelFilter !== "all") q = q.contains("labels", [labelFilter]);
      const { data, error } = await q.limit(200);
      if (error) throw error;
      return data;
    },
  });

  // All labels used across this workspace's conversations (for the filter list)
  const { data: allLabels = [] } = useQuery({
    queryKey: ["conversation-labels", currentWorkspaceId],
    enabled: !!currentWorkspaceId,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("conversations")
        .select("labels")
        .eq("workspace_id", currentWorkspaceId!)
        .limit(1000);
      if (error) throw error;
      const set = new Set<string>();
      for (const row of (data ?? []) as any[]) {
        for (const l of (row.labels ?? []) as string[]) if (l) set.add(l);
      }
      return Array.from(set).sort((a, b) => a.localeCompare(b));
    },
  });


  const [notifEnabled, setNotifEnabled] = useState<boolean>(
    typeof window !== "undefined" && "Notification" in window && Notification.permission === "granted",
  );
  const notifEnabledRef = useRef(notifEnabled);
  useEffect(() => { notifEnabledRef.current = notifEnabled; }, [notifEnabled]);
  const selectedIdRef = useRef<string | null>(selectedId);
  useEffect(() => { selectedIdRef.current = selectedId; }, [selectedId]);

  // Notification ping (WebAudio — no asset needed)
  const playPing = () => {
    try {
      const AC = (window as any).AudioContext || (window as any).webkitAudioContext;
      if (!AC) return;
      const ctx = new AC();
      const o = ctx.createOscillator();
      const g = ctx.createGain();
      o.type = "sine";
      o.frequency.setValueAtTime(880, ctx.currentTime);
      o.frequency.exponentialRampToValueAtTime(1320, ctx.currentTime + 0.12);
      g.gain.setValueAtTime(0.0001, ctx.currentTime);
      g.gain.exponentialRampToValueAtTime(0.25, ctx.currentTime + 0.02);
      g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.35);
      o.connect(g).connect(ctx.destination);
      o.start();
      o.stop(ctx.currentTime + 0.4);
      setTimeout(() => ctx.close(), 600);
    } catch {}
  };

  useEffect(() => {
    if (!currentWorkspaceId) return;
    const ch = supabase
      .channel("inbox-" + currentWorkspaceId)
      .on("postgres_changes",
        { event: "*", schema: "public", table: "conversations", filter: `workspace_id=eq.${currentWorkspaceId}` },
        () => qc.invalidateQueries({ queryKey: ["conversations"] }))
      .on("postgres_changes",
        { event: "INSERT", schema: "public", table: "messages", filter: `workspace_id=eq.${currentWorkspaceId}` },
        (payload: any) => {
          qc.invalidateQueries({ queryKey: ["messages"] });
          qc.invalidateQueries({ queryKey: ["conversations"] });
          const m = payload.new;
          if (m?.direction === "in" && m.conversation_id !== selectedIdRef.current) {
            if (notifEnabledRef.current) playPing();
            if (typeof window !== "undefined" && "Notification" in window &&
                Notification.permission === "granted" && !document.hasFocus()) {
              try {
                const n = new Notification("New WhatsApp message", {
                  body: (m.content || `[${m.type}]`).slice(0, 140),
                  tag: m.conversation_id,
                });
                n.onclick = () => { window.focus(); openConversation(m.conversation_id); n.close(); };
              } catch {}
            }
          }
        })
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [currentWorkspaceId, qc]);

  useEffect(() => {
    if (!currentWorkspaceId || syncedWorkspaceRef.current === currentWorkspaceId) return;
    syncedWorkspaceRef.current = currentWorkspaceId;
    syncContactsFn({ data: { workspace_id: currentWorkspaceId } })
      .then((r: any) => {
        if (r?.created || r?.updated) qc.invalidateQueries({ queryKey: ["conversations"] });
      })
      .catch(() => { syncedWorkspaceRef.current = null; });
  }, [currentWorkspaceId, qc, syncContactsFn]);

  // Dedupe conversations by normalized phone — keep the most recent row,
  // sum unread counts, and remember the duplicate IDs so we can delete them too.
  const deduped = useMemo(() => {
    // Match the server-side phone key: compare the last 10 digits so the same
    // WhatsApp number never shows up twice because of country-code variants.
    const norm = (p?: string | null) => {
      const d = String(p || "").replace(/[^\d]/g, "");
      if (!d) return `__id_${Math.random()}`;
      return d.length > 10 ? d.slice(-10) : d;
    };
    const map = new Map<string, any>();
    for (const c of conversations as any[]) {
      const key = norm(c.contact_phone);
      const prev = map.get(key);
      if (!prev) {
        map.set(key, { ...c, _dupIds: [c.id], unread_count: c.unread_count || 0 });
      } else {
        prev._dupIds.push(c.id);
        prev.unread_count = (prev.unread_count || 0) + (c.unread_count || 0);
        // keep the most recent as the canonical row
        const prevTs = new Date(prev.last_message_at || 0).getTime();
        const curTs = new Date(c.last_message_at || 0).getTime();
        if (curTs > prevTs) {
          const dupIds = prev._dupIds;
          const unread = prev.unread_count;
          map.set(key, { ...c, _dupIds: dupIds, unread_count: unread });
        }
      }
    }
    return Array.from(map.values()).sort(
      (a, b) =>
        new Date(b.last_message_at || 0).getTime() -
        new Date(a.last_message_at || 0).getTime(),
    );
  }, [conversations]);

  // Keep the last known conversation object so switching filters (e.g. Unread)
  // never drops the currently open chat just because it left the filtered list.
  const lastSelectedRef = useRef<any>(null);
  const selected = useMemo(() => {
    const found = deduped.find((c: any) => c.id === selectedId) ?? null;
    if (found) {
      lastSelectedRef.current = found;
      return found;
    }
    if (selectedId && lastSelectedRef.current?.id === selectedId) {
      return lastSelectedRef.current;
    }
    return null;
  }, [deduped, selectedId]);

  // No auto-selection: the Inbox opens with an empty conversation panel
  // (WhatsApp Web behaviour). A chat opens only on explicit user action or
  // via a ?conversation= deep link.



  // Changing the read filter re-scopes the list; any resulting selection is
  // implicit, so drop the "opened by user" flag until the user clicks a chat.
  useEffect(() => {
    setOpenedByUser(false);
  }, [readFilter]);


  const totalUnread = deduped.reduce((s: number, c: any) => s + (c.unread_count || 0), 0);

  async function deleteConversation(c: any) {
    if (!confirm(`Delete chat with ${c.contact_name || c.contact_phone}? This removes ${c._dupIds.length} duplicate entr${c._dupIds.length === 1 ? "y" : "ies"} and all its messages.`)) return;
    const ids: string[] = c._dupIds || [c.id];
    const { error: mErr } = await supabase.from("messages").delete().in("conversation_id", ids);
    if (mErr) return toast.error(mErr.message);
    const { error } = await supabase.from("conversations").delete().in("id", ids);
    if (error) return toast.error(error.message);
    toast.success("Chat deleted");
    if (selectedId && ids.includes(selectedId)) setSelectedId(null);
    qc.invalidateQueries({ queryKey: ["conversations"] });
  }


  return (
    <div className={cn(
      "fixed inset-x-0 bottom-0 top-14 md:top-0 md:left-64 z-20 grid grid-cols-1 bg-card overflow-hidden",
      infoOpen && selected
        ? "md:grid-cols-[360px_1fr_320px]"
        : "md:grid-cols-[360px_1fr]",
    )}>
      {/* ---------- LEFT: chat list ---------- */}
      <aside className={cn(
        "flex flex-col min-h-0 border-r bg-card",
        selected && "hidden md:flex",
      )}>
        <div className="px-4 pt-4 pb-3 border-b bg-card">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <h1 className="font-display text-xl font-bold">Chats</h1>
              {totalUnread > 0 && (
                <span className="text-[10px] bg-primary text-primary-foreground rounded-full px-2 py-0.5 font-semibold">
                  {totalUnread}
                </span>
              )}
            </div>
            <div className="flex items-center gap-1">
              <Button
                size="icon" variant="ghost" className="h-8 w-8 rounded-full"
                title={notifEnabled ? "Notifications on" : "Enable notifications"}
                onClick={async () => {
                  if (!("Notification" in window)) return toast.error("Notifications not supported");
                  if (Notification.permission === "granted") { setNotifEnabled(true); return; }
                  const p = await Notification.requestPermission();
                  setNotifEnabled(p === "granted");
                  if (p === "granted") toast.success("Notifications enabled");
                }}
              >
                {notifEnabled ? <Bell className="h-4 w-4 text-primary" /> : <BellOff className="h-4 w-4" />}
              </Button>
              <NewChatButton onOpened={(id) => openConversation(id)} />
            </div>
          </div>

          <div className="relative mb-2">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              className="pl-9 h-9 rounded-full bg-muted/60 border-transparent text-sm"
              placeholder="Search or start new chat"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>

          <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
            <FilterPill active={readFilter === "all" && agentFilter === "all" && labelFilter === "all"} onClick={() => { setReadFilter("all"); setAgentFilter("all"); setLabelFilter("all"); }}>
              All
            </FilterPill>
            <FilterPill active={readFilter === "unread"} onClick={() => setReadFilter(readFilter === "unread" ? "all" : "unread")}>
              Unread
            </FilterPill>
            <FilterPill active={readFilter === "read"} onClick={() => setReadFilter(readFilter === "read" ? "all" : "read")}>
              Read
            </FilterPill>

            <FilterPill active={agentFilter === "me"} onClick={() => setAgentFilter(agentFilter === "me" ? "all" : "me")}>
              Mine
            </FilterPill>
            <FilterPill active={agentFilter === "unassigned"} onClick={() => setAgentFilter(agentFilter === "unassigned" ? "all" : "unassigned")}>
              Unassigned
            </FilterPill>
            {labelFilter !== "all" && (
              <FilterPill active onClick={() => setLabelFilter("all")}>
                Label: {labelFilter} ✕
              </FilterPill>
            )}
            <Popover>
              <PopoverTrigger asChild>
                <button className="shrink-0 h-7 w-7 grid place-items-center rounded-full hover:bg-muted text-muted-foreground">
                  <Filter className="h-3.5 w-3.5" />
                </button>
              </PopoverTrigger>
              <PopoverContent className="w-56 p-1" align="end">
                <p className="px-2 py-1 text-[10px] uppercase tracking-wide text-muted-foreground">Agent</p>
                <Select value={agentFilter} onValueChange={setAgentFilter}>
                  <SelectTrigger className="h-8 text-xs mx-1 w-[calc(100%-0.5rem)]">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All agents</SelectItem>
                    <SelectItem value="me">Assigned to me</SelectItem>
                    <SelectItem value="unassigned">Unassigned</SelectItem>
                    {members.map((m) => (
                      <SelectItem key={m.user_id} value={m.user_id}>{m.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <p className="px-2 pt-2 pb-1 text-[10px] uppercase tracking-wide text-muted-foreground">Label</p>
                <Select value={labelFilter} onValueChange={setLabelFilter}>
                  <SelectTrigger className="h-8 text-xs mx-1 w-[calc(100%-0.5rem)]">
                    <SelectValue placeholder="All labels" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All labels</SelectItem>
                    {allLabels.map((l) => (
                      <SelectItem key={l} value={l}>{l}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {!allLabels.length && (
                  <p className="px-2 pb-2 pt-1 text-[10px] text-muted-foreground">
                    No labels yet — add one from Contact info.
                  </p>
                )}
              </PopoverContent>
            </Popover>
          </div>
        </div>

        <Tabs value={status} onValueChange={(v) => setStatus(v as Status)} className="px-2 pt-2">
          <TabsList className="grid w-full grid-cols-3 h-9 bg-muted/50">
            <TabsTrigger value="open" className="text-xs data-[state=active]:bg-card">Open</TabsTrigger>
            <TabsTrigger value="pending" className="text-xs data-[state=active]:bg-card">Pending</TabsTrigger>
            <TabsTrigger value="resolved" className="text-xs data-[state=active]:bg-card">Resolved</TabsTrigger>
          </TabsList>
        </Tabs>

        <div className="flex-1 overflow-y-auto">
          {deduped.length === 0 ? (
            <div className="p-10 text-center text-sm text-muted-foreground">
              <MessageCircle className="h-10 w-10 mx-auto mb-2 opacity-30" />
              No {status} chats
            </div>
          ) : (
            deduped.map((c: any) => {
              const assignee = members.find((m) => m.user_id === c.assigned_to);
              const name = c.contact_name || c.contact_phone;
              const active = selectedId === c.id;
              return (
                <ContextMenu key={c.id}>
                  <ContextMenuTrigger asChild>
                    <div
                      onClick={() => openConversation(c.id)}
                      className={cn(
                        "group relative w-full text-left px-3 py-3 flex gap-3 hover:bg-muted/50 transition border-b border-border/40 cursor-pointer",
                        active && "bg-muted/70",
                      )}
                    >
                      <Avatar name={name} size={48} />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-baseline justify-between gap-2">
                          <p className="font-semibold text-sm truncate">{name}</p>
                          <span className={cn(
                            "text-[10px] shrink-0",
                            c.unread_count > 0 ? "text-primary font-semibold" : "text-muted-foreground",
                          )}>
                            {formatListTime(c.last_message_at)}
                          </span>
                        </div>
                        <div className="flex items-center justify-between gap-2 mt-0.5">
                          <p className="text-xs text-muted-foreground truncate flex-1">
                            {displayPreview(c.last_message_preview) || "Start a conversation"}
                          </p>
                          {c.unread_count > 0 && (
                            <span className="text-[10px] bg-primary text-primary-foreground rounded-full px-1.5 min-w-[18px] text-center font-semibold">
                              {c.unread_count}
                            </span>
                          )}
                        </div>
                        {(c.labels?.length || assignee || (c._dupIds?.length || 0) > 1) && (
                          <div className="flex items-center gap-1 mt-1 flex-wrap">
                            {c.labels?.slice(0, 2).map((l: string) => (
                              <span key={l} className="text-[10px] px-1.5 py-px rounded bg-primary/10 text-primary font-medium">
                                {l}
                              </span>
                            ))}
                            {assignee && (
                              <span className="text-[10px] text-muted-foreground inline-flex items-center gap-0.5">
                                <UserCog className="h-2.5 w-2.5" /> {assignee.name}
                              </span>
                            )}
                            {(c._dupIds?.length || 0) > 1 && (
                              <span className="text-[10px] px-1.5 py-px rounded bg-amber-500/15 text-amber-700 dark:text-amber-400 font-medium" title="Multiple conversation rows merged">
                                {c._dupIds.length}× merged
                              </span>
                            )}
                          </div>
                        )}
                      </div>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <button
                            onClick={(e) => e.stopPropagation()}
                            className="absolute right-2 top-2 h-7 w-7 grid place-items-center rounded-full opacity-0 group-hover:opacity-100 hover:bg-muted text-muted-foreground"
                            title="More"
                          >
                            <MoreVertical className="h-4 w-4" />
                          </button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end" onClick={(e) => e.stopPropagation()}>
                          <DropdownMenuItem
                            className="text-destructive"
                            onClick={() => deleteConversation(c)}
                          >
                            <Trash2 className="h-4 w-4 mr-2" /> Delete chat
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </ContextMenuTrigger>
                  <ContextMenuContent>
                    <ContextMenuItem
                      className="text-destructive"
                      onClick={() => deleteConversation(c)}
                    >
                      <Trash2 className="h-4 w-4 mr-2" /> Delete chat
                    </ContextMenuItem>
                  </ContextMenuContent>
                </ContextMenu>
              );
            })
          )}

        </div>
      </aside>

      {/* ---------- CENTER: chat ---------- */}
      <section className={cn("min-h-0 flex flex-col", !selected && "hidden md:flex")}>
        {selected ? (
          <ChatPanel
            key={selected.id}
            convo={selected}
            members={members}
            me={me}
            onBack={() => openConversation(null)}
            onToggleInfo={() => setInfoOpen((v) => !v)}
            infoOpen={infoOpen}
            autoMarkRead={readFilter !== "unread"}
            openedByUser={openedByUser}
            onDeleteChat={() => deleteConversation(selected)}
          />

        ) : (
          <EmptyChat />
        )}
      </section>

      {/* ---------- RIGHT: info panel ---------- */}
      {infoOpen && selected && (
        <InfoPanel
          convo={selected}
          members={members}
          me={me}
          onClose={() => setInfoOpen(false)}
        />
      )}
    </div>
  );
}

function FilterPill({ active, onClick, children }: { active: boolean; onClick: () => void; children: React.ReactNode }) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "shrink-0 px-3 h-7 rounded-full text-xs font-medium transition",
        active
          ? "bg-primary text-primary-foreground"
          : "bg-muted/60 text-foreground/70 hover:bg-muted",
      )}
    >
      {children}
    </button>
  );
}

function EmptyChat() {
  return (
    <div className="h-full wa-chat-bg grid place-items-center text-muted-foreground">
      <div className="text-center max-w-sm px-6">
        <div className="mx-auto mb-4 grid h-20 w-20 place-items-center rounded-full bg-primary/10">
          <MessageCircle className="h-10 w-10 text-primary" />
        </div>
        <h2 className="font-display text-xl font-semibold text-foreground mb-1">Slice Inbox</h2>
        <p className="text-sm">Select a conversation from the left to start replying.</p>
      </div>
    </div>
  );
}

const QUICK_REACTIONS = ["👍", "❤️", "😂", "😮", "😢", "🙏"];

function MessageActions({
  m, onReply, onReact,
}: {
  m: any;
  onReply: () => void;
  onReact: (emoji: string) => void;
}) {
  const [open, setOpen] = useState(false);
  if (!m.wa_message_id) return null;
  return (
    <div className="opacity-0 group-hover:opacity-100 transition flex items-center gap-0.5 shrink-0">
      <Popover open={open} onOpenChange={setOpen}>
        <PopoverTrigger asChild>
          <button
            className="h-7 w-7 grid place-items-center rounded-full hover:bg-muted text-muted-foreground"
            title="React"
          >
            <SmilePlus className="h-3.5 w-3.5" />
          </button>
        </PopoverTrigger>
        <PopoverContent className="p-1 w-auto" align="center" side="top">
          <div className="flex gap-0.5">
            {QUICK_REACTIONS.map((e) => (
              <button
                key={e}
                onClick={() => { onReact(e); setOpen(false); }}
                className="h-8 w-8 grid place-items-center rounded-full hover:bg-muted text-base"
              >
                {e}
              </button>
            ))}
            <button
              onClick={() => { onReact(""); setOpen(false); }}
              className="h-8 w-8 grid place-items-center rounded-full hover:bg-muted text-muted-foreground"
              title="Remove reaction"
            >
              <X className="h-3.5 w-3.5" />
            </button>
          </div>
        </PopoverContent>
      </Popover>
      <button
        onClick={onReply}
        className="h-7 w-7 grid place-items-center rounded-full hover:bg-muted text-muted-foreground"
        title="Reply"
      >
        <Reply className="h-3.5 w-3.5" />
      </button>
    </div>
  );
}


function ChatPanel({
  convo, members, me, onBack, onToggleInfo, infoOpen, autoMarkRead = true, openedByUser = false, onDeleteChat,
}: {
  convo: any; members: any[]; me: string | null;
  onBack: () => void; onToggleInfo: () => void; infoOpen: boolean;
  autoMarkRead?: boolean;
  openedByUser?: boolean;
  onDeleteChat?: () => void;
}) {
  const seenConvoRef = useRef<string | null>(null);


  const qc = useQueryClient();
  const sendFn = useServerFn(sendInboxMessage);
  const sendMediaFn = useServerFn(sendInboxMedia);
  const sendReactionFn = useServerFn(sendInboxReaction);
  const sendTemplateFn = useServerFn(sendInboxTemplate);
  const [text, setText] = useState("");
  const [note, setNote] = useState("");
  const [tab, setTab] = useState<"reply" | "note">("reply");
  const [sending, setSending] = useState(false);
  const sendingRef = useRef(false);
  const [uploading, setUploading] = useState(false);
  const [emojiOpen, setEmojiOpen] = useState(false);
  const [tplOpen, setTplOpen] = useState(false);
  const [replyTo, setReplyTo] = useState<{ wa_message_id: string; preview: string } | null>(null);
  const [searchOpen, setSearchOpen] = useState(false);
  const [chatSearch, setChatSearch] = useState("");
  const scrollerRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  // Clipboard / pending attachments (paste support)
  const [pendingFiles, setPendingFiles] = useState<Array<{ id: string; file: File; previewUrl: string | null }>>([]);
  function addPendingFiles(files: File[]) {
    const maxBytes = 16 * 1024 * 1024;
    const accepted: Array<{ id: string; file: File; previewUrl: string | null }> = [];
    for (const f of files) {
      if (!f) continue;
      if (f.size > maxBytes) { toast.error(`${f.name || "File"} is too large (max 16MB)`); continue; }
      const isPreviewable = f.type.startsWith("image/") || f.type.startsWith("video/");
      accepted.push({
        id: `${Date.now()}-${Math.random().toString(16).slice(2)}`,
        file: f,
        previewUrl: isPreviewable ? URL.createObjectURL(f) : null,
      });
    }
    if (accepted.length) setPendingFiles((prev) => [...prev, ...accepted]);
  }
  function removePendingFile(id: string) {
    setPendingFiles((prev) => {
      const target = prev.find((p) => p.id === id);
      if (target?.previewUrl) URL.revokeObjectURL(target.previewUrl);
      return prev.filter((p) => p.id !== id);
    });
  }
  function handleComposerPaste(e: React.ClipboardEvent<HTMLTextAreaElement>) {
    const dt = e.clipboardData;
    if (!dt) return;
    const files: File[] = [];
    if (dt.files && dt.files.length) {
      for (let i = 0; i < dt.files.length; i++) files.push(dt.files[i]);
    } else if (dt.items) {
      for (let i = 0; i < dt.items.length; i++) {
        const it = dt.items[i];
        if (it.kind === "file") {
          const f = it.getAsFile();
          if (f) files.push(f);
        }
      }
    }
    if (files.length) {
      // Keep any plain text that came along; let it paste into the box as usual.
      e.preventDefault();
      addPendingFiles(files);
      const plain = dt.getData("text/plain");
      if (plain) {
        const el = textareaRef.current;
        const start = el?.selectionStart ?? text.length;
        const end = el?.selectionEnd ?? text.length;
        setText(text.slice(0, start) + plain + text.slice(end));
      }
    }
    // No files: default paste (text, links) handled natively.
  }


  // ----- Message context actions: pin / star / hide (delete-for-me) -----
  const lsKey = (kind: string) => `inbox-${kind}-${convo.id}`;
  const loadSet = (kind: string): Set<string> => {
    try { return new Set(JSON.parse(localStorage.getItem(lsKey(kind)) || "[]")); } catch { return new Set(); }
  };
  const [pinned, setPinned] = useState<Set<string>>(() => loadSet("pinned"));
  const [starred, setStarred] = useState<Set<string>>(() => loadSet("starred"));
  const [hidden, setHidden] = useState<Set<string>>(() => loadSet("hidden"));
  const persistSet = (kind: string, s: Set<string>) =>
    localStorage.setItem(lsKey(kind), JSON.stringify(Array.from(s)));
  const toggleInSet = (s: Set<string>, id: string, kind: string, setter: (n: Set<string>) => void) => {
    const next = new Set(s);
    if (next.has(id)) next.delete(id); else next.add(id);
    persistSet(kind, next);
    setter(next);
  };

  // ----- Forward dialog -----
  const [forwardOpen, setForwardOpen] = useState(false);
  const [forwardMsg, setForwardMsg] = useState<any>(null);
  const [forwardTargets, setForwardTargets] = useState<Set<string>>(new Set());
  const { data: allConvos = [] } = useQuery({
    queryKey: ["fwd-conversations", convo.workspace_id, forwardOpen],
    enabled: forwardOpen,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("conversations")
        .select("id, contact_name, contact_phone")
        .eq("workspace_id", convo.workspace_id)
        .order("last_message_at", { ascending: false })
        .limit(100);
      if (error) throw error;
      return data ?? [];
    },
  });
  async function doForward() {
    if (!forwardMsg || forwardTargets.size === 0) return;
    const body = forwardMsg.content || "";
    if (!body.trim()) { toast.error("Nothing to forward"); return; }
    let ok = 0;
    for (const cid of forwardTargets) {
      const r: any = await sendFn({ data: { conversation_id: cid, text: body } }).catch(() => ({ ok: false }));
      if (r?.ok) ok++;
    }
    toast.success(`Forwarded to ${ok} chat(s)`);
    setForwardOpen(false); setForwardMsg(null); setForwardTargets(new Set());
  }

  // ----- Selection mode -----
  const [selectMode, setSelectMode] = useState(false);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  function toggleSelected(id: string) {
    const next = new Set(selected);
    if (next.has(id)) next.delete(id); else next.add(id);
    setSelected(next);
    if (next.size === 0) setSelectMode(false);
  }
  function bulkDelete() {
    const next = new Set(hidden);
    selected.forEach((id) => next.add(id));
    persistSet("hidden", next); setHidden(next);
    setSelected(new Set()); setSelectMode(false);
    toast.success("Deleted for you");
  }
  function bulkCopy() {
    const msgs = (messages as any[]).filter((m) => selected.has(m.id));
    const text = msgs.map((m) => m.content || "").join("\n");
    navigator.clipboard.writeText(text); toast.success("Copied");
    setSelected(new Set()); setSelectMode(false);
  }

  function addMessageToNote(m: any) {
    setTab("note");
    const t = m.content || "";
    setNote((prev) => prev ? `${prev}\n${t}` : t);
  }

  const { data: templates = [] } = useQuery({
    queryKey: ["wa-templates", convo.workspace_id, tplOpen],
    enabled: tplOpen,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("templates")
        .select("id, meta_template_name, language, status, body, variables_count")
        .eq("workspace_id", convo.workspace_id)
        .order("meta_template_name");
      if (error) throw error;
      return data ?? [];
    },
  });


  async function uploadAndSendFile(file: File, caption?: string) {
    const ext = file.name.split(".").pop() || "bin";
    const safeName = file.name || `pasted-${Date.now()}.${ext}`;
    const path = `${convo.workspace_id}/${convo.id}/${Date.now()}-${crypto.randomUUID()}.${ext}`;
    const { error: upErr } = await supabase.storage
      .from("chat-media")
      .upload(path, file, { contentType: file.type, upsert: false });
    if (upErr) throw upErr;
    const { data: pub } = supabase.storage.from("chat-media").getPublicUrl(path);
    const mime = file.type || "application/octet-stream";
    let mediaType: "image" | "video" | "audio" | "document" = "document";
    if (mime.startsWith("image/")) mediaType = "image";
    else if (mime.startsWith("video/")) mediaType = "video";
    else if (mime.startsWith("audio/")) mediaType = "audio";
    const r: any = await sendMediaFn({
      data: {
        conversation_id: convo.id,
        media_url: pub.publicUrl,
        media_type: mediaType,
        media_mime: mime,
        filename: safeName,
        caption: caption?.trim() || undefined,
      },
    });
    return r;
  }

  async function handleFile(file: File) {
    if (!file) return;
    const maxBytes = 16 * 1024 * 1024;
    if (file.size > maxBytes) return toast.error("File too large (max 16MB)");
    setUploading(true);
    try {
      const r = await uploadAndSendFile(file, text);
      if (!r.ok) return toast.error(r.error || "Failed to send media");
      setText("");
      qc.invalidateQueries({ queryKey: ["messages", convo.id] });
    } catch (e: any) {
      toast.error(e.message || "Upload failed");
    } finally {
      setUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  }

  async function sendPendingAttachments() {
    if (!pendingFiles.length) return;
    const items = pendingFiles;
    const caption = text.trim();
    setUploading(true);
    try {
      let failed = 0;
      for (let i = 0; i < items.length; i++) {
        try {
          const r = await uploadAndSendFile(items[i].file, i === 0 ? caption : undefined);
          if (!r.ok) { failed++; toast.error(r.error || "Failed to send media"); }
        } catch (e: any) {
          failed++;
          toast.error(e.message || "Upload failed");
        }
      }
      if (failed < items.length) {
        items.forEach((it) => it.previewUrl && URL.revokeObjectURL(it.previewUrl));
        setPendingFiles([]);
        setText("");
      }
      qc.invalidateQueries({ queryKey: ["messages", convo.id] });
    } finally {
      setUploading(false);
    }
  }


  function insertEmoji(emoji: string) {
    const el = textareaRef.current;
    if (!el) { setText((t) => t + emoji); return; }
    const start = el.selectionStart ?? text.length;
    const end = el.selectionEnd ?? text.length;
    const next = text.slice(0, start) + emoji + text.slice(end);
    setText(next);
    requestAnimationFrame(() => {
      el.focus();
      el.selectionStart = el.selectionEnd = start + emoji.length;
    });
  }

  const { data: messages = [] } = useQuery({
    queryKey: ["messages", convo.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("messages")
        .select("*")
        .eq("conversation_id", convo.id)
        .order("created_at", { ascending: true })
        .limit(500);
      if (error) throw error;
      return data;
    },
  });

  // WhatsApp-style read receipts: a chat is only marked read when the user
  // actually opened it (clicked it in the list / a notification). New messages
  // that arrive while the chat is open are marked read only if the window is
  // focused and the user is looking at the bottom of the thread.
  const markRead = useCallback(() => {
    const ids: string[] = (convo as any)._dupIds?.length ? (convo as any)._dupIds : [convo.id];
    qc.setQueriesData({ queryKey: ["conversations"] }, (old: any) =>
      Array.isArray(old)
        ? old.map((c: any) => (ids.includes(c.id) ? { ...c, unread_count: 0 } : c))
        : old,
    );
    supabase.from("conversations").update({ unread_count: 0 }).in("id", ids).then(() => {});
  }, [convo.id, qc]); // eslint-disable-line

  useEffect(() => {
    if (!openedByUser) return;
    if (!(convo.unread_count > 0)) return;
    // First render after the user opened this chat -> mark everything read.
    if (!seenConvoRef.current || seenConvoRef.current !== convo.id) {
      seenConvoRef.current = convo.id;
      markRead();
      return;
    }
    // Message arrived while the chat is already open.
    const el = scrollerRef.current;
    const atBottom = !el || el.scrollHeight - el.scrollTop - el.clientHeight < 120;
    const focused = typeof document === "undefined" || document.hasFocus();
    if (atBottom && focused) markRead();
  }, [convo.id, convo.unread_count, openedByUser, markRead]);




  useEffect(() => {
    const el = scrollerRef.current;
    if (!el) return;
    // Defer to next frame so newly-appended messages are laid out before we
    // measure scrollHeight, otherwise the last outgoing bubble stays hidden
    // below the composer at 100% zoom.
    const raf1 = requestAnimationFrame(() => {
      const raf2 = requestAnimationFrame(() => {
        el.scrollTop = el.scrollHeight;
      });
      (el as any).__raf2 = raf2;
    });
    return () => {
      cancelAnimationFrame(raf1);
      if ((el as any).__raf2) cancelAnimationFrame((el as any).__raf2);
    };
  }, [messages.length, messages[messages.length - 1]?.id]);

  async function send() {
    if (sendingRef.current) return;          // guard against rapid duplicate calls
    if (uploading) return;
    if (pendingFiles.length) { await sendPendingAttachments(); return; }
    if (!text.trim()) return;

    sendingRef.current = true;
    setSending(true);
    const payloadText = text.trim();
    const payloadReply = replyTo;
    setText("");                              // optimistic clear prevents repeat sends
    setReplyTo(null);
    // Show the bubble immediately; the server round-trip happens in background.
    const tempId = `temp-${Date.now()}-${Math.random().toString(16).slice(2)}`;
    const optimistic = {
      id: tempId,
      workspace_id: convo.workspace_id,
      conversation_id: convo.id,
      direction: "out",
      type: "text",
      content: payloadText,
      created_at: new Date().toISOString(),
      status: "sending",
      reply_to_wa_message_id: payloadReply?.wa_message_id ?? null,
      reply_to_preview: payloadReply?.preview ?? null,
    };
    const dropOptimistic = () =>
      qc.setQueryData(["messages", convo.id], (old: any) =>
        Array.isArray(old) ? old.filter((m: any) => m.id !== tempId) : old,
      );
    qc.setQueryData(["messages", convo.id], (old: any) =>
      Array.isArray(old) ? [...old, optimistic] : [optimistic],
    );

    // Release the composer as soon as the bubble is rendered so the Send button
    // is immediately available again for the next message. The network round
    // trip is resolved in the background and can never leave the UI stuck.
    const release = () => {
      sendingRef.current = false;
      setSending(false);
    };
    const releaseTimer = setTimeout(release, 400);

    try {
      const r: any = await sendFn({ data: {
        conversation_id: convo.id,
        text: payloadText,
        reply_to_wa_message_id: payloadReply?.wa_message_id,
        reply_to_preview: payloadReply?.preview,
      } });
      if (!r.ok) {
        dropOptimistic();
        toast.error(r.error);
        setText((cur) => (cur.trim() ? cur : payloadText));   // restore only if composer still empty
        setReplyTo((cur) => cur ?? payloadReply);
        return;
      }
      qc.setQueryData(["messages", convo.id], (old: any) =>
        Array.isArray(old)
          ? old.map((m: any) => (m.id === tempId ? { ...m, status: "sent", wa_message_id: r.wa_message_id } : m))
          : old,
      );
      qc.invalidateQueries({ queryKey: ["messages", convo.id] });
    } catch (e: any) {
      dropOptimistic();
      toast.error(e?.message || "Failed to send message");
      setText((cur) => (cur.trim() ? cur : payloadText));
      setReplyTo((cur) => cur ?? payloadReply);
    } finally {
      clearTimeout(releaseTimer);
      release();
    }
  }

  // Safety net: never let the composer stay in a "sending" state.
  useEffect(() => {
    if (!sending) return;
    const t = setTimeout(() => { sendingRef.current = false; setSending(false); }, 10000);
    return () => clearTimeout(t);
  }, [sending]);

  // Switching chats always resets composer send state.
  useEffect(() => {
    sendingRef.current = false;
    setSending(false);
  }, [convo.id]);




  async function sendTemplate(template_id: string) {
    try {
      const r: any = await sendTemplateFn({ data: { conversation_id: convo.id, template_id } });
      if (!r.ok) return toast.error(r.error);
      toast.success("Template sent");
      setTplOpen(false);
      qc.invalidateQueries({ queryKey: ["messages", convo.id] });
    } catch (e: any) { toast.error(e.message); }
  }

  async function reactToMessage(m: any, emoji: string) {
    if (!m.wa_message_id) return toast.error("This message can't be reacted to yet");
    try {
      const r: any = await sendReactionFn({ data: {
        conversation_id: convo.id,
        wa_message_id: m.wa_message_id,
        emoji,
      } });
      if (!r.ok) return toast.error(r.error);
      qc.invalidateQueries({ queryKey: ["messages", convo.id] });
    } catch (e: any) { toast.error(e.message); }
  }


  async function addNote() {
    if (!note.trim()) return;
    const { error } = await supabase.from("messages").insert({
      workspace_id: convo.workspace_id,
      conversation_id: convo.id,
      direction: "out",
      type: "note",
      content: note.trim(),
      sender_user_id: me,
      is_internal: true,
    });
    if (error) return toast.error(error.message);
    setNote("");
    qc.invalidateQueries({ queryKey: ["messages", convo.id] });
  }

  const name = convo.contact_name || convo.contact_phone;
  const assignee = members.find((m) => m.user_id === convo.assigned_to);

  // Group messages by date (with optional in-chat search filter)
  const grouped = useMemo(() => {
    const q = chatSearch.trim().toLowerCase();
    const src = q
      ? (messages as any[]).filter((m) =>
          String(m.content || "").toLowerCase().includes(q),
        )
      : (messages as any[]);
    const out: { label: string; items: any[] }[] = [];
    let last = "";
    for (const m of src) {
      const l = dateLabel(m.created_at);
      if (l !== last) { out.push({ label: l, items: [] }); last = l; }
      out[out.length - 1].items.push(m);
    }
    return out;
  }, [messages, chatSearch]);

  return (
    <div className="relative flex flex-col h-full min-h-0 min-w-0 overflow-hidden">
      {/* Header */}
      <div className="px-4 py-2.5 border-b bg-card flex items-center gap-3">
        <Button size="icon" variant="ghost" className="h-8 w-8 md:hidden" onClick={onBack}>
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <button onClick={onToggleInfo} className="flex items-center gap-3 flex-1 min-w-0 text-left hover:opacity-80">
          <Avatar name={name} size={40} />
          <div className="min-w-0">
            <p className="font-semibold truncate text-sm">{name}</p>
            <p className="text-[11px] text-muted-foreground truncate">
              {convo.contact_phone}
              {assignee && <> · <span className="text-foreground/70">{assignee.name}</span></>}
            </p>
          </div>
        </button>
        <div className="flex items-center gap-1">
          {(() => {
            const digits = String(convo.contact_phone || "").replace(/[^\d]/g, "");
            const telHref = digits ? `tel:+${digits}` : undefined;
            const waHref = digits ? `https://wa.me/${digits}` : undefined;
            return (
              <>
                <Button asChild size="icon" variant="ghost" className="h-9 w-9 rounded-full" title="Voice call">
                  <a href={telHref} onClick={(e) => { if (!telHref) e.preventDefault(); }}>
                    <Phone className="h-4 w-4" />
                  </a>
                </Button>
                <Button asChild size="icon" variant="ghost" className="h-9 w-9 rounded-full" title="Open in WhatsApp (video / chat)">
                  <a href={waHref} target="_blank" rel="noreferrer" onClick={(e) => { if (!waHref) e.preventDefault(); }}>
                    <Video className="h-4 w-4" />
                  </a>
                </Button>
              </>
            );
          })()}
          <Button
            size="icon"
            variant={searchOpen ? "secondary" : "ghost"}
            className="h-9 w-9 rounded-full"
            title="Search in chat"
            onClick={() => { setSearchOpen((v) => !v); if (searchOpen) setChatSearch(""); }}
          >
            <Search className="h-4 w-4" />
          </Button>
          <Button
            size="icon" variant={infoOpen ? "secondary" : "ghost"}
            className="h-9 w-9 rounded-full" onClick={onToggleInfo} title="Contact info"
          >
            <Info className="h-4 w-4" />
          </Button>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button size="icon" variant="ghost" className="h-9 w-9 rounded-full" title="More">
                <MoreVertical className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={onToggleInfo}>
                <Info className="h-4 w-4 mr-2" /> Contact info
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => { setSearchOpen(true); }}>
                <Search className="h-4 w-4 mr-2" /> Search messages
              </DropdownMenuItem>
              <DropdownMenuItem
                onClick={async () => {
                  const { error } = await supabase
                    .from("conversations")
                    .update({ unread_count: 0 })
                    .eq("id", convo.id);
                  if (error) return toast.error(error.message);
                  toast.success("Marked as read");
                  qc.invalidateQueries({ queryKey: ["conversations"] });
                }}
              >
                <CheckCheck className="h-4 w-4 mr-2" /> Mark as read
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              {onDeleteChat && (
                <DropdownMenuItem className="text-destructive" onClick={onDeleteChat}>
                  <Trash2 className="h-4 w-4 mr-2" /> Delete chat
                </DropdownMenuItem>
              )}
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      {searchOpen && (
        <div className="px-4 py-2 border-b bg-muted/40 flex items-center gap-2">
          <Search className="h-4 w-4 text-muted-foreground" />
          <Input
            autoFocus
            placeholder="Search in this chat..."
            value={chatSearch}
            onChange={(e) => setChatSearch(e.target.value)}
            className="h-8"
          />
          <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => { setSearchOpen(false); setChatSearch(""); }}>
            <X className="h-4 w-4" />
          </Button>
        </div>
      )}


      {/* Messages */}
      <div ref={scrollerRef} className="flex-1 min-w-0 overflow-x-hidden overflow-y-auto px-3 md:px-6 lg:px-10 py-4 wa-chat-bg">
        {grouped.map((g) => (
          <div key={g.label} className="space-y-1.5">
            <div className="sticky top-0 z-10 grid place-items-center py-2">
              <span className="text-[11px] px-2.5 py-1 rounded-md bg-card/90 backdrop-blur shadow-sm text-muted-foreground font-medium">
                {g.label}
              </span>
            </div>
            {g.items.map((m: any) => {
              if (hidden.has(m.id)) return null;
              if (m.is_internal) {
                return (
                  <div key={m.id} className="mx-auto max-w-[80%] my-2 bg-amber-100 border border-amber-300 text-amber-900 text-sm rounded-lg px-3 py-2">
                    <div className="flex items-center gap-1 text-[10px] uppercase tracking-wide opacity-70 mb-0.5">
                      <StickyNote className="h-3 w-3" /> Internal note
                    </div>
                    {m.content}
                  </div>
                );
              }
              const out = m.direction === "out";
              const reactions: Array<{ by: string; emoji: string }> = Array.isArray(m.reactions) ? m.reactions : [];
              const isPinned = pinned.has(m.id);
              const isStarred = starred.has(m.id);
              const isSelected = selected.has(m.id);
              const onReplyAction = () => setReplyTo({
                wa_message_id: m.wa_message_id,
                preview: (m.content || `[${m.type}]`).slice(0, 120),
              });
              return (
                <div
                  key={m.id}
                  className={cn(
                    "group flex items-center gap-1",
                    out ? "justify-end" : "justify-start",
                    isSelected && "bg-primary/10 rounded-md",
                  )}
                  onClick={() => { if (selectMode) toggleSelected(m.id); }}
                >
                  {out && (
                    <MessageActions
                      m={m}
                      onReply={onReplyAction}
                      onReact={(e) => reactToMessage(m, e)}
                    />
                  )}
                  <ContextMenu>
                    <ContextMenuTrigger asChild>
                      <div className="relative max-w-[85%] md:max-w-[75%]">
                        <div
                          className={cn(
                            "px-3 py-2 text-sm rounded-lg shadow-sm",
                            out
                              ? "bg-[#d9fdd3] dark:bg-[oklch(0.35_0.08_152)] text-foreground rounded-tr-none wa-bubble-out"
                              : "bg-card text-foreground rounded-tl-none wa-bubble-in",
                          )}
                        >
                          {(isPinned || isStarred) && (
                            <div className="flex items-center gap-1 mb-1 text-[10px] text-muted-foreground">
                              {isPinned && <><Pin className="h-3 w-3" /> Pinned</>}
                              {isStarred && <Star className="h-3 w-3 fill-amber-500 text-amber-500" />}
                            </div>
                          )}
                          {m.reply_to_preview && (
                            <div className="mb-1 px-2 py-1 border-l-2 border-primary/60 bg-background/40 rounded text-[11px] text-muted-foreground line-clamp-2">
                              {m.reply_to_preview}
                            </div>
                          )}
                          <MessageBody m={m} />
                          <div className="text-[10px] text-muted-foreground/80 mt-1 flex items-center justify-end gap-1 leading-none">
                            <span>
                              {new Date(m.created_at).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                            </span>
                            {out && <DeliveryTick status={m.status} error={m.status_error} />}
                          </div>
                          {out && m.status === "failed" && m.status_error && (
                            <div className="mt-1 text-[10px] leading-snug text-destructive break-words">
                              {m.status_error}
                            </div>
                          )}
                        </div>
                        {reactions.length > 0 && (
                          <div className={cn(
                            "absolute -bottom-2 flex gap-0.5 px-1.5 py-0.5 rounded-full bg-card border shadow-sm text-xs",
                            out ? "right-2" : "left-2",
                          )}>
                            {reactions.slice(0, 4).map((r, i) => (
                              <span key={i}>{r.emoji}</span>
                            ))}
                          </div>
                        )}
                      </div>
                    </ContextMenuTrigger>
                    <ContextMenuContent className="w-52">
                      <ContextMenuItem onClick={onReplyAction}>
                        <Reply className="h-4 w-4 mr-2" /> Reply
                      </ContextMenuItem>
                      <ContextMenuItem onClick={() => { navigator.clipboard.writeText(m.content || ""); toast.success("Copied"); }}>
                        <CopyIcon className="h-4 w-4 mr-2" /> Copy
                      </ContextMenuItem>
                      <ContextMenuItem onClick={() => { setForwardMsg(m); setForwardTargets(new Set()); setForwardOpen(true); }}>
                        <ForwardIcon className="h-4 w-4 mr-2" /> Forward
                      </ContextMenuItem>
                      <ContextMenuItem onClick={() => toggleInSet(pinned, m.id, "pinned", setPinned)}>
                        {isPinned ? <><PinOff className="h-4 w-4 mr-2" /> Unpin</> : <><Pin className="h-4 w-4 mr-2" /> Pin</>}
                      </ContextMenuItem>
                      <ContextMenuItem onClick={() => toggleInSet(starred, m.id, "starred", setStarred)}>
                        {isStarred ? <><StarOff className="h-4 w-4 mr-2" /> Unstar</> : <><Star className="h-4 w-4 mr-2" /> Star</>}
                      </ContextMenuItem>
                      <ContextMenuItem onClick={() => addMessageToNote(m)}>
                        <NotebookPen className="h-4 w-4 mr-2" /> Add text to note
                      </ContextMenuItem>
                      <ContextMenuItem onClick={() => { setSelectMode(true); toggleSelected(m.id); }}>
                        <CheckSquare className="h-4 w-4 mr-2" /> Select
                      </ContextMenuItem>
                      <ContextMenuSeparator />
                      <ContextMenuItem onClick={() => toast.success("Reported. Our team will review.")}>
                        <Flag className="h-4 w-4 mr-2" /> Report
                      </ContextMenuItem>
                      <ContextMenuItem
                        className="text-destructive focus:text-destructive"
                        onClick={() => {
                          const next = new Set(hidden); next.add(m.id);
                          persistSet("hidden", next); setHidden(next);
                          toast.success("Deleted for you");
                        }}
                      >
                        <Trash2 className="h-4 w-4 mr-2" /> Delete
                      </ContextMenuItem>
                    </ContextMenuContent>
                  </ContextMenu>
                  {!out && (
                    <MessageActions
                      m={m}
                      onReply={onReplyAction}
                      onReact={(e) => reactToMessage(m, e)}
                    />
                  )}
                </div>
              );
            })}

          </div>
        ))}
        {messages.length === 0 && (
          <p className="text-center text-sm text-muted-foreground py-12">No messages yet — say hello 👋</p>
        )}
      </div>

      {/* Composer */}
      <div className="border-t bg-card">
        <Tabs value={tab} onValueChange={(v) => setTab(v as any)} className="px-3 pt-2">
          <TabsList className="h-7 bg-muted/50">
            <TabsTrigger value="reply" className="text-[11px] h-6">Reply</TabsTrigger>
            <TabsTrigger value="note" className="text-[11px] h-6">Internal note</TabsTrigger>
          </TabsList>
        </Tabs>

        {tab === "reply" ? (
          <>
            {(() => {
              const lastIn = [...(messages as any[])].reverse().find((m) => m.direction === "in");
              const ageMs = lastIn ? Date.now() - new Date(lastIn.created_at).getTime() : Infinity;
              const outsideWindow = ageMs > 24 * 60 * 60 * 1000;
              if (!outsideWindow) return null;
              return (
                <div className="mx-2 mt-2 px-3 py-2 rounded-lg bg-amber-50 border border-amber-200 text-amber-800 text-xs flex items-start gap-2">
                  <AlertCircle className="h-3.5 w-3.5 mt-0.5 shrink-0" />
                  <div>
                    <span className="font-semibold">24-hour window closed.</span>{" "}
                    Free-form replies aren't allowed until the contact messages you again. Send an approved <strong>template</strong> (template icon below) to re-open the conversation.
                  </div>
                </div>
              );
            })()}
            {replyTo && (
              <div className="mx-2 mt-2 flex items-start gap-2 px-3 py-2 rounded-lg bg-muted/50 border-l-4 border-primary">
                <Reply className="h-3.5 w-3.5 mt-0.5 text-primary shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-[10px] uppercase tracking-wide text-muted-foreground font-semibold">Replying to</p>
                  <p className="text-xs truncate">{replyTo.preview}</p>
                </div>
                <button onClick={() => setReplyTo(null)} className="text-muted-foreground hover:text-foreground">
                  <X className="h-4 w-4" />
                </button>
              </div>
            )}
            {pendingFiles.length > 0 && (
              <div className="mx-2 mt-2 flex flex-wrap gap-2 rounded-lg border bg-muted/40 p-2">
                {pendingFiles.map((p) => (
                  <div key={p.id} className="relative w-24 rounded-md border bg-background p-1">
                    {p.previewUrl && p.file.type.startsWith("image/") ? (
                      <img src={p.previewUrl} alt={p.file.name || "Pasted image"} className="h-16 w-full rounded object-cover" />
                    ) : p.previewUrl && p.file.type.startsWith("video/") ? (
                      <video src={p.previewUrl} className="h-16 w-full rounded object-cover" muted />
                    ) : (
                      <div className="flex h-16 w-full items-center justify-center rounded bg-muted">
                        <FileText className="h-6 w-6 text-muted-foreground" />
                      </div>
                    )}
                    <p className="mt-1 truncate text-[10px] text-muted-foreground">{p.file.name || "attachment"}</p>
                    <button
                      type="button"
                      onClick={() => removePendingFile(p.id)}
                      title="Remove attachment"
                      className="absolute -right-1.5 -top-1.5 rounded-full bg-background border p-0.5 text-muted-foreground hover:text-foreground"
                    >
                      <X className="h-3 w-3" />
                    </button>
                  </div>
                ))}
              </div>
            )}
            <div className="flex items-end gap-1.5 px-2 pb-2.5 pt-1.5">

              <input
                ref={fileInputRef} type="file" className="hidden"
                accept="image/*,video/*,audio/*,application/pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.txt,.csv,.zip"
                onChange={(e) => { const f = e.target.files?.[0]; if (f) handleFile(f); }}
              />
              <Popover open={emojiOpen} onOpenChange={setEmojiOpen}>
                <PopoverTrigger asChild>
                  <Button size="icon" variant="ghost" className="h-10 w-10 rounded-full text-muted-foreground" title="Emoji">
                    <Smile className="h-5 w-5" />
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="p-0 w-auto border-none" align="start" side="top">
                  <EmojiPicker
                    onEmojiClick={(d) => { insertEmoji(d.emoji); setEmojiOpen(false); }}
                    emojiStyle={EmojiStyle.NATIVE} theme={Theme.AUTO} width={320} height={380} lazyLoadEmojis
                  />
                </PopoverContent>
              </Popover>
              <Button
                size="icon" variant="ghost" className="h-10 w-10 rounded-full text-muted-foreground"
                disabled={uploading} title="Attach" onClick={() => fileInputRef.current?.click()}
              >
                <Paperclip className="h-5 w-5" />
              </Button>
              <Popover open={tplOpen} onOpenChange={setTplOpen}>
                <PopoverTrigger asChild>
                  <Button size="icon" variant="ghost" className="h-10 w-10 rounded-full text-muted-foreground" title="Send template">
                    <FileText className="h-5 w-5" />
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-80 p-0" align="start" side="top">
                  <div className="p-2 border-b">
                    <p className="text-xs font-semibold">Send approved template</p>
                    <p className="text-[10px] text-muted-foreground">Only APPROVED templates can be delivered.</p>
                  </div>
                  <div className="max-h-72 overflow-y-auto">
                    {templates.length === 0 && (
                      <p className="p-4 text-sm text-muted-foreground text-center">No templates synced yet.</p>
                    )}
                    {templates.map((t: any) => (
                      <button
                        key={t.id}
                        onClick={() => sendTemplate(t.id)}
                        disabled={t.status && t.status !== "APPROVED"}
                        className="w-full text-left px-3 py-2 hover:bg-accent border-b last:border-b-0 disabled:opacity-50 disabled:cursor-not-allowed"
                      >
                        <div className="flex items-center justify-between gap-2">
                          <p className="text-sm font-medium truncate">{t.meta_template_name}</p>
                          <span className={cn(
                            "text-[9px] px-1.5 py-0.5 rounded font-semibold uppercase",
                            t.status === "APPROVED" ? "bg-emerald-100 text-emerald-700" : "bg-muted text-muted-foreground",
                          )}>{t.status || "?"}</span>
                        </div>
                        <p className="text-[11px] text-muted-foreground truncate">{t.language} · {t.body?.slice(0, 60) || "—"}</p>
                      </button>
                    ))}
                  </div>
                </PopoverContent>
              </Popover>
              <div className="flex-1 bg-muted/50 rounded-2xl px-3 py-1.5">
                <Textarea
                  ref={textareaRef}
                  rows={1}
                  className="resize-none border-0 bg-transparent shadow-none focus-visible:ring-0 px-0 py-1 min-h-[28px] max-h-32 text-sm"
                  placeholder={uploading ? "Uploading…" : "Type a message"}
                  value={text}
                  onChange={(e) => setText(e.target.value)}
                  onPaste={handleComposerPaste}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" && !e.shiftKey) {
                      e.preventDefault();
                      if (e.repeat) return;          // ignore auto-repeat from held key
                      if (sendingRef.current) return;
                      send();
                    }
                  }}
                />
              </div>
              <Button
                size="icon"
                onClick={send}
                disabled={uploading || (!text.trim() && pendingFiles.length === 0)}

                className={cn("h-10 w-10 rounded-full shrink-0", sending && "opacity-70")}

                title="Send"
              >
                <Send className="h-4 w-4" />
              </Button>
            </div>
          </>
        ) : (

          <div className="flex items-end gap-2 px-3 pb-3 pt-1.5">
            <Textarea
              rows={2} className="resize-none bg-amber-50 border-amber-200"
              placeholder="Visible to your team only…"
              value={note} onChange={(e) => setNote(e.target.value)}
            />
            <Button variant="secondary" onClick={addNote} disabled={!note.trim()} className="self-end">
              <StickyNote className="h-4 w-4 mr-1" /> Save
            </Button>
          </div>
        )}
      </div>

      {/* Selection bar */}
      {selectMode && (
        <div className="absolute top-14 left-1/2 -translate-x-1/2 z-20 flex items-center gap-2 bg-card border shadow-lg rounded-full px-3 py-1.5">
          <span className="text-xs font-medium">{selected.size} selected</span>
          <Button size="sm" variant="ghost" className="h-7" onClick={bulkCopy}><CopyIcon className="h-3.5 w-3.5 mr-1" /> Copy</Button>
          <Button size="sm" variant="ghost" className="h-7 text-destructive" onClick={bulkDelete}><Trash2 className="h-3.5 w-3.5 mr-1" /> Delete</Button>
          <Button size="sm" variant="ghost" className="h-7" onClick={() => { setSelected(new Set()); setSelectMode(false); }}><X className="h-3.5 w-3.5" /></Button>
        </div>
      )}

      {/* Forward dialog */}
      <Dialog open={forwardOpen} onOpenChange={setForwardOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>Forward message</DialogTitle></DialogHeader>
          <div className="text-xs px-3 py-2 rounded bg-muted text-muted-foreground line-clamp-2">
            {forwardMsg?.content || "—"}
          </div>
          <div className="max-h-72 overflow-y-auto border rounded-md divide-y">
            {allConvos.length === 0 && (
              <p className="text-sm text-muted-foreground text-center py-6">No chats available</p>
            )}
            {(allConvos as any[]).filter((c) => c.id !== convo.id).map((c) => {
              const checked = forwardTargets.has(c.id);
              return (
                <label key={c.id} className="flex items-center gap-2 px-3 py-2 hover:bg-accent cursor-pointer text-sm">
                  <Checkbox checked={checked} onCheckedChange={() => {
                    const next = new Set(forwardTargets);
                    if (next.has(c.id)) next.delete(c.id); else next.add(c.id);
                    setForwardTargets(next);
                  }} />
                  <div className="min-w-0 flex-1">
                    <p className="truncate font-medium">{c.contact_name || c.contact_phone}</p>
                    <p className="text-[11px] text-muted-foreground truncate">{c.contact_phone}</p>
                  </div>
                </label>
              );
            })}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setForwardOpen(false)}>Cancel</Button>
            <Button onClick={doForward} disabled={forwardTargets.size === 0}>
              <ForwardIcon className="h-4 w-4 mr-1" /> Forward ({forwardTargets.size})
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// ---------- Right contact info panel ----------
function InfoPanel({ convo, members, me, onClose }: { convo: any; members: any[]; me: string | null; onClose: () => void }) {
  const qc = useQueryClient();
  const [newLabel, setNewLabel] = useState("");
  const name = convo.contact_name || convo.contact_phone;
  const assignee = members.find((m) => m.user_id === convo.assigned_to);

  async function setStatus(s: Status) {
    const { error } = await supabase.from("conversations").update({ status: s }).eq("id", convo.id);
    if (error) return toast.error(error.message);
    toast.success(`Marked ${s}`);
    qc.invalidateQueries({ queryKey: ["conversations"] });
  }
  async function assignTo(userId: string | null) {
    const { error } = await supabase.from("conversations").update({ assigned_to: userId }).eq("id", convo.id);
    if (error) return toast.error(error.message);
    qc.invalidateQueries({ queryKey: ["conversations"] });
  }
  async function toggleLabel(label: string) {
    const labels: string[] = convo.labels || [];
    const next = labels.includes(label) ? labels.filter((x) => x !== label) : [...labels, label];
    const { error } = await supabase.from("conversations").update({ labels: next }).eq("id", convo.id);
    if (error) return toast.error(error.message);
    qc.invalidateQueries({ queryKey: ["conversations"] });
    qc.invalidateQueries({ queryKey: ["conversation-labels"] });
  }

  return (
    <aside className="hidden md:flex flex-col min-h-0 border-l bg-card">
      <div className="px-4 py-2.5 border-b flex items-center gap-2">
        <Button size="icon" variant="ghost" className="h-8 w-8 rounded-full" onClick={onClose}>
          <X className="h-4 w-4" />
        </Button>
        <p className="font-semibold text-sm">Contact info</p>
      </div>

      <div className="flex-1 overflow-y-auto">
        <div className="p-6 text-center border-b">
          <div className="mx-auto mb-3"><Avatar name={name} size={96} /></div>
          <p className="font-display text-lg font-semibold">{name}</p>
          <p className="text-xs text-muted-foreground mt-0.5">{convo.contact_phone}</p>
          <div className="flex items-center justify-center gap-2 mt-4">
            <Button size="sm" variant="outline" className="rounded-full" disabled>
              <Phone className="h-3.5 w-3.5 mr-1" /> Call
            </Button>
            <Button size="sm" variant="outline" className="rounded-full" disabled>
              <Video className="h-3.5 w-3.5 mr-1" /> Video
            </Button>
          </div>
        </div>

        {/* Status */}
        <div className="px-4 py-3 border-b space-y-2">
          <p className="text-[10px] uppercase tracking-wide text-muted-foreground font-semibold">Status</p>
          <div className="flex gap-1.5">
            <Button size="sm" variant={convo.status === "open" ? "default" : "outline"} className="flex-1 h-8" onClick={() => setStatus("open")}>
              Open
            </Button>
            <Button size="sm" variant={convo.status === "pending" ? "default" : "outline"} className="flex-1 h-8" onClick={() => setStatus("pending")}>
              <Clock className="h-3 w-3 mr-1" /> Pending
            </Button>
            <Button size="sm" variant={convo.status === "resolved" ? "default" : "outline"} className="flex-1 h-8" onClick={() => setStatus("resolved")}>
              <CheckCircle2 className="h-3 w-3 mr-1" /> Resolved
            </Button>
          </div>
        </div>

        {/* Assignee */}
        <div className="px-4 py-3 border-b space-y-2">
          <p className="text-[10px] uppercase tracking-wide text-muted-foreground font-semibold">Assigned agent</p>
          <Popover>
            <PopoverTrigger asChild>
              <Button variant="outline" size="sm" className="w-full justify-start h-9">
                <UserCog className="h-3.5 w-3.5 mr-2" />
                {assignee?.name || "Unassigned"}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-56 p-1" align="start">
              <button onClick={() => assignTo(null)} className="w-full text-left px-2 py-1.5 text-sm hover:bg-accent rounded">
                Unassigned
              </button>
              {members.map((m) => (
                <button key={m.user_id} onClick={() => assignTo(m.user_id)} className="w-full text-left px-2 py-1.5 text-sm hover:bg-accent rounded">
                  {m.name}
                </button>
              ))}
            </PopoverContent>
          </Popover>
        </div>

        {/* Labels */}
        <div className="px-4 py-3 border-b space-y-2">
          <p className="text-[10px] uppercase tracking-wide text-muted-foreground font-semibold flex items-center gap-1">
            <Tag className="h-3 w-3" /> Labels
          </p>
          <div className="flex flex-wrap gap-1">
            {(convo.labels || []).map((l: string) => (
              <span key={l} className="inline-flex items-center gap-1 text-xs px-2 py-0.5 rounded bg-primary/10 text-primary">
                {l}
                <button onClick={() => toggleLabel(l)}><X className="h-3 w-3" /></button>
              </span>
            ))}
            {!convo.labels?.length && <span className="text-xs text-muted-foreground">No labels</span>}
          </div>
          <div className="flex gap-1">
            <Input className="h-8 text-sm" placeholder="Add label" value={newLabel} onChange={(e) => setNewLabel(e.target.value)} />
            <Button size="sm" className="h-8" onClick={() => {
              if (newLabel.trim()) { toggleLabel(newLabel.trim()); setNewLabel(""); }
            }}>
              <Plus className="h-3.5 w-3.5" />
            </Button>
          </div>
        </div>

        {/* CRM */}
        <div className="px-4 py-3 border-b">
          <p className="text-[10px] uppercase tracking-wide text-muted-foreground font-semibold mb-2 flex items-center gap-1">
            <Briefcase className="h-3 w-3" /> CRM
          </p>
          <CRMActions convo={convo} me={me} />
        </div>
      </div>
    </aside>
  );
}

function NewChatButton({ onOpened }: { onOpened: (id: string) => void }) {
  const qc = useQueryClient();
  const { currentWorkspaceId } = useWorkspace();
  const startFn = useServerFn(startConversations);
  const [open, setOpen] = useState(false);
  const [tab, setTab] = useState<"contacts" | "groups">("contacts");
  const [q, setQ] = useState("");
  const [selContacts, setSelContacts] = useState<Set<string>>(new Set());
  const [selGroups, setSelGroups] = useState<Set<string>>(new Set());
  const [busy, setBusy] = useState(false);

  const { data: contacts = [] } = useQuery({
    queryKey: ["picker-contacts", currentWorkspaceId, q],
    enabled: open && !!currentWorkspaceId,
    queryFn: async () => {
      let qb = supabase.from("contacts").select("id, name, phone")
        .eq("workspace_id", currentWorkspaceId!).order("name").limit(200);
      if (q) qb = qb.or(`name.ilike.%${q}%,phone.ilike.%${q}%`);
      const { data, error } = await qb;
      if (error) throw error;
      return data ?? [];
    },
  });

  const { data: groups = [] } = useQuery({
    queryKey: ["picker-groups", currentWorkspaceId],
    enabled: open && !!currentWorkspaceId,
    queryFn: async () => {
      const { data, error } = await supabase.from("contact_groups")
        .select("id, name, description").eq("workspace_id", currentWorkspaceId!).order("name");
      if (error) throw error;
      return data ?? [];
    },
  });

  function toggle(set: Set<string>, setter: (s: Set<string>) => void, id: string) {
    const next = new Set(set);
    next.has(id) ? next.delete(id) : next.add(id);
    setter(next);
  }

  async function start() {
    if (!currentWorkspaceId) return;
    if (selContacts.size === 0 && selGroups.size === 0) return toast.error("Select at least one contact or group");
    setBusy(true);
    try {
      const r: any = await startFn({
        data: {
          workspace_id: currentWorkspaceId,
          contact_ids: Array.from(selContacts),
          group_ids: Array.from(selGroups),
        },
      });
      if (!r.ok) return toast.error("Failed to start chat");
      toast.success(r.created > 0 ? `Started ${r.created} new chat(s)` : "Opened existing chat");
      qc.invalidateQueries({ queryKey: ["conversations"] });
      setOpen(false);
      setSelContacts(new Set());
      setSelGroups(new Set());
      if (r.first_conversation_id) setTimeout(() => onOpened(r.first_conversation_id), 200);
    } catch (e: any) {
      toast.error(e.message);
    } finally { setBusy(false); }
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <Button size="icon" variant="ghost" className="h-8 w-8 rounded-full" onClick={() => setOpen(true)} title="New chat">
        <MessageSquarePlus className="h-4 w-4" />
      </Button>
      <DialogContent className="max-w-md">
        <DialogHeader><DialogTitle>Start a new chat</DialogTitle></DialogHeader>
        <Tabs value={tab} onValueChange={(v) => setTab(v as any)}>
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="contacts">Contacts ({contacts.length})</TabsTrigger>
            <TabsTrigger value="groups">Groups ({groups.length})</TabsTrigger>
          </TabsList>
        </Tabs>
        {tab === "contacts" && (
          <>
            <Input placeholder="Search name or phone" value={q} onChange={(e) => setQ(e.target.value)} />
            <div className="max-h-72 overflow-y-auto border rounded-md divide-y">
              {contacts.length === 0 && (
                <p className="p-4 text-sm text-muted-foreground text-center">No contacts</p>
              )}
              {contacts.map((c: any) => (
                <label key={c.id} className="flex items-center gap-2 p-2 hover:bg-accent/40 cursor-pointer">
                  <Checkbox checked={selContacts.has(c.id)} onCheckedChange={() => toggle(selContacts, setSelContacts, c.id)} />
                  <Avatar name={c.name || c.phone} size={32} />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{c.name}</p>
                    <p className="text-xs text-muted-foreground truncate">{c.phone}</p>
                  </div>
                </label>
              ))}
            </div>
          </>
        )}
        {tab === "groups" && (
          <div className="max-h-72 overflow-y-auto border rounded-md divide-y">
            {groups.length === 0 && (
              <p className="p-4 text-sm text-muted-foreground text-center">No groups</p>
            )}
            {groups.map((g: any) => (
              <label key={g.id} className="flex items-center gap-2 p-2 hover:bg-accent/40 cursor-pointer">
                <Checkbox checked={selGroups.has(g.id)} onCheckedChange={() => toggle(selGroups, setSelGroups, g.id)} />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">{g.name}</p>
                  {g.description && <p className="text-xs text-muted-foreground truncate">{g.description}</p>}
                </div>
              </label>
            ))}
          </div>
        )}
        <DialogFooter>
          <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
          <Button onClick={start} disabled={busy}>Start chat</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function DeliveryTick({ status, error }: { status?: string | null; error?: string | null }) {
  if (status === "failed") {
    return (
      <span title={error || "Failed"} className="inline-flex">
        <AlertCircle className="h-3 w-3 text-destructive" aria-label={error ? `Failed: ${error}` : "Failed"} />
      </span>
    );
  }
  if (status === "read") return <CheckCheck className="h-3 w-3 text-sky-500" aria-label="Read" />;
  if (status === "delivered") return <CheckCheck className="h-3 w-3 opacity-80" aria-label="Delivered" />;
  return <Check className="h-3 w-3 opacity-70" aria-label="Sent" />;
}

function MessageBody({ m }: { m: any }) {
  const isHttp = typeof m.media_url === "string" && /^https?:\/\//.test(m.media_url);
  const mime = String(m.media_mime || "").toLowerCase();
  const mediaKind = m.type === "document" && mime.startsWith("image/") ? "image" : m.type;
  const normalizedContent = String(m.content || "").trim() === "[button]" ? "Button reply" : m.content;
  const lines = typeof normalizedContent === "string" ? normalizedContent.split(/\r?\n/) : [];
  const buttonLines = lines.filter((line) => /^button:\s*/i.test(line));
  const bodyLines = lines.filter((line) => !/^button:\s*/i.test(line));
  return (
    <div className="space-y-1">
      {isHttp && mediaKind === "image" && (
        <a href={m.media_url} target="_blank" rel="noreferrer" title="Open image in new tab">
          <img
            src={m.media_url}
            alt=""
            className="rounded-lg max-h-64 max-w-full cursor-zoom-in hover:opacity-90 transition"
          />
        </a>
      )}
      {isHttp && mediaKind === "video" && (
        <div className="space-y-1">
          <video
            src={m.media_url}
            controls
            playsInline
            preload="metadata"
            className="rounded-lg max-h-64 max-w-full bg-black"
          />
          <a
            href={m.media_url}
            target="_blank"
            rel="noreferrer"
            className="text-[11px] underline opacity-80 hover:opacity-100"
          >
            Open video in new tab
          </a>
        </div>
      )}
      {isHttp && mediaKind === "audio" && (
        <audio src={m.media_url} controls className="w-full" />
      )}
      {isHttp && mediaKind === "document" && (
        <a href={m.media_url} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 underline">
          <Paperclip className="h-3 w-3" /> Open document
        </a>
      )}
      {!isHttp && mediaKind !== "text" && mediaKind !== "note" && (
        <div className="text-[10px] uppercase tracking-wide opacity-70">[{m.type}]</div>
      )}
      {bodyLines.length > 0 && <div className="whitespace-pre-wrap break-words">{bodyLines.join("\n")}</div>}
      {buttonLines.length > 0 && (
        <div className="flex flex-wrap gap-1 pt-1">
          {buttonLines.map((line, index) => (
            <span key={`${line}-${index}`} className="rounded-full border bg-background/70 px-2.5 py-1 text-xs font-medium">
              {line.replace(/^button:\s*/i, "")}
            </span>
          ))}
        </div>
      )}
    </div>
  );
}

function CRMActions({ convo, me }: { convo: any; me: string | null }) {
  const qc = useQueryClient();
  const [busy, setBusy] = useState(false);
  const [stageId, setStageId] = useState("");
  const [dealTitle, setDealTitle] = useState("");
  const [groupId, setGroupId] = useState("");
  const [followTitle, setFollowTitle] = useState("");
  const [followDue, setFollowDue] = useState("");

  const { data: stages = [] } = useQuery({
    queryKey: ["pipeline-stages", convo.workspace_id],
    queryFn: async () => {
      const { data, error } = await supabase.from("pipeline_stages")
        .select("id, name").eq("workspace_id", convo.workspace_id).order("position");
      if (error) throw error;
      return data ?? [];
    },
  });

  const { data: groups = [] } = useQuery({
    queryKey: ["crm-groups", convo.workspace_id],
    queryFn: async () => {
      const { data, error } = await supabase.from("contact_groups")
        .select("id, name").eq("workspace_id", convo.workspace_id).order("name");
      if (error) throw error;
      return data ?? [];
    },
  });

  async function addToPipeline() {
    if (!stageId || !me) return toast.error("Pick a pipeline stage");
    setBusy(true);
    const { error } = await supabase.from("deals").insert({
      workspace_id: convo.workspace_id, user_id: me, contact_id: convo.contact_id,
      stage_id: stageId,
      title: dealTitle.trim() || `Deal · ${convo.contact_name || convo.contact_phone}`,
    });
    setBusy(false);
    if (error) return toast.error(error.message);
    toast.success("Added to pipeline");
    setDealTitle("");
    qc.invalidateQueries({ queryKey: ["deals"] });
  }

  async function addToGroup() {
    if (!groupId || !convo.contact_id) return toast.error("Pick a group");
    setBusy(true);
    const { error } = await supabase.from("contact_group_members").insert({
      workspace_id: convo.workspace_id, group_id: groupId, contact_id: convo.contact_id,
    });
    setBusy(false);
    if (error && !error.message.includes("duplicate")) return toast.error(error.message);
    toast.success("Added to group");
  }

  async function scheduleFollowUp() {
    if (!followTitle.trim() || !followDue || !me) return toast.error("Title and due date required");
    setBusy(true);
    const { error } = await supabase.from("follow_ups").insert({
      workspace_id: convo.workspace_id, user_id: me, contact_id: convo.contact_id,
      conversation_id: convo.id, title: followTitle.trim(),
      due_at: new Date(followDue).toISOString(),
    });
    setBusy(false);
    if (error) return toast.error(error.message);
    toast.success("Follow-up scheduled");
    setFollowTitle(""); setFollowDue("");
    qc.invalidateQueries({ queryKey: ["follow_ups"] });
  }

  return (
    <div className="space-y-4">
      <div className="space-y-1.5">
        <Label className="text-xs flex items-center gap-1"><Briefcase className="h-3 w-3" /> Add to pipeline</Label>
        <Select value={stageId} onValueChange={setStageId}>
          <SelectTrigger className="h-8 text-xs"><SelectValue placeholder="Pick a stage" /></SelectTrigger>
          <SelectContent>
            {stages.map((s: any) => (<SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>))}
          </SelectContent>
        </Select>
        <Input className="h-8 text-xs" placeholder="Deal title (optional)" value={dealTitle} onChange={(e) => setDealTitle(e.target.value)} />
        <Button size="sm" className="w-full h-8" disabled={busy || !stageId} onClick={addToPipeline}>Add deal</Button>
      </div>

      <div className="space-y-1.5">
        <Label className="text-xs flex items-center gap-1"><UsersIcon className="h-3 w-3" /> Add to group</Label>
        <Select value={groupId} onValueChange={setGroupId}>
          <SelectTrigger className="h-8 text-xs"><SelectValue placeholder="Pick a group" /></SelectTrigger>
          <SelectContent>
            {groups.map((g: any) => (<SelectItem key={g.id} value={g.id}>{g.name}</SelectItem>))}
          </SelectContent>
        </Select>
        <Button size="sm" className="w-full h-8" disabled={busy || !groupId || !convo.contact_id} onClick={addToGroup}>Add to group</Button>
      </div>

      <div className="space-y-1.5">
        <Label className="text-xs flex items-center gap-1"><CalendarClock className="h-3 w-3" /> Schedule follow-up</Label>
        <Input className="h-8 text-xs" placeholder="Follow-up title" value={followTitle} onChange={(e) => setFollowTitle(e.target.value)} />
        <Input type="datetime-local" className="h-8 text-xs" value={followDue} onChange={(e) => setFollowDue(e.target.value)} />
        <Button size="sm" className="w-full h-8" disabled={busy || !followTitle.trim() || !followDue} onClick={scheduleFollowUp}>
          Schedule
        </Button>
      </div>
    </div>
  );
}

