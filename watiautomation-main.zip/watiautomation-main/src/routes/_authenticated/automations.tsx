import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useWorkspace } from "@/lib/workspace-context";
import { saveAutomation, deleteAutomation, toggleAutomation } from "@/lib/automations.functions";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { toast } from "sonner";
import { Plus, Zap, MessageSquare, Clock, Search, UserPlus, Trash2, Pencil } from "lucide-react";

export const Route = createFileRoute("/_authenticated/automations")({
  component: AutomationsPage,
  head: () => ({ meta: [{ title: "Automations — Slice" }] }),
});

type AutomationType = "welcome" | "away" | "keyword" | "routing";

const TYPE_META: Record<AutomationType, { label: string; icon: any; desc: string }> = {
  welcome: { label: "Welcome", icon: MessageSquare, desc: "Sent on the contact's first message" },
  away: { label: "Away", icon: Clock, desc: "Sent outside business hours" },
  keyword: { label: "Keyword", icon: Search, desc: "Triggered when a message matches keywords" },
  routing: { label: "Routing", icon: UserPlus, desc: "Auto-assign chats to a teammate" },
};

const emptyDraft = (workspace_id: string, type: AutomationType = "keyword") => ({
  workspace_id,
  name: "",
  type,
  enabled: true,
  keywords: [] as string[],
  match_type: "contains" as "contains" | "exact" | "starts_with",
  reply_text: "",
  template_id: null as string | null,
  away_start: "09:00",
  away_end: "18:00",
  away_days: [1, 2, 3, 4, 5],
  assign_to: null as string | null,
  priority: 0,
});

function AutomationsPage() {
  const qc = useQueryClient();
  const { currentWorkspaceId } = useWorkspace();
  const saveFn = useServerFn(saveAutomation);
  const deleteFn = useServerFn(deleteAutomation);
  const toggleFn = useServerFn(toggleAutomation);

  const [editing, setEditing] = useState<any | null>(null);
  const [keywordInput, setKeywordInput] = useState("");

  const { data: automations = [] } = useQuery({
    queryKey: ["automations", currentWorkspaceId],
    queryFn: async () => {
      const { data, error } = await supabase.from("automations").select("*")
        .eq("workspace_id", currentWorkspaceId!).order("created_at", { ascending: false });
      if (error) throw error;
      return data || [];
    },
    enabled: !!currentWorkspaceId,
  });

  const { data: templates = [] } = useQuery({
    queryKey: ["templates-min", currentWorkspaceId],
    queryFn: async () => {
      const { data } = await supabase.from("templates").select("id, meta_template_name, language, status")
        .eq("workspace_id", currentWorkspaceId!);
      return data || [];
    },
    enabled: !!currentWorkspaceId,
  });

  const { data: members = [] } = useQuery({
    queryKey: ["workspace-members", currentWorkspaceId],
    queryFn: async () => {
      const { data } = await supabase.from("workspace_members").select("user_id, role")
        .eq("workspace_id", currentWorkspaceId!);
      return data || [];
    },
    enabled: !!currentWorkspaceId,
  });

  const memberIds = members.map((m: any) => m.user_id);
  const { data: profiles = [] } = useQuery({
    queryKey: ["profiles-of", memberIds.join(",")],
    queryFn: async () => {
      if (!memberIds.length) return [];
      const { data } = await supabase.from("profiles").select("id, full_name, email").in("id", memberIds);
      return data || [];
    },
    enabled: memberIds.length > 0,
  });
  const profileById = new Map(profiles.map((p: any) => [p.id, p]));

  function openNew(type: AutomationType) {
    setEditing({ ...emptyDraft(currentWorkspaceId!, type), name: `${TYPE_META[type].label} message` });
    setKeywordInput("");
  }

  function openEdit(a: any) {
    setEditing({ ...a });
    setKeywordInput("");
  }

  async function save() {
    if (!editing?.name?.trim()) { toast.error("Name is required"); return; }
    if ((editing.type === "welcome" || editing.type === "away") && !editing.reply_text?.trim()) {
      toast.error("Reply message is required"); return;
    }
    if (editing.type === "keyword" && (!editing.keywords?.length || (!editing.reply_text?.trim() && !editing.template_id))) {
      toast.error("Keyword automation needs keywords and either a reply or template"); return;
    }
    if (editing.type === "routing" && !editing.assign_to) {
      toast.error("Pick a teammate to assign chats to"); return;
    }
    try {
      await saveFn({ data: editing });
      toast.success("Automation saved");
      setEditing(null);
      qc.invalidateQueries({ queryKey: ["automations", currentWorkspaceId] });
    } catch (e: any) {
      toast.error(e.message);
    }
  }

  async function remove(id: string) {
    if (!confirm("Delete this automation?")) return;
    await deleteFn({ data: { id } });
    qc.invalidateQueries({ queryKey: ["automations", currentWorkspaceId] });
  }

  async function toggle(id: string, enabled: boolean) {
    await toggleFn({ data: { id, enabled } });
    qc.invalidateQueries({ queryKey: ["automations", currentWorkspaceId] });
  }

  function addKeyword() {
    const k = keywordInput.trim();
    if (!k || !editing) return;
    if (editing.keywords.includes(k)) return;
    setEditing({ ...editing, keywords: [...editing.keywords, k] });
    setKeywordInput("");
  }

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-3xl font-display font-bold flex items-center gap-2">
            <Zap className="h-7 w-7 text-primary" /> Automations
          </h1>
          <p className="text-muted-foreground mt-1">Auto-reply, routing, and keyword triggers for incoming WhatsApp messages.</p>
        </div>
        <div className="flex flex-wrap gap-2">
          {(Object.keys(TYPE_META) as AutomationType[]).map((t) => {
            const Icon = TYPE_META[t].icon;
            return (
              <Button key={t} variant="outline" size="sm" onClick={() => openNew(t)}>
                <Icon className="h-4 w-4 mr-1.5" /> {TYPE_META[t].label}
              </Button>
            );
          })}
        </div>
      </div>

      {automations.length === 0 ? (
        <Card className="p-12 text-center">
          <Zap className="h-12 w-12 mx-auto text-muted-foreground mb-3" />
          <h3 className="font-semibold text-lg">No automations yet</h3>
          <p className="text-sm text-muted-foreground mt-1">Create your first auto-reply or routing rule above.</p>
          <Button className="mt-4" onClick={() => openNew("keyword")}>
            <Plus className="h-4 w-4 mr-1.5" /> New automation
          </Button>
        </Card>
      ) : (
        <div className="grid gap-3">
          {automations.map((a: any) => {
            const meta = TYPE_META[a.type as AutomationType];
            const Icon = meta.icon;
            return (
              <Card key={a.id} className="p-4 flex items-start gap-4">
                <div className="grid h-10 w-10 place-items-center rounded-lg bg-primary/10 text-primary shrink-0">
                  <Icon className="h-5 w-5" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <h3 className="font-semibold truncate">{a.name}</h3>
                    <Badge variant="secondary" className="capitalize">{meta.label}</Badge>
                    {!a.enabled && <Badge variant="outline">Disabled</Badge>}
                  </div>
                  <p className="text-xs text-muted-foreground mt-0.5">{meta.desc}</p>
                  {a.type === "keyword" && a.keywords?.length > 0 && (
                    <div className="flex flex-wrap gap-1 mt-2">
                      {a.keywords.map((k: string) => <Badge key={k} variant="outline" className="text-xs">{k}</Badge>)}
                    </div>
                  )}
                  {a.reply_text && (
                    <p className="text-sm mt-2 line-clamp-2 text-muted-foreground">{a.reply_text}</p>
                  )}
                  {a.assign_to && (
                    <p className="text-xs mt-1.5 text-muted-foreground">
                      Assigns to: <span className="font-medium text-foreground">
                        {(profileById.get(a.assign_to) as any)?.full_name || (profileById.get(a.assign_to) as any)?.email || "Teammate"}
                      </span>
                    </p>
                  )}
                </div>
                <div className="flex items-center gap-1">
                  <Switch checked={a.enabled} onCheckedChange={(v) => toggle(a.id, v)} />
                  <Button size="icon" variant="ghost" onClick={() => openEdit(a)}><Pencil className="h-4 w-4" /></Button>
                  <Button size="icon" variant="ghost" onClick={() => remove(a.id)}><Trash2 className="h-4 w-4 text-destructive" /></Button>
                </div>
              </Card>
            );
          })}
        </div>
      )}

      <Dialog open={!!editing} onOpenChange={(o) => !o && setEditing(null)}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editing?.id ? "Edit automation" : "New automation"}</DialogTitle>
          </DialogHeader>
          {editing && (
            <div className="space-y-4">
              <div>
                <Label>Name</Label>
                <Input value={editing.name} onChange={(e) => setEditing({ ...editing, name: e.target.value })} maxLength={120} />
              </div>
              <div>
                <Label>Type</Label>
                <Select value={editing.type} onValueChange={(v: AutomationType) => setEditing({ ...editing, type: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {(Object.keys(TYPE_META) as AutomationType[]).map((t) => (
                      <SelectItem key={t} value={t}>{TYPE_META[t].label} — {TYPE_META[t].desc}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {(editing.type === "keyword" || editing.type === "routing") && (
                <div>
                  <Label>Keywords</Label>
                  <div className="flex gap-2">
                    <Input
                      value={keywordInput}
                      onChange={(e) => setKeywordInput(e.target.value)}
                      onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); addKeyword(); } }}
                      placeholder='e.g. "pricing"'
                    />
                    <Button type="button" variant="outline" onClick={addKeyword}>Add</Button>
                  </div>
                  <div className="flex flex-wrap gap-1 mt-2">
                    {editing.keywords.map((k: string) => (
                      <Badge key={k} variant="secondary" className="cursor-pointer"
                        onClick={() => setEditing({ ...editing, keywords: editing.keywords.filter((x: string) => x !== k) })}>
                        {k} ×
                      </Badge>
                    ))}
                  </div>
                  <div className="mt-2">
                    <Label className="text-xs">Match type</Label>
                    <Select value={editing.match_type} onValueChange={(v) => setEditing({ ...editing, match_type: v })}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="contains">Contains</SelectItem>
                        <SelectItem value="exact">Exact match</SelectItem>
                        <SelectItem value="starts_with">Starts with</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              )}

              {editing.type === "away" && (
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <Label>Business hours start</Label>
                    <Input type="time" value={editing.away_start || ""} onChange={(e) => setEditing({ ...editing, away_start: e.target.value })} />
                  </div>
                  <div>
                    <Label>Business hours end</Label>
                    <Input type="time" value={editing.away_end || ""} onChange={(e) => setEditing({ ...editing, away_end: e.target.value })} />
                  </div>
                  <div className="col-span-2">
                    <Label className="text-xs">Active on days (outside these hours = away)</Label>
                    <div className="flex gap-1 mt-1">
                      {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((d, i) => {
                        const on = editing.away_days.includes(i);
                        return (
                          <button
                            key={d}
                            type="button"
                            onClick={() => setEditing({
                              ...editing,
                              away_days: on ? editing.away_days.filter((x: number) => x !== i) : [...editing.away_days, i].sort(),
                            })}
                            className={`px-2 py-1 text-xs rounded border ${on ? "bg-primary text-primary-foreground border-primary" : "bg-background"}`}
                          >{d}</button>
                        );
                      })}
                    </div>
                  </div>
                </div>
              )}

              {editing.type !== "routing" && (
                <div>
                  <Label>Reply message</Label>
                  <Textarea rows={4} value={editing.reply_text || ""} onChange={(e) => setEditing({ ...editing, reply_text: e.target.value })} placeholder="Hi! Thanks for reaching out…" />
                </div>
              )}

              {editing.type === "keyword" && (
                <div>
                  <Label>Or send a template (optional)</Label>
                  <Select value={editing.template_id || "none"} onValueChange={(v) => setEditing({ ...editing, template_id: v === "none" ? null : v })}>
                    <SelectTrigger><SelectValue placeholder="Select template" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">— None —</SelectItem>
                      {templates.filter((t: any) => t.status === "APPROVED").map((t: any) => (
                        <SelectItem key={t.id} value={t.id}>{t.meta_template_name} ({t.language})</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}

              {(editing.type === "routing" || editing.type === "keyword") && (
                <div>
                  <Label>{editing.type === "routing" ? "Assign chat to" : "Assign chat to (optional)"}</Label>
                  <Select value={editing.assign_to || "none"} onValueChange={(v) => setEditing({ ...editing, assign_to: v === "none" ? null : v })}>
                    <SelectTrigger><SelectValue placeholder="Select teammate" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">— None —</SelectItem>
                      {members.map((m: any) => {
                        const p: any = profileById.get(m.user_id);
                        return (
                          <SelectItem key={m.user_id} value={m.user_id}>
                            {p?.full_name || p?.email || m.user_id.slice(0, 8)} ({m.role})
                          </SelectItem>
                        );
                      })}
                    </SelectContent>
                  </Select>
                </div>
              )}

              <div className="flex items-center justify-between">
                <Label>Enabled</Label>
                <Switch checked={editing.enabled} onCheckedChange={(v) => setEditing({ ...editing, enabled: v })} />
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditing(null)}>Cancel</Button>
            <Button onClick={save}>Save</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
