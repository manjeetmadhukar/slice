import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useWorkspace, canManageWorkspace } from "@/lib/workspace-context";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger } from "@/components/ui/dialog";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { toast } from "sonner";
import { CreditCard, Check, Star, Clock, X, ShieldCheck, Package, Sparkles } from "lucide-react";
import { PricingComparisonTable, type PricingPlan } from "@/components/PricingComparisonTable";


import { FEATURE_CATALOG, FEATURE_KEYS as CUSTOM_FEATURE_KEYS, LIMIT_CATALOG as CUSTOM_LIMIT_KEYS } from "@/lib/features-catalog";
import { PricingFields, type PricingValue } from "@/components/PricingFields";



export const Route = createFileRoute("/_authenticated/subscription")({
  component: SubscriptionPage,
  head: () => ({ meta: [{ title: "My Subscription — Slice" }] }),
});

const fmt = (amount: number, currency: string) =>
  new Intl.NumberFormat(undefined, { style: "currency", currency: currency || "USD", maximumFractionDigits: 0 }).format(amount);

function StatusBadge({ status }: { status: string }) {
  const map: Record<string, { label: string; cls: string }> = {
    pending: { label: "Pending approval", cls: "bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-300" },
    approved: { label: "Approved", cls: "bg-emerald-100 text-emerald-800 dark:bg-emerald-900/30 dark:text-emerald-300" },
    rejected: { label: "Rejected", cls: "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300" },
    cancelled: { label: "Cancelled", cls: "bg-muted text-muted-foreground" },
  };
  const v = map[status] ?? map.pending;
  return <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${v.cls}`}>{v.label}</span>;
}

function SubscriptionPage() {
  const qc = useQueryClient();
  const { currentWorkspaceId, role } = useWorkspace();
  const isAdmin = canManageWorkspace(role);

  const { data: subs = [] } = useQuery({
    queryKey: ["subscriptions", currentWorkspaceId],
    enabled: !!currentWorkspaceId,
    queryFn: async () => {
      const { data, error } = await supabase.from("subscriptions").select("*")
        .eq("workspace_id", currentWorkspaceId!).order("created_at", { ascending: false });
      if (error) throw error;
      return data;
    },
  });

  const { data: vendors = [] } = useQuery({
    queryKey: ["vendors-pub", currentWorkspaceId],
    enabled: !!currentWorkspaceId,
    queryFn: async () => {
      const { data, error } = await supabase.from("vendors").select("*")
        .eq("workspace_id", currentWorkspaceId!).eq("status", "active").order("name");
      if (error) throw error;
      return data;
    },
  });

  const { data: plans = [] } = useQuery({
    queryKey: ["vendor-plans-pub", currentWorkspaceId],
    enabled: !!currentWorkspaceId,
    queryFn: async () => {
      const { data, error } = await supabase.from("vendor_plans").select("*")
        .eq("workspace_id", currentWorkspaceId!).order("position");
      if (error) throw error;
      return data;
    },
  });

  const active = subs.find((s: any) => s.status === "approved");
  const pending = subs.filter((s: any) => s.status === "pending");

  async function requestPlan(plan: any, vendor: any) {
    if (!currentWorkspaceId) return toast.error("No workspace selected");
    const { data: u } = await supabase.auth.getUser();
    if (!u.user) return toast.error("Not signed in");
    const { error } = await supabase.from("subscriptions").insert({
      workspace_id: currentWorkspaceId,
      vendor_id: vendor.id,
      plan_id: plan.id,
      requested_by: u.user.id,
      status: "pending",
      price_snapshot: plan.price,
      currency: plan.currency,
      billing_interval: plan.billing_interval,
      plan_name_snapshot: plan.name,
      vendor_name_snapshot: vendor.name,
    });
    if (error) return toast.error(error.message);
    toast.success("Plan requested. Waiting for admin approval.");
    qc.invalidateQueries({ queryKey: ["subscriptions"] });
  }

  async function cancel(id: string) {
    if (!confirm("Cancel this subscription?")) return;
    const { error } = await supabase.from("subscriptions")
      .update({ status: "cancelled", cancelled_at: new Date().toISOString() })
      .eq("id", id);
    if (error) return toast.error(error.message);
    toast.success("Subscription cancelled");
    qc.invalidateQueries({ queryKey: ["subscriptions"] });
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h1 className="font-display text-3xl font-bold flex items-center gap-2">
            <CreditCard className="h-7 w-7" />My Subscription
          </h1>
          <p className="text-muted-foreground">Browse plans and request a subscription. An admin will approve your request.</p>
        </div>
        <div className="flex items-center gap-2">
          <Button asChild variant="outline" size="sm">
            <a href="/pricing" target="_blank" rel="noopener noreferrer">
              <Sparkles className="h-4 w-4 mr-1.5" /> View pricing page
            </a>
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={async () => {
              const url = `${window.location.origin}/pricing`;
              try {
                if (navigator.share) {
                  await navigator.share({ title: "Our pricing", url });
                } else {
                  await navigator.clipboard.writeText(url);
                  toast.success("Pricing link copied to clipboard");
                }
              } catch {
                /* user cancelled */
              }
            }}
          >
            Share link
          </Button>
        </div>
      </div>


      {isAdmin && <CustomPlanRequestCard workspaceId={currentWorkspaceId!} />}

      <div className="grid gap-4 md:grid-cols-3">
        <Card className="p-4">
          <p className="text-xs text-muted-foreground uppercase tracking-wide">Active plan</p>
          {active ? (
            <>
              <p className="text-lg font-bold mt-1">{active.plan_name_snapshot}</p>
              <p className="text-xs text-muted-foreground">{active.vendor_name_snapshot} · {fmt(Number(active.price_snapshot), active.currency)}/{active.billing_interval}</p>
            </>
          ) : (
            <p className="text-sm text-muted-foreground mt-2">No active plan</p>
          )}
        </Card>
        <Card className="p-4">
          <p className="text-xs text-muted-foreground uppercase tracking-wide">Pending requests</p>
          <p className="text-2xl font-bold mt-1">{pending.length}</p>
        </Card>
        <Card className="p-4">
          <p className="text-xs text-muted-foreground uppercase tracking-wide">Total history</p>
          <p className="text-2xl font-bold mt-1">{subs.length}</p>
        </Card>
      </div>

      <Tabs defaultValue="plans">
        <TabsList>
          <TabsTrigger value="plans">Available plans</TabsTrigger>
          <TabsTrigger value="history">My requests ({subs.length})</TabsTrigger>
          {isAdmin && <TabsTrigger value="manage">Admin approvals {pending.length > 0 && <Badge className="ml-2" variant="default">{pending.length}</Badge>}</TabsTrigger>}
        </TabsList>

        <TabsContent value="plans" className="space-y-6 mt-4">
          <PlatformPlans workspaceId={currentWorkspaceId!} isAdmin={isAdmin} />
          {vendors.length === 0 ? (
            <Card className="p-8 text-center text-sm text-muted-foreground">No vendors yet. Ask an admin to add vendors in the Vendors page.</Card>
          ) : (
            vendors.map((v: any) => {
              const vp = plans.filter((p: any) => p.vendor_id === v.id);
              if (vp.length === 0) return null;
              return (
                <div key={v.id}>
                  <div className="flex items-center gap-2 mb-2">
                    <Package className="h-4 w-4 text-muted-foreground" />
                    <h3 className="font-semibold">{v.name}</h3>
                    {v.category && <Badge variant="outline">{v.category}</Badge>}
                  </div>
                  <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
                    {vp.map((p: any) => {
                      const mine = subs.find((s: any) => s.plan_id === p.id && (s.status === "pending" || s.status === "approved"));
                      return (
                        <Card key={p.id} className={`p-4 relative ${p.is_popular ? "border-primary shadow-md" : ""}`}>
                          {p.is_popular && <Badge className="absolute -top-2 left-4 gap-1"><Star className="h-3 w-3" />Popular</Badge>}
                          <p className="font-semibold">{p.name}</p>
                          {p.description && <p className="text-xs text-muted-foreground">{p.description}</p>}
                          <div className="mt-3 mb-3">
                            <span className="text-2xl font-bold">{fmt(Number(p.price), p.currency)}</span>
                            <span className="text-xs text-muted-foreground">/{p.billing_interval}</span>
                          </div>
                          <ul className="space-y-1.5 text-sm mb-4">
                            {(p.features || []).map((f: string, i: number) => (
                              <li key={i} className="flex items-start gap-2">
                                <Check className="h-4 w-4 text-primary shrink-0 mt-0.5" />
                                <span>{f}</span>
                              </li>
                            ))}
                          </ul>
                          {mine ? (
                            <div className="flex items-center justify-between gap-2">
                              <StatusBadge status={mine.status} />
                              {mine.status === "pending" && (
                                <Button size="sm" variant="outline" onClick={() => cancel(mine.id)}>Cancel</Button>
                              )}
                            </div>
                          ) : (
                            <Button className="w-full" onClick={() => requestPlan(p, v)}>Request plan</Button>
                          )}
                        </Card>
                      );
                    })}
                  </div>
                </div>
              );
            })
          )}
        </TabsContent>

        <TabsContent value="history" className="mt-4">
          {subs.length === 0 ? (
            <Card className="p-8 text-center text-sm text-muted-foreground">No subscription history yet.</Card>
          ) : (
            <div className="space-y-2">
              {subs.map((s: any) => (
                <Card key={s.id} className="p-4 flex items-center justify-between gap-4">
                  <div className="min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <p className="font-medium">{s.plan_name_snapshot}</p>
                      <StatusBadge status={s.status} />
                    </div>
                    <p className="text-xs text-muted-foreground">{s.vendor_name_snapshot} · {fmt(Number(s.price_snapshot), s.currency)}/{s.billing_interval} · Requested {new Date(s.created_at).toLocaleDateString()}</p>
                    {s.admin_notes && <p className="text-xs mt-1"><span className="text-muted-foreground">Admin: </span>{s.admin_notes}</p>}
                  </div>
                  {s.status === "pending" && (
                    <Button size="sm" variant="outline" onClick={() => cancel(s.id)}>Cancel</Button>
                  )}
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        {isAdmin && (
          <TabsContent value="manage" className="mt-4">
            <AdminApprovals subs={subs} onChanged={() => qc.invalidateQueries({ queryKey: ["subscriptions"] })} />
          </TabsContent>
        )}
      </Tabs>
    </div>
  );
}

function AdminApprovals({ subs, onChanged }: { subs: any[]; onChanged: () => void }) {
  const [open, setOpen] = useState<{ sub: any; action: "approved" | "rejected" } | null>(null);
  const [notes, setNotes] = useState("");

  const pending = subs.filter((s) => s.status === "pending");

  async function act() {
    if (!open) return;
    const { sub, action } = open;
    const { data: u } = await supabase.auth.getUser();
    const payload: any = {
      status: action,
      admin_notes: notes || null,
      approved_by: u.user?.id,
    };
    if (action === "approved") payload.approved_at = new Date().toISOString();
    if (action === "rejected") payload.rejected_at = new Date().toISOString();
    const { error } = await supabase.from("subscriptions").update(payload).eq("id", sub.id);
    if (error) return toast.error(error.message);
    toast.success(action === "approved" ? "Subscription approved" : "Subscription rejected");
    setOpen(null);
    setNotes("");
    onChanged();
  }

  return (
    <div className="space-y-3">
      <Card className="p-4 bg-primary/5 border-primary/30 flex items-start gap-3">
        <ShieldCheck className="h-5 w-5 text-primary mt-0.5" />
        <div>
          <p className="font-medium">Admin approval queue</p>
          <p className="text-xs text-muted-foreground">Approve or reject subscription requests from your workspace members.</p>
        </div>
      </Card>

      {pending.length === 0 ? (
        <Card className="p-8 text-center text-sm text-muted-foreground">No pending requests.</Card>
      ) : (
        <div className="space-y-2">
          {pending.map((s) => (
            <Card key={s.id} className="p-4 flex items-center justify-between gap-4">
              <div className="min-w-0">
                <p className="font-medium">{s.plan_name_snapshot} <span className="text-muted-foreground font-normal">— {s.vendor_name_snapshot}</span></p>
                <p className="text-xs text-muted-foreground flex items-center gap-2 mt-1">
                  <Clock className="h-3 w-3" />Requested {new Date(s.created_at).toLocaleString()} · {fmt(Number(s.price_snapshot), s.currency)}/{s.billing_interval}
                </p>
                {s.notes && <p className="text-xs mt-1"><span className="text-muted-foreground">Note: </span>{s.notes}</p>}
              </div>
              <div className="flex gap-2 shrink-0">
                <Button size="sm" variant="outline" onClick={() => { setOpen({ sub: s, action: "rejected" }); setNotes(""); }}>
                  <X className="h-3.5 w-3.5 mr-1" />Reject
                </Button>
                <Button size="sm" onClick={() => { setOpen({ sub: s, action: "approved" }); setNotes(""); }}>
                  <Check className="h-3.5 w-3.5 mr-1" />Approve
                </Button>
              </div>
            </Card>
          ))}
        </div>
      )}

      <Dialog open={!!open} onOpenChange={(o) => !o && setOpen(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{open?.action === "approved" ? "Approve subscription" : "Reject subscription"}</DialogTitle>
          </DialogHeader>
          {open && (
            <div className="space-y-3">
              <Card className="p-3 bg-muted/40">
                <p className="font-medium">{open.sub.plan_name_snapshot}</p>
                <p className="text-xs text-muted-foreground">{open.sub.vendor_name_snapshot} · {fmt(Number(open.sub.price_snapshot), open.sub.currency)}/{open.sub.billing_interval}</p>
              </Card>
              <div>
                <p className="text-sm font-medium mb-1">Admin note (optional)</p>
                <Textarea value={notes} onChange={(e) => setNotes(e.target.value)} rows={3} placeholder="Add a note visible to the requester…" />
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(null)}>Cancel</Button>
            <Button onClick={act} variant={open?.action === "rejected" ? "destructive" : "default"}>
              {open?.action === "approved" ? "Approve" : "Reject"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function CustomPlanRequestCard({ workspaceId }: { workspaceId: string }) {
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const [planName, setPlanName] = useState("Custom");
  const [features, setFeatures] = useState<Record<string, boolean>>(() => {
    const init: Record<string, boolean> = {};
    CUSTOM_FEATURE_KEYS.forEach((k) => { init[k] = true; });
    return init;
  });
  const [limits, setLimits] = useState<Record<string, number>>(() => {
    const init: Record<string, number> = {};
    CUSTOM_LIMIT_KEYS.forEach(({ key }) => { init[key] = 0; });
    return init;
  });
  const [notes, setNotes] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [pricing, setPricing] = useState<PricingValue>({ price_monthly: 0, price_yearly: 0, currency: "INR" });
  const [billingInterval, setBillingInterval] = useState<"monthly" | "yearly">("monthly");

  const { data: requests = [] } = useQuery({
    queryKey: ["plan-requests", workspaceId],
    enabled: !!workspaceId,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("plan_requests")
        .select("*")
        .eq("workspace_id", workspaceId)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data;
    },
  });

  const pendingReq = requests.find((r: any) => r.status === "pending");

  async function submit() {
    const { data: u } = await supabase.auth.getUser();
    if (!u.user) return toast.error("Not signed in");
    const { error } = await supabase.from("plan_requests").insert({
      workspace_id: workspaceId,
      requested_by: u.user.id,
      plan_name: planName.trim() || "Custom",
      features,
      limits,
      notes: notes.trim() || null,
      status: "pending",
      price_monthly: pricing.price_monthly,
      price_yearly: pricing.price_yearly,
      currency: pricing.currency,
      billing_interval: billingInterval,
    });
    setSubmitting(false);

    setSubmitting(false);
    if (error) return toast.error(error.message);
    toast.success("Custom plan requested. Super admin will review it.");
    setOpen(false);
    qc.invalidateQueries({ queryKey: ["plan-requests", workspaceId] });
  }

  return (
    <Card className="p-5 border-primary/30 bg-gradient-to-br from-primary/5 to-transparent">
      <div className="flex items-start gap-4 flex-wrap">
        <div className="grid h-11 w-11 place-items-center rounded-xl bg-primary/15 text-primary shrink-0">
          <Sparkles className="h-5 w-5" />
        </div>
        <div className="flex-1 min-w-0">
          <h3 className="font-semibold">Need a custom plan?</h3>
          <p className="text-sm text-muted-foreground">
            Pick the exact features and limits you need. A super admin will review and approve your request.
          </p>
          {requests.length > 0 && (
            <div className="mt-3 space-y-1.5">
              {requests.slice(0, 3).map((r: any) => (
                <div key={r.id} className="flex items-center gap-2 text-xs">
                  <StatusBadge status={r.status} />
                  <span className="text-muted-foreground">{r.plan_name} · {new Date(r.created_at).toLocaleDateString()}</span>
                  {r.admin_notes && <span className="text-muted-foreground italic">— {r.admin_notes}</span>}
                </div>
              ))}
            </div>
          )}
        </div>
        <Button onClick={() => setOpen(true)} disabled={!!pendingReq}>
          <Sparkles className="h-4 w-4 mr-1" />
          {pendingReq ? "Request pending" : "Request custom plan"}
        </Button>
      </div>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Request a custom plan</DialogTitle>
          </DialogHeader>

          <div className="space-y-5">
            <div className="space-y-2">
              <Label>Plan name</Label>
              <Input value={planName} onChange={(e) => setPlanName(e.target.value)} maxLength={80} />
            </div>

            <div className="space-y-2">
              <Label>Features you need</Label>
              <div className="grid grid-cols-2 gap-3 rounded-lg border p-4">
                {FEATURE_CATALOG.map(({ key: k, label }) => (
                  <div key={k} className="flex items-center justify-between">
                    <span className="text-sm">{label}</span>
                    <Switch
                      checked={features[k] ?? false}
                      onCheckedChange={(v) => setFeatures((f) => ({ ...f, [k]: v }))}
                    />
                  </div>
                ))}

              </div>
            </div>

            <div className="space-y-2">
              <Label>Requested limits</Label>
              <div className="grid grid-cols-2 gap-3 rounded-lg border p-4">
                {CUSTOM_LIMIT_KEYS.map(({ key, label }) => (
                  <div key={key} className="space-y-1">
                    <span className="text-xs text-muted-foreground">{label}</span>
                    <Input
                      type="number"
                      min={0}
                      value={limits[key] ?? 0}
                      onChange={(e) => setLimits((l) => ({ ...l, [key]: Number(e.target.value || 0) }))}
                    />
                  </div>
                ))}
              </div>
              <p className="text-xs text-muted-foreground">Set 0 for unlimited.</p>
            </div>

            <div className="space-y-2">
              <Label>Proposed pricing</Label>
              <PricingFields value={pricing} onChange={setPricing} />
              <div className="flex items-center gap-3 text-sm">
                <span className="text-muted-foreground">Preferred billing:</span>
                <select
                  value={billingInterval}
                  onChange={(e) => setBillingInterval(e.target.value as any)}
                  className="h-9 rounded-md border border-input bg-background px-2"
                >
                  <option value="monthly">Monthly</option>
                  <option value="yearly">Yearly</option>
                </select>
              </div>
            </div>


            <div className="space-y-2">
              <Label>Notes for super admin</Label>
              <Textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                rows={3}
                maxLength={1000}
                placeholder="Tell us about your use case, expected volume, integrations needed…"
              />
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button onClick={submit} disabled={submitting}>
              {submitting ? "Submitting…" : "Submit request"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  );
}

function PlatformPlans({ workspaceId, isAdmin }: { workspaceId: string; isAdmin: boolean }) {
  const qc = useQueryClient();
  const { data: pricingData } = useQuery({
    queryKey: ["plan-templates-public"],
    queryFn: async () => {
      const res = await fetch("/api/public/pricing");
      if (!res.ok) throw new Error("Failed to load plans");
      return res.json() as Promise<{
        plans: any[];
        masterFeatures: any[];
        planFeatures: any[];
      }>;
    },
  });

  const templates = pricingData?.plans ?? [];
  const masterFeatures = pricingData?.masterFeatures ?? [];
  const planFeatures = pricingData?.planFeatures ?? [];

  const { data: reqs = [] } = useQuery({
    queryKey: ["plan-requests", workspaceId],
    enabled: !!workspaceId,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("plan_requests")
        .select("id, plan_name, status, created_at")
        .eq("workspace_id", workspaceId)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data;
    },
  });

  const pendingByName = new Map(
    reqs.filter((r: any) => r.status === "pending").map((r: any) => [r.plan_name, r]),
  );

  const [showCompare, setShowCompare] = useState(false);
  const [billing, setBilling] = useState<"monthly" | "yearly">("monthly");

  async function request(t: any) {
    const { data: u } = await supabase.auth.getUser();
    if (!u.user) return toast.error("Not signed in");
    const { error } = await supabase.from("plan_requests").insert({
      workspace_id: workspaceId,
      requested_by: u.user.id,
      plan_name: t.name,
      features: t.features ?? {},
      limits: t.limits ?? {},
      notes: t.description ?? null,
      status: "pending",
      price_monthly: t.price_monthly ?? 0,
      price_yearly: t.price_yearly ?? 0,
      currency: t.currency ?? "INR",
      billing_interval: billing,
    });
    if (error) return toast.error(error.message);
    toast.success("Plan requested. Super admin will review it.");
    qc.invalidateQueries({ queryKey: ["plan-requests", workspaceId] });
  }

  if (templates.length === 0) return null;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div className="flex items-center gap-2">
          <Sparkles className="h-4 w-4 text-primary" />
          <h3 className="font-semibold">Plans from Slice</h3>
        </div>
        <div className="flex items-center gap-2">
          <div className="inline-flex rounded-full border bg-muted p-0.5 text-xs">
            <button
              onClick={() => setBilling("monthly")}
              className={`px-3 py-1 rounded-full ${billing === "monthly" ? "bg-background shadow-sm font-medium" : "text-muted-foreground"}`}
            >Monthly</button>
            <button
              onClick={() => setBilling("yearly")}
              className={`px-3 py-1 rounded-full ${billing === "yearly" ? "bg-background shadow-sm font-medium" : "text-muted-foreground"}`}
            >Yearly</button>
          </div>
          <Button variant="outline" size="sm" onClick={() => setShowCompare((v) => !v)}>
            {showCompare ? "Hide comparison" : "Compare features"}
          </Button>
        </div>
      </div>

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
        {templates.map((t: any) => {
          const pending = pendingByName.get(t.name);
          const planLinks = planFeatures.filter((l: any) => l.template_id === t.id && l.included);
          const popular = !!t.is_popular;
          const price = billing === "yearly" ? Number(t.price_yearly) : Number(t.price_monthly);
          return (
            <Card key={t.id} className={`p-4 flex flex-col relative ${popular ? "border-primary shadow-md ring-1 ring-primary/30" : ""}`}>
              {popular && (
                <Badge className="absolute -top-2 left-4 gap-1">
                  <Star className="h-3 w-3" />{t.badge_text || "Most popular"}
                </Badge>
              )}
              <p className="font-semibold">{t.name}</p>
              {t.description && (
                <p className="text-xs text-muted-foreground line-clamp-2 mt-0.5">{t.description}</p>
              )}
              <div className="mt-3 mb-3">
                <span className="text-2xl font-bold">{price > 0 ? fmt(price, t.currency) : "Free"}</span>
                {price > 0 && (
                  <span className="text-xs text-muted-foreground">/{billing === "yearly" ? "yr" : "mo"}</span>
                )}
              </div>
              <ul className="text-xs space-y-1 mb-3 flex-1">
                {planLinks.slice(0, 5).map((link: any) => {
                  const f = masterFeatures.find((m: any) => m.id === link.feature_id);
                  if (!f) return null;
                  return (
                    <li key={link.feature_id} className="flex items-start gap-1.5">
                      <Check className="h-3.5 w-3.5 text-emerald-500 shrink-0 mt-0.5" />
                      <span>{f.name}{link.custom_value ? <span className="text-muted-foreground"> · {link.custom_value}</span> : null}</span>
                    </li>
                  );
                })}
                {planLinks.length > 5 && (
                  <li className="text-muted-foreground">+{planLinks.length - 5} more</li>
                )}
              </ul>
              <div className="mt-auto">
                {pending ? (
                  <StatusBadge status="pending" />
                ) : isAdmin ? (
                  <Button className="w-full" size="sm" variant={popular ? "default" : "outline"} onClick={() => request(t)}>
                    Request this plan
                  </Button>
                ) : (
                  <p className="text-xs text-muted-foreground">Ask a workspace admin to request this plan.</p>
                )}
              </div>
            </Card>
          );
        })}
      </div>

      {showCompare && masterFeatures.length > 0 && (
        <div className="pt-4">
          <PricingComparisonTable
            plans={templates}
            masterFeatures={masterFeatures}
            planFeatures={planFeatures}
            interval={billing}
            cta={(p: PricingPlan) => {
              const pending = pendingByName.get(p.name);
              if (pending) return <StatusBadge status="pending" />;
              if (!isAdmin) return <p className="text-[10px] text-muted-foreground">Admin only</p>;
              const t = templates.find((x: any) => x.id === p.id);
              return (
                <Button size="sm" variant={p.is_popular ? "default" : "outline"} className="w-full" onClick={() => request(t)}>
                  Request
                </Button>
              );
            }}
          />
        </div>
      )}
    </div>
  );
}



