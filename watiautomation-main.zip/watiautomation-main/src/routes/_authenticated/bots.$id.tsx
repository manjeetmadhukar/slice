import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import ReactFlow, {
  Background, Controls, MiniMap, addEdge, useNodesState, useEdgesState,
  type Node, type Edge, type Connection, type NodeProps, Handle, Position, ReactFlowProvider,
} from "reactflow";
import "reactflow/dist/style.css";
import { getBot, saveBot } from "@/lib/bots.functions";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card } from "@/components/ui/card";
import {
  Bot, MessageSquare, HelpCircle, Sparkles, GitBranch, Clock,
  UserPlus, Tag, FileText, Image as ImageIcon, MousePointer,
  StopCircle, ArrowLeft, Save, Trash2, Plus, X,
} from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useWorkspace } from "@/lib/workspace-context";

export const Route = createFileRoute("/_authenticated/bots/$id")({
  component: () => <ReactFlowProvider><BotEditor /></ReactFlowProvider>,
  head: () => ({ meta: [{ title: "Bot editor — Slice" }] }),
});

type NodeType =
  | "trigger" | "send_message" | "send_buttons" | "send_media" | "send_template"
  | "ask" | "ai_reply" | "condition" | "delay" | "assign" | "tag" | "update_field" | "end";

const NODE_META: Record<NodeType, { label: string; icon: any; color: string }> = {
  trigger:       { label: "Trigger",        icon: Bot,                color: "bg-violet-500" },
  send_message:  { label: "Send message",   icon: MessageSquare,      color: "bg-emerald-500" },
  send_buttons:  { label: "Send buttons",   icon: MousePointer,       color: "bg-emerald-500" },
  send_media:    { label: "Send media",     icon: ImageIcon,          color: "bg-emerald-500" },
  send_template: { label: "Send template",  icon: FileText,           color: "bg-emerald-500" },
  ask:           { label: "Ask question",   icon: HelpCircle,         color: "bg-sky-500" },
  ai_reply:      { label: "AI reply",       icon: Sparkles,           color: "bg-fuchsia-500" },
  condition:     { label: "Condition",      icon: GitBranch,          color: "bg-amber-500" },
  delay:         { label: "Delay",          icon: Clock,              color: "bg-slate-500" },
  assign:        { label: "Assign agent",   icon: UserPlus,           color: "bg-blue-500" },
  tag:           { label: "Add tag",        icon: Tag,                color: "bg-pink-500" },
  update_field:  { label: "Update field",   icon: Pencil2,            color: "bg-pink-500" },
  end:           { label: "End",            icon: StopCircle,         color: "bg-rose-500" },
};

function Pencil2(props: any) { return <Tag {...props} />; }

// ---- Custom node component ----
function FlowNode({ data, type, selected }: NodeProps) {
  const meta = NODE_META[type as NodeType] ?? NODE_META.send_message;
  const Icon = meta.icon;
  const preview =
    type === "send_message" || type === "ask" ? (data.text || "Click to configure")
    : type === "ai_reply" ? (data.system_prompt || "AI reply")
    : type === "condition" ? `${data.field || "last_reply"} ${data.operator || "contains"} ${data.value || "..."}`
    : type === "delay" ? `Wait ${data.seconds || 0}s`
    : type === "send_template" ? (data.template_name || "Pick template")
    : type === "send_media" ? `${data.media_type || "image"}: ${data.url ? "set" : "no url"}`
    : type === "send_buttons" ? (data.text || "Buttons")
    : type === "tag" ? `Tag: ${data.tag || ""}`
    : type === "update_field" ? `${data.field || "field"} = ${data.value || ""}`
    : type === "assign" ? `Assign to ${data.user_name || "..."}`
    : type === "trigger" ? "Entry point"
    : type === "end" ? "End of flow" : "";

  return (
    <div className={`min-w-[200px] max-w-[260px] rounded-lg border-2 bg-card shadow-sm transition ${selected ? "border-primary" : "border-border"}`}>
      {type !== "trigger" && <Handle type="target" position={Position.Top} className="!bg-muted-foreground" />}
      <div className={`flex items-center gap-2 px-3 py-2 rounded-t-md text-white text-xs font-semibold ${meta.color}`}>
        <Icon className="h-3.5 w-3.5" /> {meta.label}
      </div>
      <div className="px-3 py-2 text-xs text-muted-foreground line-clamp-3">{preview}</div>
      {type === "condition" ? (
        <>
          <div className="flex items-center justify-between px-3 pb-2 text-[10px] text-muted-foreground">
            <span>true</span><span>false</span>
          </div>
          <Handle id="true" type="source" position={Position.Bottom} style={{ left: "25%" }} className="!bg-emerald-500" />
          <Handle id="false" type="source" position={Position.Bottom} style={{ left: "75%" }} className="!bg-rose-500" />
        </>
      ) : type === "end" ? null : (
        <Handle type="source" position={Position.Bottom} className="!bg-muted-foreground" />
      )}
    </div>
  );
}

const nodeTypes = Object.fromEntries(Object.keys(NODE_META).map((k) => [k, FlowNode]));

const PALETTE: NodeType[] = [
  "send_message", "send_buttons", "send_media", "send_template",
  "ask", "ai_reply", "condition", "delay",
  "assign", "tag", "update_field", "end",
];

function BotEditor() {
  const { id } = Route.useParams();
  const navigate = useNavigate();
  const { currentWorkspaceId } = useWorkspace();
  const getFn = useServerFn(getBot);
  const saveFn = useServerFn(saveBot);

  const { data, isLoading, refetch } = useQuery({
    queryKey: ["bot", id],
    queryFn: () => getFn({ data: { id } }),
  });

  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [enabled, setEnabled] = useState(false);
  const [triggers, setTriggers] = useState<any[]>([]);
  const [nodes, setNodes, onNodesChange] = useNodesState([]);
  const [edges, setEdges, onEdgesChange] = useEdgesState([]);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [showTriggers, setShowTriggers] = useState(false);
  const wrapperRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!data) return;
    setName(data.bot.name);
    setDescription(data.bot.description || "");
    setEnabled(data.bot.enabled);
    setTriggers((data.bot.triggers as any[]) || []);
    setNodes((data.nodes || []).map((n: any) => ({
      id: n.id, type: n.type, position: n.position, data: n.data || {},
    })));
    setEdges((data.edges || []).map((e: any) => ({
      id: e.id, source: e.source_node_id, target: e.target_node_id,
      sourceHandle: e.source_handle, animated: true,
    })));
  }, [data, setNodes, setEdges]);

  const onConnect = useCallback((c: Connection) => setEdges((eds) => addEdge({ ...c, animated: true }, eds)), [setEdges]);

  const onDragStart = (e: React.DragEvent, type: NodeType) => {
    e.dataTransfer.setData("application/reactflow", type);
    e.dataTransfer.effectAllowed = "move";
  };
  const onDragOver = useCallback((e: React.DragEvent) => { e.preventDefault(); e.dataTransfer.dropEffect = "move"; }, []);
  const onDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    const type = e.dataTransfer.getData("application/reactflow") as NodeType;
    if (!type || !wrapperRef.current) return;
    const bounds = wrapperRef.current.getBoundingClientRect();
    const position = { x: e.clientX - bounds.left - 100, y: e.clientY - bounds.top - 40 };
    setNodes((ns) => [...ns, { id: crypto.randomUUID(), type, position, data: {} } as Node]);
  }, [setNodes]);

  const selected = useMemo(() => nodes.find((n) => n.id === selectedId), [nodes, selectedId]);

  function updateSelected(patch: any) {
    if (!selectedId) return;
    setNodes((ns) => ns.map((n) => n.id === selectedId ? { ...n, data: { ...n.data, ...patch } } : n));
  }

  function deleteSelected() {
    if (!selectedId || selected?.type === "trigger") return;
    setNodes((ns) => ns.filter((n) => n.id !== selectedId));
    setEdges((es) => es.filter((e) => e.source !== selectedId && e.target !== selectedId));
    setSelectedId(null);
  }

  async function save() {
    if (!currentWorkspaceId) return;
    try {
      await saveFn({ data: {
        id, workspace_id: currentWorkspaceId, name, description: description || null,
        enabled, priority: 0, triggers,
        nodes: nodes.map((n) => ({ id: n.id, type: n.type!, position: n.position, data: n.data || {} })),
        edges: edges.map((e) => ({ id: e.id, source: e.source, target: e.target, sourceHandle: e.sourceHandle ?? null })),
      } });
      toast.success("Bot saved");
      refetch();
    } catch (e: any) { toast.error(e.message); }
  }

  if (isLoading) return <div className="p-6">Loading…</div>;

  return (
    <div className="-mx-6 -my-8 h-[calc(100vh-3.5rem)] md:h-screen flex flex-col">
      {/* Top bar */}
      <div className="border-b bg-card px-4 py-2 flex items-center gap-3">
        <Button variant="ghost" size="sm" onClick={() => navigate({ to: "/bots" })}>
          <ArrowLeft className="h-4 w-4 mr-1" /> Back
        </Button>
        <Input value={name} onChange={(e) => setName(e.target.value)} className="max-w-xs h-8" />
        <div className="flex items-center gap-2 text-sm">
          <Switch checked={enabled} onCheckedChange={setEnabled} />
          <span className="text-muted-foreground">{enabled ? "Active" : "Disabled"}</span>
        </div>
        <Button variant="outline" size="sm" onClick={() => setShowTriggers(true)}>
          Triggers ({triggers.length})
        </Button>
        <div className="ml-auto" />
        <Button size="sm" onClick={save}><Save className="h-4 w-4 mr-1.5" /> Save</Button>
      </div>

      <div className="flex-1 flex min-h-0">
        {/* Left palette */}
        <aside className="w-52 border-r bg-card overflow-y-auto p-2 shrink-0">
          <p className="px-2 py-1 text-[11px] uppercase tracking-wide text-muted-foreground">Drag to canvas</p>
          <div className="space-y-1">
            {PALETTE.map((t) => {
              const meta = NODE_META[t]; const Icon = meta.icon;
              return (
                <div key={t} draggable onDragStart={(e) => onDragStart(e, t)}
                  className="flex items-center gap-2 rounded-md border bg-background px-2 py-1.5 text-xs cursor-grab hover:bg-accent active:cursor-grabbing">
                  <span className={`grid h-6 w-6 place-items-center rounded ${meta.color} text-white`}><Icon className="h-3.5 w-3.5" /></span>
                  {meta.label}
                </div>
              );
            })}
          </div>
        </aside>

        {/* Canvas */}
        <div className="flex-1 relative" ref={wrapperRef} onDrop={onDrop} onDragOver={onDragOver}>
          <ReactFlow
            nodes={nodes} edges={edges}
            nodeTypes={nodeTypes as any}
            onNodesChange={onNodesChange} onEdgesChange={onEdgesChange}
            onConnect={onConnect}
            onNodeClick={(_, n) => setSelectedId(n.id)}
            onPaneClick={() => setSelectedId(null)}
            fitView
            deleteKeyCode={["Backspace", "Delete"]}
          >
            <Background gap={16} />
            <MiniMap pannable zoomable />
            <Controls />
          </ReactFlow>
        </div>

        {/* Right inspector */}
        <aside className="w-80 border-l bg-card overflow-y-auto shrink-0">
          {selected ? (
            <Inspector
              node={selected}
              onUpdate={updateSelected}
              onDelete={deleteSelected}
              workspaceId={currentWorkspaceId!}
            />
          ) : (
            <div className="p-6 text-sm text-muted-foreground">
              <p className="font-medium text-foreground mb-1">No node selected</p>
              <p>Click a node on the canvas to edit it, or drag a new block from the left panel.</p>
              <div className="mt-4 space-y-2">
                <Label className="text-xs">Description</Label>
                <Textarea rows={3} value={description} onChange={(e) => setDescription(e.target.value)} placeholder="What does this bot do?" />
              </div>
            </div>
          )}
        </aside>
      </div>

      {showTriggers && (
        <TriggerDialog triggers={triggers} setTriggers={setTriggers} onClose={() => setShowTriggers(false)} />
      )}
    </div>
  );
}

function Inspector({ node, onUpdate, onDelete, workspaceId }: { node: Node; onUpdate: (p: any) => void; onDelete: () => void; workspaceId: string }) {
  const meta = NODE_META[node.type as NodeType] ?? NODE_META.send_message;
  const Icon = meta.icon;
  const d = node.data || {};

  const { data: templates = [] } = useQuery({
    queryKey: ["templates-min-bots", workspaceId],
    queryFn: async () => {
      const { data } = await supabase.from("templates").select("id, meta_template_name, language, status")
        .eq("workspace_id", workspaceId);
      return (data || []).filter((t: any) => t.status === "APPROVED");
    },
    enabled: !!workspaceId && (node.type === "send_template"),
  });

  const { data: members = [] } = useQuery({
    queryKey: ["members-bots", workspaceId],
    queryFn: async () => {
      const { data: m } = await supabase.from("workspace_members").select("user_id, role").eq("workspace_id", workspaceId);
      const ids = (m || []).map((x: any) => x.user_id);
      if (!ids.length) return [];
      const { data: p } = await supabase.from("profiles").select("id, full_name, email").in("id", ids);
      return (m || []).map((mm: any) => ({ ...mm, profile: (p || []).find((pp: any) => pp.id === mm.user_id) }));
    },
    enabled: !!workspaceId && node.type === "assign",
  });

  return (
    <div className="p-4 space-y-4">
      <div className="flex items-center gap-2">
        <span className={`grid h-7 w-7 place-items-center rounded ${meta.color} text-white`}><Icon className="h-4 w-4" /></span>
        <h3 className="font-semibold">{meta.label}</h3>
        {node.type !== "trigger" && (
          <Button size="icon" variant="ghost" className="ml-auto" onClick={onDelete}><Trash2 className="h-4 w-4 text-destructive" /></Button>
        )}
      </div>

      {node.type === "trigger" && (
        <p className="text-xs text-muted-foreground">This is the bot entry point. Configure triggers from the top bar.</p>
      )}

      {(node.type === "send_message" || node.type === "ask") && (
        <div>
          <Label>{node.type === "ask" ? "Question text" : "Message"}</Label>
          <Textarea rows={5} value={d.text || ""} onChange={(e) => onUpdate({ text: e.target.value })}
            placeholder="Hi {{contact.name}}, how can I help?" />
          <p className="text-[11px] text-muted-foreground mt-1">Use {`{{contact.name}}`} or {`{{var.your_var}}`}</p>
        </div>
      )}

      {node.type === "ask" && (
        <>
          <div>
            <Label>Save answer to variable</Label>
            <Input value={d.variable || ""} onChange={(e) => onUpdate({ variable: e.target.value.replace(/\s+/g, "_") })} placeholder="email" />
          </div>
          <div>
            <Label>Also save to contact field</Label>
            <Select value={d.save_to_contact || "none"} onValueChange={(v) => onUpdate({ save_to_contact: v === "none" ? null : v })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="none">— None —</SelectItem>
                <SelectItem value="name">Name</SelectItem>
                <SelectItem value="email">Email</SelectItem>
                <SelectItem value="city">City</SelectItem>
                <SelectItem value="lead_source">Lead source</SelectItem>
                <SelectItem value="custom">Custom field (same as variable name)</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </>
      )}

      {node.type === "send_buttons" && (
        <>
          <div>
            <Label>Body</Label>
            <Textarea rows={3} value={d.text || ""} onChange={(e) => onUpdate({ text: e.target.value })} />
          </div>
          <div>
            <Label>Buttons (max 3)</Label>
            {[0, 1, 2].map((i) => (
              <Input key={i} className="mt-1" value={(d.buttons?.[i]) || ""} maxLength={20}
                onChange={(e) => {
                  const b = [...(d.buttons || ["", "", ""])]; b[i] = e.target.value;
                  onUpdate({ buttons: b });
                }} placeholder={`Button ${i + 1}`} />
            ))}
          </div>
        </>
      )}

      {node.type === "send_media" && (
        <>
          <div>
            <Label>Media type</Label>
            <Select value={d.media_type || "image"} onValueChange={(v) => onUpdate({ media_type: v })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="image">Image</SelectItem>
                <SelectItem value="video">Video</SelectItem>
                <SelectItem value="audio">Audio</SelectItem>
                <SelectItem value="document">Document</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label>URL</Label>
            <Input value={d.url || ""} onChange={(e) => onUpdate({ url: e.target.value })} placeholder="https://…" />
          </div>
          <div>
            <Label>Caption (optional)</Label>
            <Input value={d.caption || ""} onChange={(e) => onUpdate({ caption: e.target.value })} />
          </div>
        </>
      )}

      {node.type === "send_template" && (
        <div>
          <Label>Template</Label>
          <Select value={d.template_id || ""} onValueChange={(v) => {
            const t = templates.find((x: any) => x.id === v);
            onUpdate({ template_id: v, template_name: t?.meta_template_name });
          }}>
            <SelectTrigger><SelectValue placeholder="Pick template" /></SelectTrigger>
            <SelectContent>
              {templates.map((t: any) => (
                <SelectItem key={t.id} value={t.id}>{t.meta_template_name} ({t.language})</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      )}

      {node.type === "ai_reply" && (
        <>
          <div>
            <Label>System prompt</Label>
            <Textarea rows={5} value={d.system_prompt || ""} onChange={(e) => onUpdate({ system_prompt: e.target.value })}
              placeholder="You are a friendly customer-support agent for…" />
          </div>
          <div>
            <Label>Knowledge (optional)</Label>
            <Textarea rows={6} value={d.knowledge || ""} onChange={(e) => onUpdate({ knowledge: e.target.value })}
              placeholder="Pricing, FAQs, policies the AI should know…" />
          </div>
        </>
      )}

      {node.type === "condition" && (
        <>
          <div>
            <Label>Field</Label>
            <Input value={d.field || "last_reply"} onChange={(e) => onUpdate({ field: e.target.value })}
              placeholder="last_reply / contact.name / var.your_var" />
          </div>
          <div>
            <Label>Operator</Label>
            <Select value={d.operator || "contains"} onValueChange={(v) => onUpdate({ operator: v })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="contains">Contains</SelectItem>
                <SelectItem value="equals">Equals</SelectItem>
                <SelectItem value="starts_with">Starts with</SelectItem>
                <SelectItem value="not_empty">Not empty</SelectItem>
              </SelectContent>
            </Select>
          </div>
          {d.operator !== "not_empty" && (
            <div>
              <Label>Value</Label>
              <Input value={d.value || ""} onChange={(e) => onUpdate({ value: e.target.value })} />
            </div>
          )}
          <p className="text-[11px] text-muted-foreground">Connect the green handle as TRUE and red as FALSE.</p>
        </>
      )}

      {node.type === "delay" && (
        <div>
          <Label>Wait seconds</Label>
          <Input type="number" min={0} value={d.seconds || 0} onChange={(e) => onUpdate({ seconds: Number(e.target.value) })} />
          <p className="text-[11px] text-muted-foreground mt-1">Flow pauses; resumes on next inbound message.</p>
        </div>
      )}

      {node.type === "assign" && (
        <div>
          <Label>Assign to</Label>
          <Select value={d.user_id || ""} onValueChange={(v) => {
            const m: any = members.find((mm: any) => mm.user_id === v);
            onUpdate({ user_id: v, user_name: m?.profile?.full_name || m?.profile?.email });
          }}>
            <SelectTrigger><SelectValue placeholder="Pick teammate" /></SelectTrigger>
            <SelectContent>
              {members.map((m: any) => (
                <SelectItem key={m.user_id} value={m.user_id}>
                  {m.profile?.full_name || m.profile?.email || m.user_id.slice(0, 8)} ({m.role})
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      )}

      {node.type === "tag" && (
        <div>
          <Label>Tag to add</Label>
          <Input value={d.tag || ""} onChange={(e) => onUpdate({ tag: e.target.value })} placeholder="vip" />
        </div>
      )}

      {node.type === "update_field" && (
        <>
          <div>
            <Label>Field</Label>
            <Input value={d.field || ""} onChange={(e) => onUpdate({ field: e.target.value })}
              placeholder="lead_stage / city / your_custom" />
          </div>
          <div>
            <Label>Value</Label>
            <Input value={d.value || ""} onChange={(e) => onUpdate({ value: e.target.value })}
              placeholder="qualified or {{var.x}}" />
          </div>
        </>
      )}
    </div>
  );
}

function TriggerDialog({ triggers, setTriggers, onClose }: { triggers: any[]; setTriggers: (t: any[]) => void; onClose: () => void }) {
  const [local, setLocal] = useState<any[]>(triggers);
  function add() { setLocal([...local, { type: "keyword", keywords: [], match_type: "contains" }]); }
  function remove(i: number) { setLocal(local.filter((_, idx) => idx !== i)); }
  function update(i: number, patch: any) { setLocal(local.map((t, idx) => idx === i ? { ...t, ...patch } : t)); }
  function save() { setTriggers(local); onClose(); }
  return (
    <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4" onClick={onClose}>
      <Card className="w-full max-w-lg max-h-[80vh] overflow-y-auto p-5 space-y-4" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between">
          <h3 className="font-semibold text-lg">Triggers</h3>
          <Button size="icon" variant="ghost" onClick={onClose}><X className="h-4 w-4" /></Button>
        </div>
        <p className="text-sm text-muted-foreground">When the bot should start running.</p>
        <div className="space-y-3">
          {local.map((t, i) => (
            <div key={i} className="rounded-lg border p-3 space-y-2">
              <div className="flex items-center justify-between">
                <Select value={t.type} onValueChange={(v) => update(i, { type: v })}>
                  <SelectTrigger className="w-48"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="keyword">Keyword match</SelectItem>
                    <SelectItem value="first_message">First message from contact</SelectItem>
                    <SelectItem value="manual">Manual start from inbox</SelectItem>
                  </SelectContent>
                </Select>
                <Button size="icon" variant="ghost" onClick={() => remove(i)}><Trash2 className="h-4 w-4 text-destructive" /></Button>
              </div>
              {t.type === "keyword" && (
                <>
                  <Input placeholder="Comma-separated keywords"
                    value={(t.keywords || []).join(", ")}
                    onChange={(e) => update(i, { keywords: e.target.value.split(",").map((s) => s.trim()).filter(Boolean) })} />
                  <Select value={t.match_type || "contains"} onValueChange={(v) => update(i, { match_type: v })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="contains">Contains</SelectItem>
                      <SelectItem value="exact">Exact match</SelectItem>
                      <SelectItem value="starts_with">Starts with</SelectItem>
                    </SelectContent>
                  </Select>
                </>
              )}
            </div>
          ))}
          <Button variant="outline" size="sm" onClick={add}><Plus className="h-4 w-4 mr-1.5" /> Add trigger</Button>
        </div>
        <div className="flex justify-end gap-2">
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button onClick={save}>Apply</Button>
        </div>
      </Card>
    </div>
  );
}
