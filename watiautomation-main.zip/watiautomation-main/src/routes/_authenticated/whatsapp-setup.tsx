import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { useWorkspace } from "@/lib/workspace-context";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { toast } from "sonner";
import { Facebook, LogIn, Loader2, ShieldCheck, CheckCircle2, Sparkles, AlertCircle, Zap, Webhook, FileText } from "lucide-react";
import { finishEmbeddedSignup, getEmbeddedSignupConfig } from "@/lib/whatsapp-accounts.functions";

declare global {
  interface Window {
    FB?: any;
    fbAsyncInit?: () => void;
  }
}

export const Route = createFileRoute("/_authenticated/whatsapp-setup")({
  component: WhatsAppSetupPage,
  head: () => ({ meta: [{ title: "WhatsApp Cloud API Setup" }] }),
});

function WhatsAppSetupPage() {
  const { current } = useWorkspace();
  const wsId = current?.workspace_id || "";
  const finishFn = useServerFn(finishEmbeddedSignup);
  const getCfgFn = useServerFn(getEmbeddedSignupConfig);

  const [fbOpen, setFbOpen] = useState(false);
  const [done, setDone] = useState(false);
  const [connectedNumber, setConnectedNumber] = useState<string>("");

  const [fbStatus, setFbStatus] = useState<"idle" | "loading" | "waiting" | "connecting" | "error">("idle");
  const [fbError, setFbError] = useState<string>("");
  const sessionRef = useRef<{ waba_id?: string; phone_number_id?: string; business_id?: string }>({});

  function loadFbSdk(appId: string): Promise<void> {
    return new Promise((resolve) => {
      if (window.FB) {
        try { window.FB.init({ appId, autoLogAppEvents: true, xfbml: true, version: "v21.0" }); } catch {}
        resolve();
        return;
      }
      window.fbAsyncInit = function () {
        window.FB.init({ appId, autoLogAppEvents: true, xfbml: true, version: "v21.0" });
        resolve();
      };
      const id = "facebook-jssdk";
      if (document.getElementById(id)) return;
      const js = document.createElement("script");
      js.id = id;
      js.async = true;
      js.defer = true;
      js.crossOrigin = "anonymous";
      js.src = "https://connect.facebook.net/en_US/sdk.js";
      document.body.appendChild(js);
    });
  }

  useEffect(() => {
    function onMessage(ev: MessageEvent) {
      try {
        const data = typeof ev.data === "string" ? JSON.parse(ev.data) : ev.data;
        if (data?.type === "WA_EMBEDDED_SIGNUP") {
          // Capture any IDs Meta sends across any event (FINISH, FINISH_ONLY_WABA, etc.)
          const d = data.data || {};
          sessionRef.current = {
            waba_id: d.waba_id || sessionRef.current.waba_id,
            phone_number_id: d.phone_number_id || sessionRef.current.phone_number_id,
            business_id: d.business_id || sessionRef.current.business_id,
          };
          console.log("[ES] message", data.event, d);
        }
      } catch {}
    }
    window.addEventListener("message", onMessage);
    return () => window.removeEventListener("message", onMessage);
  }, []);

  async function startEmbeddedSignup() {
    if (!wsId) return toast.error("Select a workspace first");
    setFbError("");
    setFbStatus("loading");
    setFbOpen(true);
    sessionRef.current = {};
    try {
      const cfg: any = await getCfgFn();
      if (!cfg?.app_id || !cfg?.config_id) {
        throw new Error("WhatsApp integration is not configured yet. Please contact support.");
      }
      await loadFbSdk(cfg.app_id);
      setFbStatus("waiting");
      window.FB.login(
        (response: any) => {
          void (async () => {
            const code = response?.authResponse?.code;
            if (!code) {
              setFbStatus("error");
              setFbError("Sign-in was cancelled. Please try again.");
              return;
            }
            const s = sessionRef.current;
            setFbStatus("connecting");
            try {
              const r: any = await finishFn({
                data: {
                  workspace_id: wsId,
                  code,
                  waba_id: s.waba_id || null,
                  phone_number_id: s.phone_number_id || null,
                  business_id: s.business_id || null,
                  set_active: true,
                },
              });
              if (r.ok) {
                if (r.warning) {
                  toast.warning("Connected, but setup needs attention", { description: r.warning });
                } else {
                  toast.success("WhatsApp number connected!");
                }
                setConnectedNumber(r.account?.phone_number || r.account?.display_name || "");
                setDone(true);
                setFbOpen(false);
                setFbStatus("idle");
              } else {
                setFbStatus("error");
                setFbError(r.error || "Failed to finalize connection.");
              }
            } catch (e: any) {
              setFbStatus("error");
              setFbError(e.message || "Server error while finalizing connection.");
            }
          })();
        },
        {
          config_id: cfg.config_id,
          response_type: "code",
          override_default_response_type: true,
          extras: {
            setup: {},
            featureType: "whatsapp_business_app_onboarding",
            sessionInfoVersion: "3",
          },
        },
      );
    } catch (e: any) {
      setFbStatus("error");
      setFbError(e.message || "Could not start setup.");
    }
  }

  return (
    <div className="space-y-6 max-w-3xl mx-auto">
      <div className="text-center space-y-2">
        <h1 className="font-display text-3xl font-bold tracking-tight">Connect WhatsApp Business</h1>
        <p className="text-muted-foreground">
          One click. No tokens, no copy-paste, no Meta dashboards.
        </p>
      </div>

      {done && (
        <Card className="border-emerald-500/30 bg-emerald-500/5">
          <CardContent className="p-4 flex items-center gap-3">
            <CheckCircle2 className="h-5 w-5 text-emerald-600" />
            <div className="flex-1">
              <p className="font-medium">Setup complete{connectedNumber ? ` — ${connectedNumber}` : ""}</p>
              <p className="text-sm text-muted-foreground">Your number is active. Inbox, CRM, Campaigns and Automations are ready.</p>
            </div>
            <Button asChild variant="outline" size="sm">
              <Link to="/whatsapp-accounts">Manage numbers</Link>
            </Button>
          </CardContent>
        </Card>
      )}

      <Card className="overflow-hidden border-2">
        <CardContent className="py-12 flex flex-col items-center justify-center text-center gap-6">
          <div className="grid h-16 w-16 place-items-center rounded-2xl bg-[#1877F2]/10 text-[#1877F2]">
            <Facebook className="h-8 w-8" />
          </div>
          <div className="space-y-1">
            <h2 className="font-display text-xl font-semibold">Connect WhatsApp with Facebook</h2>
            <p className="text-sm text-muted-foreground max-w-md">
              Sign in with Meta, pick your business and phone number. We take care of the rest automatically.
            </p>
          </div>
          <Button
            size="lg"
            onClick={startEmbeddedSignup}
            className="bg-[#1877F2] hover:bg-[#166fe0] text-white h-12 px-8 text-base gap-3 shadow-md"
          >
            <Facebook className="h-5 w-5" />
            Connect WhatsApp with Facebook
            <LogIn className="h-4 w-4" />
          </Button>
          <p className="text-xs text-muted-foreground flex items-center gap-1.5">
            <ShieldCheck className="h-3.5 w-3.5" />
            Uses Meta's official OAuth. We never see your Facebook password.
          </p>
        </CardContent>
      </Card>

      <div className="grid gap-3 sm:grid-cols-3">
        <FeatureBullet icon={Zap} title="No tokens to copy">
          Phone Number ID, WABA ID and access token are captured automatically.
        </FeatureBullet>
        <FeatureBullet icon={Webhook} title="Webhook auto-wired">
          We subscribe Meta's webhook to your account so messages flow instantly.
        </FeatureBullet>
        <FeatureBullet icon={FileText} title="Templates synced">
          Your approved message templates are pulled in automatically.
        </FeatureBullet>
      </div>

      <div className="text-center text-sm text-muted-foreground">
        Already connected? <Link to="/whatsapp-accounts" className="text-primary underline">Manage your numbers</Link>.
      </div>

      <Dialog open={fbOpen} onOpenChange={(v) => { if (fbStatus === "connecting" || fbStatus === "loading") return; setFbOpen(v); if (!v) { setFbStatus("idle"); setFbError(""); } }}>
        <DialogContent className="sm:max-w-[460px]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Facebook className="h-5 w-5 text-[#1877F2]" />
              Connect with Facebook
            </DialogTitle>
            <DialogDescription>
              Complete the Meta popup to finish setup.
            </DialogDescription>
          </DialogHeader>

          <div className="py-4 flex flex-col items-center justify-center text-center gap-3 min-h-[140px]">
            {fbStatus === "loading" && (
              <>
                <Loader2 className="h-6 w-6 animate-spin text-[#1877F2]" />
                <p className="text-sm text-muted-foreground">Loading Meta sign-in…</p>
              </>
            )}
            {fbStatus === "waiting" && (
              <>
                <Facebook className="h-6 w-6 text-[#1877F2]" />
                <p className="text-sm font-medium">Complete the Meta popup window</p>
                <p className="text-xs text-muted-foreground max-w-xs">
                  Select your Business Portfolio, WhatsApp Business Account and phone number. The popup will close automatically.
                </p>
              </>
            )}
            {fbStatus === "connecting" && (
              <>
                <Loader2 className="h-6 w-6 animate-spin text-emerald-600" />
                <p className="text-sm font-medium">Finalizing connection with Meta…</p>
                <p className="text-xs text-muted-foreground">Subscribing webhook, registering your number and syncing templates.</p>
              </>
            )}
            {fbStatus === "error" && (
              <>
                <AlertCircle className="h-6 w-6 text-destructive" />
                <p className="text-sm font-medium">Couldn't connect</p>
                <p className="text-xs text-muted-foreground max-w-xs">{fbError}</p>
                <Button size="sm" onClick={startEmbeddedSignup} className="mt-1 gap-1">
                  <Sparkles className="h-3.5 w-3.5" /> Try again
                </Button>
              </>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function FeatureBullet({ icon: Icon, title, children }: { icon: any; title: string; children: React.ReactNode }) {
  return (
    <Card>
      <CardContent className="p-4 space-y-2">
        <div className="grid h-9 w-9 place-items-center rounded-lg bg-primary/10 text-primary">
          <Icon className="h-4 w-4" />
        </div>
        <div className="font-medium text-sm">{title}</div>
        <p className="text-xs text-muted-foreground">{children}</p>
      </CardContent>
    </Card>
  );
}
