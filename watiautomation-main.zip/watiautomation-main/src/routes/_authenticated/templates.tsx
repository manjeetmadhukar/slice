import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useEffect, useMemo, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { syncTemplates, createTemplate, editTemplate, setTemplateMapping, autoMapAllTemplates } from "@/lib/whatsapp.functions";
import { useWorkspace } from "@/lib/workspace-context";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogTrigger,
} from "@/components/ui/dialog";
import { toast } from "sonner";
import { RefreshCw, Loader2, FileText, Plus, Eye, Pencil, Image as ImageIcon, Video, FileIcon, MapPin, Reply, Phone, Copy, Link as LinkIcon, Trash2, Braces } from "lucide-react";
import { TEMPLATE_FIELDS, fieldByKey, guessTemplateMapping, type TemplateFieldKey, type VariableMappingEntry } from "@/lib/wa-template-fields";
import { AbandonedCartTemplateGuide } from "@/components/AbandonedCartTemplateGuide";
import { TemplateUrlPreview } from "@/components/TemplateUrlPreview";


type ButtonDraft =
  | { type: "QUICK_REPLY"; text: string }
  | { type: "PHONE_NUMBER"; text: string; phone_number: string }
  | { type: "URL"; text: string; url: string; dynamic?: boolean; example?: string }
  | { type: "COPY_CODE"; example: string };

export const Route = createFileRoute("/_authenticated/templates")({
  component: Templates,
  head: () => ({ meta: [{ title: "Templates — Slice" }] }),
});

function Templates() {
  const qc = useQueryClient();
  const { currentWorkspaceId } = useWorkspace();
  const syncFn = useServerFn(syncTemplates);
  const autoMapFn = useServerFn(autoMapAllTemplates);
  const [syncing, setSyncing] = useState(false);
  const [autoMapping, setAutoMapping] = useState(false);
  const [createOpen, setCreateOpen] = useState(false);
  const [editingTemplate, setEditingTemplate] = useState<any | null>(null);
  const [mappingTemplate, setMappingTemplate] = useState<any | null>(null);
  const [previewTemplate, setPreviewTemplate] = useState<any | null>(null);

  const { data: templates = [] } = useQuery({
    queryKey: ["templates", currentWorkspaceId],
    enabled: !!currentWorkspaceId,
    queryFn: async () => {
      const { data, error } = await supabase.from("templates").select("*")
        .eq("workspace_id", currentWorkspaceId!)
        .order("meta_template_name");
      if (error) throw error;
      return data;
    },
  });

  async function sync() {
    if (!currentWorkspaceId) return;
    setSyncing(true);
    try {
      const { count } = await syncFn({ data: { workspace_id: currentWorkspaceId } });
      toast.success(`Synced ${count} templates`);
      qc.invalidateQueries({ queryKey: ["templates"] });
    } catch (e: any) {
      toast.error(e.message);
    } finally {
      setSyncing(false);
    }
  }

  async function autoMapAll() {
    if (!currentWorkspaceId) return;
    setAutoMapping(true);
    try {
      const res = await autoMapFn({ data: { workspace_id: currentWorkspaceId } });
      if (!(res as any).ok) {
        toast.error((res as any).error || "Auto-map failed");
        return;
      }
      const n = (res as any).updated || 0;
      toast.success(n ? `Auto-mapped ${n} template${n > 1 ? "s" : ""}` : "All templates already mapped");
      qc.invalidateQueries({ queryKey: ["templates"] });
    } catch (e: any) {
      toast.error(e.message);
    } finally {
      setAutoMapping(false);
    }
  }


  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-3xl font-bold">Templates</h1>
          <p className="text-muted-foreground">Create templates and submit them to Meta for approval</p>
        </div>
        <div className="flex gap-2">
          <Dialog open={createOpen} onOpenChange={setCreateOpen}>
            <DialogTrigger asChild>
              <Button variant="default"><Plus className="mr-2 h-4 w-4" />Create Template</Button>
            </DialogTrigger>
            <CreateTemplateDialog
              workspaceId={currentWorkspaceId}
              onCreated={() => {
                setCreateOpen(false);
                qc.invalidateQueries({ queryKey: ["templates"] });
              }}
            />
          </Dialog>
          <AbandonedCartTemplateGuide />
          <Button variant="outline" onClick={autoMapAll} disabled={autoMapping}>
            {autoMapping ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Braces className="mr-2 h-4 w-4" />}
            Auto-map all
          </Button>
          <Button variant="outline" onClick={sync} disabled={syncing}>
            {syncing ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <RefreshCw className="mr-2 h-4 w-4" />}
            Sync from Meta
          </Button>
        </div>
      </div>

      {templates.length === 0 ? (
        <Card className="p-12 text-center">
          <FileText className="h-10 w-10 mx-auto text-muted-foreground/50" />
          <p className="mt-3 font-medium">No templates yet</p>
          <p className="text-sm text-muted-foreground mt-1">
            Create a template above, or click "Sync from Meta" to import existing ones.
          </p>
        </Card>
      ) : (
        <div className="grid gap-4 md:grid-cols-2">
          {templates.map((t: any) => (
            <Card key={t.id} className="p-5">
              <div className="flex items-start justify-between">
                <div className="min-w-0">
                  <p className="font-display font-semibold truncate">{t.meta_template_name}</p>
                  <p className="text-xs text-muted-foreground mt-0.5">
                    {t.language} · {t.category}
                  </p>
                </div>
                <StatusBadge status={t.status} />
              </div>
              {t.body && (
                <p className="mt-3 text-sm text-foreground/80 whitespace-pre-wrap line-clamp-4 p-3 rounded-lg bg-secondary/50 border">
                  {t.body}
                </p>
              )}
              {t.variables_count > 0 && (
                <p className="mt-2 text-xs text-muted-foreground">{t.variables_count} variable{t.variables_count > 1 ? "s" : ""}</p>
              )}
              {t.variables_count > 0 && !(Array.isArray(t.variable_mapping) && t.variable_mapping.length >= t.variables_count) && (
                <div className="mt-2 rounded-md border border-amber-500/40 bg-amber-500/10 px-3 py-2 text-xs text-amber-700 dark:text-amber-300">
                  ⚠ Fields not mapped — {`{{N}}`} placeholders will be guessed at send time. Click <strong>Map fields</strong> to lock the correct data source.
                </div>
              )}
              <div className="mt-3 flex flex-wrap justify-end gap-2">
                {t.variables_count > 0 && (
                  <Button variant="outline" size="sm" onClick={() => setMappingTemplate(t)}>
                    <Braces className="mr-2 h-4 w-4" />Map fields
                  </Button>
                )}
                {t.status !== "APPROVED" && (
                  <Button variant="outline" size="sm" onClick={() => setEditingTemplate(t)}>
                    <Pencil className="mr-2 h-4 w-4" />Edit
                  </Button>
                )}
                <Button variant="outline" size="sm" onClick={() => setPreviewTemplate(t)}>
                  <Eye className="mr-2 h-4 w-4" />Preview
                </Button>
              </div>
            </Card>
          ))}
        </div>
      )}

      <Dialog open={!!editingTemplate} onOpenChange={(o) => !o && setEditingTemplate(null)}>
        {editingTemplate && (
          <CreateTemplateDialog
            workspaceId={currentWorkspaceId}
            editing={editingTemplate}
            onCreated={() => {
              setEditingTemplate(null);
              qc.invalidateQueries({ queryKey: ["templates"] });
            }}
          />
        )}
      </Dialog>

      <Dialog open={!!mappingTemplate} onOpenChange={(o) => !o && setMappingTemplate(null)}>
        {mappingTemplate && (
          <MapFieldsDialog
            workspaceId={currentWorkspaceId}
            template={mappingTemplate}
            onSaved={() => {
              setMappingTemplate(null);
              qc.invalidateQueries({ queryKey: ["templates"] });
            }}
          />
        )}
      </Dialog>

      <Dialog open={!!previewTemplate} onOpenChange={(o) => !o && setPreviewTemplate(null)}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>{previewTemplate?.meta_template_name}</DialogTitle>
            <DialogDescription>
              {previewTemplate?.language} · {previewTemplate?.category} · {previewTemplate?.status}
            </DialogDescription>
          </DialogHeader>
          {previewTemplate && (() => {
            const h = extractHeader(previewTemplate.components);
            return (
              <TemplatePreview
                header_type={h.type}
                header_text={h.text}
                header_media_url={h.media_url}
                body={previewTemplate.body || ""}
                footer={extractFooter(previewTemplate.components)}
                buttons={extractButtons(previewTemplate.components)}
              />
            );
          })()}
        </DialogContent>
      </Dialog>
    </div>
  );
}

function CreateTemplateDialog({
  workspaceId,
  onCreated,
  editing,
}: {
  workspaceId: string | null;
  onCreated: () => void;
  editing?: any;
}) {
  const createFn = useServerFn(createTemplate);
  const editFn = useServerFn(editTemplate);
  const isEdit = !!editing;
  const [submitting, setSubmitting] = useState(false);
  const initialHeader = editing ? extractHeader(editing.components) : { type: "NONE", text: "", media_url: "" };
  const [form, setForm] = useState({
    name: editing?.meta_template_name || "",
    language: editing?.language || "en_US",
    category: (editing?.category || "MARKETING") as "MARKETING" | "UTILITY" | "AUTHENTICATION",
    header_type: initialHeader.type as "NONE" | "TEXT" | "IMAGE" | "VIDEO" | "DOCUMENT" | "LOCATION",
    header_text: initialHeader.text,
    header_media_url: initialHeader.media_url,
    body: editing?.body || "",
    footer: editing ? extractFooter(editing.components) : "",
  });
  const [buttons, setButtons] = useState<ButtonDraft[]>(editing ? extractButtons(editing.components) : []);
  const [bodyExamples, setBodyExamples] = useState<string[]>(editing ? extractBodyExamples(editing.components) : []);
  const [variableMapping, setVariableMapping] = useState<VariableMappingEntry[]>(
    editing?.variable_mapping && Array.isArray(editing.variable_mapping) ? editing.variable_mapping : [],
  );
  const bodyRef = useRef<HTMLTextAreaElement>(null);
  const [uploadingMedia, setUploadingMedia] = useState(false);

  const varCount = useMemo(() => (form.body.match(/\{\{\d+\}\}/g) || []).length, [form.body]);

  // Keep the mapping array length in sync with detected {{N}} placeholders.
  // New slots default to "customer_name" so the dropdown is never empty.
  useEffect(() => {
    setVariableMapping((prev) => {
      const next = [...prev];
      while (next.length < varCount) next.push({ index: next.length + 1, field: "customer_name" });
      while (next.length > varCount) next.pop();
      return next.map((e, i) => ({ ...e, index: i + 1 }));
    });
  }, [varCount]);

  function updateMapping(idx: number, patch: Partial<VariableMappingEntry>) {
    setVariableMapping((prev) => prev.map((e, i) => (i === idx ? { ...e, ...patch } as VariableMappingEntry : e)));
  }

  function insertVariable() {
    const next = varCount + 1;
    const token = `{{${next}}}`;
    const ta = bodyRef.current;
    if (ta) {
      const start = ta.selectionStart ?? form.body.length;
      const end = ta.selectionEnd ?? form.body.length;
      const newBody = form.body.slice(0, start) + token + form.body.slice(end);
      setForm({ ...form, body: newBody });
      requestAnimationFrame(() => {
        ta.focus();
        const pos = start + token.length;
        ta.setSelectionRange(pos, pos);
      });
    } else {
      setForm({ ...form, body: form.body + token });
    }
  }

  function addButton(type: ButtonDraft["type"]) {
    if (buttons.length >= 10) { toast.error("Maximum 10 buttons"); return; }
    const hasQuick = buttons.some((b) => b.type === "QUICK_REPLY");
    const hasCta = buttons.some((b) => b.type !== "QUICK_REPLY");
    if (type === "QUICK_REPLY" && hasCta) { toast.error("Can't mix quick replies with CTA buttons"); return; }
    if (type !== "QUICK_REPLY" && hasQuick) { toast.error("Can't mix CTA buttons with quick replies"); return; }
    if (type === "QUICK_REPLY") setButtons([...buttons, { type, text: "" }]);
    else if (type === "PHONE_NUMBER") setButtons([...buttons, { type, text: "", phone_number: "" }]);
    else if (type === "URL") setButtons([...buttons, { type, text: "", url: "", dynamic: false }]);
    else if (type === "COPY_CODE") setButtons([...buttons, { type, example: "" }]);
  }
  function updateButton(idx: number, patch: any) {
    setButtons(buttons.map((b, i) => (i === idx ? ({ ...b, ...patch } as ButtonDraft) : b)));
  }
  function removeButton(idx: number) {
    setButtons(buttons.filter((_, i) => i !== idx));
  }

  async function submit() {
    if (!workspaceId) return;
    if (!/^[a-z0-9_]+$/.test(form.name)) {
      toast.error("Name must be lowercase letters, numbers, underscores only");
      return;
    }
    setSubmitting(true);
    try {
      const payload: any = {
        workspace_id: workspaceId,
        name: form.name,
        language: form.language,
        category: form.category,
        header_type: form.header_type,
        body: form.body,
      };
      if (varCount > 0) {
        // Validate every {{N}} has a locked mapping. Static-text variants
        // also need a non-empty value so Meta never sees a blank placeholder.
        for (let i = 0; i < varCount; i++) {
          const entry = variableMapping[i];
          if (!entry?.field) {
            toast.error(`Pick a field for {{${i + 1}}}`);
            setSubmitting(false); return;
          }
          if (entry.field === "static_text" && !(entry.static_value || "").trim()) {
            toast.error(`Enter the static text for {{${i + 1}}}`);
            setSubmitting(false); return;
          }
        }
        // Sample values sent to Meta: prefer the user-typed sample, else the
        // field's representative example so Meta approval never blocks on
        // missing examples.
        const filled = Array.from({ length: varCount }, (_, i) => {
          const typed = (bodyExamples[i] || "").trim();
          if (typed) return typed;
          const entry = variableMapping[i];
          if (entry?.field === "static_text") return (entry.static_value || "").trim() || "sample";
          return fieldByKey(entry?.field)?.sample || "sample";
        });
        payload.body_examples = filled;
        payload.variable_mapping = variableMapping.slice(0, varCount);
      }
      if (form.header_type === "TEXT" && form.header_text) payload.header_text = form.header_text;
      if (["IMAGE", "VIDEO", "DOCUMENT"].includes(form.header_type) && form.header_media_url) {
        payload.header_media_url = form.header_media_url;
      }
      if (form.footer) payload.footer = form.footer;
      if (buttons.length > 0) {
        for (const b of buttons) {
          if (b.type === "QUICK_REPLY" && !b.text) { toast.error("Quick reply text required"); setSubmitting(false); return; }
          if (b.type === "PHONE_NUMBER" && (!b.text || !b.phone_number)) { toast.error("Phone button needs text and number"); setSubmitting(false); return; }
          if (b.type === "URL" && (!b.text || !b.url)) { toast.error("URL button needs text and URL"); setSubmitting(false); return; }
          if (b.type === "URL" && b.dynamic && !b.example) { toast.error("Dynamic URL needs an example value"); setSubmitting(false); return; }
          if (b.type === "COPY_CODE" && !b.example) { toast.error("Copy code needs an example code"); setSubmitting(false); return; }
        }
        payload.buttons = buttons;
      }

      const res = isEdit
        ? await editFn({ data: { ...payload, template_id: editing.id } })
        : await createFn({ data: payload });
      if (!res.ok) {
        toast.error(res.error);
        return;
      }
      toast.success(isEdit
        ? `Template resubmitted (status: ${res.status || "PENDING"})`
        : `Template submitted to Meta (status: ${res.status || "PENDING"})`);
      onCreated();
    } catch (e: any) {
      toast.error(e.message);
    } finally {
      setSubmitting(false);
    }
  }

  const needsMediaUrl = ["IMAGE", "VIDEO", "DOCUMENT"].includes(form.header_type);

  return (
    <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
      <DialogHeader>
        <DialogTitle>{isEdit ? "Edit WhatsApp Template" : "Create WhatsApp Template"}</DialogTitle>
        <DialogDescription>
          {isEdit
            ? "Update this pending template and resubmit it to Meta for approval."
            : "Submit a new message template to Meta for approval."}
        </DialogDescription>
      </DialogHeader>

      <div className="grid gap-6 md:grid-cols-[1fr_320px]">
        <div className="space-y-4">
        <div className="grid grid-cols-2 gap-3">
          <div>
            <Label>Name</Label>
            <Input
              placeholder="order_confirmation"
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value.toLowerCase() })}
            />
            <p className="text-xs text-muted-foreground mt-1">lowercase, numbers, _</p>
          </div>
          <div>
            <Label>Language</Label>
            <Input
              placeholder="en_US"
              value={form.language}
              onChange={(e) => setForm({ ...form, language: e.target.value })}
            />
          </div>
        </div>

        <div>
          <Label>Category</Label>
          <Select value={form.category} onValueChange={(v: any) => setForm({ ...form, category: v })}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="MARKETING">Marketing</SelectItem>
              <SelectItem value="UTILITY">Utility</SelectItem>
              <SelectItem value="AUTHENTICATION">Authentication</SelectItem>
            </SelectContent>
          </Select>
          {form.category === "AUTHENTICATION" && (
            <p className="text-xs text-muted-foreground mt-2">
              Meta enforces a fixed shape for Authentication templates: no custom body text,
              one OTP "Copy code" button, and a code-expiration footer. Your body text will be
              ignored on submit. To keep custom wording (e.g. "Your OTP for COD order #..."),
              choose <b>Utility</b> instead.
              {form.footer && /\d/.test(form.footer)
                ? ` Code expiry will be parsed from the footer (${form.footer}).`
                : " Default code expiry: 10 minutes (put a number in Footer to override)."}
            </p>
          )}
        </div>

        <div>
          <Label>Header type</Label>
          <Select value={form.header_type} onValueChange={(v: any) => setForm({ ...form, header_type: v })}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="NONE">None</SelectItem>
              <SelectItem value="TEXT">Text</SelectItem>
              <SelectItem value="IMAGE">Image</SelectItem>
              <SelectItem value="VIDEO">Video</SelectItem>
              <SelectItem value="DOCUMENT">Document</SelectItem>
              <SelectItem value="LOCATION">Location</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {form.header_type === "TEXT" && (
          <div>
            <Label>Header text</Label>
            <Input
              maxLength={60}
              placeholder="Welcome!"
              value={form.header_text}
              onChange={(e) => setForm({ ...form, header_text: e.target.value })}
            />
          </div>
        )}

        {needsMediaUrl && (
          <div>
            <Label>Sample media</Label>
            <div className="flex gap-2">
              <Input
                placeholder="https://example.com/sample.jpg or upload"
                value={form.header_media_url}
                onChange={(e) => setForm({ ...form, header_media_url: e.target.value })}
              />
              <Button
                type="button"
                variant="outline"
                disabled={uploadingMedia}
                onClick={() => document.getElementById("tpl-media-upload")?.click()}
              >
                {uploadingMedia ? <Loader2 className="h-4 w-4 animate-spin" /> : "Upload"}
              </Button>
              <input
                id="tpl-media-upload"
                type="file"
                className="hidden"
                accept={
                  form.header_type === "IMAGE" ? "image/*" :
                  form.header_type === "VIDEO" ? "video/*" :
                  ".pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.txt"
                }
                onChange={async (e) => {
                  const file = e.target.files?.[0];
                  if (!file) return;
                  setUploadingMedia(true);
                  try {
                    if (!workspaceId) throw new Error("No workspace selected");
                    const ext = file.name.split(".").pop() || "bin";
                    const path = `${workspaceId}/template-headers/${crypto.randomUUID()}.${ext}`;
                    const { error } = await supabase.storage.from("chat-media").upload(path, file, {
                      contentType: file.type, upsert: false,
                    });
                    if (error) throw error;
                    const { data } = supabase.storage.from("chat-media").getPublicUrl(path);
                    setForm((f) => ({ ...f, header_media_url: data.publicUrl }));
                    toast.success("Media uploaded");
                  } catch (err: any) {
                    toast.error(err.message || "Upload failed");
                  } finally {
                    setUploadingMedia(false);
                    e.target.value = "";
                  }
                }}
              />
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              Paste a public URL or upload a sample for {form.header_type.toLowerCase()} headers.
            </p>
          </div>
        )}

        <div>
          <div className="flex items-center justify-between mb-1">
            <Label>Body</Label>
            <Button type="button" size="sm" variant="secondary" onClick={insertVariable} className="h-7">
              <Braces className="mr-1.5 h-3.5 w-3.5" />Add Variable
            </Button>
          </div>
          <Textarea
            ref={bodyRef}
            rows={5}
            maxLength={1024}
            placeholder="Hi {{1}}, your order {{2}} has been confirmed."
            value={form.body}
            onChange={(e) => setForm({ ...form, body: e.target.value })}
          />
          <p className="text-xs text-muted-foreground mt-1">
            Click <span className="font-medium">Add Variable</span> to insert {`{{1}}`}, {`{{2}}`}… at the cursor.
          </p>

          {varCount > 0 && (
            <div className="mt-3 rounded-md border p-3 bg-secondary/30 space-y-3">
              <div>
                <p className="text-xs font-medium">Variable mapping <span className="text-muted-foreground font-normal">(locked at template approval — prevents wrong values at send time)</span></p>
                <p className="text-[11px] text-muted-foreground mt-0.5">Pick the data source for each {`{{N}}`}. Sample values are sent to Meta for approval and auto-filled from your choice.</p>
              </div>
              {Array.from({ length: varCount }).map((_, i) => {
                const entry = variableMapping[i];
                const field = fieldByKey(entry?.field);
                const isStatic = entry?.field === "static_text";
                const samplePlaceholder = isStatic
                  ? "Required: literal text to send"
                  : field?.sample
                    ? `Auto: ${field.sample}`
                    : `Example value for variable ${i + 1}`;
                return (
                  <div key={i} className="rounded border bg-background/60 p-2 space-y-2">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-mono text-muted-foreground w-12 shrink-0">{`{{${i + 1}}}`}</span>
                      <Select
                        value={entry?.field || "customer_name"}
                        onValueChange={(v) => updateMapping(i, { field: v as TemplateFieldKey, static_value: v === "static_text" ? (entry?.static_value || "") : undefined })}
                      >
                        <SelectTrigger className="h-9"><SelectValue placeholder="Pick a field" /></SelectTrigger>
                        <SelectContent>
                          {(["Customer","Order","Product","Shipping","Store","Other"] as const).map((group) => {
                            const items = TEMPLATE_FIELDS.filter((f) => f.group === group);
                            if (!items.length) return null;
                            return (
                              <div key={group}>
                                <p className="px-2 py-1 text-[10px] uppercase tracking-wider text-muted-foreground">{group}</p>
                                {items.map((f) => (
                                  <SelectItem key={f.key} value={f.key}>{f.label}</SelectItem>
                                ))}
                              </div>
                            );
                          })}
                        </SelectContent>
                      </Select>
                    </div>
                    {isStatic ? (
                      <Input
                        placeholder={samplePlaceholder}
                        value={entry?.static_value || ""}
                        maxLength={200}
                        onChange={(e) => updateMapping(i, { static_value: e.target.value })}
                      />
                    ) : (
                      <Input
                        placeholder={samplePlaceholder}
                        value={bodyExamples[i] || ""}
                        maxLength={200}
                        onChange={(e) => {
                          const next = [...bodyExamples];
                          next[i] = e.target.value;
                          setBodyExamples(next);
                        }}
                      />
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>


        <div>
          <Label>Footer (optional)</Label>
          <Input
            maxLength={60}
            placeholder="Reply STOP to unsubscribe"
            value={form.footer}
            onChange={(e) => setForm({ ...form, footer: e.target.value })}
          />
        </div>

        <div className="border rounded-lg p-3 space-y-3">
          <div>
            <Label className="text-sm">Buttons <span className="text-xs text-muted-foreground font-normal">(optional)</span></Label>
            <p className="text-xs text-muted-foreground mt-0.5">Let customers respond or take action. Max 10. Quick replies and CTA buttons can't be mixed.</p>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button type="button" size="sm" variant="secondary" onClick={() => addButton("QUICK_REPLY")}><Reply className="mr-1.5 h-3.5 w-3.5" />Quick Reply</Button>
            <Button type="button" size="sm" variant="secondary" onClick={() => addButton("PHONE_NUMBER")}><Phone className="mr-1.5 h-3.5 w-3.5" />Phone Number</Button>
            <Button type="button" size="sm" variant="secondary" onClick={() => addButton("COPY_CODE")}><Copy className="mr-1.5 h-3.5 w-3.5" />Copy Code</Button>
            <Button type="button" size="sm" variant="secondary" onClick={() => addButton("URL")}><LinkIcon className="mr-1.5 h-3.5 w-3.5" />URL</Button>
          </div>

          {buttons.length > 0 && (
            <div className="space-y-2">
              {buttons.map((b, i) => (
                <div key={i} className="rounded-md border p-3 bg-secondary/30 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-medium uppercase tracking-wide text-muted-foreground">{b.type.replace("_", " ")}</span>
                    <Button type="button" variant="ghost" size="icon" className="h-7 w-7" onClick={() => removeButton(i)}><Trash2 className="h-3.5 w-3.5" /></Button>
                  </div>
                  {b.type === "QUICK_REPLY" && (
                    <Input maxLength={25} placeholder="Button text (max 25)" value={b.text} onChange={(e) => updateButton(i, { text: e.target.value })} />
                  )}
                  {b.type === "PHONE_NUMBER" && (
                    <div className="grid grid-cols-2 gap-2">
                      <Input maxLength={25} placeholder="Button text" value={b.text} onChange={(e) => updateButton(i, { text: e.target.value })} />
                      <Input placeholder="+1234567890" value={b.phone_number} onChange={(e) => updateButton(i, { phone_number: e.target.value })} />
                    </div>
                  )}
                  {b.type === "COPY_CODE" && (
                    <Input maxLength={15} placeholder="Sample code, e.g. SAVE20" value={b.example} onChange={(e) => updateButton(i, { example: e.target.value })} />
                  )}
                  {b.type === "URL" && (
                    <div className="space-y-2">
                      <div className="grid grid-cols-2 gap-2">
                        <Input maxLength={25} placeholder="Button text (e.g. Complete Purchase)" value={b.text} onChange={(e) => updateButton(i, { text: e.target.value })} />
                        <Input placeholder={b.dynamic ? "https://slice.dotscube.com/r/{{1}}" : "https://site.com"} value={b.url} onChange={(e) => updateButton(i, { url: e.target.value })} />
                      </div>
                      <label className="flex items-center gap-2 text-xs text-muted-foreground">
                        <input type="checkbox" checked={!!b.dynamic} onChange={(e) => updateButton(i, { dynamic: e.target.checked })} />
                        Dynamic URL (append a variable like {`{{1}}`})
                      </label>
                      {b.dynamic && (
                        <>
                          <Input placeholder="Example value, e.g. sample-token-xyz" value={b.example || ""} onChange={(e) => updateButton(i, { example: e.target.value })} />
                          <TemplateUrlPreview url={b.url} example={b.example || ""} />

                          <div className="rounded-md border border-emerald-300 bg-emerald-50 p-2 text-[11px] text-emerald-900 dark:border-emerald-900/50 dark:bg-emerald-950/30 dark:text-emerald-100 space-y-1">
                            <p className="font-medium">For an Abandoned Cart "Complete Purchase" button</p>
                            <p>
                              Set the URL to <code className="rounded bg-emerald-100 dark:bg-emerald-900/50 px-1">https://slice.dotscube.com/r/{`{{1}}`}</code> and map this variable to
                              {" "}<strong>Recovery / CTA Link (recovery_url)</strong> on the mapping step.
                            </p>
                            <p>Do NOT paste a raw store checkout URL here — Slice fills the recovery token automatically so the button opens the same recovery page as the Checkout button in Commerce → Abandoned Carts.</p>
                          </div>
                        </>
                      )}
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>

        <p className="text-xs text-muted-foreground">
          Carousel headers aren't supported here yet — use Meta's WhatsApp Manager for those.
        </p>
        </div>

        <div className="md:sticky md:top-0 self-start">
          <Label className="mb-2 block">Preview</Label>
          <TemplatePreview
            header_type={form.header_type}
            header_text={form.header_text}
            header_media_url={form.header_media_url}
            body={form.body}
            footer={form.footer}
            buttons={buttons}
          />
        </div>
      </div>

      <DialogFooter>
        <Button onClick={submit} disabled={submitting || !form.name || !form.body}>
          {submitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
          {isEdit ? "Resubmit to Meta" : "Submit to Meta"}
        </Button>
      </DialogFooter>
    </DialogContent>
  );
}

function extractHeader(components: any): { type: "NONE" | "TEXT" | "IMAGE" | "VIDEO" | "DOCUMENT" | "LOCATION"; text: string; media_url: string } {
  if (!Array.isArray(components)) return { type: "NONE", text: "", media_url: "" };
  const h = components.find((c: any) => c?.type === "HEADER");
  if (!h) return { type: "NONE", text: "", media_url: "" };
  const fmt = (h.format || "TEXT").toUpperCase();
  if (fmt === "TEXT") return { type: "TEXT", text: h.text || "", media_url: "" };
  if (["IMAGE", "VIDEO", "DOCUMENT"].includes(fmt)) {
    const url = h.example?.header_handle?.[0] || "";
    return { type: fmt as any, text: "", media_url: url };
  }
  if (fmt === "LOCATION") return { type: "LOCATION", text: "", media_url: "" };
  return { type: "NONE", text: "", media_url: "" };
}

function extractFooter(components: any): string {
  if (!Array.isArray(components)) return "";
  return components.find((c: any) => c?.type === "FOOTER")?.text || "";
}

function extractBodyExamples(components: any): string[] {
  if (!Array.isArray(components)) return [];
  const body = components.find((c: any) => c?.type === "BODY");
  const row = body?.example?.body_text?.[0];
  return Array.isArray(row) ? row.map((v: any) => String(v ?? "")) : [];
}


function extractButtons(components: any): ButtonDraft[] {
  if (!Array.isArray(components)) return [];
  const block = components.find((c: any) => c?.type === "BUTTONS");
  if (!block?.buttons) return [];
  return block.buttons.map((b: any): ButtonDraft => {
    if (b.type === "QUICK_REPLY") return { type: "QUICK_REPLY", text: b.text || "" };
    if (b.type === "PHONE_NUMBER") return { type: "PHONE_NUMBER", text: b.text || "", phone_number: b.phone_number || "" };
    if (b.type === "COPY_CODE") return { type: "COPY_CODE", example: Array.isArray(b.example) ? b.example[0] : b.example || "" };
    if (b.type === "URL") return { type: "URL", text: b.text || "", url: b.url || "", dynamic: Array.isArray(b.example), example: Array.isArray(b.example) ? b.example[0] : undefined };
    return { type: "QUICK_REPLY", text: "" };
  });
}

function TemplatePreview({
  header_type,
  header_text,
  header_media_url,
  body,
  footer,
  buttons,
}: {
  header_type: string;
  header_text?: string;
  header_media_url?: string;
  body: string;
  footer?: string;
  buttons?: ButtonDraft[];
}) {
  const renderedBody = (body || "").replace(/\{\{(\d+)\}\}/g, (_, n) => `[var${n}]`);
  const time = new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  const isQuickReplies = (buttons || []).every((b) => b.type === "QUICK_REPLY") && (buttons || []).length > 0;

  return (
    <div className="rounded-2xl p-4 bg-[#e5ddd5] dark:bg-[#0b141a] border min-h-[360px]">
      <div className="max-w-[280px] ml-auto space-y-1.5">
        <div className="bg-[#dcf8c6] dark:bg-[#005c4b] rounded-lg shadow-sm overflow-hidden text-[13px] text-foreground/90 dark:text-white">
          {header_type === "IMAGE" && (
            header_media_url ? (
              <img src={header_media_url} alt="" className="w-full h-32 object-cover" />
            ) : (
              <div className="w-full h-32 bg-black/10 flex items-center justify-center"><ImageIcon className="h-8 w-8 opacity-40" /></div>
            )
          )}
          {header_type === "VIDEO" && (
            <div className="w-full h-32 bg-black/20 flex items-center justify-center"><Video className="h-8 w-8 opacity-60" /></div>
          )}
          {header_type === "DOCUMENT" && (
            <div className="m-2 p-3 rounded bg-black/5 dark:bg-white/10 flex items-center gap-2">
              <FileIcon className="h-6 w-6 opacity-70" />
              <span className="text-xs truncate">{header_media_url ? header_media_url.split("/").pop() : "document.pdf"}</span>
            </div>
          )}
          {header_type === "LOCATION" && (
            <div className="w-full h-24 bg-black/10 flex items-center justify-center gap-2"><MapPin className="h-5 w-5" /><span className="text-xs">Shared location</span></div>
          )}

          <div className="px-2.5 pt-2 pb-1.5">
            {header_type === "TEXT" && header_text && (
              <p className="font-semibold mb-1 break-words">{header_text}</p>
            )}
            <p className="whitespace-pre-wrap break-words">
              {renderedBody || <span className="opacity-50 italic">Your message body…</span>}
            </p>
            {footer && <p className="text-[11px] opacity-60 mt-1.5">{footer}</p>}
            <p className="text-[10px] opacity-60 text-right mt-1">{time}</p>
          </div>

          {buttons && buttons.length > 0 && !isQuickReplies && (
            <div className="border-t border-black/10 dark:border-white/10">
              {buttons.map((b, i) => {
                const icon = b.type === "PHONE_NUMBER" ? <Phone className="h-3.5 w-3.5" /> :
                             b.type === "COPY_CODE" ? <Copy className="h-3.5 w-3.5" /> :
                             <LinkIcon className="h-3.5 w-3.5" />;
                const label = b.type === "COPY_CODE"
                  ? `Copy code${(b as any).example ? ` (${(b as any).example})` : ""}`
                  : (b as any).text || <span className="opacity-50 italic">Button text</span>;
                return (
                  <div key={i} className={`flex items-center justify-center gap-1.5 py-2 text-[13px] text-[#00a5f4] dark:text-[#53bdeb] ${i > 0 ? "border-t border-black/10 dark:border-white/10" : ""}`}>
                    {icon}<span className="truncate">{label}</span>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {isQuickReplies && buttons!.map((b, i) => (
          <div key={i} className="bg-white dark:bg-[#1f2c33] rounded-lg shadow-sm text-center py-2 text-[13px] text-[#00a5f4] dark:text-[#53bdeb]">
            {(b as any).text || <span className="opacity-50 italic">Quick reply</span>}
          </div>
        ))}
      </div>
    </div>
  );
}

function StatusBadge({ status }: { status: string }) {
  const color =
    status === "APPROVED" ? "bg-success/15 text-success" :
    status === "REJECTED" ? "bg-destructive/15 text-destructive" :
    "bg-warning/15 text-warning";
  return <span className={`text-xs px-2 py-1 rounded-full font-medium ${color}`}>{status}</span>;
}

// Lightweight dialog to lock per-variable field mapping on an existing
// template (works for APPROVED templates too — does NOT resubmit to Meta).
function MapFieldsDialog({
  workspaceId,
  template,
  onSaved,
}: {
  workspaceId: string | null;
  template: any;
  onSaved: () => void;
}) {
  const saveFn = useServerFn(setTemplateMapping);
  const count: number = Number(template.variables_count || 0);
  const initial: VariableMappingEntry[] = Array.isArray(template.variable_mapping)
    ? template.variable_mapping
    : [];
  const [mapping, setMapping] = useState<VariableMappingEntry[]>(() => {
    const guessed = guessTemplateMapping({
      variables_count: count,
      body: template.body,
      components: template.components,
    });
    const next: VariableMappingEntry[] = [];
    for (let i = 1; i <= count; i++) {
      const existing = initial.find((e: any) => Number(e?.index) === i);
      const guess = guessed.find((e) => e.index === i);
      next.push(existing ?? guess ?? { index: i, field: "customer_name" });
    }
    return next;
  });
  const [saving, setSaving] = useState(false);

  // Find body text + Meta-approved example values so the user has context.
  const bodyComp = Array.isArray(template.components)
    ? template.components.find((c: any) => String(c?.type || "").toUpperCase() === "BODY")
    : null;
  const bodyText: string = bodyComp?.text || template.body || "";
  const exampleRow: string[] = (() => {
    const ex = bodyComp?.example?.body_text;
    if (Array.isArray(ex) && ex.length && Array.isArray(ex[0])) {
      return (ex[0] as any[]).map((v: any) => String(v ?? ""));
    }
    return [];
  })();

  // Detect which {{N}} placeholders should be mapped to the recovery URL
  // token — either because they appear inside a `/r/{{N}}` link in the body
  // OR because a dynamic URL button has `.../r/{{N}}` as its URL template.
  const recoveryVarIndices: Set<number> = (() => {
    const idx = new Set<number>();
    const scan = (text: string) => {
      const re = /(?:https?:\/\/[^\s{}]+)?\/(?:api\/public\/)?r\/\{\{\s*(\d+)\s*\}\}/gi;
      let m: RegExpExecArray | null;
      while ((m = re.exec(text)) !== null) idx.add(Number(m[1]));
    };
    scan(bodyText);
    if (Array.isArray(template.components)) {
      const btns = template.components.find((c: any) => String(c?.type || "").toUpperCase() === "BUTTONS");
      const list = Array.isArray(btns?.buttons) ? btns.buttons : [];
      for (const b of list) {
        if (String(b?.type || "").toUpperCase() === "URL") scan(String(b?.url || ""));
      }
    }
    return idx;
  })();

  async function save() {
    if (!workspaceId) return;
    for (const e of mapping) {
      if (!e.field) { toast.error(`Pick a field for {{${e.index}}}`); return; }
      if (e.field === "static_text" && !(e.static_value || "").trim()) {
        toast.error(`Enter static text for {{${e.index}}}`); return;
      }
    }
    setSaving(true);
    try {
      const res = await saveFn({
        data: {
          workspace_id: workspaceId,
          template_id: template.id,
          variable_mapping: mapping,
        },
      });
      if (!(res as any).ok) {
        toast.error((res as any).error || "Could not save mapping");
        return;
      }
      toast.success("Field mapping saved");
      onSaved();
    } catch (e: any) {
      toast.error(e.message);
    } finally {
      setSaving(false);
    }
  }

  return (
    <DialogContent className="max-w-lg">
      <DialogHeader>
        <DialogTitle>Map fields for {template.meta_template_name}</DialogTitle>
        <DialogDescription>
          Lock each placeholder to a data source. Values are always pulled from the chosen field — no guessing at send time.
        </DialogDescription>
      </DialogHeader>
      <div className="space-y-3">
        <div className="rounded-md border bg-secondary/30 p-3 text-sm whitespace-pre-wrap">
          {bodyText || <span className="text-muted-foreground italic">No body text</span>}
        </div>
        {recoveryVarIndices.size > 0 && (
          <div className="rounded-md border border-emerald-300 bg-emerald-50 p-3 text-xs text-emerald-900 dark:border-emerald-900/50 dark:bg-emerald-950/30 dark:text-emerald-100">
            <p className="font-semibold mb-1">Recovery link detected</p>
            <p>
              For {[...recoveryVarIndices].sort((a,b)=>a-b).map((n) => <code key={n} className="rounded bg-emerald-100 dark:bg-emerald-900/50 px-1 mx-0.5">{`{{${n}}}`}</code>)} always select
              {" "}<strong>Recovery / CTA Link (recovery_url)</strong>. Do not use any other URL, checkout, or redirect field —
              Slice fills the recovery token automatically so the "Complete Purchase" button opens the exact same page as the Checkout button in Commerce → Abandoned Carts.
            </p>
          </div>
        )}
        {mapping.map((entry, i) => {
          const isRecoverySlot = recoveryVarIndices.has(entry.index);
          return (
          <div key={i} className={`grid gap-2 rounded-md border p-3 ${isRecoverySlot ? "border-emerald-300 dark:border-emerald-900/50" : ""}`}>
            <div className="flex items-center justify-between">
              <Label className="font-mono">{`{{${entry.index}}}`}</Label>
              {exampleRow[i] && (
                <span className="text-xs text-muted-foreground">
                  Meta example: <span className="font-medium">{exampleRow[i]}</span>
                </span>
              )}
            </div>
            {isRecoverySlot && (
              <p className="text-[11px] rounded bg-emerald-100 dark:bg-emerald-900/40 px-2 py-1 text-emerald-900 dark:text-emerald-100">
                Recommended: <strong>Recovery / CTA Link (recovery_url)</strong> — required for the "Complete Purchase" button to open the correct cart.
              </p>
            )}
            <Select
              value={entry.field}
              onValueChange={(v) =>
                setMapping((prev) =>
                  prev.map((e, idx) => (idx === i ? { ...e, field: v as TemplateFieldKey } : e)),
                )
              }
            >
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {(["Customer","Order","Product","Shipping","Store","Other"] as const).map((group) => {
                  const items = TEMPLATE_FIELDS.filter((f) => f.group === group);
                  if (!items.length) return null;
                  return (
                    <div key={group}>
                      <div className="px-2 py-1 text-xs font-semibold text-muted-foreground">{group}</div>
                      {items.map((f) => (
                        <SelectItem key={f.key} value={f.key}>{f.label}</SelectItem>
                      ))}
                    </div>
                  );
                })}
              </SelectContent>
            </Select>
            {entry.field === "static_text" && (
              <Input
                placeholder="Static value sent to every customer"
                value={entry.static_value || ""}
                onChange={(e) =>
                  setMapping((prev) =>
                    prev.map((x, idx) => (idx === i ? { ...x, static_value: e.target.value } : x)),
                  )
                }
              />
            )}
            {entry.field !== "static_text" && (
              <p className="text-xs text-muted-foreground">
                Always sends: <strong>{fieldByKey(entry.field)?.label}</strong> (example: {fieldByKey(entry.field)?.sample})
              </p>
            )}
          </div>
        );})}
      </div>
      <DialogFooter>
        <Button onClick={save} disabled={saving}>
          {saving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
          Save mapping
        </Button>
      </DialogFooter>
    </DialogContent>
  );
}
