import { createFileRoute, Link, Outlet, useRouterState } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useWorkspace } from "@/lib/workspace-context";
import { registerWhatsAppPhoneNumber } from "@/lib/whatsapp-accounts.functions";
import { cancelScheduledCampaign, sendScheduledCampaignNow, rescheduleCampaign } from "@/lib/whatsapp.functions";
import { isMetaSuppressedDelivery } from "@/lib/whatsapp-delivery-status";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Plus, Send, ChevronDown, ChevronRight, AlertCircle, KeyRound, Loader2, Clock, X, Pencil, Zap } from "lucide-react";



export const Route = createFileRoute("/_authenticated/campaigns")({
  component: CampaignsLayout,
  head: () => ({ meta: [{ title: "Campaigns — Slice" }] }),
});

function CampaignsLayout() {
  const path = useRouterState({ select: (s) => s.location.pathname });
  if (path !== "/campaigns") return <Outlet />;
  return <CampaignsList />;
}

function CampaignsList() {
  const { currentWorkspaceId } = useWorkspace();
  const { data: campaigns = [] } = useQuery({
    queryKey: ["campaigns", currentWorkspaceId],
    enabled: !!currentWorkspaceId,
    queryFn: async () => {
      const { data, error } = await supabase.from("campaigns").select("*")
        .eq("workspace_id", currentWorkspaceId!)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data;
    },
  });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-3xl font-bold">Campaigns</h1>
          <p className="text-muted-foreground">Send template messages to your contacts</p>
        </div>
        <Link to="/campaigns/new">
          <Button><Plus className="mr-2 h-4 w-4" />New campaign</Button>
        </Link>
      </div>

      {campaigns.length === 0 ? (
        <Card className="p-12 text-center">
          <Send className="h-10 w-10 mx-auto text-muted-foreground/50" />
          <p className="mt-3 font-medium">No campaigns yet</p>
          <Link to="/campaigns/new" className="text-sm text-primary hover:underline mt-1 inline-block">
            Launch your first campaign →
          </Link>
        </Card>
      ) : (
        <Card className="divide-y">
          {campaigns.map((c: any) => (
            <CampaignRow key={c.id} campaign={c} />
          ))}
        </Card>
      )}
    </div>
  );
}

function CampaignRow({ campaign: c }: { campaign: any }) {
  const { currentWorkspaceId } = useWorkspace();
  const [open, setOpen] = useState(false);
  const [registering, setRegistering] = useState(false);
  const registerFn = useServerFn(registerWhatsAppPhoneNumber);
  const { data: recipients = [] } = useQuery({
    queryKey: ["recipients", c.id],
    enabled: open,
    queryFn: async () =>
      (await supabase.from("campaign_recipients").select("phone,name,status,error")
        .eq("campaign_id", c.id).limit(200)).data ?? [],
  });

  const suppressedCount = recipients.filter((r: any) => isMetaSuppressedDelivery(r)).length;
  const visibleFailedCount = open ? recipients.filter((r: any) => r.status === "failed" && !isMetaSuppressedDelivery(r)).length : c.failed_count;
  const hasDeliveryIssues = c.failed_count > 0 || suppressedCount > 0 || Number(c.sent_count || 0) > Number(c.delivered_count || 0);
  const has133010 = recipients.some((r: any) => r.error?.includes("133010"));
  const isScheduled = c.status === "scheduled";

  const cancelFn = useServerFn(cancelScheduledCampaign);
  const sendNowFn = useServerFn(sendScheduledCampaignNow);
  const rescheduleFn = useServerFn(rescheduleCampaign);
  const [cancelling, setCancelling] = useState(false);
  const [sending, setSending] = useState(false);
  const [editOpen, setEditOpen] = useState(false);
  const [newWhen, setNewWhen] = useState<string>(() => {
    if (!c.scheduled_at) return "";
    const d = new Date(c.scheduled_at);
    const pad = (n: number) => String(n).padStart(2, "0");
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
  });
  const [saving, setSaving] = useState(false);

  async function handleRegisterNow() {
    if (!currentWorkspaceId) return;
    setRegistering(true);
    try {
      const { data: acc } = await supabase
        .from("whatsapp_accounts").select("id")
        .eq("workspace_id", currentWorkspaceId)
        .eq("is_active", true).maybeSingle();
      if (!acc) {
        toast.error("No active WhatsApp account found. Go to WhatsApp Accounts to connect one.");
        return;
      }
      const res = await registerFn({ data: { account_id: acc.id } });
      if (res.ok) toast.success("Phone number registered. Re-launch the campaign.");
      else toast.error(res.error || "Registration failed");
    } catch (e: any) {
      toast.error(e.message || "Registration failed");
    } finally {
      setRegistering(false);
    }
  }

  async function handleSendNow() {
    if (!currentWorkspaceId) return;
    if (!confirm(`Send "${c.name}" now to ${c.total_count} recipient(s)?`)) return;
    setSending(true);
    try {
      const res = await sendNowFn({ data: { workspace_id: currentWorkspaceId, campaign_id: c.id } });
      toast.success(`Sent ${res.sent}, failed ${res.failed}`);
    } catch (e: any) {
      toast.error(e.message || "Send failed");
    } finally {
      setSending(false);
    }
  }

  async function handleReschedule() {
    if (!currentWorkspaceId || !newWhen) return;
    setSaving(true);
    try {
      const iso = new Date(newWhen).toISOString();
      await rescheduleFn({ data: { workspace_id: currentWorkspaceId, campaign_id: c.id, scheduled_at: iso } });
      toast.success("Schedule updated");
      setEditOpen(false);
    } catch (e: any) {
      toast.error(e.message || "Update failed");
    } finally {
      setSaving(false);
    }
  }


  async function handleCancelScheduled() {
    if (!currentWorkspaceId) return;
    setCancelling(true);
    try {
      await cancelFn({ data: { workspace_id: currentWorkspaceId, campaign_id: c.id } });
      toast.success("Scheduled campaign cancelled");
    } catch (e: any) {
      toast.error(e.message || "Cancel failed");
    } finally {
      setCancelling(false);
    }
  }

  return (
    <div className="p-5">
      <div className="flex items-center justify-between">
        <div className="flex-1">
          <p className="font-medium">{c.name}</p>
          <p className="text-xs text-muted-foreground mt-0.5">
            Template: {c.template_name} · {new Date(c.created_at).toLocaleString()}
          </p>
          {isScheduled && c.scheduled_at && (
            <p className="text-xs text-primary mt-1 inline-flex items-center gap-1">
              <Clock className="h-3 w-3" /> Scheduled for {new Date(c.scheduled_at).toLocaleString()}
            </p>
          )}

          <div className="mt-2 flex gap-4 text-xs items-center">
            <span className="text-success">✓ {c.sent_count} sent</span>
            {visibleFailedCount > 0 && <span className="text-destructive">✗ {visibleFailedCount} failed</span>}
            {suppressedCount > 0 && <span className="text-amber-600">ⓘ {suppressedCount} Meta suppressed</span>}
            <span className="text-muted-foreground">{c.total_count} total</span>
            {hasDeliveryIssues && (
              <button
                onClick={() => setOpen(!open)}
                className="ml-2 inline-flex items-center gap-1 text-primary hover:underline"
              >
                {open ? <ChevronDown className="h-3 w-3" /> : <ChevronRight className="h-3 w-3" />}
                {open ? "Hide" : "Delivery details"}
              </button>
            )}
          </div>
        </div>
        <div className="flex items-center gap-3">
          <span className="text-xs px-3 py-1 rounded-full bg-secondary font-medium">{c.status}</span>
          {isScheduled && (
            <>
              <Button size="sm" onClick={handleSendNow} disabled={sending}>
                {sending ? <Loader2 className="mr-1 h-3 w-3 animate-spin" /> : <Zap className="mr-1 h-3 w-3" />}
                Send now
              </Button>
              <Button size="sm" variant="outline" onClick={() => setEditOpen(true)}>
                <Pencil className="mr-1 h-3 w-3" /> Edit
              </Button>
              <Button size="sm" variant="outline" onClick={handleCancelScheduled} disabled={cancelling}>
                {cancelling ? <Loader2 className="mr-1 h-3 w-3 animate-spin" /> : <X className="mr-1 h-3 w-3" />}
                Cancel
              </Button>
            </>
          )}
          <Link to="/campaigns/$id" params={{ id: c.id }}>
            <Button size="sm" variant="outline">View report</Button>
          </Link>
        </div>

      </div>

      <Dialog open={editOpen} onOpenChange={setEditOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Reschedule campaign</DialogTitle>
          </DialogHeader>
          <div className="space-y-2">
            <Label htmlFor={`when-${c.id}`}>New send time</Label>
            <Input
              id={`when-${c.id}`}
              type="datetime-local"
              value={newWhen}
              onChange={(e) => setNewWhen(e.target.value)}
            />
            <p className="text-xs text-muted-foreground">Must be in the future. Uses your browser timezone.</p>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditOpen(false)}>Cancel</Button>
            <Button onClick={handleReschedule} disabled={saving || !newWhen}>
              {saving && <Loader2 className="mr-1 h-3 w-3 animate-spin" />}
              Save
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>


      {open && hasDeliveryIssues && (
        <div className="mt-4 rounded-lg border bg-muted/30 p-4 space-y-3">
          {has133010 && (
            <div className="flex gap-3 rounded-md border border-destructive/30 bg-destructive/5 p-3 text-xs">
              <AlertCircle className="h-4 w-4 text-destructive shrink-0 mt-0.5" />
              <div className="flex-1">
                <p className="font-medium text-destructive">Your WhatsApp number isn't registered with Cloud API yet</p>
                <p className="text-muted-foreground mt-1">
                  Meta error #133010 means the sender phone number has never completed the one-time Cloud API registration.
                  Click <b>Register now</b> below to fix it, then re-launch the campaign.
                </p>
                <div className="mt-3 flex gap-2">
                  <Button size="sm" onClick={handleRegisterNow} disabled={registering}>
                    {registering ? <Loader2 className="mr-2 h-3 w-3 animate-spin" /> : <KeyRound className="mr-2 h-3 w-3" />}
                    Register now
                  </Button>
                  <Link to="/whatsapp-accounts">
                    <Button size="sm" variant="outline">Open WhatsApp Accounts</Button>
                  </Link>
                </div>
              </div>
            </div>
          )}
          {recipients.some((r: any) => isMetaSuppressedDelivery(r)) && (
            <div className="flex gap-3 rounded-md border border-amber-500/30 bg-amber-500/5 p-3 text-xs">
              <AlertCircle className="h-4 w-4 text-amber-600 shrink-0 mt-0.5" />
              <div>
                <p className="font-medium text-amber-700">Meta suppressed delivery</p>
                <p className="text-muted-foreground mt-1">
                  These are not Slice send failures. WhatsApp/Meta accepted the send, then blocked delivery for policy/user reasons such as per-user marketing limits (#131049), experiments (#130472), or recipient opt-out (#131050).
                  To reduce this: (1) send to warmer opted-in contacts, (2) wait at least 24 hours before retrying suppressed recipients, (3) check your template quality in
                  {" "}<a href="https://business.facebook.com/wa/manage/message-templates/" target="_blank" rel="noreferrer" className="text-primary underline">Meta Business Manager → Message Templates</a>, and
                  (4) improve template content.
                </p>
              </div>
            </div>
          )}
          {recipients.some((r: any) => r.error?.includes("131030")) && (
            <div className="flex gap-3 rounded-md border border-destructive/30 bg-destructive/5 p-3 text-xs">
              <AlertCircle className="h-4 w-4 text-destructive shrink-0 mt-0.5" />
              <div>
                <p className="font-medium text-destructive">Recipient not in your allowed list</p>
                <p className="text-muted-foreground mt-1">
                  Your WhatsApp Business account is in test mode. Add the recipient as a test number in
                  {" "}
                  <a
                    href="https://developers.facebook.com/apps"
                    target="_blank" rel="noreferrer"
                    className="text-primary underline"
                  >
                    Meta for Developers
                  </a>
                  {" "}→ WhatsApp → API Setup → <b>To: Manage phone number list</b>, or submit your app for
                  review to send to any WhatsApp user.
                </p>
              </div>
            </div>
          )}
          <div className="space-y-1.5">
            {recipients.filter((r: any) => r.status === "failed" || isMetaSuppressedDelivery(r)).map((r: any, i: number) => (
              <div key={i} className="text-xs flex items-start gap-2">
                <span className="font-mono text-muted-foreground shrink-0">{r.phone}</span>
                <span className={isMetaSuppressedDelivery(r) ? "text-amber-700" : "text-destructive"}>{r.error || "Unknown error"}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
