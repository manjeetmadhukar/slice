import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useWorkspace } from "@/lib/workspace-context";
import { syncContactConversations } from "@/lib/inbox.functions";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";
import {
  Plus, GripVertical, Calendar, User, Trash2, Phone, MessageCircle, StickyNote,
  Settings2, Tag as TagIcon, History, Pencil, X, Trophy, ThumbsDown,
} from "lucide-react";
import { useCurrency } from "@/lib/currency";

export const Route = createFileRoute("/_authenticated/pipeline")({
  component: Pipeline,
  head: () => ({ meta: [{ title: "Pipeline — Slice" }] }),
});

const STAGE_COLORS = ["#64748b", "#3b82f6", "#8b5cf6", "#f59e0b", "#f97316", "#10b981", "#ef4444", "#ec4899", "#14b8a6"];

async function logActivity(workspaceId: string, dealId: string, type: string, data: any = {}) {
  const { data: u } = await supabase.auth.getUser();
  await supabase.from("deal_activities").insert({
    workspace_id: workspaceId,
    deal_id: dealId,
    user_id: u.user?.id ?? null,
    type,
    data,
  });
}

function Pipeline() {
  const qc = useQueryClient();
  const navigate = useNavigate();
  const { currency, format } = useCurrency();
  const { currentWorkspaceId } = useWorkspace();
  const syncFn = useServerFn(syncContactConversations);

  const [open, setOpen] = useState(false);
  const [dragId, setDragId] = useState<string | null>(null);
  const [detailDealId, setDetailDealId] = useState<string | null>(null);
  const [stageManagerOpen, setStageManagerOpen] = useState(false);
  const [form, setForm] = useState({
    title: "", value: "", contact_id: "", stage_id: "", expected_close_date: "", notes: "",
  });

  const { data: stages = [] } = useQuery({
    queryKey: ["pipeline-stages", currentWorkspaceId],
    enabled: !!currentWorkspaceId,
    queryFn: async () => {
      const { data, error } = await supabase.from("pipeline_stages").select("*")
        .eq("workspace_id", currentWorkspaceId!).order("position");
      if (error) throw error;
      return data;
    },
  });

  const { data: deals = [] } = useQuery({
    queryKey: ["deals", currentWorkspaceId],
    enabled: !!currentWorkspaceId,
    queryFn: async () => {
      const { data, error } = await supabase.from("deals").select("*, contacts(name, phone)")
        .eq("workspace_id", currentWorkspaceId!).order("position");
      if (error) throw error;
      return data;
    },
  });

  const { data: contacts = [] } = useQuery({
    queryKey: ["contacts-light", currentWorkspaceId],
    enabled: !!currentWorkspaceId,
    queryFn: async () => {
      const { data } = await supabase.from("contacts").select("id, name, phone")
        .eq("workspace_id", currentWorkspaceId!).order("name").limit(500);
      return data ?? [];
    },
  });

  const detailDeal = deals.find((d: any) => d.id === detailDealId) ?? null;

  async function createDeal() {
    if (!currentWorkspaceId || !form.title.trim() || !form.stage_id) {
      return toast.error("Title and stage required");
    }
    const { data: u } = await supabase.auth.getUser();
    const { data: inserted, error } = await supabase.from("deals").insert({
      workspace_id: currentWorkspaceId,
      user_id: u.user!.id,
      title: form.title.trim(),
      value: Number(form.value) || 0,
      currency,
      contact_id: form.contact_id || null,
      stage_id: form.stage_id,
      expected_close_date: form.expected_close_date || null,
      notes: form.notes || null,
    }).select("id").single();
    if (error) return toast.error(error.message);
    await logActivity(currentWorkspaceId, inserted!.id, "created", { title: form.title.trim() });
    toast.success("Deal created");
    setOpen(false);
    setForm({ title: "", value: "", contact_id: "", stage_id: "", expected_close_date: "", notes: "" });
    qc.invalidateQueries({ queryKey: ["deals"] });
  }

  async function moveDeal(dealId: string, stageId: string) {
    const deal = deals.find((d: any) => d.id === dealId);
    if (!deal || deal.stage_id === stageId) return;
    const fromStage = stages.find((s: any) => s.id === deal.stage_id);
    const toStage = stages.find((s: any) => s.id === stageId);
    const { error } = await supabase.from("deals")
      .update({ stage_id: stageId, updated_at: new Date().toISOString() })
      .eq("id", dealId);
    if (error) return toast.error(error.message);
    if (currentWorkspaceId) {
      await logActivity(currentWorkspaceId, dealId, "stage_changed", {
        from: fromStage?.name, to: toStage?.name,
      });
    }
    qc.invalidateQueries({ queryKey: ["deals"] });
  }

  async function deleteDeal(id: string) {
    const { error } = await supabase.from("deals").delete().eq("id", id);
    if (error) return toast.error(error.message);
    qc.invalidateQueries({ queryKey: ["deals"] });
  }

  async function openInInbox(deal: any) {
    if (!deal?.contact_id || !currentWorkspaceId) {
      return toast.error("No contact linked to this deal");
    }
    try {
      const r: any = await syncFn({ data: { workspace_id: currentWorkspaceId, contact_id: deal.contact_id } });
      const convId = r?.first_conversation_id;
      if (!convId) {
        return toast.error("Could not open chat. Make sure the contact has a phone number.");
      }
      await logActivity(currentWorkspaceId, deal.id, "message_opened", {});
      navigate({ to: "/inbox", search: { conversation: convId } as any });
    } catch (e: any) {
      toast.error(e?.message || "Failed to open chat");
    }
  }

  const totalValue = deals.reduce((s: number, d: any) => s + Number(d.value || 0), 0);

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-3xl font-bold">Pipeline</h1>
          <p className="text-muted-foreground">
            {deals.length} deals · {format(totalValue)} pipeline value
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => setStageManagerOpen(true)}>
            <Settings2 className="mr-2 h-4 w-4" />Manage stages
          </Button>
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button><Plus className="mr-2 h-4 w-4" />New deal</Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader><DialogTitle>New deal</DialogTitle></DialogHeader>
              <div className="space-y-3">
                <div><Label>Title</Label><Input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} /></div>
                <div className="grid grid-cols-2 gap-3">
                  <div><Label>Value ({currency})</Label><Input type="number" value={form.value} onChange={(e) => setForm({ ...form, value: e.target.value })} /></div>
                  <div><Label>Expected close</Label><Input type="date" value={form.expected_close_date} onChange={(e) => setForm({ ...form, expected_close_date: e.target.value })} /></div>
                </div>
                <div>
                  <Label>Stage</Label>
                  <Select value={form.stage_id} onValueChange={(v) => setForm({ ...form, stage_id: v })}>
                    <SelectTrigger><SelectValue placeholder="Select stage" /></SelectTrigger>
                    <SelectContent>
                      {stages.map((s: any) => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Contact (optional)</Label>
                  <Select value={form.contact_id} onValueChange={(v) => setForm({ ...form, contact_id: v })}>
                    <SelectTrigger><SelectValue placeholder="Link to contact" /></SelectTrigger>
                    <SelectContent>
                      {contacts.map((c: any) => <SelectItem key={c.id} value={c.id}>{c.name} · {c.phone}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div><Label>Notes</Label><Textarea rows={3} value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} /></div>
              </div>
              <DialogFooter><Button onClick={createDeal}>Create</Button></DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <div className="overflow-x-auto -mx-6 px-6 pb-2">
        <div className="flex gap-4 min-w-max">
          {stages.map((s: any) => {
            const stageDeals = deals.filter((d: any) => d.stage_id === s.id);
            const stageValue = stageDeals.reduce((sum: number, d: any) => sum + Number(d.value || 0), 0);
            return (
              <div
                key={s.id}
                className="w-72 shrink-0"
                onDragOver={(e) => e.preventDefault()}
                onDrop={() => { if (dragId) { moveDeal(dragId, s.id); setDragId(null); } }}
              >
                <div className="flex items-center justify-between mb-2 px-1">
                  <div className="flex items-center gap-2">
                    <span className="h-2.5 w-2.5 rounded-full" style={{ background: s.color }} />
                    <span className="font-medium text-sm">{s.name}</span>
                    {s.is_won && <Trophy className="h-3 w-3 text-green-600" />}
                    {s.is_lost && <ThumbsDown className="h-3 w-3 text-destructive" />}
                    <span className="text-xs text-muted-foreground">({stageDeals.length})</span>
                  </div>
                  <span className="text-xs text-muted-foreground">{format(stageValue)}</span>
                </div>
                <div className="space-y-2 min-h-[200px] rounded-lg bg-muted/30 p-2">
                  {stageDeals.map((d: any) => (
                    <Card
                      key={d.id}
                      draggable
                      onDragStart={() => setDragId(d.id)}
                      onDragEnd={() => setDragId(null)}
                      onClick={() => setDetailDealId(d.id)}
                      className="p-3 cursor-pointer hover:shadow-md transition group"
                    >
                      <div className="flex items-start justify-between gap-1">
                        <GripVertical className="h-3.5 w-3.5 text-muted-foreground mt-0.5 shrink-0 cursor-grab" />
                        <div className="flex-1 min-w-0">
                          <p className="font-medium text-sm truncate">{d.title}</p>
                          {d.contacts && (
                            <p className="text-xs text-muted-foreground truncate flex items-center gap-1 mt-0.5">
                              <User className="h-3 w-3" />{d.contacts.name}
                            </p>
                          )}
                          {(d.tags?.length ?? 0) > 0 && (
                            <div className="flex flex-wrap gap-1 mt-1.5">
                              {d.tags.slice(0, 3).map((t: string) => (
                                <Badge key={t} variant="secondary" className="text-[10px] px-1.5 py-0">{t}</Badge>
                              ))}
                              {d.tags.length > 3 && <span className="text-[10px] text-muted-foreground">+{d.tags.length - 3}</span>}
                            </div>
                          )}
                          <div className="flex items-center gap-2 mt-1.5 text-xs">
                            {Number(d.value) > 0 && (
                              <span className="inline-flex items-center gap-0.5 text-green-700 dark:text-green-400 font-medium">
                                {d.currency && d.currency !== currency
                                  ? new Intl.NumberFormat(undefined, { style: "currency", currency: d.currency, maximumFractionDigits: 0 }).format(Number(d.value))
                                  : format(d.value)}
                              </span>
                            )}
                            {d.expected_close_date && (
                              <span className="inline-flex items-center gap-0.5 text-muted-foreground">
                                <Calendar className="h-3 w-3" />{new Date(d.expected_close_date).toLocaleDateString()}
                              </span>
                            )}
                          </div>
                        </div>
                        <button
                          onClick={(e) => { e.stopPropagation(); deleteDeal(d.id); }}
                          className="opacity-0 group-hover:opacity-100 transition text-muted-foreground hover:text-destructive"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    </Card>
                  ))}
                  {stageDeals.length === 0 && (
                    <div className="text-center text-xs text-muted-foreground py-8">Drop deals here</div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <DealDetailDialog
        deal={detailDeal}
        stages={stages}
        onClose={() => setDetailDealId(null)}
        onMessage={openInInbox}
      />

      <StageManager
        open={stageManagerOpen}
        onClose={() => setStageManagerOpen(false)}
        workspaceId={currentWorkspaceId}
        stages={stages}
      />
    </div>
  );
}

// ===================== Deal Detail with Tabs =====================
function DealDetailDialog({ deal, stages, onClose, onMessage }: {
  deal: any; stages: any[]; onClose: () => void; onMessage: (d: any) => void;
}) {
  const qc = useQueryClient();
  const { currency, format } = useCurrency();

  const { data: notes = [] } = useQuery({
    queryKey: ["deal-notes", deal?.id],
    enabled: !!deal?.id,
    queryFn: async () => {
      const { data } = await supabase.from("deal_notes")
        .select("*").eq("deal_id", deal.id).order("created_at", { ascending: false });
      return data ?? [];
    },
  });

  const { data: activities = [] } = useQuery({
    queryKey: ["deal-activities", deal?.id],
    enabled: !!deal?.id,
    queryFn: async () => {
      const { data } = await supabase.from("deal_activities")
        .select("*").eq("deal_id", deal.id).order("created_at", { ascending: false }).limit(50);
      return data ?? [];
    },
  });

  const [noteBody, setNoteBody] = useState("");
  const [newTag, setNewTag] = useState("");

  async function addNote() {
    if (!noteBody.trim() || !deal) return;
    const { data: u } = await supabase.auth.getUser();
    const { error } = await supabase.from("deal_notes").insert({
      workspace_id: deal.workspace_id, deal_id: deal.id, user_id: u.user!.id, body: noteBody.trim(),
    });
    if (error) return toast.error(error.message);
    await logActivity(deal.workspace_id, deal.id, "note_added", { preview: noteBody.trim().slice(0, 80) });
    setNoteBody("");
    qc.invalidateQueries({ queryKey: ["deal-notes", deal.id] });
    qc.invalidateQueries({ queryKey: ["deal-activities", deal.id] });
  }

  async function deleteNote(id: string) {
    await supabase.from("deal_notes").delete().eq("id", id);
    qc.invalidateQueries({ queryKey: ["deal-notes", deal.id] });
  }

  async function addTag(t: string) {
    const tag = t.trim();
    if (!tag || !deal) return;
    const existing: string[] = deal.tags ?? [];
    if (existing.includes(tag)) return;
    const next = [...existing, tag];
    await supabase.from("deals").update({ tags: next }).eq("id", deal.id);
    await logActivity(deal.workspace_id, deal.id, "tag_added", { tag });
    setNewTag("");
    qc.invalidateQueries({ queryKey: ["deals"] });
    qc.invalidateQueries({ queryKey: ["deal-activities", deal.id] });
  }
  async function removeTag(tag: string) {
    if (!deal) return;
    const next = (deal.tags ?? []).filter((t: string) => t !== tag);
    await supabase.from("deals").update({ tags: next }).eq("id", deal.id);
    await logActivity(deal.workspace_id, deal.id, "tag_removed", { tag });
    qc.invalidateQueries({ queryKey: ["deals"] });
    qc.invalidateQueries({ queryKey: ["deal-activities", deal.id] });
  }

  async function changeStage(stageId: string) {
    if (!deal) return;
    const fromStage = stages.find((s: any) => s.id === deal.stage_id);
    const toStage = stages.find((s: any) => s.id === stageId);
    await supabase.from("deals").update({ stage_id: stageId, updated_at: new Date().toISOString() }).eq("id", deal.id);
    await logActivity(deal.workspace_id, deal.id, "stage_changed", { from: fromStage?.name, to: toStage?.name });
    qc.invalidateQueries({ queryKey: ["deals"] });
    qc.invalidateQueries({ queryKey: ["deal-activities", deal.id] });
  }

  return (
    <Dialog open={!!deal} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        {deal && (
          <>
            <DialogHeader>
              <DialogTitle className="pr-6">{deal.title}</DialogTitle>
            </DialogHeader>

            <Tabs defaultValue="overview">
              <TabsList className="grid grid-cols-4 w-full">
                <TabsTrigger value="overview"><User className="h-3.5 w-3.5 mr-1.5" />Overview</TabsTrigger>
                <TabsTrigger value="notes"><StickyNote className="h-3.5 w-3.5 mr-1.5" />Notes ({notes.length})</TabsTrigger>
                <TabsTrigger value="tags"><TagIcon className="h-3.5 w-3.5 mr-1.5" />Tags</TabsTrigger>
                <TabsTrigger value="activity"><History className="h-3.5 w-3.5 mr-1.5" />Activity</TabsTrigger>
              </TabsList>

              <TabsContent value="overview" className="space-y-3 text-sm">
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Stage</span>
                  <Select value={deal.stage_id} onValueChange={changeStage}>
                    <SelectTrigger className="w-44 h-8"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {stages.map((s: any) => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Value</span>
                  <span className="font-medium text-green-700 dark:text-green-400">
                    {Number(deal.value) > 0
                      ? (deal.currency && deal.currency !== currency
                          ? new Intl.NumberFormat(undefined, { style: "currency", currency: deal.currency }).format(Number(deal.value))
                          : format(deal.value))
                      : "—"}
                  </span>
                </div>
                {deal.source && (
                  <div className="flex items-center justify-between">
                    <span className="text-muted-foreground">Source</span>
                    <Badge variant="outline">{deal.source}</Badge>
                  </div>
                )}
                {deal.expected_close_date && (
                  <div className="flex items-center justify-between">
                    <span className="text-muted-foreground">Expected close</span>
                    <span className="font-medium">{new Date(deal.expected_close_date).toLocaleDateString()}</span>
                  </div>
                )}
                {deal.contacts && (
                  <div className="rounded-lg border p-3 space-y-1">
                    <p className="font-medium flex items-center gap-1.5"><User className="h-3.5 w-3.5" />{deal.contacts.name}</p>
                    {deal.contacts.phone && (
                      <p className="text-xs text-muted-foreground">{deal.contacts.phone}</p>
                    )}
                  </div>
                )}
                {deal.notes && (
                  <div className="rounded-lg bg-muted/40 p-3">
                    <p className="text-xs flex items-center gap-1 text-muted-foreground mb-1"><StickyNote className="h-3 w-3" />Initial note</p>
                    <p className="whitespace-pre-wrap text-sm">{deal.notes}</p>
                  </div>
                )}
                <div className="flex gap-2 pt-2">
                  {deal.contacts?.phone && (
                    <Button variant="outline" className="flex-1" asChild>
                      <a href={`tel:${deal.contacts.phone}`}><Phone className="h-4 w-4 mr-1.5" />Call</a>
                    </Button>
                  )}
                  <Button className="flex-1" onClick={() => onMessage(deal)} disabled={!deal.contact_id}>
                    <MessageCircle className="h-4 w-4 mr-1.5" />Message
                  </Button>
                </div>
              </TabsContent>

              <TabsContent value="notes" className="space-y-3">
                <div className="flex gap-2">
                  <Textarea
                    value={noteBody}
                    onChange={(e) => setNoteBody(e.target.value)}
                    placeholder="Add a note..."
                    rows={2}
                  />
                  <Button onClick={addNote} disabled={!noteBody.trim()}>Add</Button>
                </div>
                <div className="space-y-2">
                  {notes.length === 0 && <p className="text-sm text-muted-foreground text-center py-6">No notes yet.</p>}
                  {notes.map((n: any) => (
                    <div key={n.id} className="rounded-lg border p-3 group">
                      <div className="flex items-start justify-between gap-2">
                        <p className="text-sm whitespace-pre-wrap flex-1">{n.body}</p>
                        <button onClick={() => deleteNote(n.id)} className="opacity-0 group-hover:opacity-100 text-muted-foreground hover:text-destructive">
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      </div>
                      <p className="text-[11px] text-muted-foreground mt-1.5">{new Date(n.created_at).toLocaleString()}</p>
                    </div>
                  ))}
                </div>
              </TabsContent>

              <TabsContent value="tags" className="space-y-3">
                <TagPicker
                  workspaceId={deal.workspace_id}
                  current={deal.tags ?? []}
                  onAdd={addTag}
                />
                <div className="flex flex-wrap gap-1.5">
                  {(deal.tags ?? []).length === 0 && <p className="text-sm text-muted-foreground">No tags yet.</p>}
                  {(deal.tags ?? []).map((t: string) => (
                    <Badge key={t} variant="secondary" className="gap-1">
                      {t}
                      <button onClick={() => removeTag(t)}><X className="h-3 w-3" /></button>
                    </Badge>
                  ))}
                </div>
                <div className="flex gap-2">
                  <Input
                    value={newTag}
                    onChange={(e) => setNewTag(e.target.value)}
                    placeholder="Custom tag…"
                    onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); addTag(newTag); } }}
                  />
                  <Button onClick={() => addTag(newTag)} disabled={!newTag.trim()}>Add</Button>
                </div>
              </TabsContent>

              <TabsContent value="activity">
                <div className="space-y-2">
                  {activities.length === 0 && <p className="text-sm text-muted-foreground text-center py-6">No activity yet.</p>}
                  {activities.map((a: any) => (
                    <div key={a.id} className="flex gap-3 text-sm border-l-2 border-primary/40 pl-3 py-1">
                      <div className="flex-1">
                        <p>{activityLabel(a)}</p>
                        <p className="text-[11px] text-muted-foreground">{new Date(a.created_at).toLocaleString()}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </TabsContent>
            </Tabs>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}

function activityLabel(a: any) {
  const d = a.data || {};
  switch (a.type) {
    case "created": return `Deal created${d.title ? ` — ${d.title}` : ""}`;
    case "stage_changed": return `Stage changed: ${d.from ?? "—"} → ${d.to ?? "—"}`;
    case "note_added": return `Note added${d.preview ? `: "${d.preview}"` : ""}`;
    case "tag_added": return `Tag added: ${d.tag}`;
    case "tag_removed": return `Tag removed: ${d.tag}`;
    case "lead_imported": return `Lead imported from ${d.source ?? d.provider ?? "external source"}`;
    case "message_opened": return `Opened WhatsApp conversation`;
    case "value_changed": return `Value changed: ${d.from ?? 0} → ${d.to ?? 0}`;
    default: return a.type;
  }
}

// ===================== Tag library picker =====================
function TagPicker({ workspaceId, current, onAdd }: {
  workspaceId: string; current: string[]; onAdd: (t: string) => void;
}) {
  const qc = useQueryClient();
  const { data: lib = [] } = useQuery({
    queryKey: ["deal-tag-library", workspaceId],
    queryFn: async () => {
      const { data } = await supabase.from("deal_tags").select("*")
        .eq("workspace_id", workspaceId).order("name");
      return data ?? [];
    },
  });
  const [creating, setCreating] = useState(false);
  const [name, setName] = useState("");

  async function createLibTag() {
    if (!name.trim()) return;
    const { error } = await supabase.from("deal_tags").insert({
      workspace_id: workspaceId, name: name.trim(),
    });
    if (error) return toast.error(error.message);
    setName("");
    setCreating(false);
    qc.invalidateQueries({ queryKey: ["deal-tag-library"] });
  }

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <Label className="text-xs text-muted-foreground">Tag library</Label>
        <Button size="sm" variant="ghost" onClick={() => setCreating(!creating)}>
          <Plus className="h-3 w-3 mr-1" />New
        </Button>
      </div>
      {creating && (
        <div className="flex gap-2">
          <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Tag name" />
          <Button size="sm" onClick={createLibTag}>Save</Button>
        </div>
      )}
      <div className="flex flex-wrap gap-1.5">
        {lib.length === 0 && <p className="text-xs text-muted-foreground">No saved tags. Create one above or add a custom tag below.</p>}
        {lib.filter((t: any) => !current.includes(t.name)).map((t: any) => (
          <button
            key={t.id}
            onClick={() => onAdd(t.name)}
            className="text-xs px-2 py-1 rounded-md border hover:bg-accent"
            style={{ borderColor: t.color }}
          >
            + {t.name}
          </button>
        ))}
      </div>
    </div>
  );
}

// ===================== Stage Manager =====================
function StageManager({ open, onClose, workspaceId, stages }: {
  open: boolean; onClose: () => void; workspaceId: string | null; stages: any[];
}) {
  const qc = useQueryClient();
  const [name, setName] = useState("");
  const [color, setColor] = useState(STAGE_COLORS[0]);
  const [editId, setEditId] = useState<string | null>(null);

  async function addStage() {
    if (!name.trim() || !workspaceId) return;
    const maxPos = stages.length ? Math.max(...stages.map((s: any) => s.position)) : -1;
    const { error } = await supabase.from("pipeline_stages").insert({
      workspace_id: workspaceId, name: name.trim(), color, position: maxPos + 1,
    });
    if (error) return toast.error(error.message);
    setName(""); setColor(STAGE_COLORS[0]);
    qc.invalidateQueries({ queryKey: ["pipeline-stages"] });
  }

  async function updateStage(id: string, patch: any) {
    const { error } = await supabase.from("pipeline_stages").update(patch).eq("id", id);
    if (error) return toast.error(error.message);
    qc.invalidateQueries({ queryKey: ["pipeline-stages"] });
  }

  async function removeStage(id: string) {
    const { count } = await supabase.from("deals")
      .select("id", { count: "exact", head: true }).eq("stage_id", id);
    if ((count ?? 0) > 0) {
      return toast.error(`Cannot delete: ${count} deals are in this stage. Move them first.`);
    }
    const { error } = await supabase.from("pipeline_stages").delete().eq("id", id);
    if (error) return toast.error(error.message);
    qc.invalidateQueries({ queryKey: ["pipeline-stages"] });
  }

  async function move(id: string, dir: -1 | 1) {
    const idx = stages.findIndex((s: any) => s.id === id);
    const swap = stages[idx + dir];
    if (!swap) return;
    const me = stages[idx];
    await supabase.from("pipeline_stages").update({ position: swap.position }).eq("id", me.id);
    await supabase.from("pipeline_stages").update({ position: me.position }).eq("id", swap.id);
    qc.invalidateQueries({ queryKey: ["pipeline-stages"] });
  }

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Manage pipeline stages</DialogTitle>
        </DialogHeader>

        <div className="space-y-2">
          {stages.map((s: any, idx: number) => (
            <div key={s.id} className="flex items-center gap-2 border rounded-lg p-2">
              <input
                type="color"
                value={s.color}
                onChange={(e) => updateStage(s.id, { color: e.target.value })}
                className="h-8 w-10 rounded cursor-pointer"
              />
              {editId === s.id ? (
                <Input
                  autoFocus
                  defaultValue={s.name}
                  onBlur={(e) => { updateStage(s.id, { name: e.target.value }); setEditId(null); }}
                  onKeyDown={(e) => { if (e.key === "Enter") { (e.target as HTMLInputElement).blur(); } }}
                />
              ) : (
                <span className="flex-1 font-medium text-sm">{s.name}</span>
              )}
              <div className="flex items-center gap-1 text-xs">
                <label className="flex items-center gap-1 cursor-pointer">
                  <input type="checkbox" checked={s.is_won}
                    onChange={(e) => updateStage(s.id, { is_won: e.target.checked, is_lost: e.target.checked ? false : s.is_lost })} />
                  Won
                </label>
                <label className="flex items-center gap-1 cursor-pointer">
                  <input type="checkbox" checked={s.is_lost}
                    onChange={(e) => updateStage(s.id, { is_lost: e.target.checked, is_won: e.target.checked ? false : s.is_won })} />
                  Lost
                </label>
              </div>
              <Button size="sm" variant="ghost" disabled={idx === 0} onClick={() => move(s.id, -1)}>↑</Button>
              <Button size="sm" variant="ghost" disabled={idx === stages.length - 1} onClick={() => move(s.id, 1)}>↓</Button>
              <Button size="sm" variant="ghost" onClick={() => setEditId(s.id)}><Pencil className="h-3.5 w-3.5" /></Button>
              <Button size="sm" variant="ghost" onClick={() => removeStage(s.id)}>
                <Trash2 className="h-3.5 w-3.5 text-destructive" />
              </Button>
            </div>
          ))}
        </div>

        <div className="border-t pt-4 space-y-2">
          <Label>Add new stage</Label>
          <div className="flex gap-2 items-center">
            <input
              type="color"
              value={color}
              onChange={(e) => setColor(e.target.value)}
              className="h-9 w-12 rounded cursor-pointer"
            />
            <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Stage name" />
            <Button onClick={addStage}>Add</Button>
          </div>
          <div className="flex gap-1 flex-wrap">
            {STAGE_COLORS.map((c) => (
              <button
                key={c}
                onClick={() => setColor(c)}
                className="h-5 w-5 rounded-full border-2"
                style={{ background: c, borderColor: color === c ? "#000" : "transparent" }}
              />
            ))}
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Done</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
