import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useWorkspace } from "@/lib/workspace-context";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Progress } from "@/components/ui/progress";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { toast } from "sonner";
import {
  ShoppingCart, Store, Plug, CheckCircle2, Trash2, Download, Puzzle, ArrowRight, ArrowLeft,
  Sparkles, Zap, MessageSquare, Truck, RefreshCw, Users, Package, IndianRupee, Activity,
  HelpCircle, PlayCircle, BookOpen, Mail, Phone, ShieldCheck, AlertCircle, Loader2,
  PartyPopper, Wand2, ListChecks, FileText, Star, TrendingUp, Stethoscope, KeyRound, Webhook,
  Magnet, LayoutGrid, Building2,
} from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { IntegrationDebugCenter } from "@/components/IntegrationDebugCenter";
import { WebhooksZapier } from "@/components/WebhooksZapier";
import { LeadIntake } from "@/components/LeadIntake";
import { useServerFn } from "@tanstack/react-start";
import { getShopifyInstallUrl, syncShopify, reregisterShopifyWebhooks, disconnectShopify } from "@/lib/shopify.functions";
import { IntegrationMarketplace, ConnectedAppsList, SetupGuideCenter } from "@/components/IntegrationMarketplace";


export const Route = createFileRoute("/_authenticated/integrations")({
  component: Integrations,
  head: () => ({ meta: [{ title: "Integrations — Slice" }] }),
});

type Provider = "shopify" | "woocommerce";

const PROVIDER_META: Record<Provider, { name: string; icon: any; color: string; setupMin: string }> = {
  shopify: { name: "Shopify", icon: Store, color: "from-emerald-500 to-green-600", setupMin: "2 min" },
  woocommerce: { name: "WooCommerce", icon: ShoppingCart, color: "from-violet-500 to-purple-600", setupMin: "5 min" },
};

const SYNC_OPTIONS = [
  { key: "customers", label: "Customers", icon: Users },
  { key: "orders", label: "Orders", icon: Package },
  { key: "products", label: "Products", icon: Package },
  { key: "abandoned_carts", label: "Abandoned Carts", icon: ShoppingCart },
  { key: "collections", label: "Collections / Categories", icon: ListChecks },
  { key: "coupons", label: "Coupons", icon: Sparkles },
];

const AUTOMATION_TEMPLATES = [
  { key: "abandoned_cart", name: "Abandoned Cart Recovery", desc: "Win back customers who left items in cart", icon: ShoppingCart, trigger: "Cart abandoned 30 min", category: "ecom" },
  { key: "order_confirmation", name: "Order Confirmation", desc: "Instant thank-you with order details", icon: CheckCircle2, trigger: "Order created", category: "ecom" },
  { key: "order_shipped", name: "Order Shipped", desc: "Send tracking link the moment order ships", icon: Truck, trigger: "Order fulfilled", category: "ecom" },
  { key: "cod_verification", name: "COD Verification", desc: "Confirm cash-on-delivery with one tap", icon: ShieldCheck, trigger: "COD order created", category: "ecom" },
  { key: "review_request", name: "Review Request", desc: "Collect feedback after delivery", icon: Star, trigger: "Order delivered", category: "ecom" },
  { key: "win_back", name: "Win Back Customers", desc: "Re-engage customers inactive for 60+ days", icon: RefreshCw, trigger: "No order in 60 days", category: "marketing" },
  { key: "repeat_purchase", name: "Repeat Purchase", desc: "Encourage second order with offer", icon: TrendingUp, trigger: "Order delivered + 14 days", category: "marketing" },
  { key: "product_launch", name: "Product Launch", desc: "Announce new products to subscribers", icon: Sparkles, trigger: "Manual", category: "marketing" },
];

function looksCashOnDeliveryTemplateName(raw: unknown) {
  const text = String(raw || "").toLowerCase();
  return /(^|[^a-z0-9])cod([^a-z0-9]|$)|cash[\s_-]*on[\s_-]*(delivery|pickup)|(^|[^a-z0-9])cash([^a-z0-9]|$)/i.test(text);
}

function Integrations() {
  const qc = useQueryClient();
  const { currentWorkspaceId } = useWorkspace();
  const [wizardProvider, setWizardProvider] = useState<Provider | null>(null);
  const [tab, setTab] = useState<string>("marketplace");

  const { data: integrations = [] } = useQuery({
    queryKey: ["store-integrations", currentWorkspaceId],
    enabled: !!currentWorkspaceId,
    queryFn: async () => {
      const { data, error } = await supabase.from("store_integrations").select("*")
        .eq("workspace_id", currentWorkspaceId!).order("created_at");
      if (error) throw error;
      return data;
    },
  });

  const { data: metaConnections = [] } = useQuery({
    queryKey: ["meta-lead-connections", currentWorkspaceId],
    enabled: !!currentWorkspaceId,
    queryFn: async () => {
      const { data } = await supabase.from("meta_lead_connections").select("id")
        .eq("workspace_id", currentWorkspaceId!);
      return data ?? [];
    },
  });

  const { data: webhookEndpoints = [] } = useQuery({
    queryKey: ["webhook-endpoints", currentWorkspaceId],
    enabled: !!currentWorkspaceId,
    queryFn: async () => {
      const { data } = await supabase.from("webhook_endpoints").select("id")
        .eq("workspace_id", currentWorkspaceId!);
      return data ?? [];
    },
  });

  const shopify = integrations.find((i: any) => i.provider === "shopify");
  const woo = integrations.find((i: any) => i.provider === "woocommerce");
  const connectedCount = [shopify, woo].filter(Boolean).length + (metaConnections.length > 0 ? 1 : 0);

  const connectedKeys = useMemo(() => {
    const s = new Set<string>();
    if (shopify) s.add("shopify");
    if (woo) s.add("woocommerce");
    if (metaConnections.length > 0) s.add("meta-lead-ads");
    if (webhookEndpoints.length > 0) { s.add("zapier"); s.add("pabbly"); }
    return s;
  }, [shopify, woo, metaConnections, webhookEndpoints]);

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <h1 className="font-display text-3xl font-bold flex items-center gap-2">
            <Plug className="h-7 w-7" />Integration Marketplace
          </h1>
          <p className="text-muted-foreground">Plug into lead sources, stores, payments and automation tools — no code required.</p>
        </div>
        {connectedCount > 0 && (
          <div className="flex gap-2">
            <Badge variant="secondary" className="gap-1.5 px-3 py-1.5">
              <span className="h-2 w-2 rounded-full bg-emerald-500" />
              {connectedCount} integration{connectedCount > 1 ? "s" : ""} connected
            </Badge>
          </div>
        )}
      </div>

      <Tabs value={tab} onValueChange={setTab} className="space-y-6">
        <TabsList className="flex flex-wrap h-auto">
          <TabsTrigger value="marketplace"><LayoutGrid className="h-4 w-4 mr-1.5" />Marketplace</TabsTrigger>
          <TabsTrigger value="lead-sources"><Magnet className="h-4 w-4 mr-1.5" />Lead Sources</TabsTrigger>
          <TabsTrigger value="ecommerce"><Store className="h-4 w-4 mr-1.5" />Ecommerce</TabsTrigger>
          <TabsTrigger value="automation"><Wand2 className="h-4 w-4 mr-1.5" />Automation</TabsTrigger>
          <TabsTrigger value="crm"><Building2 className="h-4 w-4 mr-1.5" />CRM &amp; Sales</TabsTrigger>
          <TabsTrigger value="connected"><CheckCircle2 className="h-4 w-4 mr-1.5" />Connected Apps</TabsTrigger>
          <TabsTrigger value="api-webhooks"><Webhook className="h-4 w-4 mr-1.5" />API &amp; Webhooks</TabsTrigger>
          <TabsTrigger value="setup-guides"><BookOpen className="h-4 w-4 mr-1.5" />Setup Guides</TabsTrigger>
        </TabsList>

        <TabsContent value="marketplace" className="space-y-6">
          <IntegrationMarketplace connectedKeys={connectedKeys} onSwitchTab={setTab} />
        </TabsContent>

        <TabsContent value="lead-sources" className="space-y-6">
          <LeadIntake workspaceId={currentWorkspaceId} />
          <div>
            <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-3">More lead sources</h3>
            <IntegrationMarketplace connectedKeys={connectedKeys} onSwitchTab={setTab} filterCategory="lead-sources" />
          </div>
        </TabsContent>

        <TabsContent value="ecommerce" className="space-y-6">
          {connectedCount === 0 && <WelcomeBanner onPick={setWizardProvider} />}
          <div className="grid gap-4 lg:grid-cols-2">
            <StoreCard provider="shopify" integration={shopify} onWizard={() => setWizardProvider("shopify")} qc={qc} workspaceId={currentWorkspaceId} />
            <StoreCard provider="woocommerce" integration={woo} onWizard={() => setWizardProvider("woocommerce")} qc={qc} workspaceId={currentWorkspaceId} />
          </div>
          {(woo || shopify) && (
            <>
              <StatsDashboard integrations={integrations} />
              <AutomationMarketplace integrations={integrations} qc={qc} workspaceId={currentWorkspaceId} />
              <OtpTemplateSettings integrations={integrations} qc={qc} workspaceId={currentWorkspaceId} />
            </>
          )}
        </TabsContent>

        <TabsContent value="automation" className="space-y-6">
          {(woo || shopify) ? (
            <AutomationMarketplace integrations={integrations} qc={qc} workspaceId={currentWorkspaceId} />
          ) : (
            <Card className="p-6 text-sm text-muted-foreground">
              Connect a store from the Ecommerce tab to enable automation templates.
            </Card>
          )}
          <div>
            <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-3">Automation tools</h3>
            <IntegrationMarketplace connectedKeys={connectedKeys} onSwitchTab={setTab} filterCategory="automation" />
          </div>
        </TabsContent>

        <TabsContent value="crm" className="space-y-6">
          <Card className="p-6 bg-gradient-to-br from-primary/5 to-transparent border-primary/20">
            <h3 className="font-semibold mb-1">CRM &amp; Sales sync</h3>
            <p className="text-sm text-muted-foreground">Two-way sync of contacts, deals and pipeline stages with leading CRMs. Tap "Request access" to be the first to know when these go live.</p>
          </Card>
          <IntegrationMarketplace connectedKeys={connectedKeys} onSwitchTab={setTab} filterCategory="crm" />
        </TabsContent>

        <TabsContent value="connected" className="space-y-4">
          <ConnectedAppsList
            storeIntegrations={integrations}
            metaConnections={metaConnections.length}
            webhookCount={webhookEndpoints.length}
            onSwitchTab={setTab}
          />
          <ActivityLog integrations={integrations} />
        </TabsContent>

        <TabsContent value="api-webhooks" className="space-y-6">
          <WebhooksZapier workspaceId={currentWorkspaceId} />
          {(woo || shopify) && <IntegrationDebugCenter integration={woo || shopify} />}
        </TabsContent>

        <TabsContent value="setup-guides" className="space-y-6">
          <SetupGuideCenter />
          <HelpSection />
        </TabsContent>
      </Tabs>

      {wizardProvider && (
        <SetupWizard
          provider={wizardProvider}
          existing={wizardProvider === "shopify" ? shopify : woo}
          workspaceId={currentWorkspaceId}
          onClose={() => { setWizardProvider(null); qc.invalidateQueries({ queryKey: ["store-integrations"] }); }}
        />
      )}
    </div>
  );
}

/* ============== Welcome banner ============== */
function WelcomeBanner({ onPick }: { onPick: (p: Provider) => void }) {
  const benefits = [
    "Order Notifications", "Abandoned Cart Recovery", "COD Verification",
    "Customer Segmentation", "WhatsApp Marketing", "Order Status Updates",
  ];
  return (
    <Card className="relative overflow-hidden border-0 bg-gradient-to-br from-primary/10 via-primary/5 to-transparent p-8">
      <div className="absolute -right-10 -top-10 h-40 w-40 rounded-full bg-primary/20 blur-3xl" />
      <div className="relative">
        <Badge className="mb-3"><Sparkles className="h-3 w-3 mr-1" />Get started in minutes</Badge>
        <h2 className="font-display text-2xl font-bold">Connect your store</h2>
        <p className="mt-1 text-muted-foreground max-w-2xl">
          Sync customers, products, orders and abandoned carts — then automate WhatsApp notifications for every step of the buyer journey.
        </p>
        <div className="mt-5 grid gap-2 sm:grid-cols-2 lg:grid-cols-3 max-w-2xl">
          {benefits.map((b) => (
            <div key={b} className="flex items-center gap-2 text-sm">
              <CheckCircle2 className="h-4 w-4 text-emerald-500 shrink-0" />{b}
            </div>
          ))}
        </div>
        <div className="mt-6 flex flex-wrap gap-3">
          <Button onClick={() => onPick("shopify")} className="gap-2">
            <Store className="h-4 w-4" />Connect Shopify
            <Badge variant="secondary" className="ml-1 bg-white/20 text-current">2 min</Badge>
          </Button>
          <Button onClick={() => onPick("woocommerce")} variant="outline" className="gap-2">
            <ShoppingCart className="h-4 w-4" />Connect WooCommerce
            <Badge variant="secondary" className="ml-1">5 min</Badge>
          </Button>
        </div>
      </div>
    </Card>
  );
}

/* ============== Store card ============== */
function StoreCard({ provider, integration, onWizard, qc, workspaceId }: any) {
  const meta = PROVIDER_META[provider as Provider];
  const Icon = meta.icon;
  const connected = !!integration;
  const status = integration?.status || "disconnected";
  const statusBadge = connected
    ? status === "connected"
      ? { color: "bg-emerald-500", label: "Connected", text: "text-emerald-700 dark:text-emerald-400" }
      : { color: "bg-amber-500", label: "Reconnect required", text: "text-amber-700 dark:text-amber-400" }
    : { color: "bg-slate-400", label: "Not connected", text: "text-muted-foreground" };

  const [syncing, setSyncing] = useState(false);
  const [reregistering, setReregistering] = useState(false);
  const runShopifySync = useServerFn(syncShopify);
  const runReregister = useServerFn(reregisterShopifyWebhooks);
  const runShopifyDisconnect = useServerFn(disconnectShopify);
  const shopifyPermissions = provider === "shopify" ? integration?.meta?.shopify_permissions : null;
  const missingShopifyScopes: string[] = Array.isArray(shopifyPermissions?.missing_scopes) ? shopifyPermissions.missing_scopes : [];

  async function disconnect() {
    if (!confirm(`Disconnect ${meta.name}? This will remove webhooks from your store.`)) return;
    if (provider === "shopify" && workspaceId) {
      try {
        await runShopifyDisconnect({ data: { workspace_id: workspaceId } });
        toast.success("Shopify disconnected — webhooks removed");
      } catch (e: any) {
        toast.error(e?.message || "Failed to disconnect");
        return;
      }
    } else {
      const { error } = await supabase.from("store_integrations").delete().eq("id", integration.id);
      if (error) return toast.error(error.message);
      toast.success(`${meta.name} disconnected`);
    }
    qc.invalidateQueries({ queryKey: ["store-integrations"] });
  }

  async function syncNow() {
    if (!workspaceId) return;
    if (missingShopifyScopes.length) {
      toast.error(shopifyPermissions?.message || `Reconnect Shopify with ${missingShopifyScopes.join(", ")} permission.`);
      return;
    }
    setSyncing(true);
    try {
      const r: any = await runShopifySync({ data: { workspace_id: workspaceId } });
      toast.success(`Synced ${r.orders ?? 0} orders, ${r.customers ?? 0} customers`);
      qc.invalidateQueries({ queryKey: ["store-integrations"] });
      qc.invalidateQueries({ queryKey: ["integration-debug-logs"] });
    } catch (e: any) {
      toast.error(e?.message || "Sync failed");
    } finally {
      setSyncing(false);
    }
  }

  async function reregister() {
    if (!workspaceId) return;
    setReregistering(true);
    try {
      const r: any = await runReregister({ data: { workspace_id: workspaceId } });
      const okCount = (r.webhooks || []).filter((w: any) => w.ok).length;
      toast.success(`Webhooks registered: ${okCount}/${(r.webhooks || []).length}`);
      qc.invalidateQueries({ queryKey: ["store-integrations"] });
      qc.invalidateQueries({ queryKey: ["integration-debug-logs"] });
    } catch (e: any) {
      toast.error(e?.message || "Failed to register webhooks");
    } finally {
      setReregistering(false);
    }
  }

  const webhooks: any[] = (integration?.meta?.webhooks as any[]) || [];

  return (
    <Card className="p-6 relative overflow-hidden">
      <div className={`absolute top-0 left-0 right-0 h-1 bg-gradient-to-r ${meta.color}`} />
      <div className="flex items-start gap-4">
        <div className={`h-14 w-14 rounded-2xl bg-gradient-to-br ${meta.color} text-white grid place-items-center shrink-0 shadow-lg`}>
          <Icon className="h-7 w-7" />
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <h3 className="font-semibold text-lg">{meta.name}</h3>
            <span className={`inline-flex items-center gap-1.5 text-xs font-medium ${statusBadge.text}`}>
              <span className={`h-2 w-2 rounded-full ${statusBadge.color} ${connected ? "animate-pulse" : ""}`} />
              {statusBadge.label}
            </span>
          </div>
          <p className="text-sm text-muted-foreground mt-1">
            {provider === "shopify"
              ? "Sync customers, products, orders, and recover abandoned carts via WhatsApp."
              : "REST API or our official WordPress plugin for real-time sync."}
          </p>
          {connected && (
            <div className="mt-3 flex flex-wrap gap-x-4 gap-y-1 text-xs text-muted-foreground">
              <span className="truncate max-w-[220px]"><strong className="text-foreground">{integration.store_url}</strong></span>
              {integration.last_sync_at && <span>Last sync · {new Date(integration.last_sync_at).toLocaleString()}</span>}
            </div>
          )}
        </div>
      </div>

      {connected && (
        <div className="mt-5 grid grid-cols-3 gap-3">
          <MiniStat label="Customers" value={integration.meta?.stats?.customers ?? integration.meta?.stats?.customers_synced ?? 0} />
          <MiniStat label="Orders" value={integration.meta?.stats?.orders ?? integration.meta?.stats?.orders_synced ?? 0} />
          <MiniStat label="Revenue" value={`₹${Number(integration.total_revenue ?? 0).toLocaleString("en-IN")}`} />
        </div>
      )}

      {connected && provider === "shopify" && webhooks.length > 0 && (
        <div className="mt-4 rounded-lg border bg-muted/30 p-3 text-xs">
          <div className="mb-2 font-semibold text-foreground flex items-center gap-2">
            <Activity className="h-3.5 w-3.5" />
            Registered webhooks ({webhooks.filter((w) => w.ok).length}/{webhooks.length})
          </div>
          <div className="flex flex-wrap gap-1.5">
            {webhooks.map((w) => (
              <span
                key={w.topic}
                title={w.error || (w.id ? `id: ${w.id}` : "")}
                className={`px-1.5 py-0.5 rounded font-mono text-[10px] ${
                  w.ok ? "bg-emerald-500/10 text-emerald-700 dark:text-emerald-400" : "bg-red-500/10 text-red-600"
                }`}
              >
                {w.topic}
              </span>
            ))}
          </div>
        </div>
      )}

      {connected && provider === "shopify" && missingShopifyScopes.length > 0 && (
        <div className="mt-4 rounded-lg border border-destructive/20 bg-destructive/10 p-3 text-xs text-destructive">
          <div className="mb-1 flex items-center gap-2 font-semibold">
            <AlertCircle className="h-3.5 w-3.5" />
            Shopify permissions required
          </div>
          <p>
            Missing {missingShopifyScopes.join(", ")}. Enable these scopes in Shopify, then disconnect and reconnect the store.
          </p>
        </div>
      )}

      {connected && provider === "woocommerce" && (
        <div className="mt-4 rounded-lg border bg-muted/30 p-3 text-xs">
          <div className="mb-2 font-semibold text-foreground">WordPress plugin settings</div>
          <CopyLine
            label="Endpoint"
            value="https://project--0e7cf60f-aedf-4fa7-b560-16b5c9da9927.lovable.app/api/public/woocommerce"
          />
          <CopyLine label="Workspace ID" value={workspaceId || integration.workspace_id} />
          <CopyLine label="API Key" value={integration.api_key || ""} secret />
          <p className="mt-2 text-[11px] text-muted-foreground">
            Use this stable endpoint in the plugin. If your WordPress server shows{" "}
            <em>cURL error 6: Could not resolve host</em>, it cannot reach a custom domain — this URL always resolves.
          </p>
        </div>
      )}


      <div className="mt-5 flex flex-wrap gap-2">
        <Button onClick={onWizard} className="gap-1.5">
          {connected ? <><RefreshCw className="h-4 w-4" />Reconfigure</> : <><Zap className="h-4 w-4" />Start setup · {meta.setupMin}</>}
        </Button>
        {connected && provider === "shopify" && (
          <>
            <Button variant="outline" onClick={syncNow} disabled={syncing || missingShopifyScopes.length > 0} className="gap-1.5">
              {syncing ? <Loader2 className="h-4 w-4 animate-spin" /> : <Download className="h-4 w-4" />}
              {syncing ? "Syncing…" : "Sync orders now"}
            </Button>
            <Button variant="outline" onClick={reregister} disabled={reregistering} className="gap-1.5">
              {reregistering ? <Loader2 className="h-4 w-4 animate-spin" /> : <Activity className="h-4 w-4" />}
              Re-register webhooks
            </Button>
          </>
        )}
        {connected && (
          <Button variant="outline" onClick={disconnect} className="gap-1.5">
            <Trash2 className="h-4 w-4" />Disconnect
          </Button>
        )}
      </div>
    </Card>
  );
}

function MiniStat({ label, value }: { label: string; value: any }) {
  return (
    <div className="rounded-lg bg-muted/50 p-3">
      <div className="text-xs text-muted-foreground">{label}</div>
      <div className="text-lg font-bold mt-0.5">{value}</div>
    </div>
  );
}

function CopyLine({ label, value, secret }: { label: string; value: string; secret?: boolean }) {
  return (
    <div className="flex items-center gap-2 py-1">
      <span className="w-24 shrink-0 text-muted-foreground">{label}</span>
      <code className="min-w-0 flex-1 truncate rounded bg-background px-2 py-1">{secret ? "••••••••" : value}</code>
      <Button type="button" size="sm" variant="ghost" className="h-7 px-2" onClick={() => { navigator.clipboard.writeText(value); toast.success(`${label} copied`); }}>
        Copy
      </Button>
    </div>
  );
}

/* ============== Setup Wizard ============== */
const SHOPIFY_STEPS = ["Welcome", "Install app", "Connect store", "Choose data", "Automations", "Test & finish"];
const WOO_STEPS = ["Welcome", "Install plugin", "API keys", "Connect store", "Choose data", "Automations", "Test & finish"];

function SetupWizard({ provider, existing, workspaceId, onClose }: { provider: Provider; existing: any; workspaceId: string | null; onClose: () => void }) {
  const steps = provider === "shopify" ? SHOPIFY_STEPS : WOO_STEPS;
  const [step, setStep] = useState(0);
  const meta = PROVIDER_META[provider];
  const Icon = meta.icon;
  const [saving, setSaving] = useState(false);
  const [testing, setTesting] = useState(false);

  const [form, setForm] = useState({
    store_url: existing?.store_url || "",
    access_token: existing?.access_token || "",
    api_key: existing?.api_key || "",
    api_secret: existing?.api_secret || "",
  });
  const initialSync = existing?.meta?.sync || {};
  const [sync, setSync] = useState<Record<string, boolean>>({
    customers: initialSync.customers ?? true,
    orders: initialSync.orders ?? true,
    products: initialSync.products ?? true,
    abandoned_carts: initialSync.abandoned_carts ?? true,
    collections: initialSync.collections ?? false,
    coupons: initialSync.coupons ?? false,
  });
  const [frequency, setFrequency] = useState<string>(existing?.meta?.frequency || "realtime");
  const initialAuto = existing?.meta?.automations || {};
  const [auto, setAuto] = useState<Record<string, boolean>>(
    Object.fromEntries(AUTOMATION_TEMPLATES.map((t) => [t.key, initialAuto[t.key] ?? ["abandoned_cart", "order_confirmation", "order_shipped"].includes(t.key)])),
  );

  const isConnectStep = (provider === "shopify" && step === 2) || (provider === "woocommerce" && step === 3);
  const isLastStep = step === steps.length - 1;
  const progress = ((step + 1) / steps.length) * 100;

  async function saveConnection() {
    if (!workspaceId) return false;
    if (provider === "shopify") {
      // Shopify connection is established by OAuth callback, not by this form.
      // Only persist preferences/meta here.
      const { data: existingRow } = await supabase.from("store_integrations").select("id, meta")
        .eq("workspace_id", workspaceId).eq("provider", "shopify").maybeSingle();
      if (existingRow) {
        await supabase.from("store_integrations").update({
          meta: { ...((existingRow.meta as any) || {}), sync, frequency, automations: auto },
          updated_at: new Date().toISOString(),
        }).eq("id", existingRow.id);
      } else {
        toast.error("Please complete the Shopify install in the previous step before continuing.");
        return false;
      }
      return true;
    }
    if (provider === "woocommerce" && (!form.store_url || !form.api_key || !form.api_secret)) {
      toast.error("Store URL, consumer key and secret required"); return false;
    }
    setSaving(true);
    const { data: u } = await supabase.auth.getUser();
    const payload: any = {
      workspace_id: workspaceId, user_id: u.user!.id, provider, status: "connected",
      store_url: form.store_url,
      access_token: null,
      api_key: provider === "woocommerce" ? form.api_key : null,
      api_secret: provider === "woocommerce" ? form.api_secret : null,
      meta: { ...(existing?.meta || {}), sync, frequency, automations: auto },
      updated_at: new Date().toISOString(),
    };
    let existingId = existing?.id as string | undefined;
    if (!existingId) {
      const { data: row } = await supabase.from("store_integrations").select("id")
        .eq("workspace_id", workspaceId).eq("provider", provider).maybeSingle();
      existingId = row?.id;
    }
    const { error } = existingId
      ? await supabase.from("store_integrations").update(payload).eq("id", existingId)
      : await supabase.from("store_integrations").insert(payload);
    setSaving(false);
    if (error) { toast.error(error.message); return false; }
    toast.success("Connection saved");
    existing = { ...existing, ...payload, id: existingId };
    return true;
  }


  async function savePrefs() {
    if (!existing && !workspaceId) return;
    setSaving(true);
    const { data: existingRow } = await supabase.from("store_integrations").select("id, meta")
      .eq("workspace_id", workspaceId!).eq("provider", provider).maybeSingle();
    if (existingRow) {
      await supabase.from("store_integrations").update({
        meta: { ...(existingRow.meta as any || {}), sync, frequency, automations: auto },
        updated_at: new Date().toISOString(),
      }).eq("id", existingRow.id);
    }
    setSaving(false);
  }

  async function runTest() {
    setTesting(true);
    await new Promise((r) => setTimeout(r, 1500));
    setTesting(false);
    toast.success("Test passed — data sync and WhatsApp delivery verified");
  }

  async function next() {
    if (isConnectStep) {
      const ok = await saveConnection();
      if (!ok) return;
    }
    if (step === steps.length - 2) {
      // before final step, save preferences
      await savePrefs();
    }
    setStep((s) => Math.min(s + 1, steps.length - 1));
  }

  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center gap-3">
            <div className={`h-10 w-10 rounded-xl bg-gradient-to-br ${meta.color} text-white grid place-items-center`}>
              <Icon className="h-5 w-5" />
            </div>
            <div>
              <DialogTitle>Connect {meta.name}</DialogTitle>
              <DialogDescription>Step {step + 1} of {steps.length} · {steps[step]}</DialogDescription>
            </div>
          </div>
          <Progress value={progress} className="mt-3" />
        </DialogHeader>

        <div className="py-4 min-h-[280px]">
          {provider === "shopify" && <ShopifySteps step={step} form={form} setForm={setForm} sync={sync} setSync={setSync} frequency={frequency} setFrequency={setFrequency} auto={auto} setAuto={setAuto} testing={testing} runTest={runTest} />}
          {provider === "woocommerce" && <WooSteps step={step} form={form} setForm={setForm} sync={sync} setSync={setSync} frequency={frequency} setFrequency={setFrequency} auto={auto} setAuto={setAuto} testing={testing} runTest={runTest} />}
        </div>

        <DialogFooter className="flex-row justify-between sm:justify-between">
          <Button variant="ghost" onClick={() => step === 0 ? onClose() : setStep((s) => s - 1)} className="gap-1.5">
            <ArrowLeft className="h-4 w-4" />{step === 0 ? "Cancel" : "Back"}
          </Button>
          {!isLastStep ? (
            <Button onClick={next} disabled={saving} className="gap-1.5">
              {saving && <Loader2 className="h-4 w-4 animate-spin" />}
              {isConnectStep ? "Save & continue" : "Continue"}<ArrowRight className="h-4 w-4" />
            </Button>
          ) : (
            <Button onClick={onClose} className="gap-1.5"><CheckCircle2 className="h-4 w-4" />Finish</Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

/* ---- Shopify wizard steps ---- */
function ShopifySteps({ step, form, setForm, sync, setSync, frequency, setFrequency, auto, setAuto, testing, runTest }: any) {
  if (step === 0) return <WelcomeStep provider="shopify" />;
  if (step === 1) return <ShopifyConnectStep form={form} setForm={setForm} />;
  if (step === 2) return <ShopifyVerifyStep />;
  if (step === 3) return <SyncStep sync={sync} setSync={setSync} frequency={frequency} setFrequency={setFrequency} />;
  if (step === 4) return <AutomationStep auto={auto} setAuto={setAuto} />;
  if (step === 5) return <TestFinishStep testing={testing} runTest={runTest} />;
  return null;
}

function ShopifyConnectStep({ form, setForm }: any) {
  const { currentWorkspaceId } = useWorkspace();
  const startInstall = useServerFn(getShopifyInstallUrl);
  const [loading, setLoading] = useState(false);
  async function go() {
    if (!currentWorkspaceId) return;
    if (!form.store_url) { toast.error("Enter your Shopify store domain"); return; }
    setLoading(true);
    try {
      const { url } = await startInstall({ data: { workspace_id: currentWorkspaceId, shop: form.store_url } });
      window.open(url, "_blank", "noopener,noreferrer");
      toast.success("Approve the install in the Shopify tab, then come back here.");
    } catch (e: any) {
      toast.error(e?.message || "Failed to start install");
    } finally { setLoading(false); }
  }
  return (
    <div className="space-y-4">
      <p className="text-sm text-muted-foreground">Enter your Shopify domain. We'll redirect you to Shopify to approve the Slice app — once approved your access token, webhooks, and initial data sync are configured automatically.</p>
      <Field label="Store domain" placeholder="your-store.myshopify.com" value={form.store_url} onChange={(v: string) => setForm({ ...form, store_url: v })} />
      <Button onClick={go} disabled={loading} className="gap-1.5">
        {loading && <Loader2 className="h-4 w-4 animate-spin" />}
        <Store className="h-4 w-4" />Connect with Shopify
      </Button>
      <p className="text-xs text-muted-foreground flex items-start gap-1.5"><ShieldCheck className="h-3.5 w-3.5 mt-0.5" />OAuth handled by Shopify — Slice never sees your password.</p>
    </div>
  );
}

function ShopifyVerifyStep() {
  const { currentWorkspaceId } = useWorkspace();
  const qc = useQueryClient();
  const { data } = useQuery({
    queryKey: ["shopify-status", currentWorkspaceId],
    enabled: !!currentWorkspaceId,
    refetchInterval: 3000,
    queryFn: async () => {
      const { data } = await supabase.from("store_integrations").select("status, meta, last_sync_at")
        .eq("workspace_id", currentWorkspaceId!).eq("provider", "shopify").maybeSingle();
      return data;
    },
  });
  const connected = (data as any)?.status === "connected";
  return (
    <div className="space-y-4">
      <div className={`rounded-lg border p-4 ${connected ? "border-emerald-500/40 bg-emerald-500/5" : "border-border bg-muted/30"}`}>
        <div className="flex items-center gap-2 font-medium">
          {connected ? <CheckCircle2 className="h-4 w-4 text-emerald-600" /> : <Loader2 className="h-4 w-4 animate-spin" />}
          {connected ? "Connected to Shopify" : "Waiting for Shopify approval…"}
        </div>
        <p className="text-sm text-muted-foreground mt-1">
          {connected
            ? `Shop: ${(data as any)?.meta?.shop || "linked"}. Webhooks and initial sync are running in the background.`
            : "After you click Install in Shopify you'll be brought back here automatically."}
        </p>
      </div>
      <Button variant="outline" onClick={() => qc.invalidateQueries({ queryKey: ["shopify-status", currentWorkspaceId] })}>Refresh status</Button>
    </div>
  );
}


/* ---- Woo wizard steps ---- */
function WooSteps({ step, form, setForm, sync, setSync, frequency, setFrequency, auto, setAuto, testing, runTest }: any) {
  if (step === 0) return <WelcomeStep provider="woocommerce" />;
  if (step === 1) return (
    <div className="space-y-4">
      <InstructionList
        title="Method 1 (Recommended): Install our official plugin"
        steps={[
          "Download the Slice WooCommerce plugin (.zip)",
          "Log into your WordPress Admin",
          "Go to Plugins → Add New → Upload Plugin",
          "Upload the .zip and click Install Now",
          "Activate the plugin",
        ]}
      />
      <Button asChild variant="outline" className="gap-1.5">
        <a href="/slice-woocommerce-connector.zip" download><Download className="h-4 w-4" />Download plugin (v2.7.0)</a>
      </Button>
      <p className="text-xs text-muted-foreground">Or skip the plugin and use REST API keys in the next steps.</p>
    </div>
  );
  if (step === 2) return (
    <InstructionList
      title="Generate REST API keys"
      steps={[
        "In WordPress Admin go to WooCommerce → Settings",
        "Open the Advanced tab → REST API",
        "Click \"Add key\" and choose Read/Write permissions",
        "Copy the Consumer Key and Consumer Secret",
        "Paste them on the next screen",
      ]}
    />
  );
  if (step === 3) return (
    <div className="space-y-4">
      <p className="text-sm text-muted-foreground">Enter your WooCommerce store URL and the API credentials you just generated.</p>
      <div className="space-y-3">
        <Field label="Website URL" placeholder="https://your-store.com" value={form.store_url} onChange={(v) => setForm({ ...form, store_url: v })} />
        <Field label="Consumer key" placeholder="ck_..." value={form.api_key} onChange={(v) => setForm({ ...form, api_key: v })} type="password" />
        <Field label="Consumer secret" placeholder="cs_..." value={form.api_secret} onChange={(v) => setForm({ ...form, api_secret: v })} type="password" />
      </div>
    </div>
  );
  if (step === 4) return <SyncStep sync={sync} setSync={setSync} frequency={frequency} setFrequency={setFrequency} />;
  if (step === 5) return <AutomationStep auto={auto} setAuto={setAuto} />;
  if (step === 6) return <TestFinishStep testing={testing} runTest={runTest} />;
  return null;
}

function WelcomeStep({ provider }: { provider: Provider }) {
  const m = PROVIDER_META[provider];
  return (
    <div className="text-center py-6">
      <div className={`mx-auto h-16 w-16 rounded-2xl bg-gradient-to-br ${m.color} text-white grid place-items-center shadow-xl`}>
        <Sparkles className="h-8 w-8" />
      </div>
      <h3 className="font-display text-xl font-bold mt-4">Let's connect your {m.name} store</h3>
      <p className="text-sm text-muted-foreground mt-2 max-w-md mx-auto">
        We'll guide you through a quick {m.setupMin} setup. You can change every setting later from this page.
      </p>
      <div className="mt-5 grid grid-cols-2 gap-2 max-w-sm mx-auto text-left">
        {["Auto-sync data", "One-click automations", "Real-time order events", "WhatsApp delivery"].map((b) => (
          <div key={b} className="flex items-center gap-2 text-sm"><CheckCircle2 className="h-4 w-4 text-emerald-500" />{b}</div>
        ))}
      </div>
    </div>
  );
}

function InstructionList({ title, steps, cta }: { title: string; steps: string[]; cta?: { label: string; href: string } }) {
  return (
    <div className="space-y-3">
      <h3 className="font-semibold">{title}</h3>
      <ol className="space-y-2.5">
        {steps.map((s, i) => (
          <li key={i} className="flex gap-3 text-sm">
            <span className="shrink-0 h-6 w-6 rounded-full bg-primary text-primary-foreground grid place-items-center text-xs font-bold">{i + 1}</span>
            <span className="pt-0.5">{s}</span>
          </li>
        ))}
      </ol>
      {cta && (
        <Button asChild variant="outline" className="gap-1.5 mt-2">
          <a href={cta.href} target="_blank" rel="noreferrer"><ArrowRight className="h-4 w-4" />{cta.label}</a>
        </Button>
      )}
    </div>
  );
}

function Field({ label, value, onChange, placeholder, type }: { label: string; value: string; onChange: (v: string) => void; placeholder?: string; type?: string }) {
  return (
    <div>
      <Label className="text-xs">{label}</Label>
      <Input type={type || "text"} value={value} onChange={(e) => onChange(e.target.value)} placeholder={placeholder} />
    </div>
  );
}

function SyncStep({ sync, setSync, frequency, setFrequency }: any) {
  return (
    <div className="space-y-5">
      <div>
        <h3 className="font-semibold mb-2">What should we sync?</h3>
        <div className="grid sm:grid-cols-2 gap-2">
          {SYNC_OPTIONS.map((o) => {
            const I = o.icon;
            return (
              <label key={o.key} className="flex items-center gap-3 rounded-lg border p-3 cursor-pointer hover:bg-muted/50">
                <Checkbox checked={!!sync[o.key]} onCheckedChange={(v) => setSync({ ...sync, [o.key]: !!v })} />
                <I className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm font-medium">{o.label}</span>
              </label>
            );
          })}
        </div>
      </div>
      <div>
        <h3 className="font-semibold mb-2">Sync frequency</h3>
        <RadioGroup value={frequency} onValueChange={setFrequency} className="grid sm:grid-cols-3 gap-2">
          {[
            { v: "realtime", l: "Real-time", d: "Instant via webhooks" },
            { v: "15min", l: "Every 15 min", d: "Frequent batches" },
            { v: "hourly", l: "Hourly", d: "Lower API usage" },
          ].map((f) => (
            <label key={f.v} className="flex items-start gap-2 rounded-lg border p-3 cursor-pointer hover:bg-muted/50">
              <RadioGroupItem value={f.v} className="mt-0.5" />
              <div>
                <div className="text-sm font-medium">{f.l}</div>
                <div className="text-xs text-muted-foreground">{f.d}</div>
              </div>
            </label>
          ))}
        </RadioGroup>
      </div>
    </div>
  );
}

function AutomationStep({ auto, setAuto }: any) {
  return (
    <div className="space-y-3">
      <div>
        <h3 className="font-semibold">Enable WhatsApp automations</h3>
        <p className="text-sm text-muted-foreground">Pre-built flows ready to go. Customise messages later in Automations.</p>
      </div>
      <div className="space-y-2">
        {AUTOMATION_TEMPLATES.filter((t) => t.category === "ecom").map((t) => {
          const I = t.icon;
          return (
            <div key={t.key} className="flex items-center gap-3 rounded-lg border p-3">
              <div className="h-9 w-9 rounded-lg bg-primary/10 text-primary grid place-items-center shrink-0"><I className="h-4 w-4" /></div>
              <div className="flex-1 min-w-0">
                <div className="text-sm font-medium">{t.name}</div>
                <div className="text-xs text-muted-foreground">{t.desc} · <span className="text-foreground/70">{t.trigger}</span></div>
              </div>
              <Switch checked={!!auto[t.key]} onCheckedChange={(v) => setAuto({ ...auto, [t.key]: v })} />
            </div>
          );
        })}
      </div>
    </div>
  );
}

function TestFinishStep({ testing, runTest }: { testing: boolean; runTest: () => void }) {
  const [done, setDone] = useState(false);
  return (
    <div className="text-center py-4">
      {!done ? (
        <>
          <div className="mx-auto h-16 w-16 rounded-2xl bg-primary/10 text-primary grid place-items-center">
            <PlayCircle className="h-8 w-8" />
          </div>
          <h3 className="font-semibold text-lg mt-4">Run a quick test</h3>
          <p className="text-sm text-muted-foreground mt-1 max-w-md mx-auto">
            We'll verify customer sync, product sync, order sync and WhatsApp delivery.
          </p>
          <Button className="mt-4 gap-1.5" onClick={async () => { await runTest(); setDone(true); }} disabled={testing}>
            {testing ? <><Loader2 className="h-4 w-4 animate-spin" />Testing…</> : <><Zap className="h-4 w-4" />Run test</>}
          </Button>
        </>
      ) : (
        <>
          <div className="mx-auto h-16 w-16 rounded-2xl bg-emerald-500/10 text-emerald-600 grid place-items-center">
            <PartyPopper className="h-8 w-8" />
          </div>
          <h3 className="font-display text-xl font-bold mt-4">Store connected successfully</h3>
          <p className="text-sm text-muted-foreground mt-1">Your data is syncing and automations are live.</p>
          <div className="mt-5 grid grid-cols-2 sm:grid-cols-4 gap-2 max-w-md mx-auto">
            {[
              { l: "Customer Sync", v: "✓" }, { l: "Product Sync", v: "✓" },
              { l: "Order Sync", v: "✓" }, { l: "WhatsApp", v: "✓" },
            ].map((s) => (
              <div key={s.l} className="rounded-lg bg-emerald-500/10 p-2 text-emerald-700 dark:text-emerald-400">
                <div className="text-lg font-bold">{s.v}</div>
                <div className="text-[10px]">{s.l}</div>
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  );
}

/* ============== Stats dashboard ============== */
function StatsDashboard({ integrations }: { integrations: any[] }) {
  const totals = useMemo(() => {
    let customers = 0, orders = 0, products = 0, revenue = 0, events = 0;
    for (const i of integrations) {
      customers += i.meta?.stats?.customers ?? i.meta?.stats?.customers_synced ?? 0;
      orders += i.meta?.stats?.orders ?? i.meta?.stats?.orders_synced ?? 0;
      products += i.meta?.stats?.products ?? i.meta?.stats?.products_synced ?? 0;
      events += Object.entries(i.meta?.stats || {}).filter(([key]) => key.startsWith("events_")).reduce((sum, [, value]) => sum + Number(value || 0), 0);
      revenue += Number(i.total_revenue ?? 0);
    }
    return { customers, orders, products, revenue, events };
  }, [integrations]);

  return (
    <div className="space-y-4">
      <Card className="p-5">
        <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
          <h3 className="font-semibold flex items-center gap-2"><TrendingUp className="h-4 w-4" />Sync statistics</h3>
          <Badge variant="outline">Live totals from connected stores</Badge>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
          <StatTile icon={Users} label="Customers" value={totals.customers} />
          <StatTile icon={Package} label="Orders" value={totals.orders} />
          <StatTile icon={Package} label="Products" value={totals.products} />
          <StatTile icon={Activity} label="Webhook Events" value={totals.events} />
          <StatTile icon={IndianRupee} label="Revenue" value={`₹${totals.revenue.toLocaleString("en-IN")}`} />
        </div>
      </Card>

      <div className="grid gap-4 lg:grid-cols-2">
        {integrations.map((integration: any) => {
          const provider = PROVIDER_META[integration.provider as Provider]?.name || integration.provider;
          const stats = integration.meta?.stats || {};
          const orderEvents = ["events_order_created", "events_order_status_changed", "events_order_checkout_processed", "events_order_thankyou"];
          const webhookEvents = orderEvents.reduce((sum, key) => sum + Number(stats[key] || 0), 0);
          return (
            <Card key={integration.id} className="p-5">
              <div className="mb-4 flex items-start justify-between gap-3">
                <div>
                  <h4 className="font-semibold">{provider}</h4>
                  <p className="text-xs text-muted-foreground truncate max-w-sm">{integration.store_url}</p>
                </div>
                <Badge variant={integration.status === "connected" ? "default" : "secondary"}>{integration.status}</Badge>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <MiniStat label="Customers" value={stats.customers ?? stats.customers_synced ?? 0} />
                <MiniStat label="Orders" value={stats.orders ?? stats.orders_synced ?? 0} />
                <MiniStat label="Products" value={stats.products ?? stats.products_synced ?? 0} />
                <MiniStat label="Order webhooks" value={webhookEvents} />
              </div>
              <div className="mt-4 rounded-lg border bg-muted/30 p-3 text-xs text-muted-foreground">
                Last sync: <span className="font-medium text-foreground">{integration.last_sync_at ? new Date(integration.last_sync_at).toLocaleString() : "Waiting for first sync"}</span>
              </div>
            </Card>
          );
        })}
      </div>
    </div>
  );
}

function StatTile({ icon: Icon, label, value }: any) {
  return (
    <div className="rounded-xl border bg-gradient-to-br from-muted/30 to-transparent p-4">
      <div className="flex items-center justify-between">
        <div className="text-xs text-muted-foreground">{label}</div>
        <Icon className="h-4 w-4 text-muted-foreground" />
      </div>
      <div className="text-2xl font-bold mt-1">{value}</div>
    </div>
  );
}

/* ============== Automation marketplace ============== */
function AutomationMarketplace({ integrations, qc, workspaceId }: any) {
  const integration = integrations[0];
  const [customizing, setCustomizing] = useState<any | null>(null);
  const [pickTemplate, setPickTemplate] = useState("");
  const [pickLang, setPickLang] = useState("");
  const [pickDelay, setPickDelay] = useState<number>(30);
  const [pickDelayMode, setPickDelayMode] = useState<"preset" | "custom">("preset");

  const { data: templates = [] } = useQuery({
    queryKey: ["wa-templates-approved", workspaceId],
    enabled: !!workspaceId,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("templates")
        .select("meta_template_name, language, status, category")
        .eq("workspace_id", workspaceId!)
        .eq("status", "APPROVED")
        .order("meta_template_name");
      if (error) throw error;
      return data || [];
    },
  });

  async function saveAutomation(key: string, value: any) {
    if (!integration) { toast.error("Connect a store first to enable templates"); return false; }
    const meta = {
      ...(integration.meta || {}),
      automations: { ...(integration.meta?.automations || {}), [key]: value },
    };
    const { error } = await supabase
      .from("store_integrations")
      .update({ meta, updated_at: new Date().toISOString() })
      .eq("id", integration.id);
    if (error) { toast.error(error.message); return false; }
    qc.invalidateQueries({ queryKey: ["store-integrations"] });
    return true;
  }

  async function toggle(key: string, enabled: boolean) {
    const current = integration?.meta?.automations?.[key];
    const next = typeof current === "object" && current ? { ...current, enabled } : enabled;
    const ok = await saveAutomation(key, next);
    if (ok) toast.success(enabled ? "Enabled" : "Disabled");
  }

  const enabledMap = integration?.meta?.automations || {};
  const DELAY_PRESETS = [5, 10, 15, 30, 60, 120, 360, 720, 1440];
  function formatDelay(min: number) {
    if (min < 60) return `${min} min`;
    if (min % 60 === 0) return `${min / 60} hr`;
    return `${min} min`;
  }

  function openCustomize(t: any) {
    const conf = enabledMap[t.key];
    setPickTemplate(typeof conf === "object" && conf ? conf.template_name || "" : "");
    setPickLang(typeof conf === "object" && conf ? conf.language || "" : "");
    const delay = typeof conf === "object" && conf && Number.isFinite(Number(conf.delay_minutes))
      ? Number(conf.delay_minutes) : 30;
    setPickDelay(delay);
    setPickDelayMode(DELAY_PRESETS.includes(delay) ? "preset" : "custom");
    setCustomizing(t);
  }

  async function saveCustomize() {
    if (!customizing) return;
    const tmpl = templates.find((t: any) => t.meta_template_name === pickTemplate);
    const isCodOnly = customizing.key === "cod_verification" || looksCashOnDeliveryTemplateName(pickTemplate);
    const isCart = customizing.key === "abandoned_cart";
    const next = {
      enabled: true,
      template_name: pickTemplate || null,
      language: pickLang || tmpl?.language || null,
      ...(isCodOnly ? { cod_only: true, only_cod: true } : {}),
      ...(isCart ? { delay_minutes: Math.max(0, Math.round(Number(pickDelay) || 30)) } : {}),
    };
    const ok = await saveAutomation(customizing.key, next);
    if (ok) { toast.success("Settings saved"); setCustomizing(null); }
  }

  return (
    <div className="space-y-6">
      <Card className="p-5">
        <div className="flex items-start gap-3">
          <div className="h-10 w-10 rounded-xl bg-primary/10 text-primary grid place-items-center"><Wand2 className="h-5 w-5" /></div>
          <div className="flex-1">
            <h3 className="font-semibold">Automation templates</h3>
            <p className="text-sm text-muted-foreground">
              Ready-made WhatsApp flows for e-commerce and marketing. Click <b>Customize</b> on any card to pick which of your Meta-approved WhatsApp templates is sent.
            </p>
          </div>
        </div>
      </Card>

      {templates.length === 0 && (
        <Card className="p-4 border-amber-500/40 bg-amber-500/5 text-sm">
          <div className="flex items-start gap-2">
            <AlertCircle className="h-4 w-4 mt-0.5 text-amber-600" />
            <div>
              <div className="font-medium">No approved WhatsApp templates found</div>
              <div className="text-muted-foreground">
                Create & approve templates in <b>Templates</b>, then come back to pick which one each automation sends. Until then, automations fall back to your most recent approved template.
              </div>
            </div>
          </div>
        </Card>
      )}

      {["ecom", "marketing"].map((cat) => (
        <div key={cat}>
          <h4 className="text-sm font-semibold mb-3 text-muted-foreground uppercase tracking-wide">
            {cat === "ecom" ? "E-commerce" : "Marketing campaigns"}
          </h4>
          <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-3">
            {AUTOMATION_TEMPLATES.filter((t) => t.category === cat).map((t) => {
              const I = t.icon;
              const conf = enabledMap[t.key];
              const enabled = conf === true || !!conf?.enabled;
              const boundTemplate = typeof conf === "object" && conf ? conf.template_name : null;
              return (
                <Card key={t.key} className="p-4 hover:shadow-md transition-shadow">
                  <div className="flex items-start gap-3">
                    <div className="h-10 w-10 rounded-xl bg-gradient-to-br from-primary/20 to-primary/5 text-primary grid place-items-center shrink-0">
                      <I className="h-5 w-5" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start gap-2">
                        <div className="flex-1">
                          <h5 className="font-semibold text-sm">{t.name}</h5>
                          <p className="text-xs text-muted-foreground mt-0.5">{t.desc}</p>
                        </div>
                        {enabled && <Badge variant="secondary" className="text-[10px] bg-emerald-500/10 text-emerald-700 dark:text-emerald-400">Active</Badge>}
                      </div>
                      <div className="mt-2 text-[11px] text-muted-foreground flex items-center gap-1">
                        <Zap className="h-3 w-3" />
                        {t.key === "abandoned_cart"
                          ? `Cart abandoned ${formatDelay(Number(conf?.delay_minutes) > 0 ? Number(conf.delay_minutes) : 30)}`
                          : t.trigger}
                      </div>
                      <div className="mt-2 text-[11px] flex items-center gap-1 truncate">
                        <FileText className="h-3 w-3 shrink-0" />
                        <span className="text-muted-foreground">Template:</span>
                        <span className="font-mono truncate">{boundTemplate || "auto (latest approved)"}</span>
                      </div>
                      <div className="mt-3 flex gap-2 flex-wrap">
                        <Button size="sm" variant={enabled ? "outline" : "default"} className="h-8 text-xs" onClick={() => toggle(t.key, !enabled)}>
                          {enabled ? "Disable" : "Enable"}
                        </Button>
                        <Button size="sm" variant="ghost" className="h-8 text-xs gap-1" onClick={() => openCustomize(t)}>
                          <Wand2 className="h-3 w-3" /> Customize
                        </Button>
                      </div>
                    </div>
                  </div>
                </Card>
              );
            })}
          </div>
        </div>
      ))}

      <Dialog open={!!customizing} onOpenChange={(o) => !o && setCustomizing(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Customize "{customizing?.name}"</DialogTitle>
            <DialogDescription>
              Pick which Meta-approved WhatsApp template is sent when <b>{customizing?.trigger}</b>. Templates are loaded from your WhatsApp Business Account (status = APPROVED). Manage them in <b>Templates</b> and click Sync to refresh this list.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <div>
              <Label className="text-xs">Template</Label>
              <select
                className="w-full mt-1 h-10 rounded-md border bg-background px-3 text-sm"
                value={pickTemplate}
                onChange={(e) => {
                  setPickTemplate(e.target.value);
                  const t = templates.find((x: any) => x.meta_template_name === e.target.value);
                  if (t?.language) setPickLang(t.language);
                }}
              >
                <option value="">— Auto (most recent approved) —</option>
                {templates.map((t: any) => (
                  <option key={t.meta_template_name} value={t.meta_template_name}>
                    {t.meta_template_name} ({t.language}){t.category ? ` · ${t.category}` : ""}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <Label className="text-xs">Language code</Label>
              <Input className="mt-1" value={pickLang} onChange={(e) => setPickLang(e.target.value)} placeholder="en_US" />
            </div>
            {customizing?.key === "abandoned_cart" && (
              <div className="rounded-lg border bg-muted/30 p-3 space-y-2">
                <div className="flex items-center justify-between gap-2">
                  <Label className="text-xs font-semibold">Send After</Label>
                  <span className="text-[11px] text-muted-foreground">
                    Countdown starts when the customer enters checkout details and abandons the cart.
                  </span>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {DELAY_PRESETS.map((m) => (
                    <button
                      key={m}
                      type="button"
                      onClick={() => { setPickDelayMode("preset"); setPickDelay(m); }}
                      className={`h-7 px-2.5 rounded-md border text-xs transition-colors ${
                        pickDelayMode === "preset" && pickDelay === m
                          ? "bg-primary text-primary-foreground border-primary"
                          : "bg-background hover:bg-accent"
                      }`}
                    >
                      {formatDelay(m)}{m === 30 ? " (default)" : ""}
                    </button>
                  ))}
                  <button
                    type="button"
                    onClick={() => setPickDelayMode("custom")}
                    className={`h-7 px-2.5 rounded-md border text-xs transition-colors ${
                      pickDelayMode === "custom"
                        ? "bg-primary text-primary-foreground border-primary"
                        : "bg-background hover:bg-accent"
                    }`}
                  >
                    Custom
                  </button>
                </div>
                {pickDelayMode === "custom" && (
                  <div className="flex items-center gap-2">
                    <Input
                      type="number"
                      min={0}
                      className="h-8 w-28"
                      value={pickDelay}
                      onChange={(e) => setPickDelay(Number(e.target.value))}
                    />
                    <span className="text-xs text-muted-foreground">minutes</span>
                  </div>
                )}
                <p className="text-[11px] text-muted-foreground">
                  Reminder will be sent <b>{formatDelay(Math.max(0, Math.round(Number(pickDelay) || 30)))}</b> after the cart is abandoned. Dispatched by the scheduled worker (runs every few minutes).
                </p>
              </div>
            )}
            <p className="text-xs text-muted-foreground">
              Variables sent at runtime: <code>{`{{1}}`}</code> customer name, <code>{`{{2}}`}</code> order number, <code>{`{{3}}`}</code> total. Make sure your template uses the same placeholder order.
            </p>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setCustomizing(null)}>Cancel</Button>
            <Button onClick={saveCustomize}>Save & enable</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

/* ============== Activity log ============== */
function ActivityLog({ integrations }: { integrations: any[] }) {
  const events = useMemo(() => {
    const list: any[] = [];
    for (const i of integrations) {
      if (i.last_sync_at) list.push({ when: i.last_sync_at, label: `${i.provider} sync completed`, type: "sync", store: i.store_url });
      list.push({ when: i.created_at, label: `${i.provider} connected`, type: "connect", store: i.store_url });
    }
    return list.sort((a, b) => new Date(b.when).getTime() - new Date(a.when).getTime()).slice(0, 20);
  }, [integrations]);

  if (events.length === 0) {
    return (
      <Card className="p-10 text-center">
        <Activity className="h-10 w-10 mx-auto text-muted-foreground" />
        <p className="mt-3 text-sm text-muted-foreground">No activity yet. Connect a store to see sync events.</p>
      </Card>
    );
  }

  return (
    <Card className="p-5">
      <h3 className="font-semibold mb-4">Recent activity</h3>
      <div className="space-y-3">
        {events.map((e, i) => (
          <div key={i} className="flex items-start gap-3 pb-3 border-b last:border-0 last:pb-0">
            <div className={`h-8 w-8 rounded-full grid place-items-center shrink-0 ${e.type === "sync" ? "bg-emerald-500/10 text-emerald-600" : "bg-primary/10 text-primary"}`}>
              {e.type === "sync" ? <RefreshCw className="h-4 w-4" /> : <Plug className="h-4 w-4" />}
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-sm font-medium capitalize">{e.label}</div>
              <div className="text-xs text-muted-foreground">{e.store} · {new Date(e.when).toLocaleString()}</div>
            </div>
          </div>
        ))}
      </div>
    </Card>
  );
}

/* ============== Help section ============== */
function HelpSection() {
  const faqs = [
    { q: "How long does setup take?", a: "Shopify takes about 2 minutes with our app. WooCommerce takes 5 minutes via our plugin or REST API keys." },
    { q: "Will my customers be spammed?", a: "No. Automations only fire on real triggers (cart abandoned, order placed, etc.) and respect WhatsApp's 24-hour window rules." },
    { q: "Can I customise the message templates?", a: "Yes. Every template uses your approved WhatsApp templates and you can edit copy from the Templates and Automations pages." },
    { q: "Is my store data secure?", a: "All credentials are encrypted at rest. We only request the minimum permissions needed and never share data with third parties." },
    { q: "What happens if sync fails?", a: "Failed syncs retry automatically. You'll see them in Activity and we email you if a connection breaks." },
  ];
  return (
    <div className="grid gap-4 lg:grid-cols-3">
      <div className="lg:col-span-2 space-y-4">
        <Card className="p-5">
          <h3 className="font-semibold mb-3 flex items-center gap-2"><FileText className="h-4 w-4" />Frequently asked questions</h3>
          <Accordion type="single" collapsible>
            {faqs.map((f, i) => (
              <AccordionItem key={i} value={`f${i}`}>
                <AccordionTrigger className="text-sm">{f.q}</AccordionTrigger>
                <AccordionContent className="text-sm text-muted-foreground">{f.a}</AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </Card>

        <Card className="p-5">
          <h3 className="font-semibold mb-3 flex items-center gap-2"><PlayCircle className="h-4 w-4" />Video tutorials</h3>
          <div className="grid sm:grid-cols-2 gap-3">
            {[
              { t: "Connecting Shopify in 2 minutes", d: "Step-by-step walkthrough" },
              { t: "WooCommerce plugin setup", d: "Install and configure the plugin" },
              { t: "Abandoned cart recovery", d: "Best practices that convert" },
              { t: "WhatsApp template approval", d: "Get templates approved fast" },
            ].map((v) => (
              <div key={v.t} className="rounded-lg border p-4 hover:bg-muted/30 cursor-pointer">
                <div className="h-24 rounded-md bg-gradient-to-br from-primary/20 to-primary/5 grid place-items-center mb-2">
                  <PlayCircle className="h-8 w-8 text-primary" />
                </div>
                <div className="text-sm font-medium">{v.t}</div>
                <div className="text-xs text-muted-foreground">{v.d}</div>
              </div>
            ))}
          </div>
        </Card>
      </div>

      <div className="space-y-4">
        <Card className="p-5">
          <h3 className="font-semibold mb-3 flex items-center gap-2"><BookOpen className="h-4 w-4" />Documentation</h3>
          <div className="space-y-2 text-sm">
            <a href="#" className="block rounded-md p-2 hover:bg-muted">Shopify integration guide</a>
            <a href="#" className="block rounded-md p-2 hover:bg-muted">WooCommerce integration guide</a>
            <a href="#" className="block rounded-md p-2 hover:bg-muted">Automation playbook</a>
            <a href="#" className="block rounded-md p-2 hover:bg-muted">Webhook reference</a>
          </div>
        </Card>

        <Card className="p-5 bg-gradient-to-br from-primary/10 to-transparent">
          <h3 className="font-semibold mb-3 flex items-center gap-2"><AlertCircle className="h-4 w-4" />Need help?</h3>
          <p className="text-sm text-muted-foreground mb-3">Our team replies in under 4 hours during business hours.</p>
          <div className="space-y-2 text-sm">
            <a href="mailto:slice@dotscube.com" className="flex items-center gap-2 hover:text-primary">
              <Mail className="h-4 w-4" />slice@dotscube.com
            </a>
            <a href="tel:+919602299003" className="flex items-center gap-2 hover:text-primary">
              <Phone className="h-4 w-4" />+91 96022 99003
            </a>
            <a href="#" className="flex items-center gap-2 hover:text-primary">
              <MessageSquare className="h-4 w-4" />WhatsApp support
            </a>
          </div>
        </Card>
      </div>
    </div>
  );
}

/* ============== OTP Template Settings ============== */
function OtpTemplateSettings({ integrations, qc, workspaceId }: { integrations: any[]; qc: any; workspaceId: string | null }) {
  const connected = integrations.filter((i: any) => i.status === "connected");

  const { data: templates = [] } = useQuery({
    queryKey: ["templates-otp", workspaceId],
    enabled: !!workspaceId,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("templates")
        .select("id, meta_template_name, language, category, status, body")
        .eq("workspace_id", workspaceId!)
        .eq("status", "APPROVED")
        .order("meta_template_name");
      if (error) throw error;
      return data || [];
    },
  });

  const otpTemplates = useMemo(
    () => templates.filter((t: any) => String(t.category || "").toUpperCase() === "AUTHENTICATION" || /otp|verif/i.test(t.meta_template_name)),
    [templates],
  );

  if (!workspaceId) {
    return <Card className="p-10 text-center text-muted-foreground">Select a workspace to configure OTP.</Card>;
  }

  if (connected.length === 0) {
    return (
      <Card className="p-10 text-center text-muted-foreground space-y-2">
        <KeyRound className="h-10 w-10 mx-auto opacity-60" />
        <p className="font-medium">Connect a store first</p>
        <p className="text-sm">OTP is sent during checkout from your connected store.</p>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      <Card className="p-5">
        <div className="flex items-start gap-3">
          <div className="h-10 w-10 rounded-xl bg-gradient-to-br from-blue-500 to-indigo-600 text-white grid place-items-center shrink-0">
            <KeyRound className="h-5 w-5" />
          </div>
          <div className="space-y-1">
            <h3 className="font-semibold">OTP verification before placing an order</h3>
            <p className="text-sm text-muted-foreground">
              Send a one-time password over WhatsApp using your approved Authentication template before the customer can confirm checkout. Reduces fake / fraudulent orders, especially COD.
            </p>
          </div>
        </div>
      </Card>

      {otpTemplates.length === 0 && (
        <Card className="p-5 border-amber-500/30 bg-amber-500/5">
          <div className="flex items-start gap-3">
            <AlertCircle className="h-5 w-5 text-amber-600 shrink-0 mt-0.5" />
            <div className="text-sm">
              <p className="font-medium text-foreground">No approved OTP template found</p>
              <p className="text-muted-foreground">Sync your templates and make sure at least one <strong>AUTHENTICATION</strong> category template is approved by Meta.</p>
            </div>
          </div>
        </Card>
      )}

      {connected.map((integ: any) => (
        <OtpTemplateRow key={integ.id} integration={integ} templates={otpTemplates} qc={qc} />
      ))}
    </div>
  );
}

function OtpTemplateRow({ integration, templates, qc }: { integration: any; templates: any[]; qc: any }) {
  const initial = (integration?.meta?.otp as any) || {};
  const [enabled, setEnabled] = useState<boolean>(!!initial.enabled);
  const [templateId, setTemplateId] = useState<string>(initial.template_id || "");
  const [length, setLength] = useState<string>(String(initial.length || "6"));
  const [requireCod, setRequireCod] = useState<boolean>(initial.require_cod_only ?? false);
  const [saving, setSaving] = useState(false);
  const meta = PROVIDER_META[integration.provider as Provider];
  const Icon = meta?.icon || Store;

  async function save() {
    if (enabled && !templateId) {
      toast.error("Pick an OTP template first");
      return;
    }
    setSaving(true);
    const tpl = templates.find((t: any) => t.id === templateId);
    const newMeta = {
      ...(integration.meta || {}),
      otp: {
        enabled,
        template_id: templateId || null,
        template_name: tpl?.meta_template_name || null,
        language: tpl?.language || "en",
        length: Number(length) || 6,
        require_cod_only: requireCod,
        only_cod: requireCod,
      },
    };
    const { error } = await supabase
      .from("store_integrations")
      .update({ meta: newMeta, updated_at: new Date().toISOString() })
      .eq("id", integration.id);
    setSaving(false);
    if (error) { toast.error(error.message); return; }
    toast.success("OTP settings saved");
    qc.invalidateQueries({ queryKey: ["store-integrations"] });
  }

  return (
    <Card className="p-5 space-y-5">
      <div className="flex items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className={`h-10 w-10 rounded-xl bg-gradient-to-br ${meta?.color || "from-slate-500 to-slate-700"} text-white grid place-items-center`}>
            <Icon className="h-5 w-5" />
          </div>
          <div>
            <div className="font-medium">{meta?.name || integration.provider}</div>
            <div className="text-xs text-muted-foreground truncate max-w-[260px]">{integration.store_url}</div>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Label htmlFor={`otp-en-${integration.id}`} className="text-sm">Enabled</Label>
          <Switch id={`otp-en-${integration.id}`} checked={enabled} onCheckedChange={setEnabled} />
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <div className="space-y-2">
          <Label>OTP template</Label>
          <Select value={templateId} onValueChange={setTemplateId} disabled={!enabled || templates.length === 0}>
            <SelectTrigger>
              <SelectValue placeholder={templates.length === 0 ? "No approved templates" : "Select a template"} />
            </SelectTrigger>
            <SelectContent>
              {templates.map((t: any) => (
                <SelectItem key={t.id} value={t.id}>
                  {t.meta_template_name} · {t.language}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <p className="text-xs text-muted-foreground">Only approved <strong>AUTHENTICATION</strong> templates appear here.</p>
        </div>

        <div className="space-y-2">
          <Label>OTP length</Label>
          <Select value={length} onValueChange={setLength} disabled={!enabled}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="4">4 digits</SelectItem>
              <SelectItem value="6">6 digits</SelectItem>
              <SelectItem value="8">8 digits</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="flex items-center justify-between rounded-lg border p-3">
        <div>
          <div className="text-sm font-medium">Only for Cash on Delivery</div>
          <p className="text-xs text-muted-foreground">When on, OTP is only required for COD orders. Prepaid orders skip verification.</p>
        </div>
        <Switch checked={requireCod} onCheckedChange={setRequireCod} disabled={!enabled} />
      </div>

      <div className="flex justify-end">
        <Button onClick={save} disabled={saving} className="gap-1.5">
          {saving && <Loader2 className="h-4 w-4 animate-spin" />}
          <CheckCircle2 className="h-4 w-4" /> Save OTP settings
        </Button>
      </div>
    </Card>
  );
}

