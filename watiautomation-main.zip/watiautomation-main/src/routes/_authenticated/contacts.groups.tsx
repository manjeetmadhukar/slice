import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { z } from "zod";
import { supabase } from "@/integrations/supabase/client";
import { useWorkspace } from "@/lib/workspace-context";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { toast } from "sonner";
import { Plus, Trash2, Pencil, FolderKanban, Users, Search, Upload } from "lucide-react";
import { cn } from "@/lib/utils";
import { parseContactsCsv } from "@/lib/csv-import";

export const Route = createFileRoute("/_authenticated/contacts/groups")({
  component: Groups,
});

const schema = z.object({
  name: z.string().trim().min(1).max(80),
  description: z.string().trim().max(500).optional(),
});

function Groups() {
  const qc = useQueryClient();
  const { currentWorkspaceId } = useWorkspace();
  const [createOpen, setCreateOpen] = useState(false);
  const [form, setForm] = useState({ name: "", description: "" });
  const [openGroup, setOpenGroup] = useState<{ id: string; name: string } | null>(null);
  const [importGroup, setImportGroup] = useState<{ id: string; name: string } | null>(null);
  const [editGroup, setEditGroup] = useState<{ id: string; name: string; description: string | null } | null>(null);

  const { data: groups = [] } = useQuery({
    queryKey: ["contact_groups", currentWorkspaceId],
    enabled: !!currentWorkspaceId,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("contact_groups")
        .select("id, name, description, created_at, contact_group_members(count)")
        .eq("workspace_id", currentWorkspaceId!)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data;
    },
  });

  async function create() {
    if (!currentWorkspaceId) return;
    const p = schema.safeParse(form);
    if (!p.success) return toast.error(p.error.issues[0].message);
    const { data: u } = await supabase.auth.getUser();
    const { error } = await supabase.from("contact_groups").insert({
      workspace_id: currentWorkspaceId,
      user_id: u.user!.id,
      name: p.data.name,
      description: p.data.description || null,
    });
    if (error) return toast.error(error.message);
    toast.success("Group created");
    setForm({ name: "", description: "" });
    setCreateOpen(false);
    qc.invalidateQueries({ queryKey: ["contact_groups"] });
  }

  async function del(id: string) {
    if (!confirm("Delete this group? Contacts won't be removed.")) return;
    const { error } = await supabase.from("contact_groups").delete().eq("id", id);
    if (error) return toast.error(error.message);
    qc.invalidateQueries({ queryKey: ["contact_groups"] });
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-3xl font-bold">Groups</h1>
          <p className="text-muted-foreground">Organize contacts into groups for targeted campaigns</p>
        </div>
        <Dialog open={createOpen} onOpenChange={setCreateOpen}>
          <DialogTrigger asChild><Button><Plus className="mr-2 h-4 w-4" />New group</Button></DialogTrigger>
          <DialogContent>
            <DialogHeader><DialogTitle>Create group</DialogTitle></DialogHeader>
            <div className="space-y-3">
              <div><Label>Name</Label><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="VIP Customers" /></div>
              <div><Label>Description (optional)</Label><Textarea rows={3} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} /></div>
            </div>
            <DialogFooter><Button onClick={create}>Create</Button></DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {groups.length === 0 ? (
        <Card className="p-12 text-center text-muted-foreground">
          <FolderKanban className="h-10 w-10 mx-auto mb-3 opacity-50" />
          <p>No groups yet. Create your first group to organize contacts.</p>
        </Card>
      ) : (
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {groups.map((g: any) => (
            <Card key={g.id} className="p-5 flex flex-col gap-3">
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0">
                  <h3 className="font-semibold truncate">{g.name}</h3>
                  {g.description && <p className="text-sm text-muted-foreground line-clamp-2 mt-0.5">{g.description}</p>}
                </div>
                <div className="flex items-center">
                  <Button variant="ghost" size="icon" onClick={() => setEditGroup({ id: g.id, name: g.name, description: g.description })}>
                    <Pencil className="h-4 w-4" />
                  </Button>
                  <Button variant="ghost" size="icon" onClick={() => del(g.id)}>
                    <Trash2 className="h-4 w-4 text-destructive" />
                  </Button>
                </div>
              </div>
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Users className="h-4 w-4" />
                {g.contact_group_members?.[0]?.count ?? 0} contacts
              </div>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" className="flex-1" onClick={() => setOpenGroup({ id: g.id, name: g.name })}>
                  Manage
                </Button>
                <Button variant="outline" size="sm" className="flex-1" onClick={() => setImportGroup({ id: g.id, name: g.name })}>
                  <Upload className="mr-1.5 h-3.5 w-3.5" />CSV
                </Button>
              </div>
            </Card>
          ))}
        </div>
      )}

      {openGroup && (
        <ManageGroupDialog
          group={openGroup}
          onClose={() => { setOpenGroup(null); qc.invalidateQueries({ queryKey: ["contact_groups"] }); }}
        />
      )}
      {importGroup && (
        <ImportCsvToGroupDialog
          group={importGroup}
          onClose={() => { setImportGroup(null); qc.invalidateQueries({ queryKey: ["contact_groups"] }); }}
        />
      )}
      {editGroup && (
        <EditGroupDialog
          group={editGroup}
          onClose={() => { setEditGroup(null); qc.invalidateQueries({ queryKey: ["contact_groups"] }); }}
        />
      )}
    </div>
  );
}

function ManageGroupDialog({ group, onClose }: { group: { id: string; name: string }; onClose: () => void }) {
  const { currentWorkspaceId } = useWorkspace();
  const qc = useQueryClient();
  const [search, setSearch] = useState("");
  const [mode, setMode] = useState<"members" | "add">("members");

  const { data: contacts = [] } = useQuery({
    queryKey: ["contacts-all", currentWorkspaceId],
    enabled: !!currentWorkspaceId && mode === "add",
    queryFn: async () => {
      const { data, error } = await supabase
        .from("contacts")
        .select("id, name, phone")
        .eq("workspace_id", currentWorkspaceId!)
        .order("name")
        .limit(1000);
      if (error) throw error;
      return data;
    },
  });

  const { data: memberContacts = [] } = useQuery({
    queryKey: ["contact_group_members_full", group.id],
    queryFn: async () => {
      const ids: string[] = [];
      const page = 1000;
      for (let from = 0; ; from += page) {
        const { data, error } = await supabase
          .from("contact_group_members")
          .select("contact_id")
          .eq("group_id", group.id)
          .range(from, from + page - 1);
        if (error) throw error;
        ids.push(...(data ?? []).map((m: any) => m.contact_id));
        if (!data || data.length < page) break;
      }
      if (!ids.length) return [];

      const chunk = 200;
      const rows: any[] = [];
      for (let i = 0; i < ids.length; i += chunk) {
        const { data: cts, error: cErr } = await supabase
          .from("contacts")
          .select("id, name, phone")
          .in("id", ids.slice(i, i + chunk));
        if (cErr) throw cErr;
        rows.push(...(cts ?? []));
      }
      return rows.sort((a: any, b: any) => (a.name || "").localeCompare(b.name || ""));
    },
  });

  const memberSet = useMemo(
    () => new Set(memberContacts.map((c: any) => c.id)),
    [memberContacts],
  );
  const source: any[] = mode === "members" ? memberContacts : contacts;
  const filtered = useMemo(
    () => source.filter((c: any) =>
      !search ||
      (c.name || "").toLowerCase().includes(search.toLowerCase()) ||
      (c.phone || "").includes(search),
    ),
    [source, search],
  );

  async function toggle(contactId: string, checked: boolean) {
    if (!currentWorkspaceId) return;
    if (checked) {
      const { error } = await supabase.from("contact_group_members").insert({
        group_id: group.id,
        contact_id: contactId,
        workspace_id: currentWorkspaceId,
      });
      if (error) return toast.error(error.message);
    } else {
      const { error } = await supabase
        .from("contact_group_members")
        .delete()
        .eq("group_id", group.id)
        .eq("contact_id", contactId);
      if (error) return toast.error(error.message);
    }
    qc.invalidateQueries({ queryKey: ["contact_group_members", group.id] });
    qc.invalidateQueries({ queryKey: ["contact_group_members_full", group.id] });
    qc.invalidateQueries({ queryKey: ["contact_groups"] });
  }

  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>
            {group.name} — {mode === "members" ? `members (${memberContacts.length})` : "add contacts"}
          </DialogTitle>
        </DialogHeader>
        <div className="flex gap-1 rounded-md bg-muted p-1 w-fit">
          <button
            type="button"
            onClick={() => setMode("members")}
            className={cn(
              "px-3 py-1.5 text-sm rounded",
              mode === "members" ? "bg-background shadow-sm" : "text-muted-foreground",
            )}
          >
            Members
          </button>
          <button
            type="button"
            onClick={() => setMode("add")}
            className={cn(
              "px-3 py-1.5 text-sm rounded",
              mode === "add" ? "bg-background shadow-sm" : "text-muted-foreground",
            )}
          >
            Add contacts
          </button>
        </div>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input className="pl-9" placeholder={mode === "members" ? "Search members" : "Search contacts to add"} value={search} onChange={(e) => setSearch(e.target.value)} />
        </div>
        <div className="max-h-80 overflow-auto divide-y rounded-md border">
          {filtered.length === 0 ? (
            <div className="p-6 text-sm text-muted-foreground text-center">
              {mode === "members" ? "No contacts in this group yet" : "No contacts found"}
            </div>
          ) : (
            filtered.map((c: any) => {
              const inGroup = memberSet.has(c.id);
              return (
                <label key={c.id} className="flex items-center gap-3 p-3 cursor-pointer hover:bg-accent/50">
                  <Checkbox
                    checked={inGroup}
                    onCheckedChange={(v) => toggle(c.id, Boolean(v))}
                  />
                  <div className="min-w-0 flex-1">
                    <p className="font-medium truncate text-sm">{c.name}</p>
                    <p className="text-xs text-muted-foreground">{c.phone}</p>
                  </div>
                </label>
              );
            })
          )}
        </div>
        <DialogFooter><Button onClick={onClose}>Done</Button></DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function ImportCsvToGroupDialog({ group, onClose }: { group: { id: string; name: string }; onClose: () => void }) {
  const { currentWorkspaceId } = useWorkspace();
  const [csv, setCsv] = useState("");
  const [busy, setBusy] = useState(false);

  async function run() {
    if (!currentWorkspaceId) return;
    setBusy(true);
    try {
      const { data: u } = await supabase.auth.getUser();
      const parsed = parseContactsCsv(csv);
      if (!parsed.length) { toast.error("No valid rows"); return; }

      const { data: upserted, error: upErr } = await supabase.rpc("upsert_contacts_bulk", {
        _workspace_id: currentWorkspaceId,
        _user_id: u.user!.id,
        _rows: parsed as any,
      });
      if (upErr) { toast.error(upErr.message); return; }

      const allContactIds = Array.from(
        new Set((upserted ?? []).map((r: any) => r.id).filter(Boolean) as string[]),
      );
      const createdIds = allContactIds;

      const { data: alreadyMembers } = await supabase
        .from("contact_group_members")
        .select("contact_id")
        .eq("group_id", group.id)
        .in("contact_id", allContactIds);
      const memberSet = new Set((alreadyMembers ?? []).map((m: any) => m.contact_id));

      const memberRows = allContactIds
        .filter((id) => !memberSet.has(id))
        .map((id) => ({ group_id: group.id, contact_id: id, workspace_id: currentWorkspaceId }));

      if (memberRows.length) {
        const { error: memErr } = await supabase.from("contact_group_members").insert(memberRows);
        if (memErr) { toast.error(memErr.message); return; }
      }

      toast.success(`${createdIds.length} new contacts · ${memberRows.length} added to ${group.name}`);
      onClose();
    } finally {
      setBusy(false);
    }
  }

  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent>
        <DialogHeader><DialogTitle>Import CSV into {group.name}</DialogTitle></DialogHeader>
        <p className="text-sm text-muted-foreground">
          Upload a <code>.csv</code> file or paste rows. Format: <code>name,phone,email</code>.
          New contacts will be created; existing contacts (matched by phone) will be added to this group. <a href="/contacts-sample.csv" download className="text-primary underline underline-offset-2">Download sample CSV</a>.
        </p>
        <Input
          type="file"
          accept=".csv,text/csv"
          onChange={async (e) => {
            const f = e.target.files?.[0];
            if (!f) return;
            if (f.size > 5 * 1024 * 1024) return toast.error("File too large (max 5MB)");
            setCsv(await f.text());
            toast.success(`Loaded ${f.name}`);
          }}
        />
        <Textarea rows={8} value={csv} onChange={(e) => setCsv(e.target.value)} placeholder="Jane Doe,+14155551234,jane@example.com" />
        <DialogFooter>
          <Button variant="outline" onClick={onClose} disabled={busy}>Cancel</Button>
          <Button onClick={run} disabled={busy || !csv.trim()}>{busy ? "Importing…" : "Import"}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function EditGroupDialog({ group, onClose }: { group: { id: string; name: string; description: string | null }; onClose: () => void }) {
  const [form, setForm] = useState({ name: group.name, description: group.description || "" });
  const [busy, setBusy] = useState(false);

  async function save() {
    const p = schema.safeParse(form);
    if (!p.success) return toast.error(p.error.issues[0].message);
    setBusy(true);
    const { error } = await supabase
      .from("contact_groups")
      .update({ name: p.data.name, description: p.data.description || null })
      .eq("id", group.id);
    setBusy(false);
    if (error) return toast.error(error.message);
    toast.success("Group updated");
    onClose();
  }

  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent>
        <DialogHeader><DialogTitle>Rename group</DialogTitle></DialogHeader>
        <div className="space-y-3">
          <div><Label>Name</Label><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
          <div><Label>Description (optional)</Label><Textarea rows={3} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} /></div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose} disabled={busy}>Cancel</Button>
          <Button onClick={save} disabled={busy}>{busy ? "Saving…" : "Save"}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
