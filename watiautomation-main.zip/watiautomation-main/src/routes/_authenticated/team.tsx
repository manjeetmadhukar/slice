import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useWorkspace, canManageWorkspace, type Role } from "@/lib/workspace-context";
import {
  createInvitation, revokeInvitation, updateMemberRole, removeMember,
} from "@/lib/workspaces.functions";
import {
  createTeamUser, updateUserPermissions, resetUserPassword,
  setUserActive, getMemberPermissions, listWorkspaceMembers,
} from "@/lib/team-admin.functions";
import { MODULES, ACTIONS, defaultPermissions, rowsToMap, type PermissionMap } from "@/lib/permissions";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger } from "@/components/ui/dialog";
import { toast } from "sonner";
import { UserPlus, Trash2, Copy, Lock, UserCog, KeyRound, Shield, ShieldCheck } from "lucide-react";

export const Route = createFileRoute("/_authenticated/team")({
  component: TeamPage,
  head: () => ({ meta: [{ title: "Team — Slice" }] }),
});

function genPassword(len = 12) {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789!@#$";
  let s = "";
  for (let i = 0; i < len; i++) s += chars.charAt(Math.floor(Math.random() * chars.length));
  return s;
}

function TeamPage() {
  const qc = useQueryClient();
  const { currentWorkspaceId, role, current } = useWorkspace();
  const isAdmin = canManageWorkspace(role);
  const canAddUsers = !!current?.workspaces?.allow_team_user_creation;


  const inviteFn = useServerFn(createInvitation);
  const revokeFn = useServerFn(revokeInvitation);
  const updateRoleFn = useServerFn(updateMemberRole);
  const removeFn = useServerFn(removeMember);
  const createUserFn = useServerFn(createTeamUser);
  const updatePermsFn = useServerFn(updateUserPermissions);
  const resetPwFn = useServerFn(resetUserPassword);
  const setActiveFn = useServerFn(setUserActive);
  const listMembersFn = useServerFn(listWorkspaceMembers);

  const [inviteOpen, setInviteOpen] = useState(false);
  const [createOpen, setCreateOpen] = useState(false);
  const [permsOpen, setPermsOpen] = useState(false);
  const [resetOpen, setResetOpen] = useState(false);
  const [activeMember, setActiveMember] = useState<any | null>(null);

  const [inviteEmail, setInviteEmail] = useState("");
  const [inviteRole, setInviteRole] = useState<"admin" | "agent" | "viewer">("agent");
  const [lastLink, setLastLink] = useState<string | null>(null);

  const { data: members = [] } = useQuery({
    queryKey: ["members", currentWorkspaceId],
    enabled: !!currentWorkspaceId,
    queryFn: async () => {
      const res = await listMembersFn({ data: { workspace_id: currentWorkspaceId! } });
      return res.members;
    },
  });

  const { data: invites = [] } = useQuery({
    queryKey: ["invites", currentWorkspaceId],
    enabled: !!currentWorkspaceId && isAdmin,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("workspace_invitations")
        .select("*")
        .eq("workspace_id", currentWorkspaceId!)
        .is("accepted_at", null)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data;
    },
  });

  async function sendInvite() {
    if (!currentWorkspaceId) return;
    try {
      const res = await inviteFn({
        data: { workspace_id: currentWorkspaceId, email: inviteEmail, role: inviteRole },
      });
      const link = `${window.location.origin}/invite/${res.invitation.token}`;
      setLastLink(link);
      await navigator.clipboard.writeText(link).catch(() => {});
      toast.success("Invite link copied to clipboard");
      setInviteEmail("");
      qc.invalidateQueries({ queryKey: ["invites"] });
    } catch (e: any) {
      toast.error(e.message);
    }
  }

  async function changeRole(userId: string, newRole: Role) {
    if (!currentWorkspaceId || newRole === "owner") return;
    try {
      await updateRoleFn({ data: { workspace_id: currentWorkspaceId, user_id: userId, role: newRole } });
      qc.invalidateQueries({ queryKey: ["members"] });
      toast.success("Role updated");
    } catch (e: any) { toast.error(e.message); }
  }

  async function kick(userId: string) {
    if (!currentWorkspaceId) return;
    try {
      await removeFn({ data: { workspace_id: currentWorkspaceId, user_id: userId } });
      qc.invalidateQueries({ queryKey: ["members"] });
      toast.success("Member removed");
    } catch (e: any) { toast.error(e.message); }
  }

  async function revoke(id: string) {
    try {
      await revokeFn({ data: { id } });
      qc.invalidateQueries({ queryKey: ["invites"] });
    } catch (e: any) { toast.error(e.message); }
  }

  async function toggleActive(userId: string, next: boolean) {
    if (!currentWorkspaceId) return;
    try {
      await setActiveFn({ data: { workspace_id: currentWorkspaceId, user_id: userId, is_active: next } });
      qc.invalidateQueries({ queryKey: ["members"] });
      toast.success(next ? "User activated" : "User deactivated");
    } catch (e: any) { toast.error(e.message); }
  }

  return (
    <div className="space-y-8 max-w-5xl">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="font-display text-3xl font-bold">Team</h1>
          <p className="text-muted-foreground">Manage members, invitations, and permissions</p>
        </div>
        {isAdmin && canAddUsers && (
          <div className="flex gap-2">
            <Dialog open={inviteOpen} onOpenChange={setInviteOpen}>
              <DialogTrigger asChild>
                <Button variant="outline"><UserPlus className="mr-2 h-4 w-4" />Invite member</Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader><DialogTitle>Invite a team member</DialogTitle></DialogHeader>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label>Email</Label>
                    <Input type="email" value={inviteEmail} onChange={(e) => setInviteEmail(e.target.value)} placeholder="teammate@company.com" />
                  </div>
                  <div className="space-y-2">
                    <Label>Role</Label>
                    <Select value={inviteRole} onValueChange={(v) => setInviteRole(v as any)}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="admin">Admin</SelectItem>
                        <SelectItem value="agent">Agent</SelectItem>
                        <SelectItem value="viewer">Viewer</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  {lastLink && (
                    <div className="rounded-lg border bg-muted/30 p-3 text-xs">
                      <p className="font-medium mb-1">Invite link (already copied):</p>
                      <p className="break-all text-muted-foreground">{lastLink}</p>
                    </div>
                  )}
                </div>
                <DialogFooter>
                  <Button onClick={sendInvite}>Create invite</Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>

            <Button onClick={() => setCreateOpen(true)}>
              <UserCog className="mr-2 h-4 w-4" />Create user
            </Button>
          </div>
        )}
      </div>

      {isAdmin && !canAddUsers && (
        <Card className="p-4 border-warning/30 bg-warning/5 flex items-center gap-3">
          <Lock className="h-4 w-4 text-warning" />
          <p className="text-sm">
            Adding team members is disabled for this workspace. Please contact support to enable team user creation.
          </p>
        </Card>
      )}


      {!isAdmin && (
        <Card className="p-4 border-warning/30 bg-warning/5 flex items-center gap-3">
          <Lock className="h-4 w-4 text-warning" />
          <p className="text-sm">Only owners and admins can invite or manage members.</p>
        </Card>
      )}

      <section className="space-y-3">
        <h2 className="font-display text-lg font-semibold">Members ({members.length})</h2>
        <Card className="divide-y">
          {members.map((m: any) => {
            const inactive = m.is_active === false;
            return (
              <div key={m.user_id} className={`p-4 flex items-center justify-between gap-3 ${inactive ? "opacity-60" : ""}`}>
                <div className="min-w-0">
                  <p className="font-medium truncate flex items-center gap-2">
                    {m.profiles?.full_name || m.profiles?.email}
                    {m.profiles?.username && <span className="text-xs text-muted-foreground">@{m.profiles.username}</span>}
                    {inactive && <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-destructive/10 text-destructive">Deactivated</span>}
                  </p>
                  <p className="text-xs text-muted-foreground truncate">{m.profiles?.email}</p>
                </div>
                <div className="flex items-center gap-2 flex-wrap justify-end">
                  {m.role === "owner" || !isAdmin ? (
                    <span className="text-xs px-2 py-1 rounded-full bg-secondary capitalize">{m.role}</span>
                  ) : (
                    <Select value={m.role} onValueChange={(v) => changeRole(m.user_id, v as Role)}>
                      <SelectTrigger className="h-8 w-28"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="admin">Admin</SelectItem>
                        <SelectItem value="agent">Agent</SelectItem>
                        <SelectItem value="viewer">Viewer</SelectItem>
                      </SelectContent>
                    </Select>
                  )}
                  {isAdmin && m.role !== "owner" && (
                    <>
                      <Button variant="ghost" size="sm" onClick={() => { setActiveMember(m); setPermsOpen(true); }}>
                        <ShieldCheck className="h-4 w-4 mr-1" /> Permissions
                      </Button>
                      <Button variant="ghost" size="sm" onClick={() => { setActiveMember(m); setResetOpen(true); }}>
                        <KeyRound className="h-4 w-4 mr-1" /> Reset password
                      </Button>
                      <div className="flex items-center gap-1 text-xs">
                        <Switch checked={!inactive} onCheckedChange={(v) => toggleActive(m.user_id, v)} />
                        <span className="text-muted-foreground">Active</span>
                      </div>
                      <Button variant="ghost" size="icon" onClick={() => kick(m.user_id)}>
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </>
                  )}
                </div>
              </div>
            );
          })}
        </Card>
      </section>

      {isAdmin && invites.length > 0 && (
        <section className="space-y-3">
          <h2 className="font-display text-lg font-semibold">Pending invitations</h2>
          <Card className="divide-y">
            {invites.map((inv: any) => (
              <div key={inv.id} className="p-4 flex items-center justify-between gap-3">
                <div className="min-w-0">
                  <p className="font-medium truncate">{inv.email}</p>
                  <p className="text-xs text-muted-foreground capitalize">Role: {inv.role} · expires {new Date(inv.expires_at).toLocaleDateString()}</p>
                </div>
                <div className="flex gap-1">
                  <Button variant="ghost" size="icon" onClick={() => {
                    const link = `${window.location.origin}/invite/${inv.token}`;
                    navigator.clipboard.writeText(link);
                    toast.success("Link copied");
                  }}>
                    <Copy className="h-4 w-4" />
                  </Button>
                  <Button variant="ghost" size="icon" onClick={() => revoke(inv.id)}>
                    <Trash2 className="h-4 w-4 text-destructive" />
                  </Button>
                </div>
              </div>
            ))}
          </Card>
        </section>
      )}

      {isAdmin && currentWorkspaceId && (
        <>
          <CreateUserDialog
            open={createOpen}
            onOpenChange={setCreateOpen}
            workspaceId={currentWorkspaceId}
            createUserFn={createUserFn}
            onCreated={() => qc.invalidateQueries({ queryKey: ["members"] })}
          />
          <PermissionsDialog
            open={permsOpen}
            onOpenChange={(v) => { setPermsOpen(v); if (!v) setActiveMember(null); }}
            member={activeMember}
            workspaceId={currentWorkspaceId}
            updatePermsFn={updatePermsFn}
          />
          <ResetPasswordDialog
            open={resetOpen}
            onOpenChange={(v) => { setResetOpen(v); if (!v) setActiveMember(null); }}
            member={activeMember}
            workspaceId={currentWorkspaceId}
            resetPwFn={resetPwFn}
          />
        </>
      )}
    </div>
  );
}

function PermissionsMatrix({
  value, onChange,
}: { value: PermissionMap; onChange: (m: PermissionMap) => void }) {
  function toggle(mod: string, action: string, v: boolean) {
    const next = { ...value, [mod]: { ...(value[mod] || { view: false, create: false, edit: false, delete: false }), [action]: v } } as PermissionMap;
    // If view turned off, also turn off others
    if (action === "view" && !v) {
      next[mod] = { view: false, create: false, edit: false, delete: false };
    }
    onChange(next);
  }
  return (
    <div className="border rounded-lg overflow-hidden">
      <div className="grid grid-cols-[1fr,repeat(4,80px)] bg-muted/40 text-xs font-medium px-3 py-2">
        <span>Module</span>
        {ACTIONS.map((a) => <span key={a} className="text-center capitalize">{a}</span>)}
      </div>
      <div className="max-h-[340px] overflow-y-auto divide-y">
        {MODULES.map((mod) => {
          const row = value[mod.key] || { view: false, create: false, edit: false, delete: false };
          return (
            <div key={mod.key} className="grid grid-cols-[1fr,repeat(4,80px)] items-center px-3 py-2 text-sm">
              <span>{mod.label}</span>
              {ACTIONS.map((a) => (
                <div key={a} className="flex justify-center">
                  <Checkbox checked={!!(row as any)[a]} onCheckedChange={(v) => toggle(mod.key, a, !!v)} />
                </div>
              ))}
            </div>
          );
        })}
      </div>
    </div>
  );
}

function CreateUserDialog({
  open, onOpenChange, workspaceId, createUserFn, onCreated,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  workspaceId: string;
  createUserFn: any;
  onCreated: () => void;
}) {
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState(genPassword());
  const [roleSel, setRoleSel] = useState<"admin" | "agent" | "viewer">("agent");
  const [perms, setPerms] = useState<PermissionMap>(defaultPermissions("agent"));
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (open) {
      setFullName(""); setEmail(""); setUsername("");
      setPassword(genPassword());
      setRoleSel("agent");
      setPerms(defaultPermissions("agent"));
    }
  }, [open]);

  useEffect(() => { setPerms(defaultPermissions(roleSel)); }, [roleSel]);

  async function submit() {
    setSaving(true);
    try {
      const permissions = MODULES.map((m) => ({
        module: m.key,
        can_view: !!perms[m.key]?.view,
        can_create: !!perms[m.key]?.create,
        can_edit: !!perms[m.key]?.edit,
        can_delete: !!perms[m.key]?.delete,
      }));
      await createUserFn({
        data: {
          workspace_id: workspaceId,
          full_name: fullName,
          email,
          username,
          password,
          role: roleSel,
          permissions,
        },
      });
      toast.success("User created — share the credentials with them");
      onCreated();
      onOpenChange(false);
    } catch (e: any) {
      toast.error(e.message || "Failed to create user");
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2"><UserCog className="h-4 w-4" /> Create team user</DialogTitle>
        </DialogHeader>
        <div className="grid md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label>Full name</Label>
            <Input value={fullName} onChange={(e) => setFullName(e.target.value)} placeholder="Jane Doe" />
          </div>
          <div className="space-y-2">
            <Label>Email</Label>
            <Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="jane@company.com" />
          </div>
          <div className="space-y-2">
            <Label>Username</Label>
            <Input value={username} onChange={(e) => setUsername(e.target.value)} placeholder="jane.doe" />
          </div>
          <div className="space-y-2">
            <Label>Password</Label>
            <div className="flex gap-2">
              <Input value={password} onChange={(e) => setPassword(e.target.value)} />
              <Button type="button" variant="outline" onClick={() => setPassword(genPassword())}>Generate</Button>
              <Button type="button" variant="outline" onClick={() => { navigator.clipboard.writeText(password); toast.success("Copied"); }}>
                <Copy className="h-4 w-4" />
              </Button>
            </div>
            <p className="text-[11px] text-muted-foreground">Share these credentials securely with the user. They can log in immediately.</p>
          </div>
          <div className="space-y-2 md:col-span-2">
            <Label>Role</Label>
            <Select value={roleSel} onValueChange={(v) => setRoleSel(v as any)}>
              <SelectTrigger className="w-48"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="admin">Admin — full access</SelectItem>
                <SelectItem value="agent">Agent — operational access</SelectItem>
                <SelectItem value="viewer">Viewer — read-only</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="md:col-span-2 space-y-2">
            <Label className="flex items-center gap-2"><Shield className="h-4 w-4" /> Module permissions</Label>
            <PermissionsMatrix value={perms} onChange={setPerms} />
            <p className="text-[11px] text-muted-foreground">Admins always have full access regardless of these checkboxes.</p>
          </div>
        </div>
        <DialogFooter>
          <Button variant="ghost" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button onClick={submit} disabled={saving || !fullName || !email || !username || !password}>
            {saving ? "Creating…" : "Create user"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function PermissionsDialog({
  open, onOpenChange, member, workspaceId, updatePermsFn,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  member: any;
  workspaceId: string;
  updatePermsFn: any;
}) {
  const [perms, setPerms] = useState<PermissionMap>({});
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const getPermsFn = useServerFn(getMemberPermissions);

  useEffect(() => {
    if (!open || !member) return;
    setLoading(true);
    getPermsFn({ data: { workspace_id: workspaceId, user_id: member.user_id } })
      .then((res) => {
        const map = rowsToMap(res.permissions as any);
        // Ensure all modules present
        for (const m of MODULES) {
          if (!map[m.key]) map[m.key] = { view: false, create: false, edit: false, delete: false };
        }
        setPerms(map);
      })
      .catch((e: any) => toast.error(e.message))
      .finally(() => setLoading(false));
  }, [open, member, workspaceId, getPermsFn]);

  async function save() {
    setSaving(true);
    try {
      const permissions = MODULES.map((m) => ({
        module: m.key,
        can_view: !!perms[m.key]?.view,
        can_create: !!perms[m.key]?.create,
        can_edit: !!perms[m.key]?.edit,
        can_delete: !!perms[m.key]?.delete,
      }));
      await updatePermsFn({ data: { workspace_id: workspaceId, user_id: member.user_id, permissions } });
      toast.success("Permissions updated");
      onOpenChange(false);
    } catch (e: any) {
      toast.error(e.message);
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Permissions — {member?.profiles?.full_name || member?.profiles?.email}</DialogTitle>
        </DialogHeader>
        {loading ? (
          <p className="text-sm text-muted-foreground">Loading…</p>
        ) : (
          <PermissionsMatrix value={perms} onChange={setPerms} />
        )}
        <DialogFooter>
          <Button variant="ghost" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button onClick={save} disabled={saving || loading}>{saving ? "Saving…" : "Save permissions"}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function ResetPasswordDialog({
  open, onOpenChange, member, workspaceId, resetPwFn,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  member: any;
  workspaceId: string;
  resetPwFn: any;
}) {
  const [pw, setPw] = useState(genPassword());
  const [saving, setSaving] = useState(false);
  useEffect(() => { if (open) setPw(genPassword()); }, [open]);

  async function save() {
    setSaving(true);
    try {
      await resetPwFn({ data: { workspace_id: workspaceId, user_id: member.user_id, password: pw } });
      toast.success("Password reset — share it with the user");
      onOpenChange(false);
    } catch (e: any) { toast.error(e.message); }
    finally { setSaving(false); }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Reset password — {member?.profiles?.full_name || member?.profiles?.email}</DialogTitle>
        </DialogHeader>
        <div className="space-y-2">
          <Label>New password</Label>
          <div className="flex gap-2">
            <Input value={pw} onChange={(e) => setPw(e.target.value)} />
            <Button type="button" variant="outline" onClick={() => setPw(genPassword())}>Generate</Button>
            <Button type="button" variant="outline" onClick={() => { navigator.clipboard.writeText(pw); toast.success("Copied"); }}>
              <Copy className="h-4 w-4" />
            </Button>
          </div>
          <p className="text-[11px] text-muted-foreground">Share the new password securely. The user's existing sessions remain active until they sign out.</p>
        </div>
        <DialogFooter>
          <Button variant="ghost" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button onClick={save} disabled={saving || pw.length < 8}>{saving ? "Resetting…" : "Reset password"}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
