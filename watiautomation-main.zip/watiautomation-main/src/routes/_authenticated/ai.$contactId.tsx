import { createFileRoute, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, ArrowDownLeft, ArrowUpRight, Sparkles } from "lucide-react";
import { useWorkspace } from "@/lib/workspace-context";
import { getLeadTimeline } from "@/lib/ai-insights.functions";

export const Route = createFileRoute("/_authenticated/ai/$contactId")({
  component: LeadTimeline,
  head: () => ({ meta: [{ title: "Lead timeline — Slice" }] }),
  errorComponent: ({ error }) => (
    <div className="p-6 text-sm text-destructive">Failed to load timeline: {error.message}</div>
  ),
  notFoundComponent: () => <div className="p-6 text-sm">Lead not found.</div>,
});

function LeadTimeline() {
  const { contactId } = Route.useParams();
  const { currentWorkspaceId } = useWorkspace();
  const fn = useServerFn(getLeadTimeline);
  const { data, isLoading } = useQuery({
    queryKey: ["lead-timeline", currentWorkspaceId, contactId],
    enabled: !!currentWorkspaceId,
    queryFn: () => fn({ data: { workspace_id: currentWorkspaceId!, contact_id: contactId } }),
  });

  if (isLoading) return <div className="p-6 text-sm text-muted-foreground">Loading timeline…</div>;
  if (!data?.contact)
    return <div className="p-6 text-sm text-muted-foreground">Lead not found in this workspace.</div>;

  const c = data.contact;
  const conf = Math.round(Number(c.ai_confidence ?? 0) * 100);

  return (
    <div className="space-y-6">
      <Link to="/ai" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground">
        <ArrowLeft className="h-4 w-4" /> Back to AI Insights
      </Link>

      <Card className="p-5">
        <div className="flex items-start justify-between gap-4">
          <div className="min-w-0">
            <h1 className="font-display text-2xl font-bold truncate">{c.name || c.phone}</h1>
            <p className="text-sm text-muted-foreground">{c.phone}</p>
            <div className="mt-3 flex flex-wrap gap-2">
              {c.ai_lead_stage && <Badge variant="secondary">Stage: {c.ai_lead_stage}</Badge>}
              {c.ai_last_intent && <Badge variant="secondary">Intent: {c.ai_last_intent}</Badge>}
              {c.ai_language && <Badge variant="outline">{c.ai_language}</Badge>}
              {(c.tags ?? []).map((t: string) => (
                <Badge key={t} variant="outline">{t}</Badge>
              ))}
            </div>
          </div>
          <div className="text-right shrink-0">
            <p className="text-xs text-muted-foreground">AI confidence</p>
            <p className="font-display text-3xl font-bold">{conf}%</p>
          </div>
        </div>
      </Card>

      <div>
        <h2 className="font-display text-lg font-semibold mb-3">Conversation timeline</h2>
        {data.messages.length === 0 ? (
          <Card className="p-8 text-center text-sm text-muted-foreground">No messages yet.</Card>
        ) : (
          <div className="space-y-3">
            {data.messages.map((m: any) => (
              <MessageItem key={m.id} m={m} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function MessageItem({ m }: { m: any }) {
  const inbound = m.direction === "inbound";
  return (
    <Card className="p-4">
      <div className="flex items-start gap-3">
        <div
          className={`grid h-8 w-8 place-items-center rounded-lg shrink-0 ${
            inbound ? "bg-primary/10 text-primary" : "bg-secondary text-secondary-foreground"
          }`}
        >
          {inbound ? <ArrowDownLeft className="h-4 w-4" /> : <ArrowUpRight className="h-4 w-4" />}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between gap-2">
            <p className="text-xs text-muted-foreground">
              {inbound ? "Customer" : m.is_automated ? "Automated" : "Agent"} ·{" "}
              {new Date(m.created_at).toLocaleString()}
            </p>
            {m.ai && (
              <span className="inline-flex items-center gap-1 text-[11px] text-primary">
                <Sparkles className="h-3 w-3" /> AI
              </span>
            )}
          </div>
          <p className="mt-1 text-sm whitespace-pre-wrap break-words">{m.content || <em className="text-muted-foreground">({m.type})</em>}</p>
          {m.ai && (
            <div className="mt-2 flex flex-wrap gap-1.5">
              {m.ai.sentiment && <Badge variant="outline" className="text-xs capitalize">{m.ai.sentiment}</Badge>}
              {m.ai.intent && <Badge variant="outline" className="text-xs">Intent: {m.ai.intent}</Badge>}
              {m.ai.urgency && <Badge variant="outline" className="text-xs capitalize">Urgency: {m.ai.urgency}</Badge>}
              {m.ai.lead_stage && <Badge variant="outline" className="text-xs">Stage: {m.ai.lead_stage}</Badge>}
              {typeof m.ai.conversion_probability === "number" && (
                <Badge variant="outline" className="text-xs">
                  Conv: {Math.round(m.ai.conversion_probability * 100)}%
                </Badge>
              )}
            </div>
          )}
          {m.ai?.recommended_action && (
            <p className="mt-2 text-xs text-muted-foreground">
              <span className="font-medium text-foreground">Next:</span> {m.ai.recommended_action}
            </p>
          )}
        </div>
      </div>
    </Card>
  );
}
