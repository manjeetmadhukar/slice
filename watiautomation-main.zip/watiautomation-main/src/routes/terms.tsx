import { createFileRoute, Link } from "@tanstack/react-router";

export const Route = createFileRoute("/terms")({
  component: TermsPage,
  head: () => ({
    meta: [
      { title: "Terms of Service — Slice" },
      { name: "description", content: "The terms that govern your use of the Slice WhatsApp Business platform." },
      { property: "og:title", content: "Terms of Service — Slice" },
      { property: "og:description", content: "The terms that govern your use of the Slice WhatsApp Business platform." },
      { property: "og:url", content: "/terms" },
    ],
    links: [{ rel: "canonical", href: "/terms" }],
  }),
});

function TermsPage() {
  return (
    <main className="min-h-screen bg-background">
      <div className="container mx-auto max-w-3xl px-6 py-16">
        <Link to="/" className="text-sm text-muted-foreground hover:text-foreground">← Back to home</Link>
        <h1 className="font-display text-4xl font-bold tracking-tight mt-6">Terms of Service</h1>
        <p className="text-muted-foreground mt-2">Last updated: June 3, 2026</p>

        <div className="mt-8 max-w-none space-y-6 text-sm leading-relaxed">
          <section>
            <h2 className="text-xl font-semibold">1. Acceptance</h2>
            <p>
              By creating an account or using Slice (the “Service”), operated by Dotscube, you agree
              to these Terms of Service and our <Link to="/privacy" className="underline">Privacy Policy</Link>.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold">2. The Service</h2>
            <p>
              Slice is a WhatsApp Business messaging platform built on the official Meta WhatsApp
              Business Cloud API. We do not own or control Meta or WhatsApp; using the Service also
              requires you to comply with Meta's WhatsApp Business and Commerce policies.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold">3. Your account</h2>
            <ul className="list-disc pl-5 space-y-1">
              <li>You must provide accurate information and keep your credentials secure.</li>
              <li>You are responsible for all activity in your workspace.</li>
              <li>You must be authorized to message every contact you upload or send to.</li>
            </ul>
          </section>

          <section>
            <h2 className="text-xl font-semibold">4. Acceptable use</h2>
            <p>You agree not to use the Service to:</p>
            <ul className="list-disc pl-5 space-y-1">
              <li>Send spam, unlawful, deceptive, or harmful content.</li>
              <li>Violate Meta's WhatsApp Business Messaging Policy.</li>
              <li>Reverse engineer or attempt to disrupt the Service.</li>
              <li>Resell access without a written reseller agreement.</li>
            </ul>
          </section>

          <section>
            <h2 className="text-xl font-semibold">5. Plans and billing</h2>
            <p>
              Paid plans renew automatically until cancelled. WhatsApp conversation charges levied
              by Meta are billed separately or passed through. Refunds are at our discretion.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold">6. Termination</h2>
            <p>
              We may suspend or terminate accounts that breach these Terms, Meta policies, or
              applicable law. You can cancel at any time from your subscription page.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold">7. Disclaimer & liability</h2>
            <p>
              The Service is provided “as is”. To the maximum extent permitted by law, our total
              liability is limited to the fees you paid in the last 3 months.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold">8. Changes</h2>
            <p>We may update these Terms. Continued use after changes constitutes acceptance.</p>
          </section>

          <section>
            <h2 className="text-xl font-semibold">9. Contact</h2>
            <p>
              Dotscube · <a href="mailto:slice@dotscube.com" className="underline">slice@dotscube.com</a> · +91 96022 99003
            </p>
          </section>
        </div>
      </div>
    </main>
  );
}
