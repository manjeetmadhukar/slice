import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Check, Sparkles } from "lucide-react";
import { LIMIT_CATALOG, PAYMENT_PROVIDERS, type PaymentProvider } from "@/lib/features-catalog";
import { formatPrice } from "@/components/PricingFields";
import {
  PricingComparisonTable,
  type PricingPlan,
  type MasterFeature,
  type PlanFeatureLink,
} from "@/components/PricingComparisonTable";

interface Plan extends PricingPlan {
  features: Record<string, boolean>;
  limits: Record<string, number>;
  gateway_ids: PaymentProvider[] | null;
}

export const Route = createFileRoute("/pricing")({
  component: PricingPage,
  head: () => ({
    meta: [
      { title: "Pricing — Slice" },
      { name: "description", content: "Simple, transparent pricing. Pick the plan that fits your team and scale anytime." },
      { property: "og:title", content: "Pricing — Slice" },
      { property: "og:description", content: "Simple, transparent pricing. Pick the plan that fits your team and scale anytime." },
    ],
  }),
});

function PricingPage() {
  const [interval, setInterval] = useState<"monthly" | "yearly">("monthly");

  const { data, isLoading } = useQuery({
    queryKey: ["public-pricing"],
    queryFn: async (): Promise<{ plans: Plan[]; masterFeatures: MasterFeature[]; planFeatures: PlanFeatureLink[] }> => {
      const res = await fetch("/api/public/pricing");
      if (!res.ok) throw new Error("Failed to load pricing");
      return res.json();
    },
  });

  const plans = data?.plans ?? [];
  const masterFeatures = data?.masterFeatures ?? [];
  const planFeatures = data?.planFeatures ?? [];

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b">
        <div className="container mx-auto flex items-center justify-between py-4 px-4">
          <Link to="/" className="font-semibold text-lg">Slice</Link>
          <div className="flex items-center gap-2">
            <Button asChild variant="ghost"><Link to="/login">Sign in</Link></Button>
            <Button asChild><Link to="/login">Get started</Link></Button>
          </div>
        </div>
      </header>

      <section className="container mx-auto px-4 pt-16 pb-10 text-center">
        <Badge variant="secondary" className="mb-4">
          <Sparkles className="mr-1 h-3 w-3" /> Simple, transparent pricing
        </Badge>
        <h1 className="text-4xl md:text-5xl font-bold tracking-tight mb-4">
          Pick the plan that grows with you
        </h1>
        <p className="text-muted-foreground max-w-2xl mx-auto text-lg">
          All plans include core inbox, contacts, and automation features. Upgrade anytime to unlock more.
        </p>

        <div className="mt-8 inline-flex rounded-full border bg-muted p-1">
          <button
            onClick={() => setInterval("monthly")}
            className={`px-5 py-2 text-sm rounded-full transition ${interval === "monthly" ? "bg-background shadow-sm font-medium" : "text-muted-foreground"}`}
          >
            Monthly
          </button>
          <button
            onClick={() => setInterval("yearly")}
            className={`px-5 py-2 text-sm rounded-full transition flex items-center gap-2 ${interval === "yearly" ? "bg-background shadow-sm font-medium" : "text-muted-foreground"}`}
          >
            Yearly
            <span className="text-xs px-1.5 py-0.5 rounded bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300">Save</span>
          </button>
        </div>
      </section>

      {/* Plan cards */}
      <section className="container mx-auto px-4 pb-12">
        {isLoading ? (
          <div className="grid md:grid-cols-3 gap-6 max-w-6xl mx-auto">
            {[1, 2, 3].map((i) => (
              <Card key={i} className="p-6 h-96 animate-pulse bg-muted/40" />
            ))}
          </div>
        ) : plans.length === 0 ? (
          <Card className="p-12 text-center max-w-xl mx-auto">
            <p className="text-muted-foreground">No plans available yet. Please check back soon.</p>
          </Card>
        ) : (
          <div className={`grid gap-6 max-w-6xl mx-auto ${plans.length === 1 ? "md:grid-cols-1 max-w-md" : plans.length === 2 ? "md:grid-cols-2 max-w-3xl" : "md:grid-cols-3 lg:grid-cols-4"}`}>
            {plans.map((plan) => {
              const isPopular = !!plan.is_popular;
              const price = interval === "yearly" ? plan.price_yearly : plan.price_monthly;
              const planLinks = planFeatures.filter((l) => l.template_id === plan.id && l.included);

              return (
                <Card
                  key={plan.id}
                  className={`p-6 flex flex-col relative ${isPopular ? "border-primary shadow-lg ring-1 ring-primary/30" : ""}`}
                >
                  {isPopular && (
                    <Badge className="absolute -top-3 left-1/2 -translate-x-1/2">
                      {plan.badge_text || "Most popular"}
                    </Badge>
                  )}

                  <div className="mb-4">
                    <h3 className="text-xl font-semibold">{plan.name}</h3>
                    {plan.description && (
                      <p className="text-sm text-muted-foreground mt-1">{plan.description}</p>
                    )}
                  </div>

                  <div className="mb-6">
                    <div className="flex items-baseline gap-1">
                      <span className="text-4xl font-bold">
                        {price > 0 ? formatPrice(price, plan.currency) : "Free"}
                      </span>
                      {price > 0 && (
                        <span className="text-muted-foreground text-sm">/ {interval === "yearly" ? "year" : "month"}</span>
                      )}
                    </div>
                    {interval === "yearly" && plan.price_monthly > 0 && plan.price_yearly > 0 && (
                      <p className="text-xs text-muted-foreground mt-1">
                        {formatPrice(Math.round(plan.price_yearly / 12), plan.currency)} / month billed annually
                      </p>
                    )}
                  </div>

                  <Button asChild className="w-full mb-6" variant={isPopular ? "default" : "outline"}>
                    <Link to="/login">Get started</Link>
                  </Button>

                  {Object.keys(plan.limits || {}).length > 0 && (
                    <div className="mb-4 space-y-1.5">
                      {LIMIT_CATALOG.filter((l) => plan.limits?.[l.key] != null).map((l) => (
                        <div key={l.key} className="flex items-center justify-between text-sm">
                          <span className="text-muted-foreground">{l.label}</span>
                          <span className="font-medium">{plan.limits[l.key] === 0 ? "Unlimited" : plan.limits[l.key].toLocaleString()}</span>
                        </div>
                      ))}
                    </div>
                  )}

                  <div className="border-t pt-4 space-y-2 flex-1">
                    <p className="text-xs font-medium uppercase tracking-wider text-muted-foreground mb-2">
                      Highlights
                    </p>
                    {planLinks.length === 0 ? (
                      <p className="text-sm text-muted-foreground">See full comparison below.</p>
                    ) : (
                      planLinks.slice(0, 6).map((link) => {
                        const f = masterFeatures.find((m) => m.id === link.feature_id);
                        if (!f) return null;
                        return (
                          <div key={link.feature_id} className="flex items-start gap-2 text-sm">
                            <Check className="h-4 w-4 text-emerald-500 shrink-0 mt-0.5" />
                            <span>
                              {f.name}
                              {link.custom_value ? <span className="text-muted-foreground"> · {link.custom_value}</span> : null}
                            </span>
                          </div>
                        );
                      })
                    )}
                  </div>

                  {plan.gateway_ids && plan.gateway_ids.length > 0 && (
                    <div className="border-t mt-4 pt-4">
                      <p className="text-xs text-muted-foreground mb-2">Pay with</p>
                      <div className="flex flex-wrap gap-1.5">
                        {plan.gateway_ids.map((g) => {
                          const provider = PAYMENT_PROVIDERS.find((p) => p.key === g);
                          return (
                            <Badge key={g} variant="outline" className="text-xs">
                              {provider?.label ?? g}
                            </Badge>
                          );
                        })}
                      </div>
                    </div>
                  )}
                </Card>
              );
            })}
          </div>
        )}
      </section>

      {/* Comparison table */}
      {!isLoading && plans.length > 0 && masterFeatures.length > 0 && (
        <section className="container mx-auto px-4 pb-20 max-w-7xl">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold tracking-tight mb-2">Compare all features</h2>
            <p className="text-muted-foreground">Everything you get with each plan, side by side.</p>
          </div>
          <PricingComparisonTable
            plans={plans}
            masterFeatures={masterFeatures}
            planFeatures={planFeatures}
            interval={interval}
            cta={(p) => (
              <Button asChild size="sm" variant={p.is_popular ? "default" : "outline"} className="w-full">
                <Link to="/login">Choose {p.name}</Link>
              </Button>
            )}
          />
        </section>
      )}

      {/* AI Bot usage cost notice */}
      <section className="container mx-auto px-4 pb-16 max-w-5xl">
        <Card className="p-6 border-primary/30 bg-gradient-to-br from-primary/5 to-transparent">
          <div className="flex items-start gap-4">
            <div className="grid h-12 w-12 place-items-center rounded-lg bg-primary/15 text-primary shrink-0">
              <Sparkles className="h-6 w-6" />
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-2 flex-wrap">
                <h3 className="text-lg font-semibold">AI Bot usage — billed separately</h3>
                <Badge variant="secondary" className="text-[10px]">Add-on · Usage-based</Badge>
              </div>
              <p className="text-sm text-muted-foreground mt-2">
                All plans include the AI Bot builder at no extra subscription cost. AI replies,
                lead classification, and conversation analysis are metered <strong>per request</strong>
                {" "}and deducted from your workspace's AI credit balance — you only pay for what
                the bot actually uses.
              </p>
              <div className="grid gap-3 sm:grid-cols-3 mt-4">
                <div className="rounded-lg border bg-background/60 p-3">
                  <div className="text-sm font-medium text-emerald-600">Economy</div>
                  <p className="text-xs font-medium mt-1">Gemini Flash / GPT-5 Nano</p>
                  <p className="text-xs text-muted-foreground mt-1">Lowest cost per reply. Great for FAQ &amp; lead capture.</p>
                </div>
                <div className="rounded-lg border bg-background/60 p-3">
                  <div className="text-sm font-medium text-amber-600">Balanced</div>
                  <p className="text-xs font-medium mt-1">Gemini Pro / GPT-5 Mini</p>
                  <p className="text-xs text-muted-foreground mt-1">Mid-range cost. Better reasoning &amp; longer context.</p>
                </div>
                <div className="rounded-lg border bg-background/60 p-3">
                  <div className="text-sm font-medium text-violet-600">Premium</div>
                  <p className="text-xs font-medium mt-1">GPT-5 / GPT-5 Pro</p>
                  <p className="text-xs text-muted-foreground mt-1">Highest cost. Best for nuanced sales conversations.</p>
                </div>
              </div>
              <p className="text-xs text-muted-foreground mt-3">
                Top-ups and real-time usage tracking are available inside Slice under
                Settings → Plans &amp; credits. WhatsApp conversation charges from Meta are
                billed separately as per Meta's pricing.
              </p>
            </div>
          </div>
        </Card>
      </section>

      <div className="text-center pb-20 max-w-2xl mx-auto px-4">
        <h2 className="text-2xl font-semibold mb-3">Need a custom plan?</h2>
        <p className="text-muted-foreground mb-6">
          Talk to our team about volume discounts, custom limits, or enterprise features.
        </p>
        <Button asChild variant="outline">
          <Link to="/login">Contact us</Link>
        </Button>
      </div>

    </div>
  );
}
