import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { supabase } from "@/integrations/supabase/client";
import { acceptInvitation } from "@/lib/workspaces.functions";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Loader2, MessageCircle } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/invite/$token")({
  component: AcceptInvite,
  head: () => ({ meta: [{ title: "Accept invitation — Slice" }] }),
});

function AcceptInvite() {
  const { token } = Route.useParams();
  const navigate = useNavigate();
  const acceptFn = useServerFn(acceptInvitation);
  const [status, setStatus] = useState<"checking" | "needs-auth" | "accepting" | "done" | "error">("checking");
  const [error, setError] = useState("");

  useEffect(() => {
    (async () => {
      const { data } = await supabase.auth.getSession();
      if (!data.session) {
        setStatus("needs-auth");
        return;
      }
      setStatus("accepting");
      try {
        await acceptFn({ data: { token } });
        localStorage.setItem("wati:current_workspace", "");
        toast.success("Joined workspace");
        setStatus("done");
        setTimeout(() => navigate({ to: "/dashboard" }), 800);
      } catch (e: any) {
        setError(e.message);
        setStatus("error");
      }
    })();
  }, [token, acceptFn, navigate]);

  return (
    <div className="min-h-screen grid place-items-center bg-[image:var(--gradient-subtle)] px-6">
      <Card className="w-full max-w-md p-8 text-center space-y-4">
        <div className="grid h-12 w-12 mx-auto place-items-center rounded-xl bg-[image:var(--gradient-primary)] text-primary-foreground">
          <MessageCircle className="h-6 w-6" />
        </div>
        <h1 className="font-display text-2xl font-bold">Workspace invitation</h1>

        {status === "checking" && <p className="text-muted-foreground"><Loader2 className="inline mr-2 h-4 w-4 animate-spin" />Checking session…</p>}
        {status === "needs-auth" && (
          <>
            <p className="text-sm text-muted-foreground">Sign in or create an account using the email this invite was sent to, then return to this link.</p>
            <Button className="w-full" onClick={() => navigate({ to: "/login" })}>Sign in</Button>
          </>
        )}
        {status === "accepting" && <p className="text-muted-foreground"><Loader2 className="inline mr-2 h-4 w-4 animate-spin" />Joining workspace…</p>}
        {status === "done" && <p className="text-success font-medium">You're in! Redirecting…</p>}
        {status === "error" && (
          <>
            <p className="text-destructive text-sm">{error}</p>
            <Button variant="outline" onClick={() => navigate({ to: "/dashboard" })}>Go to dashboard</Button>
          </>
        )}
      </Card>
    </div>
  );
}
