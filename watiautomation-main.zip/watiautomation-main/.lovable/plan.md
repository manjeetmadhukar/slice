## Goal
Add a new **Browse Abandonment Recovery** automation that sends a WhatsApp reminder when an identified visitor views a product on a connected Shopify/WooCommerce store but doesn't add to cart or purchase within a configured delay. This is additive only — no existing behavior changes.

## Backend

### 1. New migration
- `browse_events` — product view tracking
  - `id`, `workspace_id`, `integration_id`, `contact_id (null)`, `session_key` (visitor cookie), `phone` (normalized, nullable), `product_id`, `product_title`, `product_image_url`, `product_url`, `price_minor`, `currency`, `category`, `viewed_at`, `converted_at (null)`, `dispatched_at (null)`, `skip_reason (null)`, `dispatch_scheduled_at`
  - indexes on `(workspace_id, dispatch_scheduled_at)` and `(workspace_id, phone, product_id)`
- `browse_recovery_settings` (per workspace)
  - `workspace_id (pk)`, `enabled bool default false`, `delay_minutes int default 30`, `template_id uuid null`, `frequency_cap_hours int default 24` (min hours between messages to same contact), `product_include text[] default '{}'`, `product_exclude text[] default '{}'`, `category_include text[] default '{}'`, `min_price_minor bigint null`, `updated_at`
- `browse_recovery_clicks` — mirror of `cart_recovery_clicks` for tracking short-link opens
  - `id`, `workspace_id`, `browse_event_id`, `token unique`, `clicked_at`, `converted_at`
- GRANTs + RLS scoped to workspace members.

### 2. Server functions (`src/lib/browse-recovery.functions.ts`)
- `getBrowseSettings(workspace_id)` — load current settings + analytics summary
- `saveBrowseSettings({...})` — upsert settings (admin/owner only)
- `getBrowseAnalytics(workspace_id, range)` — views, sent, clicked, converted, revenue
- `getBrowseEvents(workspace_id, filters)` — paginated list for review

### 3. Public tracking endpoint (`src/routes/api/public/browse-track.ts`)
- POST `{ workspace_token, product_id, product_title, product_image, product_url, price_minor, currency, category, phone?, session_key }`
- Authenticates via `workspace_token` (reuse `lead_intake_tokens` pattern or add small `browse_tracker_tokens` table with a token per integration)
- Inserts into `browse_events`; if `phone` present, resolves/creates contact via `upsert_contact` RPC
- Computes `dispatch_scheduled_at = now + delay_minutes` when settings.enabled and phone/contact known and filters pass
- Sets CORS headers to allow cross-origin from any store domain

### 4. Dispatcher
Extend existing `src/routes/api/public/hooks/dispatch-ecommerce-automations.ts` (or add a sibling `dispatch-browse-recovery.ts`) to:
- Query due `browse_events` (`dispatch_scheduled_at <= now, dispatched_at null, converted_at null`)
- Enforce frequency cap per contact
- Send WA template via `sendWhatsAppMessage` with variables (name, product_title, price, short link to `/api/public/br/{token}`)
- Insert short-link row, mark `dispatched_at`
- Register the cron job (reuse existing pg_cron minute schedule).

### 5. Conversion detection
- In `src/lib/abandoned-carts.server.ts` cart upsert and Shopify/WooCommerce order webhooks: on add-to-cart or order for a contact/session, mark matching recent `browse_events` as `converted_at = now` so pending messages are skipped and analytics attribute revenue.

### 6. Short-link redirector (`src/routes/api/public/br/$token.ts`)
- Marks click, redirects to `product_url`. Mirrors existing recovery redirector.

## Client

### 7. New route `src/routes/_authenticated/browse-recovery.tsx`
- Enable/disable toggle
- Delay presets (5/15/30 min, 1/2/6/12/24h) + custom
- Template picker (workspace WhatsApp templates)
- Include/exclude product IDs, categories, min price
- Frequency cap hours
- Analytics cards: Views tracked, Messages sent, Clicks, Conversions, Attributed revenue
- Recent events table
- Snippet copy box with Shopify + WooCommerce install instructions (tracking script URL + workspace token)

### 8. Nav + feature gating
- Add nav entry under "Commerce" in `src/components/AppShell.tsx` behind `hasFeature("browse_recovery")` and `hasPermission("commerce","view")`
- Register key in `src/lib/features-catalog.ts` and `src/lib/permissions.ts` module list per core-rule

### 9. Tracking snippet (`public/slice-browse-tracker.js`)
- Vanilla JS auto-attaches to product pages, reads meta tags / OG / JSON-LD or dataset attributes for product info, sends beacon to `/api/public/browse-track`
- Reads/creates persistent `slice_bv` cookie for `session_key`; if user identified (phone in dataLayer or localStorage), sends it

### 10. WooCommerce plugin
- Add optional lightweight PHP hook in the existing Slice connector plugin to enqueue the tracker on `is_product()` pages with workspace token — deferred; snippet-based install works standalone for v1.

## Technical notes
- All new tables get GRANTs + RLS (see core rules).
- No modifications to existing automations, abandoned cart, or campaign paths.
- Feature gated by `browse_recovery` key so per-workspace plans control access.
- Uses existing `sendWhatsAppMessage` for retries/logging.

## Files
- migration (new)
- `src/lib/browse-recovery.functions.ts` (new)
- `src/lib/browse-recovery.server.ts` (new — dispatcher helpers, conversion tagging)
- `src/routes/api/public/browse-track.ts` (new)
- `src/routes/api/public/br/$token.ts` (new)
- `src/routes/api/public/hooks/dispatch-browse-recovery.ts` (new)
- `src/routes/_authenticated/browse-recovery.tsx` (new)
- `public/slice-browse-tracker.js` (new)
- `src/components/AppShell.tsx` (nav entry)
- `src/lib/features-catalog.ts`, `src/lib/permissions.ts` (register key)
- Hooks into `src/lib/abandoned-carts.server.ts` + order webhooks for conversion marking