ALTER TABLE public.payment_gateways
  ADD COLUMN IF NOT EXISTS secret_key text,
  ADD COLUMN IF NOT EXISTS webhook_secret text;