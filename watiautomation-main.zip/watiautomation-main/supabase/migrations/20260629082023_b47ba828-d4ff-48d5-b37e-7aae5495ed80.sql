update public.campaign_recipients
set
  status = 'suppressed',
  error = case
    when error ilike '%131049%' then error
    when error ilike '%ecosystem engagement%' then 'Meta #131049: Delivery suppressed by WhatsApp per-user marketing limits (healthy ecosystem engagement). This is not a Slice send/API failure. Wait at least 24 hours before retrying this recipient, use warmer/opted-in audiences, and improve the marketing template quality.'
    when error ilike '%130472%' then error
    when error ilike '%part of an experiment%' then 'Meta #130472: Delivery suppressed because this recipient is part of WhatsApp''s marketing message experiment. This is controlled by Meta and should not be retried immediately.'
    when error ilike '%131050%' then error
    when error ilike '%stop receiving marketing%' or error ilike '%opted out%' then 'Meta #131050: Recipient opted out of marketing messages from this business. Do not retry marketing templates for this recipient unless they opt back in.'
    else error
  end
where status = 'failed'
  and (
    error ilike '%131049%'
    or error ilike '%ecosystem engagement%'
    or error ilike '%130472%'
    or error ilike '%part of an experiment%'
    or error ilike '%131050%'
    or error ilike '%stop receiving marketing%'
    or error ilike '%opted out%'
  );

update public.campaigns c
set failed_count = counts.failed_count
from (
  select campaign_id, count(*) filter (where status = 'failed')::int as failed_count
  from public.campaign_recipients
  group by campaign_id
) counts
where c.id = counts.campaign_id;