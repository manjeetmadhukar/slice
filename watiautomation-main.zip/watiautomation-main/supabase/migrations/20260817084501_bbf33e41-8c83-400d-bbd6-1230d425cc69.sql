CREATE OR REPLACE FUNCTION public.cleanup_debug_logs()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  DELETE FROM public.integration_debug_logs WHERE created_at < now() - interval '7 days';
  DELETE FROM public.whatsapp_delivery_logs WHERE created_at < now() - interval '30 days';
  BEGIN
    DELETE FROM cron.job_run_details WHERE end_time < now() - interval '3 days';
  EXCEPTION WHEN OTHERS THEN NULL;
  END;
END;
$$;