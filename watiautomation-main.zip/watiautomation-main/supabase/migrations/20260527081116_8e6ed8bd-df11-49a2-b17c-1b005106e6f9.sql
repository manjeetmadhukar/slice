
-- Super admin flag on profiles
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS is_super_admin boolean NOT NULL DEFAULT false;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS is_suspended boolean NOT NULL DEFAULT false;

-- Helper: is current/given user a super admin?
CREATE OR REPLACE FUNCTION public.is_super_admin(_user_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (SELECT 1 FROM public.profiles WHERE id = _user_id AND is_super_admin = true);
$$;

-- Update handle_new_user to auto-promote the first registered user as super admin
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $function$
DECLARE
  new_ws UUID;
  base_name TEXT;
  is_first BOOLEAN;
BEGIN
  SELECT NOT EXISTS (SELECT 1 FROM public.profiles) INTO is_first;

  INSERT INTO public.profiles (id, email, full_name, is_super_admin)
  VALUES (new.id, new.email, COALESCE(new.raw_user_meta_data->>'full_name', new.email), is_first);

  base_name := COALESCE(new.raw_user_meta_data->>'full_name', split_part(new.email, '@', 1), 'Workspace');

  INSERT INTO public.workspaces (name, slug, owner_id)
  VALUES (
    base_name || '''s Workspace',
    lower(regexp_replace(base_name, '[^a-z0-9]+', '-', 'gi')) || '-' || substr(new.id::text, 1, 6),
    new.id
  )
  RETURNING id INTO new_ws;

  INSERT INTO public.workspace_members (workspace_id, user_id, role)
  VALUES (new_ws, new.id, 'owner');

  INSERT INTO public.whatsapp_settings (user_id, workspace_id) VALUES (new.id, new_ws);

  RETURN new;
END;
$function$;

-- Promote the earliest existing profile if no super admin exists yet
UPDATE public.profiles
SET is_super_admin = true
WHERE id = (SELECT id FROM public.profiles ORDER BY created_at ASC LIMIT 1)
AND NOT EXISTS (SELECT 1 FROM public.profiles WHERE is_super_admin = true);

-- Allow super admins to view all profiles
CREATE POLICY "super admins view all profiles"
ON public.profiles FOR SELECT
USING (public.is_super_admin(auth.uid()));

CREATE POLICY "super admins update profiles"
ON public.profiles FOR UPDATE
USING (public.is_super_admin(auth.uid()));

-- Allow super admins to view all workspaces and members
CREATE POLICY "super admins view all workspaces"
ON public.workspaces FOR SELECT
USING (public.is_super_admin(auth.uid()));

CREATE POLICY "super admins view all members"
ON public.workspace_members FOR SELECT
USING (public.is_super_admin(auth.uid()));

-- Custom per-workspace plan defined by super admin
CREATE TABLE public.workspace_plans (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id uuid NOT NULL UNIQUE,
  plan_name text NOT NULL DEFAULT 'Custom',
  features jsonb NOT NULL DEFAULT '{}'::jsonb,
  limits jsonb NOT NULL DEFAULT '{}'::jsonb,
  notes text,
  assigned_by uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.workspace_plans TO authenticated;
GRANT ALL ON public.workspace_plans TO service_role;

ALTER TABLE public.workspace_plans ENABLE ROW LEVEL SECURITY;

CREATE POLICY "members view their workspace plan"
ON public.workspace_plans FOR SELECT
USING (public.is_workspace_member(workspace_id, auth.uid()) OR public.is_super_admin(auth.uid()));

CREATE POLICY "super admins manage plans"
ON public.workspace_plans FOR ALL
USING (public.is_super_admin(auth.uid()))
WITH CHECK (public.is_super_admin(auth.uid()));

CREATE TRIGGER update_workspace_plans_updated_at
BEFORE UPDATE ON public.workspace_plans
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
