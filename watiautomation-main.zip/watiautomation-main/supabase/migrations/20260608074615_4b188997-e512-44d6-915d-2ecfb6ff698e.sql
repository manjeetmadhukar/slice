
-- 1. Extend plan_templates
ALTER TABLE public.plan_templates
  ADD COLUMN IF NOT EXISTS is_popular boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS badge_text text,
  ADD COLUMN IF NOT EXISTS position integer NOT NULL DEFAULT 0;

-- 2. Master feature library
CREATE TABLE IF NOT EXISTS public.master_features (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  category text NOT NULL,
  icon text,
  position integer NOT NULL DEFAULT 0,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT ON public.master_features TO anon, authenticated;
GRANT ALL ON public.master_features TO service_role;
ALTER TABLE public.master_features ENABLE ROW LEVEL SECURITY;

CREATE POLICY "anyone can view master features"
  ON public.master_features FOR SELECT
  USING (true);

CREATE POLICY "super admins manage master features"
  ON public.master_features FOR ALL
  USING (public.is_super_admin(auth.uid()))
  WITH CHECK (public.is_super_admin(auth.uid()));

CREATE TRIGGER update_master_features_updated_at
  BEFORE UPDATE ON public.master_features
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- 3. Plan ↔ feature junction
CREATE TABLE IF NOT EXISTS public.plan_template_features (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  template_id uuid NOT NULL REFERENCES public.plan_templates(id) ON DELETE CASCADE,
  feature_id uuid NOT NULL REFERENCES public.master_features(id) ON DELETE CASCADE,
  included boolean NOT NULL DEFAULT true,
  custom_value text,
  position integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (template_id, feature_id)
);

GRANT SELECT ON public.plan_template_features TO anon, authenticated;
GRANT ALL ON public.plan_template_features TO service_role;
ALTER TABLE public.plan_template_features ENABLE ROW LEVEL SECURITY;

CREATE POLICY "anyone can view plan features"
  ON public.plan_template_features FOR SELECT
  USING (true);

CREATE POLICY "super admins manage plan features"
  ON public.plan_template_features FOR ALL
  USING (public.is_super_admin(auth.uid()))
  WITH CHECK (public.is_super_admin(auth.uid()));

CREATE TRIGGER update_plan_template_features_updated_at
  BEFORE UPDATE ON public.plan_template_features
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE INDEX IF NOT EXISTS idx_ptf_template ON public.plan_template_features(template_id);
CREATE INDEX IF NOT EXISTS idx_ptf_feature ON public.plan_template_features(feature_id);

-- 4. Seed master features
INSERT INTO public.master_features (name, description, category, icon, position) VALUES
  -- WhatsApp API
  ('Official WhatsApp Cloud API', 'Verified Meta Cloud API access', 'WhatsApp API', 'MessageCircle', 10),
  ('WhatsApp Number Connection', 'Connect your business number', 'WhatsApp API', 'Phone', 20),
  ('Shared Team Inbox', 'Collaborative inbox for your team', 'Inbox & Team', 'Inbox', 30),
  ('Multi-Agent Support', 'Multiple agents on the same number', 'Inbox & Team', 'Users', 40),
  -- CRM
  ('Contacts Management', 'Organize and tag contacts', 'CRM', 'BookUser', 50),
  ('Lead Management', 'Capture and nurture leads', 'CRM', 'UserPlus', 60),
  ('Sales Pipeline', 'Drag-and-drop deal stages', 'CRM', 'Columns3', 70),
  ('Customer Segmentation', 'Segment customers by attributes', 'CRM', 'PieChart', 80),
  -- Marketing
  ('Broadcast Campaigns', 'Send bulk WhatsApp campaigns', 'Marketing', 'Megaphone', 90),
  ('Campaign Scheduling', 'Schedule campaigns in advance', 'Marketing', 'CalendarClock', 100),
  ('Click-to-WhatsApp Ads', 'Run CTWA ads from your account', 'Marketing', 'MousePointerClick', 110),
  ('Instagram DM Automation', 'Automate Instagram DMs', 'Marketing', 'Instagram', 120),
  ('Facebook Lead Ads Integration', 'Sync Facebook lead form leads', 'Marketing', 'Facebook', 130),
  -- Automation
  ('Workflow Automation', 'Visual automation builder', 'Automation', 'Workflow', 140),
  ('Auto Replies', 'Keyword-based auto replies', 'Automation', 'Reply', 150),
  ('Drip Campaigns', 'Multi-step nurture sequences', 'Automation', 'Droplets', 160),
  ('Lead Assignment', 'Round-robin lead routing', 'Automation', 'UsersRound', 170),
  ('Follow-up Automation', 'Automated follow-up reminders', 'Automation', 'BellRing', 180),
  -- AI
  ('AI Chatbot', 'AI-powered chatbot replies', 'AI Bots', 'Bot', 190),
  ('AI Knowledge Base', 'Train the AI on your docs', 'AI Bots', 'BookOpen', 200),
  ('AI Lead Qualification', 'AI scores and qualifies leads', 'AI Bots', 'Sparkles', 210),
  ('AI Customer Support', 'AI-driven customer support', 'AI Bots', 'Headphones', 220),
  -- E-commerce
  ('Shopify Integration', 'Connect your Shopify store', 'E-commerce', 'ShoppingBag', 230),
  ('WooCommerce Integration', 'Connect your WooCommerce store', 'E-commerce', 'Store', 240),
  ('Abandoned Cart Recovery', 'Automated cart recovery flows', 'E-commerce', 'ShoppingCart', 250),
  ('COD Verification', 'Verify COD orders on WhatsApp', 'E-commerce', 'PackageCheck', 260),
  ('Order Notifications', 'Automated order updates', 'E-commerce', 'Package', 270),
  ('Shipping Updates', 'Real-time shipping updates', 'E-commerce', 'Truck', 280),
  ('Product Catalog Sync', 'Sync product catalog to WhatsApp', 'E-commerce', 'LayoutGrid', 290),
  ('Review Collection Automation', 'Collect reviews after delivery', 'E-commerce', 'Star', 300),
  -- Analytics
  ('Campaign Reports', 'Detailed campaign analytics', 'Analytics', 'BarChart3', 310),
  ('Agent Performance Reports', 'Track agent performance', 'Analytics', 'Activity', 320),
  ('Revenue Tracking', 'Attribute revenue to chats', 'Analytics', 'DollarSign', 330),
  ('Conversion Tracking', 'Track funnel conversions', 'Analytics', 'TrendingUp', 340),
  -- Integrations
  ('Webhooks', 'Outbound event webhooks', 'Integrations', 'Webhook', 350),
  ('Zapier', 'Connect 5000+ apps via Zapier', 'Integrations', 'Zap', 360),
  ('Make.com', 'Build flows with Make.com', 'Integrations', 'Workflow', 370),
  ('API Access', 'Full REST API access', 'Integrations', 'Code', 380),
  -- Support
  ('Email Support', 'Email support during business hours', 'Support', 'Mail', 390),
  ('Priority Support', 'Faster response times', 'Support', 'Zap', 400),
  ('Dedicated Account Manager', 'Personal account manager', 'Support', 'UserCheck', 410),
  -- Advanced
  ('White Label', 'Remove Slice branding', 'Advanced Features', 'Crown', 420),
  ('Custom Branding', 'Use your own brand assets', 'Advanced Features', 'Palette', 430),
  ('Custom Domain', 'Host on your own domain', 'Advanced Features', 'Globe', 440),
  ('Role Based Permissions', 'Granular role permissions', 'Advanced Features', 'Shield', 450)
ON CONFLICT DO NOTHING;
