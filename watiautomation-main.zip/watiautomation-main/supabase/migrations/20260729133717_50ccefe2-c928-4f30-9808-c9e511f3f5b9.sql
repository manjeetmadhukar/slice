
-- Settings per workspace
CREATE TABLE public.browse_recovery_settings (
  workspace_id UUID PRIMARY KEY REFERENCES public.workspaces(id) ON DELETE CASCADE,
  enabled BOOLEAN NOT NULL DEFAULT false,
  delay_minutes INTEGER NOT NULL DEFAULT 30,
  template_id UUID NULL,
  template_language TEXT NULL DEFAULT 'en',
  frequency_cap_hours INTEGER NOT NULL DEFAULT 24,
  product_include TEXT[] NOT NULL DEFAULT '{}',
  product_exclude TEXT[] NOT NULL DEFAULT '{}',
  category_include TEXT[] NOT NULL DEFAULT '{}',
  min_price_minor BIGINT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.browse_recovery_settings TO authenticated;
GRANT ALL ON public.browse_recovery_settings TO service_role;
ALTER TABLE public.browse_recovery_settings ENABLE ROW LEVEL SECURITY;
CREATE POLICY "brs_select_members" ON public.browse_recovery_settings FOR SELECT TO authenticated
  USING (public.is_workspace_member(workspace_id, auth.uid()));
CREATE POLICY "brs_write_admins" ON public.browse_recovery_settings FOR ALL TO authenticated
  USING (public.has_workspace_role(workspace_id, auth.uid(), ARRAY['owner','admin']::app_role[]))
  WITH CHECK (public.has_workspace_role(workspace_id, auth.uid(), ARRAY['owner','admin']::app_role[]));
CREATE TRIGGER brs_updated BEFORE UPDATE ON public.browse_recovery_settings
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Tracker tokens (public tokens for the storefront snippet)
CREATE TABLE public.browse_tracker_tokens (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id UUID NOT NULL REFERENCES public.workspaces(id) ON DELETE CASCADE,
  token TEXT NOT NULL UNIQUE,
  label TEXT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  last_used_at TIMESTAMPTZ NULL
);
CREATE INDEX btt_ws_idx ON public.browse_tracker_tokens(workspace_id);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.browse_tracker_tokens TO authenticated;
GRANT ALL ON public.browse_tracker_tokens TO service_role;
ALTER TABLE public.browse_tracker_tokens ENABLE ROW LEVEL SECURITY;
CREATE POLICY "btt_select_members" ON public.browse_tracker_tokens FOR SELECT TO authenticated
  USING (public.is_workspace_member(workspace_id, auth.uid()));
CREATE POLICY "btt_write_admins" ON public.browse_tracker_tokens FOR ALL TO authenticated
  USING (public.has_workspace_role(workspace_id, auth.uid(), ARRAY['owner','admin']::app_role[]))
  WITH CHECK (public.has_workspace_role(workspace_id, auth.uid(), ARRAY['owner','admin']::app_role[]));

-- Browse events
CREATE TABLE public.browse_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id UUID NOT NULL REFERENCES public.workspaces(id) ON DELETE CASCADE,
  contact_id UUID NULL REFERENCES public.contacts(id) ON DELETE SET NULL,
  session_key TEXT NULL,
  phone TEXT NULL,
  phone_normalized TEXT NULL,
  product_id TEXT NOT NULL,
  product_title TEXT NULL,
  product_image_url TEXT NULL,
  product_url TEXT NOT NULL,
  price_minor BIGINT NULL,
  currency TEXT NULL,
  category TEXT NULL,
  source TEXT NULL,
  viewed_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  dispatch_scheduled_at TIMESTAMPTZ NULL,
  dispatched_at TIMESTAMPTZ NULL,
  converted_at TIMESTAMPTZ NULL,
  conversion_value_minor BIGINT NULL,
  skip_reason TEXT NULL,
  wa_message_id TEXT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX be_ws_due_idx ON public.browse_events(workspace_id, dispatch_scheduled_at)
  WHERE dispatched_at IS NULL AND converted_at IS NULL;
CREATE INDEX be_ws_phone_prod_idx ON public.browse_events(workspace_id, phone_normalized, product_id);
CREATE INDEX be_ws_session_idx ON public.browse_events(workspace_id, session_key);
CREATE INDEX be_ws_viewed_idx ON public.browse_events(workspace_id, viewed_at DESC);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.browse_events TO authenticated;
GRANT ALL ON public.browse_events TO service_role;
ALTER TABLE public.browse_events ENABLE ROW LEVEL SECURITY;
CREATE POLICY "be_select_members" ON public.browse_events FOR SELECT TO authenticated
  USING (public.is_workspace_member(workspace_id, auth.uid()));

-- Browse recovery clicks
CREATE TABLE public.browse_recovery_clicks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id UUID NOT NULL REFERENCES public.workspaces(id) ON DELETE CASCADE,
  browse_event_id UUID NOT NULL REFERENCES public.browse_events(id) ON DELETE CASCADE,
  token TEXT NOT NULL UNIQUE,
  target_url TEXT NOT NULL,
  clicked_at TIMESTAMPTZ NULL,
  converted_at TIMESTAMPTZ NULL,
  conversion_value_minor BIGINT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX brc_ws_idx ON public.browse_recovery_clicks(workspace_id);
CREATE INDEX brc_event_idx ON public.browse_recovery_clicks(browse_event_id);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.browse_recovery_clicks TO authenticated;
GRANT ALL ON public.browse_recovery_clicks TO service_role;
ALTER TABLE public.browse_recovery_clicks ENABLE ROW LEVEL SECURITY;
CREATE POLICY "brc_select_members" ON public.browse_recovery_clicks FOR SELECT TO authenticated
  USING (public.is_workspace_member(workspace_id, auth.uid()));
