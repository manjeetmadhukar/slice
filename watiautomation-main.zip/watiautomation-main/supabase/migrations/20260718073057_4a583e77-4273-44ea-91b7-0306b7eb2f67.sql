
REVOKE ALL ON FUNCTION public.consume_ai_credits(uuid, bigint, text, text, jsonb) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.consume_ai_credits(uuid, bigint, text, text, jsonb) TO service_role;

REVOKE ALL ON FUNCTION public.admin_adjust_ai_credits(uuid, bigint, text, text, uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.admin_adjust_ai_credits(uuid, bigint, text, text, uuid) TO authenticated, service_role;
