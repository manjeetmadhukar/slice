CREATE TABLE public.ecom_automation_runs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id uuid NOT NULL,
  integration_id uuid,
  automation_key text NOT NULL,
  target_type text NOT NULL,
  target_id text NOT NULL,
  ok boolean NOT NULL DEFAULT true,
  message text,
  sent_at timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX ecom_automation_runs_unique
  ON public.ecom_automation_runs (workspace_id, automation_key, target_type, target_id);

CREATE INDEX ecom_automation_runs_lookup
  ON public.ecom_automation_runs (workspace_id, automation_key, sent_at DESC);

GRANT SELECT ON public.ecom_automation_runs TO authenticated;
GRANT ALL ON public.ecom_automation_runs TO service_role;

ALTER TABLE public.ecom_automation_runs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "workspace members view automation runs"
  ON public.ecom_automation_runs FOR SELECT
  TO authenticated
  USING (public.is_workspace_member(workspace_id, auth.uid()));
