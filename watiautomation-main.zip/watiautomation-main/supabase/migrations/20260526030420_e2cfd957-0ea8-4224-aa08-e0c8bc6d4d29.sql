
-- Contact enrichment
ALTER TABLE public.contacts
  ADD COLUMN IF NOT EXISTS city text,
  ADD COLUMN IF NOT EXISTS lead_source text,
  ADD COLUMN IF NOT EXISTS lead_stage text DEFAULT 'new',
  ADD COLUMN IF NOT EXISTS lifetime_value numeric(12,2) NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS total_orders integer NOT NULL DEFAULT 0;

-- Conversation priority
ALTER TABLE public.conversations
  ADD COLUMN IF NOT EXISTS priority text NOT NULL DEFAULT 'normal';

-- Pipeline stages
CREATE TABLE IF NOT EXISTS public.pipeline_stages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id uuid NOT NULL,
  name text NOT NULL,
  color text NOT NULL DEFAULT '#64748b',
  position integer NOT NULL DEFAULT 0,
  is_won boolean NOT NULL DEFAULT false,
  is_lost boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.pipeline_stages ENABLE ROW LEVEL SECURITY;
CREATE POLICY "workspace members manage pipeline stages"
  ON public.pipeline_stages FOR ALL
  USING (is_workspace_member(workspace_id, auth.uid()))
  WITH CHECK (is_workspace_member(workspace_id, auth.uid()));
CREATE INDEX IF NOT EXISTS idx_pipeline_stages_ws ON public.pipeline_stages(workspace_id, position);

-- Deals
CREATE TABLE IF NOT EXISTS public.deals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id uuid NOT NULL,
  user_id uuid NOT NULL,
  contact_id uuid,
  stage_id uuid NOT NULL,
  title text NOT NULL,
  value numeric(12,2) NOT NULL DEFAULT 0,
  currency text NOT NULL DEFAULT 'USD',
  expected_close_date date,
  assigned_to uuid,
  score integer NOT NULL DEFAULT 0,
  notes text,
  position integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.deals ENABLE ROW LEVEL SECURITY;
CREATE POLICY "workspace members manage deals"
  ON public.deals FOR ALL
  USING (is_workspace_member(workspace_id, auth.uid()))
  WITH CHECK (is_workspace_member(workspace_id, auth.uid()));
CREATE INDEX IF NOT EXISTS idx_deals_ws_stage ON public.deals(workspace_id, stage_id, position);

-- Follow-ups
CREATE TABLE IF NOT EXISTS public.follow_ups (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id uuid NOT NULL,
  user_id uuid NOT NULL,
  contact_id uuid,
  conversation_id uuid,
  deal_id uuid,
  title text NOT NULL,
  notes text,
  due_at timestamptz NOT NULL,
  assigned_to uuid,
  status text NOT NULL DEFAULT 'pending',
  type text NOT NULL DEFAULT 'manual',
  template_id uuid,
  completed_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.follow_ups ENABLE ROW LEVEL SECURITY;
CREATE POLICY "workspace members manage follow-ups"
  ON public.follow_ups FOR ALL
  USING (is_workspace_member(workspace_id, auth.uid()))
  WITH CHECK (is_workspace_member(workspace_id, auth.uid()));
CREATE INDEX IF NOT EXISTS idx_follow_ups_ws_due ON public.follow_ups(workspace_id, status, due_at);

-- Store integrations
CREATE TABLE IF NOT EXISTS public.store_integrations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id uuid NOT NULL,
  user_id uuid NOT NULL,
  provider text NOT NULL,
  store_url text NOT NULL,
  access_token text,
  api_key text,
  api_secret text,
  webhook_secret text,
  status text NOT NULL DEFAULT 'pending',
  last_sync_at timestamptz,
  total_revenue numeric(14,2) NOT NULL DEFAULT 0,
  meta jsonb NOT NULL DEFAULT '{}',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.store_integrations ENABLE ROW LEVEL SECURITY;
CREATE POLICY "members view store integrations"
  ON public.store_integrations FOR SELECT
  USING (is_workspace_member(workspace_id, auth.uid()));
CREATE POLICY "admins manage store integrations"
  ON public.store_integrations FOR ALL
  USING (has_workspace_role(workspace_id, auth.uid(), ARRAY['owner'::app_role, 'admin'::app_role]))
  WITH CHECK (has_workspace_role(workspace_id, auth.uid(), ARRAY['owner'::app_role, 'admin'::app_role]));

-- Ecom customers
CREATE TABLE IF NOT EXISTS public.ecom_customers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id uuid NOT NULL,
  integration_id uuid,
  external_id text,
  contact_id uuid,
  email text,
  phone text,
  name text,
  total_orders integer NOT NULL DEFAULT 0,
  lifetime_value numeric(12,2) NOT NULL DEFAULT 0,
  last_order_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.ecom_customers ENABLE ROW LEVEL SECURITY;
CREATE POLICY "workspace members manage ecom customers"
  ON public.ecom_customers FOR ALL
  USING (is_workspace_member(workspace_id, auth.uid()))
  WITH CHECK (is_workspace_member(workspace_id, auth.uid()));

-- Ecom orders
CREATE TABLE IF NOT EXISTS public.ecom_orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id uuid NOT NULL,
  integration_id uuid,
  external_id text,
  order_number text,
  contact_id uuid,
  customer_id uuid,
  customer_name text,
  customer_phone text,
  total numeric(12,2) NOT NULL DEFAULT 0,
  currency text NOT NULL DEFAULT 'USD',
  payment_status text NOT NULL DEFAULT 'pending',
  fulfillment_status text NOT NULL DEFAULT 'unfulfilled',
  cod_status text,
  whatsapp_notified boolean NOT NULL DEFAULT false,
  source text,
  items jsonb NOT NULL DEFAULT '[]',
  placed_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.ecom_orders ENABLE ROW LEVEL SECURITY;
CREATE POLICY "workspace members manage ecom orders"
  ON public.ecom_orders FOR ALL
  USING (is_workspace_member(workspace_id, auth.uid()))
  WITH CHECK (is_workspace_member(workspace_id, auth.uid()));
CREATE INDEX IF NOT EXISTS idx_ecom_orders_ws ON public.ecom_orders(workspace_id, placed_at DESC);

-- Abandoned carts
CREATE TABLE IF NOT EXISTS public.abandoned_carts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id uuid NOT NULL,
  integration_id uuid,
  external_id text,
  contact_id uuid,
  customer_name text,
  customer_phone text,
  customer_email text,
  total numeric(12,2) NOT NULL DEFAULT 0,
  currency text NOT NULL DEFAULT 'USD',
  checkout_url text,
  items jsonb NOT NULL DEFAULT '[]',
  status text NOT NULL DEFAULT 'abandoned',
  reminders_sent integer NOT NULL DEFAULT 0,
  last_reminder_at timestamptz,
  recovered_at timestamptz,
  recovered_revenue numeric(12,2) NOT NULL DEFAULT 0,
  abandoned_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.abandoned_carts ENABLE ROW LEVEL SECURITY;
CREATE POLICY "workspace members manage abandoned carts"
  ON public.abandoned_carts FOR ALL
  USING (is_workspace_member(workspace_id, auth.uid()))
  WITH CHECK (is_workspace_member(workspace_id, auth.uid()));
CREATE INDEX IF NOT EXISTS idx_abandoned_carts_ws ON public.abandoned_carts(workspace_id, status, abandoned_at DESC);

-- Seed default pipeline stages for each existing workspace that has none
INSERT INTO public.pipeline_stages (workspace_id, name, color, position, is_won, is_lost)
SELECT w.id, s.name, s.color, s.pos, s.is_won, s.is_lost
FROM public.workspaces w
CROSS JOIN (VALUES
  ('New Lead',        '#64748b', 0, false, false),
  ('Contacted',       '#3b82f6', 1, false, false),
  ('Interested',      '#8b5cf6', 2, false, false),
  ('Negotiation',     '#f59e0b', 3, false, false),
  ('Payment Pending', '#f97316', 4, false, false),
  ('Converted',       '#10b981', 5, true,  false)
) AS s(name, color, pos, is_won, is_lost)
WHERE NOT EXISTS (
  SELECT 1 FROM public.pipeline_stages ps WHERE ps.workspace_id = w.id
);

-- Trigger to seed stages on new workspaces
CREATE OR REPLACE FUNCTION public.seed_default_pipeline_stages()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.pipeline_stages (workspace_id, name, color, position, is_won, is_lost) VALUES
    (NEW.id, 'New Lead',        '#64748b', 0, false, false),
    (NEW.id, 'Contacted',       '#3b82f6', 1, false, false),
    (NEW.id, 'Interested',      '#8b5cf6', 2, false, false),
    (NEW.id, 'Negotiation',     '#f59e0b', 3, false, false),
    (NEW.id, 'Payment Pending', '#f97316', 4, false, false),
    (NEW.id, 'Converted',       '#10b981', 5, true,  false);
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_seed_pipeline_stages ON public.workspaces;
CREATE TRIGGER trg_seed_pipeline_stages
AFTER INSERT ON public.workspaces
FOR EACH ROW EXECUTE FUNCTION public.seed_default_pipeline_stages();
