UPDATE public.messages m
SET status_error = COALESCE(
      'Meta #' || (l.payload->'errors'->0->>'code') || ': ' ||
      COALESCE(l.payload->'errors'->0->'error_data'->>'details', l.payload->'errors'->0->>'message'),
      m.status_error),
    status_error_code = NULLIF(l.payload->'errors'->0->>'code','')::int
FROM public.integration_debug_logs l
WHERE l.event = 'webhook.status.failed'
  AND l.payload->>'id' = m.wa_message_id
  AND m.status = 'failed'
  AND m.status_error IS NULL;