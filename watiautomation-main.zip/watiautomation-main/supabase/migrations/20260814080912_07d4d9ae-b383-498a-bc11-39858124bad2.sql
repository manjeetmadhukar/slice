ALTER TABLE public.messages
  ADD COLUMN IF NOT EXISTS status_error text,
  ADD COLUMN IF NOT EXISTS status_error_code integer;