
-- 1. Normalization helper
CREATE OR REPLACE FUNCTION public.normalize_phone(p text)
RETURNS text
LANGUAGE sql
IMMUTABLE
SET search_path = public
AS $$
  SELECT NULLIF(regexp_replace(COALESCE(p, ''), '\D', '', 'g'), '')
$$;

-- 2. Backfill: merge duplicate contacts per (workspace, normalized phone)
DO $mig$
DECLARE
  r record;
BEGIN
  FOR r IN
    SELECT
      workspace_id,
      public.normalize_phone(phone) AS norm,
      (array_agg(id ORDER BY created_at ASC, id ASC))[1] AS keeper,
      array_agg(id) AS all_ids
    FROM public.contacts
    WHERE public.normalize_phone(phone) IS NOT NULL
    GROUP BY 1, 2
    HAVING count(*) > 1
  LOOP
    -- Reassign soft foreign keys from losers to keeper
    UPDATE public.abandoned_carts        SET contact_id = r.keeper WHERE contact_id = ANY(r.all_ids) AND contact_id <> r.keeper;
    UPDATE public.ai_message_analyses    SET contact_id = r.keeper WHERE contact_id = ANY(r.all_ids) AND contact_id <> r.keeper;
    UPDATE public.bot_sessions           SET contact_id = r.keeper WHERE contact_id = ANY(r.all_ids) AND contact_id <> r.keeper;
    UPDATE public.campaign_recipients    SET contact_id = r.keeper WHERE contact_id = ANY(r.all_ids) AND contact_id <> r.keeper;
    UPDATE public.conversations          SET contact_id = r.keeper WHERE contact_id = ANY(r.all_ids) AND contact_id <> r.keeper;
    UPDATE public.deals                  SET contact_id = r.keeper WHERE contact_id = ANY(r.all_ids) AND contact_id <> r.keeper;
    UPDATE public.ecom_customers         SET contact_id = r.keeper WHERE contact_id = ANY(r.all_ids) AND contact_id <> r.keeper;
    UPDATE public.ecom_orders            SET contact_id = r.keeper WHERE contact_id = ANY(r.all_ids) AND contact_id <> r.keeper;
    UPDATE public.follow_ups             SET contact_id = r.keeper WHERE contact_id = ANY(r.all_ids) AND contact_id <> r.keeper;
    UPDATE public.whatsapp_delivery_logs SET contact_id = r.keeper WHERE contact_id = ANY(r.all_ids) AND contact_id <> r.keeper;
    UPDATE public.whatsapp_group_members SET contact_id = r.keeper WHERE contact_id = ANY(r.all_ids) AND contact_id <> r.keeper;

    -- Group members: honor unique(group_id, contact_id) — drop dup rows first
    DELETE FROM public.contact_group_members m
     WHERE m.contact_id = ANY(r.all_ids)
       AND m.contact_id <> r.keeper
       AND EXISTS (
         SELECT 1 FROM public.contact_group_members k
         WHERE k.group_id = m.group_id AND k.contact_id = r.keeper
       );
    UPDATE public.contact_group_members SET contact_id = r.keeper
     WHERE contact_id = ANY(r.all_ids) AND contact_id <> r.keeper;

    -- Merge fields into keeper: union tags, merge custom_fields, prefer non-null values
    WITH agg AS (
      SELECT
        (SELECT array(SELECT DISTINCT t FROM (
            SELECT unnest(tags) AS t FROM public.contacts WHERE id = ANY(r.all_ids)
          ) x WHERE t IS NOT NULL AND t <> '')) AS tags,
        (SELECT coalesce(jsonb_object_agg(k, v), '{}'::jsonb) FROM (
            SELECT DISTINCT ON (key) key AS k, value AS v
            FROM public.contacts c, jsonb_each(c.custom_fields)
            WHERE c.id = ANY(r.all_ids)
          ) x) AS cf,
        (SELECT string_agg(notes, E'\n---\n') FROM (
            SELECT DISTINCT notes FROM public.contacts
            WHERE id = ANY(r.all_ids) AND notes IS NOT NULL AND btrim(notes) <> ''
          ) n) AS notes,
        (SELECT email FROM public.contacts WHERE id = ANY(r.all_ids) AND email IS NOT NULL AND email <> '' ORDER BY created_at DESC LIMIT 1) AS email,
        (SELECT city  FROM public.contacts WHERE id = ANY(r.all_ids) AND city  IS NOT NULL AND city  <> '' ORDER BY created_at DESC LIMIT 1) AS city,
        (SELECT lead_source FROM public.contacts WHERE id = ANY(r.all_ids) AND lead_source IS NOT NULL AND lead_source <> '' ORDER BY created_at DESC LIMIT 1) AS lead_source,
        (SELECT name FROM public.contacts
           WHERE id = ANY(r.all_ids)
             AND name IS NOT NULL AND name <> ''
             AND name !~ '^\+?\d[\d\s()+-]*$'
           ORDER BY created_at DESC LIMIT 1) AS good_name
    )
    UPDATE public.contacts c SET
      tags = COALESCE(agg.tags, c.tags),
      custom_fields = COALESCE(agg.cf, '{}'::jsonb) || COALESCE(c.custom_fields, '{}'::jsonb),
      email = COALESCE(c.email, agg.email),
      city = COALESCE(c.city, agg.city),
      lead_source = COALESCE(c.lead_source, agg.lead_source),
      notes = COALESCE(NULLIF(c.notes, ''), agg.notes),
      name = CASE
        WHEN c.name IS NULL OR c.name = '' OR c.name = c.phone OR c.name ~ '^\+?\d[\d\s()+-]*$'
          THEN COALESCE(agg.good_name, c.name)
        ELSE c.name
      END
    FROM agg
    WHERE c.id = r.keeper;

    -- Remove losers
    DELETE FROM public.contacts WHERE id = ANY(r.all_ids) AND id <> r.keeper;
  END LOOP;
END
$mig$;

-- 3. Enforce uniqueness going forward
CREATE UNIQUE INDEX IF NOT EXISTS contacts_workspace_normalized_phone_unique
  ON public.contacts (workspace_id, public.normalize_phone(phone))
  WHERE public.normalize_phone(phone) IS NOT NULL;

-- 4. Single-contact upsert used by all app + webhook code paths
CREATE OR REPLACE FUNCTION public.upsert_contact(
  _workspace_id uuid,
  _name text,
  _phone text,
  _email text DEFAULT NULL,
  _tags text[] DEFAULT NULL,
  _custom_fields jsonb DEFAULT NULL,
  _city text DEFAULT NULL,
  _lead_source text DEFAULT NULL,
  _user_id uuid DEFAULT NULL
) RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $fn$
DECLARE
  norm text := public.normalize_phone(_phone);
  existing_id uuid;
  existing_name text;
  existing_phone text;
  eff_user uuid := COALESCE(_user_id, auth.uid());
BEGIN
  IF norm IS NULL THEN
    RAISE EXCEPTION 'phone required';
  END IF;
  -- Authorize: end users must be members; service_role (auth.uid IS NULL) is always allowed
  IF auth.uid() IS NOT NULL AND NOT public.is_workspace_member(_workspace_id, auth.uid()) THEN
    RAISE EXCEPTION 'forbidden';
  END IF;

  SELECT id, name, phone INTO existing_id, existing_name, existing_phone
    FROM public.contacts
   WHERE workspace_id = _workspace_id
     AND public.normalize_phone(phone) = norm
   LIMIT 1;

  IF existing_id IS NOT NULL THEN
    UPDATE public.contacts SET
      name = CASE
        WHEN existing_name IS NULL OR existing_name = '' OR existing_name = existing_phone
          OR existing_name ~ '^\+?\d[\d\s()+-]*$'
        THEN COALESCE(NULLIF(_name, ''), existing_name)
        ELSE existing_name
      END,
      email = COALESCE(email, NULLIF(_email, '')),
      city = COALESCE(city, NULLIF(_city, '')),
      lead_source = COALESCE(lead_source, NULLIF(_lead_source, '')),
      tags = CASE
        WHEN _tags IS NULL THEN tags
        ELSE (SELECT array(SELECT DISTINCT t FROM unnest(COALESCE(tags, '{}') || _tags) t WHERE t IS NOT NULL AND t <> ''))
      END,
      custom_fields = COALESCE(custom_fields, '{}'::jsonb) || COALESCE(_custom_fields, '{}'::jsonb)
    WHERE id = existing_id;
    RETURN existing_id;
  END IF;

  IF eff_user IS NULL THEN
    RAISE EXCEPTION 'user required';
  END IF;

  INSERT INTO public.contacts (user_id, workspace_id, name, phone, email, tags, custom_fields, city, lead_source)
  VALUES (
    eff_user, _workspace_id,
    COALESCE(NULLIF(_name, ''), _phone),
    _phone,
    NULLIF(_email, ''),
    COALESCE(_tags, '{}'),
    COALESCE(_custom_fields, '{}'::jsonb),
    NULLIF(_city, ''),
    NULLIF(_lead_source, '')
  )
  RETURNING id INTO existing_id;

  RETURN existing_id;
END
$fn$;

GRANT EXECUTE ON FUNCTION public.upsert_contact(uuid, text, text, text, text[], jsonb, text, text, uuid)
  TO authenticated, service_role;

-- 5. Bulk upsert for CSV imports
CREATE OR REPLACE FUNCTION public.upsert_contacts_bulk(
  _workspace_id uuid,
  _user_id uuid,
  _rows jsonb
) RETURNS TABLE(id uuid, phone text)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $fn$
DECLARE
  r jsonb;
  eff_user uuid := COALESCE(_user_id, auth.uid());
BEGIN
  IF auth.uid() IS NOT NULL AND NOT public.is_workspace_member(_workspace_id, auth.uid()) THEN
    RAISE EXCEPTION 'forbidden';
  END IF;

  FOR r IN SELECT * FROM jsonb_array_elements(_rows)
  LOOP
    IF public.normalize_phone(r->>'phone') IS NULL THEN CONTINUE; END IF;
    id := public.upsert_contact(
      _workspace_id,
      COALESCE(NULLIF(r->>'name', ''), r->>'phone'),
      r->>'phone',
      NULLIF(r->>'email', ''),
      CASE WHEN jsonb_typeof(r->'tags') = 'array'
           THEN ARRAY(SELECT jsonb_array_elements_text(r->'tags'))
           ELSE NULL END,
      CASE WHEN jsonb_typeof(r->'custom_fields') = 'object' THEN r->'custom_fields' ELSE NULL END,
      NULLIF(r->>'city', ''),
      NULLIF(r->>'lead_source', ''),
      eff_user
    );
    phone := r->>'phone';
    RETURN NEXT;
  END LOOP;
END
$fn$;

GRANT EXECUTE ON FUNCTION public.upsert_contacts_bulk(uuid, uuid, jsonb)
  TO authenticated, service_role;
