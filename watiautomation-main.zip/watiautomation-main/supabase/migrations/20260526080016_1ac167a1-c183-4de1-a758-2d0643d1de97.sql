
CREATE TABLE public.whatsapp_accounts (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  workspace_id UUID NOT NULL,
  connected_by UUID NOT NULL,
  business_name TEXT,
  display_name TEXT,
  phone_number TEXT,
  phone_number_id TEXT NOT NULL,
  waba_id TEXT NOT NULL,
  access_token TEXT NOT NULL,
  quality_rating TEXT DEFAULT 'UNKNOWN',
  messaging_tier TEXT DEFAULT 'TIER_NOT_SET',
  display_name_status TEXT DEFAULT 'PENDING',
  status TEXT NOT NULL DEFAULT 'connected',
  webhook_status TEXT NOT NULL DEFAULT 'pending',
  webhook_last_event_at TIMESTAMPTZ,
  sync_status TEXT NOT NULL DEFAULT 'idle',
  last_synced_at TIMESTAMPTZ,
  last_error TEXT,
  is_active BOOLEAN NOT NULL DEFAULT false,
  meta JSONB NOT NULL DEFAULT '{}'::jsonb,
  connected_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(workspace_id, phone_number_id)
);

CREATE INDEX idx_wa_accounts_workspace ON public.whatsapp_accounts(workspace_id);

ALTER TABLE public.whatsapp_accounts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "members view whatsapp accounts"
  ON public.whatsapp_accounts FOR SELECT
  USING (is_workspace_member(workspace_id, auth.uid()));

CREATE POLICY "admins manage whatsapp accounts"
  ON public.whatsapp_accounts FOR ALL
  USING (has_workspace_role(workspace_id, auth.uid(), ARRAY['owner'::app_role, 'admin'::app_role]))
  WITH CHECK (has_workspace_role(workspace_id, auth.uid(), ARRAY['owner'::app_role, 'admin'::app_role]));

CREATE TRIGGER update_whatsapp_accounts_updated_at
  BEFORE UPDATE ON public.whatsapp_accounts
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
