
GRANT INSERT, UPDATE, DELETE ON public.whatsapp_accounts TO authenticated;
GRANT INSERT, UPDATE, DELETE ON public.whatsapp_settings TO authenticated;
GRANT INSERT, UPDATE, DELETE ON public.store_integrations TO authenticated;
GRANT INSERT, UPDATE, DELETE ON public.workspace_invitations TO authenticated;
GRANT INSERT, UPDATE, DELETE ON public.payment_gateways TO authenticated;
