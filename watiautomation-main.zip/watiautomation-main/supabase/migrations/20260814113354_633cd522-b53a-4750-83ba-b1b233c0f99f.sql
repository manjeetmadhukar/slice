CREATE TABLE public.abandoned_cart_reminder_locks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id uuid NOT NULL,
  phone_key text NOT NULL,
  last_cart_id uuid,
  last_cart_token text,
  sent_at timestamptz NOT NULL DEFAULT now(),
  prev_sent_at timestamptz,
  send_count integer NOT NULL DEFAULT 1,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT ON public.abandoned_cart_reminder_locks TO authenticated;
GRANT ALL ON public.abandoned_cart_reminder_locks TO service_role;

ALTER TABLE public.abandoned_cart_reminder_locks ENABLE ROW LEVEL SECURITY;

CREATE POLICY "workspace members view cart reminder locks"
  ON public.abandoned_cart_reminder_locks FOR SELECT TO authenticated
  USING (public.is_workspace_member(workspace_id, auth.uid()));

CREATE UNIQUE INDEX abandoned_cart_reminder_locks_uidx
  ON public.abandoned_cart_reminder_locks (workspace_id, phone_key);

CREATE TRIGGER trg_abandoned_cart_reminder_locks_updated
  BEFORE UPDATE ON public.abandoned_cart_reminder_locks
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE OR REPLACE FUNCTION public.claim_cart_reminder(
  _workspace_id uuid,
  _phone_key text,
  _cart_id uuid,
  _cart_token text,
  _window_minutes integer
) RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  cutoff timestamptz := now() - make_interval(mins => GREATEST(COALESCE(_window_minutes, 1440), 0));
  affected integer;
BEGIN
  IF _phone_key IS NULL OR _phone_key = '' THEN
    RETURN true;
  END IF;

  INSERT INTO public.abandoned_cart_reminder_locks
    (workspace_id, phone_key, last_cart_id, last_cart_token, sent_at, prev_sent_at, send_count)
  VALUES (_workspace_id, _phone_key, _cart_id, _cart_token, now(), NULL, 1)
  ON CONFLICT (workspace_id, phone_key) DO UPDATE
    SET sent_at = now(),
        prev_sent_at = abandoned_cart_reminder_locks.sent_at,
        last_cart_id = EXCLUDED.last_cart_id,
        last_cart_token = EXCLUDED.last_cart_token,
        send_count = abandoned_cart_reminder_locks.send_count + 1,
        updated_at = now()
    WHERE abandoned_cart_reminder_locks.sent_at < cutoff;

  GET DIAGNOSTICS affected = ROW_COUNT;
  RETURN affected > 0;
END;
$$;

CREATE OR REPLACE FUNCTION public.release_cart_reminder(
  _workspace_id uuid,
  _phone_key text,
  _cart_id uuid
) RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
BEGIN
  IF _phone_key IS NULL OR _phone_key = '' THEN
    RETURN;
  END IF;

  DELETE FROM public.abandoned_cart_reminder_locks
   WHERE workspace_id = _workspace_id
     AND phone_key = _phone_key
     AND last_cart_id IS NOT DISTINCT FROM _cart_id
     AND prev_sent_at IS NULL;

  UPDATE public.abandoned_cart_reminder_locks
     SET sent_at = prev_sent_at,
         prev_sent_at = NULL,
         send_count = GREATEST(send_count - 1, 0),
         updated_at = now()
   WHERE workspace_id = _workspace_id
     AND phone_key = _phone_key
     AND last_cart_id IS NOT DISTINCT FROM _cart_id
     AND prev_sent_at IS NOT NULL;
END;
$$;

REVOKE ALL ON FUNCTION public.claim_cart_reminder(uuid, text, uuid, text, integer) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.release_cart_reminder(uuid, text, uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.claim_cart_reminder(uuid, text, uuid, text, integer) TO service_role;
GRANT EXECUTE ON FUNCTION public.release_cart_reminder(uuid, text, uuid) TO service_role;