
ALTER TABLE public.messages
  ADD COLUMN IF NOT EXISTS reactions jsonb NOT NULL DEFAULT '[]'::jsonb,
  ADD COLUMN IF NOT EXISTS reply_to_wa_message_id text,
  ADD COLUMN IF NOT EXISTS reply_to_preview text;

CREATE INDEX IF NOT EXISTS idx_messages_wa_id_lookup
  ON public.messages(workspace_id, wa_message_id) WHERE wa_message_id IS NOT NULL;

ALTER TABLE public.contacts
  ADD COLUMN IF NOT EXISTS avatar_url text;
