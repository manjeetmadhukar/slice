ALTER TABLE public.abandoned_carts REPLICA IDENTITY FULL;
ALTER TABLE public.ecom_orders REPLICA IDENTITY FULL;
ALTER PUBLICATION supabase_realtime ADD TABLE public.abandoned_carts;
ALTER PUBLICATION supabase_realtime ADD TABLE public.ecom_orders;