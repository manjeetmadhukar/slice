
-- 1) Packages table
CREATE TABLE IF NOT EXISTS public.ai_credit_packages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  description TEXT,
  credits BIGINT NOT NULL CHECK (credits > 0),
  price NUMERIC(12,2) NOT NULL CHECK (price >= 0),
  currency TEXT NOT NULL DEFAULT 'INR',
  bonus_credits BIGINT NOT NULL DEFAULT 0 CHECK (bonus_credits >= 0),
  is_active BOOLEAN NOT NULL DEFAULT true,
  is_featured BOOLEAN NOT NULL DEFAULT false,
  sort_order INT NOT NULL DEFAULT 0,
  gateway_ids TEXT[] NOT NULL DEFAULT '{}',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

GRANT SELECT ON public.ai_credit_packages TO authenticated;
GRANT ALL ON public.ai_credit_packages TO service_role;
ALTER TABLE public.ai_credit_packages ENABLE ROW LEVEL SECURITY;

CREATE POLICY "authenticated can view active packages"
  ON public.ai_credit_packages FOR SELECT
  TO authenticated USING (is_active = true OR public.is_super_admin(auth.uid()));

CREATE POLICY "super admins manage packages"
  ON public.ai_credit_packages FOR ALL
  TO authenticated
  USING (public.is_super_admin(auth.uid()))
  WITH CHECK (public.is_super_admin(auth.uid()));

CREATE TRIGGER trg_ai_credit_packages_updated_at
BEFORE UPDATE ON public.ai_credit_packages
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- 2) Extend payment_transactions to carry credit purchases
ALTER TABLE public.payment_transactions
  ADD COLUMN IF NOT EXISTS credit_package_id UUID REFERENCES public.ai_credit_packages(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS credits_amount BIGINT,
  ADD COLUMN IF NOT EXISTS purpose TEXT NOT NULL DEFAULT 'plan';

-- Existing rows are all plan payments; keep template_id-based ones flagged
UPDATE public.payment_transactions SET purpose = 'plan' WHERE purpose IS NULL;

-- Allow plan_name_snapshot to represent package name for credit purchases (already NOT NULL, fine)

-- 3) Seed a few starter packages so the Buy screen is not empty
INSERT INTO public.ai_credit_packages (name, description, credits, bonus_credits, price, currency, sort_order, is_featured)
VALUES
  ('Starter',   '1,000 AI credits',                1000,   0,   199, 'INR', 10, false),
  ('Growth',    '5,000 AI credits + 500 bonus',    5000,  500,  899, 'INR', 20, true),
  ('Pro',       '15,000 AI credits + 2,500 bonus', 15000, 2500, 2399,'INR', 30, false),
  ('Business',  '50,000 AI credits + 10,000 bonus',50000, 10000,6999,'INR', 40, false)
ON CONFLICT DO NOTHING;
