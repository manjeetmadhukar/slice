
-- 1. deal_activities
CREATE TABLE public.deal_activities (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  workspace_id uuid NOT NULL,
  deal_id uuid NOT NULL,
  user_id uuid,
  type text NOT NULL,
  data jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_deal_activities_deal ON public.deal_activities(deal_id, created_at DESC);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.deal_activities TO authenticated;
GRANT ALL ON public.deal_activities TO service_role;
ALTER TABLE public.deal_activities ENABLE ROW LEVEL SECURITY;
CREATE POLICY "members manage deal activities" ON public.deal_activities FOR ALL
  USING (public.is_workspace_member(workspace_id, auth.uid()))
  WITH CHECK (public.is_workspace_member(workspace_id, auth.uid()));

-- 2. deal_notes
CREATE TABLE public.deal_notes (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  workspace_id uuid NOT NULL,
  deal_id uuid NOT NULL,
  user_id uuid NOT NULL,
  body text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_deal_notes_deal ON public.deal_notes(deal_id, created_at DESC);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.deal_notes TO authenticated;
GRANT ALL ON public.deal_notes TO service_role;
ALTER TABLE public.deal_notes ENABLE ROW LEVEL SECURITY;
CREATE POLICY "members view deal notes" ON public.deal_notes FOR SELECT
  USING (public.is_workspace_member(workspace_id, auth.uid()));
CREATE POLICY "members insert deal notes" ON public.deal_notes FOR INSERT
  WITH CHECK (public.is_workspace_member(workspace_id, auth.uid()) AND user_id = auth.uid());
CREATE POLICY "authors update own notes" ON public.deal_notes FOR UPDATE
  USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());
CREATE POLICY "authors or admins delete notes" ON public.deal_notes FOR DELETE
  USING (user_id = auth.uid() OR public.has_workspace_role(workspace_id, auth.uid(), ARRAY['owner'::app_role,'admin'::app_role]));

CREATE TRIGGER deal_notes_updated_at BEFORE UPDATE ON public.deal_notes
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- 3. deal_tags (workspace tag library)
CREATE TABLE public.deal_tags (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  workspace_id uuid NOT NULL,
  name text NOT NULL,
  color text NOT NULL DEFAULT '#3b82f6',
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(workspace_id, name)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.deal_tags TO authenticated;
GRANT ALL ON public.deal_tags TO service_role;
ALTER TABLE public.deal_tags ENABLE ROW LEVEL SECURITY;
CREATE POLICY "members view tag library" ON public.deal_tags FOR SELECT
  USING (public.is_workspace_member(workspace_id, auth.uid()));
CREATE POLICY "members insert tags" ON public.deal_tags FOR INSERT
  WITH CHECK (public.is_workspace_member(workspace_id, auth.uid()));
CREATE POLICY "admins update tags" ON public.deal_tags FOR UPDATE
  USING (public.has_workspace_role(workspace_id, auth.uid(), ARRAY['owner'::app_role,'admin'::app_role,'agent'::app_role]))
  WITH CHECK (public.has_workspace_role(workspace_id, auth.uid(), ARRAY['owner'::app_role,'admin'::app_role,'agent'::app_role]));
CREATE POLICY "admins delete tags" ON public.deal_tags FOR DELETE
  USING (public.has_workspace_role(workspace_id, auth.uid(), ARRAY['owner'::app_role,'admin'::app_role]));

-- 4. deal_tag_links
CREATE TABLE public.deal_tag_links (
  deal_id uuid NOT NULL,
  tag_id uuid NOT NULL,
  workspace_id uuid NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (deal_id, tag_id)
);
CREATE INDEX idx_deal_tag_links_deal ON public.deal_tag_links(deal_id);
CREATE INDEX idx_deal_tag_links_tag ON public.deal_tag_links(tag_id);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.deal_tag_links TO authenticated;
GRANT ALL ON public.deal_tag_links TO service_role;
ALTER TABLE public.deal_tag_links ENABLE ROW LEVEL SECURITY;
CREATE POLICY "members manage deal tag links" ON public.deal_tag_links FOR ALL
  USING (public.is_workspace_member(workspace_id, auth.uid()))
  WITH CHECK (public.is_workspace_member(workspace_id, auth.uid()));

-- 5. deals: add free-text tags column
ALTER TABLE public.deals ADD COLUMN IF NOT EXISTS tags text[] NOT NULL DEFAULT '{}'::text[];
ALTER TABLE public.deals ADD COLUMN IF NOT EXISTS source text;

-- 6. lead_intake_tokens
CREATE TABLE public.lead_intake_tokens (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  workspace_id uuid NOT NULL,
  provider text NOT NULL,
  token text NOT NULL UNIQUE,
  enabled boolean NOT NULL DEFAULT true,
  default_stage_id uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  last_used_at timestamptz
);
CREATE INDEX idx_lead_intake_workspace ON public.lead_intake_tokens(workspace_id);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.lead_intake_tokens TO authenticated;
GRANT ALL ON public.lead_intake_tokens TO service_role;
ALTER TABLE public.lead_intake_tokens ENABLE ROW LEVEL SECURITY;
CREATE POLICY "members view intake tokens" ON public.lead_intake_tokens FOR SELECT
  USING (public.is_workspace_member(workspace_id, auth.uid()));
CREATE POLICY "admins manage intake tokens" ON public.lead_intake_tokens FOR ALL
  USING (public.has_workspace_role(workspace_id, auth.uid(), ARRAY['owner'::app_role,'admin'::app_role]))
  WITH CHECK (public.has_workspace_role(workspace_id, auth.uid(), ARRAY['owner'::app_role,'admin'::app_role]));
