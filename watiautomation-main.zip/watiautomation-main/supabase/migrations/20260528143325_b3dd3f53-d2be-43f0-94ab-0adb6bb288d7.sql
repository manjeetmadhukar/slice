
CREATE TABLE public.plan_templates (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  features JSONB NOT NULL DEFAULT '{}'::jsonb,
  limits JSONB NOT NULL DEFAULT '{}'::jsonb,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_by UUID,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.plan_templates TO authenticated;
GRANT ALL ON public.plan_templates TO service_role;

ALTER TABLE public.plan_templates ENABLE ROW LEVEL SECURITY;

CREATE POLICY "super admins manage plan templates"
ON public.plan_templates FOR ALL
USING (public.is_super_admin(auth.uid()))
WITH CHECK (public.is_super_admin(auth.uid()));

CREATE POLICY "members view active plan templates"
ON public.plan_templates FOR SELECT
USING (is_active = true OR public.is_super_admin(auth.uid()));

CREATE TRIGGER update_plan_templates_updated_at
BEFORE UPDATE ON public.plan_templates
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
