UPDATE public.abandoned_carts
SET abandoned_at = LEAST(abandoned_at, now()),
    send_scheduled_at = CASE
      WHEN send_scheduled_at IS NOT NULL AND abandoned_at > now()
      THEN send_scheduled_at - (abandoned_at - now())
      ELSE send_scheduled_at END
WHERE abandoned_at > now() + interval '2 minutes';