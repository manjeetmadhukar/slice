
CREATE OR REPLACE FUNCTION public.phone_match_key(p text)
RETURNS text
LANGUAGE sql
IMMUTABLE
SET search_path TO 'public'
AS $$
  SELECT CASE
    WHEN d IS NULL THEN NULL
    WHEN length(d) > 10 THEN right(d, 10)
    ELSE d
  END
  FROM (SELECT NULLIF(regexp_replace(COALESCE(p, ''), '\D', '', 'g'), '') AS d) s
$$;

DO $merge$
DECLARE
  g record;
  keeper uuid;
  dups uuid[];
  total_unread int;
BEGIN
  FOR g IN
    SELECT workspace_id, public.phone_match_key(contact_phone) AS k
    FROM public.conversations
    WHERE public.phone_match_key(contact_phone) IS NOT NULL
    GROUP BY 1,2
    HAVING count(*) > 1
  LOOP
    SELECT id INTO keeper
    FROM public.conversations
    WHERE workspace_id = g.workspace_id AND public.phone_match_key(contact_phone) = g.k
    ORDER BY last_message_at DESC NULLS LAST, created_at ASC
    LIMIT 1;

    SELECT array_agg(id), COALESCE(sum(COALESCE(unread_count,0)),0)::int
      INTO dups, total_unread
    FROM public.conversations
    WHERE workspace_id = g.workspace_id AND public.phone_match_key(contact_phone) = g.k;

    UPDATE public.messages SET conversation_id = keeper WHERE conversation_id = ANY(dups) AND conversation_id <> keeper;
    UPDATE public.follow_ups SET conversation_id = keeper WHERE conversation_id = ANY(dups) AND conversation_id <> keeper;
    UPDATE public.bot_sessions SET conversation_id = keeper WHERE conversation_id = ANY(dups) AND conversation_id <> keeper;
    UPDATE public.ai_message_analyses SET conversation_id = keeper WHERE conversation_id = ANY(dups) AND conversation_id <> keeper;
    UPDATE public.template_button_clicks SET conversation_id = keeper WHERE conversation_id = ANY(dups) AND conversation_id <> keeper;
    UPDATE public.whatsapp_delivery_logs SET conversation_id = keeper WHERE conversation_id = ANY(dups) AND conversation_id <> keeper;

    UPDATE public.conversations c SET
      unread_count = total_unread,
      contact_id = COALESCE(c.contact_id, (
        SELECT o.contact_id FROM public.conversations o
        WHERE o.id = ANY(dups) AND o.contact_id IS NOT NULL LIMIT 1)),
      assigned_to = COALESCE(c.assigned_to, (
        SELECT o.assigned_to FROM public.conversations o
        WHERE o.id = ANY(dups) AND o.assigned_to IS NOT NULL LIMIT 1)),
      labels = (
        SELECT COALESCE(array_agg(DISTINCT l), '{}')
        FROM public.conversations o, unnest(COALESCE(o.labels,'{}')) l
        WHERE o.id = ANY(dups))
    WHERE c.id = keeper;

    DELETE FROM public.conversations WHERE id = ANY(dups) AND id <> keeper;
  END LOOP;
END
$merge$;

CREATE UNIQUE INDEX IF NOT EXISTS conversations_workspace_phone_key_uidx
  ON public.conversations (workspace_id, public.phone_match_key(contact_phone))
  WHERE public.phone_match_key(contact_phone) IS NOT NULL;

CREATE OR REPLACE FUNCTION public.resolve_conversation(
  _workspace_id uuid,
  _phone text,
  _name text DEFAULT NULL,
  _contact_id uuid DEFAULT NULL,
  _last_message_at timestamptz DEFAULT NULL
)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  k text := public.phone_match_key(_phone);
  norm text := public.normalize_phone(_phone);
  conv_id uuid;
BEGIN
  IF k IS NULL THEN
    RAISE EXCEPTION 'phone required';
  END IF;
  IF auth.uid() IS NOT NULL AND NOT public.is_workspace_member(_workspace_id, auth.uid()) THEN
    RAISE EXCEPTION 'forbidden';
  END IF;

  SELECT id INTO conv_id FROM public.conversations
   WHERE workspace_id = _workspace_id AND public.phone_match_key(contact_phone) = k
   ORDER BY last_message_at DESC NULLS LAST
   LIMIT 1;

  IF conv_id IS NULL THEN
    INSERT INTO public.conversations (workspace_id, contact_id, contact_phone, contact_name, status, last_message_at)
    VALUES (_workspace_id, _contact_id, '+' || norm, COALESCE(NULLIF(_name,''), '+' || norm), 'open',
            COALESCE(_last_message_at, now()))
    ON CONFLICT DO NOTHING
    RETURNING id INTO conv_id;

    IF conv_id IS NULL THEN
      SELECT id INTO conv_id FROM public.conversations
       WHERE workspace_id = _workspace_id AND public.phone_match_key(contact_phone) = k
       LIMIT 1;
    END IF;
    RETURN conv_id;
  END IF;

  UPDATE public.conversations SET
    contact_id = COALESCE(contact_id, _contact_id),
    contact_name = CASE
      WHEN COALESCE(NULLIF(_name,''), '') <> '' AND (contact_name IS NULL OR contact_name = '' OR contact_name ~ '^\+?\d[\d\s()+-]*$')
      THEN _name ELSE contact_name END,
    last_message_at = GREATEST(COALESCE(last_message_at, to_timestamp(0)), COALESCE(_last_message_at, last_message_at, now()))
  WHERE id = conv_id;

  RETURN conv_id;
END
$$;

GRANT EXECUTE ON FUNCTION public.resolve_conversation(uuid, text, text, uuid, timestamptz) TO authenticated, service_role;
GRANT EXECUTE ON FUNCTION public.phone_match_key(text) TO authenticated, anon, service_role;
