
CREATE TABLE public.bots (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  workspace_id UUID NOT NULL,
  name TEXT NOT NULL,
  description TEXT,
  enabled BOOLEAN NOT NULL DEFAULT false,
  triggers JSONB NOT NULL DEFAULT '[]'::jsonb,
  priority INTEGER NOT NULL DEFAULT 0,
  created_by UUID,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.bots TO authenticated;
GRANT ALL ON public.bots TO service_role;
ALTER TABLE public.bots ENABLE ROW LEVEL SECURITY;
CREATE POLICY "workspace members view bots" ON public.bots FOR SELECT USING (is_workspace_member(workspace_id, auth.uid()));
CREATE POLICY "agents+ insert bots" ON public.bots FOR INSERT WITH CHECK (has_workspace_role(workspace_id, auth.uid(), ARRAY['owner'::app_role,'admin'::app_role,'agent'::app_role]));
CREATE POLICY "agents+ update bots" ON public.bots FOR UPDATE USING (has_workspace_role(workspace_id, auth.uid(), ARRAY['owner'::app_role,'admin'::app_role,'agent'::app_role]));
CREATE POLICY "admins delete bots" ON public.bots FOR DELETE USING (has_workspace_role(workspace_id, auth.uid(), ARRAY['owner'::app_role,'admin'::app_role]));
CREATE TRIGGER update_bots_updated_at BEFORE UPDATE ON public.bots FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TABLE public.bot_nodes (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  bot_id UUID NOT NULL REFERENCES public.bots(id) ON DELETE CASCADE,
  workspace_id UUID NOT NULL,
  type TEXT NOT NULL,
  position JSONB NOT NULL DEFAULT '{"x":0,"y":0}'::jsonb,
  data JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_bot_nodes_bot ON public.bot_nodes(bot_id);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.bot_nodes TO authenticated;
GRANT ALL ON public.bot_nodes TO service_role;
ALTER TABLE public.bot_nodes ENABLE ROW LEVEL SECURITY;
CREATE POLICY "members view bot nodes" ON public.bot_nodes FOR SELECT USING (is_workspace_member(workspace_id, auth.uid()));
CREATE POLICY "agents+ manage bot nodes" ON public.bot_nodes FOR ALL USING (has_workspace_role(workspace_id, auth.uid(), ARRAY['owner'::app_role,'admin'::app_role,'agent'::app_role])) WITH CHECK (has_workspace_role(workspace_id, auth.uid(), ARRAY['owner'::app_role,'admin'::app_role,'agent'::app_role]));

CREATE TABLE public.bot_edges (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  bot_id UUID NOT NULL REFERENCES public.bots(id) ON DELETE CASCADE,
  workspace_id UUID NOT NULL,
  source_node_id UUID NOT NULL,
  target_node_id UUID NOT NULL,
  source_handle TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_bot_edges_bot ON public.bot_edges(bot_id);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.bot_edges TO authenticated;
GRANT ALL ON public.bot_edges TO service_role;
ALTER TABLE public.bot_edges ENABLE ROW LEVEL SECURITY;
CREATE POLICY "members view bot edges" ON public.bot_edges FOR SELECT USING (is_workspace_member(workspace_id, auth.uid()));
CREATE POLICY "agents+ manage bot edges" ON public.bot_edges FOR ALL USING (has_workspace_role(workspace_id, auth.uid(), ARRAY['owner'::app_role,'admin'::app_role,'agent'::app_role])) WITH CHECK (has_workspace_role(workspace_id, auth.uid(), ARRAY['owner'::app_role,'admin'::app_role,'agent'::app_role]));

CREATE TABLE public.bot_sessions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  workspace_id UUID NOT NULL,
  bot_id UUID NOT NULL REFERENCES public.bots(id) ON DELETE CASCADE,
  conversation_id UUID,
  contact_id UUID,
  contact_phone TEXT NOT NULL,
  current_node_id UUID,
  awaiting_input BOOLEAN NOT NULL DEFAULT false,
  variables JSONB NOT NULL DEFAULT '{}'::jsonb,
  status TEXT NOT NULL DEFAULT 'active',
  resume_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_bot_sessions_lookup ON public.bot_sessions(workspace_id, contact_phone, status);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.bot_sessions TO authenticated;
GRANT ALL ON public.bot_sessions TO service_role;
ALTER TABLE public.bot_sessions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "members manage bot sessions" ON public.bot_sessions FOR ALL USING (is_workspace_member(workspace_id, auth.uid())) WITH CHECK (is_workspace_member(workspace_id, auth.uid()));
CREATE TRIGGER update_bot_sessions_updated_at BEFORE UPDATE ON public.bot_sessions FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TABLE public.bot_runs (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  workspace_id UUID NOT NULL,
  bot_id UUID NOT NULL REFERENCES public.bots(id) ON DELETE CASCADE,
  session_id UUID,
  node_id UUID,
  node_type TEXT,
  event TEXT NOT NULL,
  detail JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_bot_runs_bot ON public.bot_runs(bot_id, created_at DESC);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.bot_runs TO authenticated;
GRANT ALL ON public.bot_runs TO service_role;
ALTER TABLE public.bot_runs ENABLE ROW LEVEL SECURITY;
CREATE POLICY "members view bot runs" ON public.bot_runs FOR SELECT USING (is_workspace_member(workspace_id, auth.uid()));
CREATE POLICY "service manage bot runs" ON public.bot_runs FOR INSERT WITH CHECK (is_workspace_member(workspace_id, auth.uid()));
