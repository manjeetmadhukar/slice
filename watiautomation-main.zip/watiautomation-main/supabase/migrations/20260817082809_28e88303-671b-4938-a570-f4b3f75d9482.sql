TRUNCATE TABLE public.integration_debug_logs;

CREATE INDEX IF NOT EXISTS idx_integration_debug_logs_created_at
  ON public.integration_debug_logs (created_at DESC);

DELETE FROM cron.job_run_details WHERE end_time < now() - interval '2 days';

CREATE OR REPLACE FUNCTION public.cleanup_debug_logs()
RETURNS void
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  DELETE FROM public.integration_debug_logs WHERE created_at < now() - interval '7 days';
$$;

SELECT cron.unschedule(jobid) FROM cron.job WHERE jobname = 'nightly-debug-log-cleanup';
SELECT cron.schedule('nightly-debug-log-cleanup', '17 2 * * *', $$select public.cleanup_debug_logs();$$);