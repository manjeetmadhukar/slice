
-- Profiles
create table public.profiles (
  id uuid primary key references auth.users on delete cascade,
  email text,
  full_name text,
  created_at timestamptz not null default now()
);
alter table public.profiles enable row level security;
create policy "own profile select" on public.profiles for select using (auth.uid() = id);
create policy "own profile update" on public.profiles for update using (auth.uid() = id);
create policy "own profile insert" on public.profiles for insert with check (auth.uid() = id);

-- Auto create profile
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, email, full_name)
  values (new.id, new.email, coalesce(new.raw_user_meta_data->>'full_name', new.email));
  insert into public.whatsapp_settings (user_id) values (new.id);
  return new;
end; $$;

-- WhatsApp settings (per user)
create table public.whatsapp_settings (
  user_id uuid primary key references auth.users on delete cascade,
  phone_number_id text,
  waba_id text,
  access_token text,
  business_phone text,
  display_name text,
  verified boolean not null default false,
  updated_at timestamptz not null default now()
);
alter table public.whatsapp_settings enable row level security;
create policy "own settings all" on public.whatsapp_settings for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- Contacts
create table public.contacts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users on delete cascade,
  name text not null,
  phone text not null,
  email text,
  tags text[] not null default '{}',
  notes text,
  created_at timestamptz not null default now()
);
create index on public.contacts(user_id);
alter table public.contacts enable row level security;
create policy "own contacts all" on public.contacts for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- Templates
create table public.templates (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users on delete cascade,
  meta_template_name text not null,
  language text not null default 'en_US',
  category text,
  status text default 'UNKNOWN',
  body text,
  components jsonb,
  variables_count int not null default 0,
  synced_at timestamptz,
  created_at timestamptz not null default now()
);
create index on public.templates(user_id);
alter table public.templates enable row level security;
create policy "own templates all" on public.templates for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- Campaigns
create type campaign_status as enum ('draft','scheduled','sending','completed','failed');
create table public.campaigns (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users on delete cascade,
  name text not null,
  template_id uuid references public.templates on delete set null,
  template_name text,
  template_language text default 'en_US',
  variables jsonb not null default '[]'::jsonb,
  status campaign_status not null default 'draft',
  scheduled_at timestamptz,
  total_count int not null default 0,
  sent_count int not null default 0,
  delivered_count int not null default 0,
  read_count int not null default 0,
  failed_count int not null default 0,
  created_at timestamptz not null default now(),
  completed_at timestamptz
);
create index on public.campaigns(user_id);
alter table public.campaigns enable row level security;
create policy "own campaigns all" on public.campaigns for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- Campaign recipients
create table public.campaign_recipients (
  id uuid primary key default gen_random_uuid(),
  campaign_id uuid not null references public.campaigns on delete cascade,
  user_id uuid not null references auth.users on delete cascade,
  contact_id uuid references public.contacts on delete set null,
  phone text not null,
  name text,
  status text not null default 'pending',
  message_id text,
  error text,
  sent_at timestamptz,
  delivered_at timestamptz,
  read_at timestamptz
);
create index on public.campaign_recipients(campaign_id);
create index on public.campaign_recipients(user_id);
alter table public.campaign_recipients enable row level security;
create policy "own recipients all" on public.campaign_recipients for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- Trigger
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();
