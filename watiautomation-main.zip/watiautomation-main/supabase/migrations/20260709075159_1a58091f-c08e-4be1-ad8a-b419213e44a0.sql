ALTER TABLE public.campaign_recipients
  ADD COLUMN IF NOT EXISTS attempts int NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS retry_count int NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS next_retry_at timestamptz,
  ADD COLUMN IF NOT EXISTS last_attempt_at timestamptz,
  ADD COLUMN IF NOT EXISTS meta_code int,
  ADD COLUMN IF NOT EXISTS meta_subcode int,
  ADD COLUMN IF NOT EXISTS http_status int;

CREATE INDEX IF NOT EXISTS idx_campaign_recipients_retry_due
  ON public.campaign_recipients (campaign_id, next_retry_at)
  WHERE status = 'pending' AND next_retry_at IS NOT NULL;

CREATE TABLE IF NOT EXISTS public.whatsapp_delivery_logs (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id  uuid NOT NULL REFERENCES public.workspaces(id) ON DELETE CASCADE,
  created_at    timestamptz NOT NULL DEFAULT now(),
  purpose       text NOT NULL,
  campaign_id   uuid REFERENCES public.campaigns(id) ON DELETE SET NULL,
  recipient_id  uuid,
  conversation_id uuid,
  contact_id    uuid,
  to_phone      text,
  template_name text,
  language      text,
  message_type  text,
  request_summary jsonb,
  ok            boolean NOT NULL,
  http_status   int,
  wa_message_id text,
  meta_code     int,
  meta_subcode  int,
  meta_title    text,
  meta_message  text,
  meta_details  text,
  meta_trace_id text,
  retryable     boolean NOT NULL DEFAULT false,
  attempts      int NOT NULL DEFAULT 1,
  latency_ms    int
);

GRANT SELECT ON public.whatsapp_delivery_logs TO authenticated;
GRANT ALL   ON public.whatsapp_delivery_logs TO service_role;

CREATE INDEX IF NOT EXISTS idx_wa_delivery_logs_ws_time
  ON public.whatsapp_delivery_logs (workspace_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_wa_delivery_logs_campaign
  ON public.whatsapp_delivery_logs (campaign_id, created_at DESC)
  WHERE campaign_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_wa_delivery_logs_failed
  ON public.whatsapp_delivery_logs (workspace_id, created_at DESC)
  WHERE ok = false;

ALTER TABLE public.whatsapp_delivery_logs ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Workspace members can view delivery logs"
  ON public.whatsapp_delivery_logs;
CREATE POLICY "Workspace members can view delivery logs"
  ON public.whatsapp_delivery_logs
  FOR SELECT
  TO authenticated
  USING (public.is_workspace_member(workspace_id, auth.uid()));