
-- Message delivery status tracking
ALTER TABLE public.messages
  ADD COLUMN IF NOT EXISTS status text NOT NULL DEFAULT 'sent',
  ADD COLUMN IF NOT EXISTS status_updated_at timestamptz;

CREATE INDEX IF NOT EXISTS idx_messages_wa_id ON public.messages(wa_message_id) WHERE wa_message_id IS NOT NULL;

-- Storage bucket for chat media uploads
INSERT INTO storage.buckets (id, name, public)
VALUES ('chat-media', 'chat-media', true)
ON CONFLICT (id) DO NOTHING;

-- Storage policies: workspace members can upload / read their own chat media files
DROP POLICY IF EXISTS "chat-media public read" ON storage.objects;
CREATE POLICY "chat-media public read"
ON storage.objects FOR SELECT
USING (bucket_id = 'chat-media');

DROP POLICY IF EXISTS "chat-media authenticated upload" ON storage.objects;
CREATE POLICY "chat-media authenticated upload"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (bucket_id = 'chat-media');

DROP POLICY IF EXISTS "chat-media authenticated update" ON storage.objects;
CREATE POLICY "chat-media authenticated update"
ON storage.objects FOR UPDATE
TO authenticated
USING (bucket_id = 'chat-media');

DROP POLICY IF EXISTS "chat-media authenticated delete" ON storage.objects;
CREATE POLICY "chat-media authenticated delete"
ON storage.objects FOR DELETE
TO authenticated
USING (bucket_id = 'chat-media');
