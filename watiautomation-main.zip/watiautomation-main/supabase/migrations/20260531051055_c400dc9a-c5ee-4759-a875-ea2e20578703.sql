GRANT INSERT ON public.integration_debug_logs TO authenticated;

CREATE POLICY "workspace members create debug logs"
ON public.integration_debug_logs
FOR INSERT
TO authenticated
WITH CHECK (public.is_workspace_member(workspace_id, auth.uid()));