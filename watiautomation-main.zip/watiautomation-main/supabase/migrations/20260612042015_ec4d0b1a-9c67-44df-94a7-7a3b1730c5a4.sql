
ALTER TABLE public.reseller_accounts
  ADD COLUMN IF NOT EXISTS subdomain text,
  ADD COLUMN IF NOT EXISTS logo_path text,
  ADD COLUMN IF NOT EXISTS features jsonb NOT NULL DEFAULT '{}'::jsonb,
  ADD COLUMN IF NOT EXISTS license_key text;

CREATE UNIQUE INDEX IF NOT EXISTS reseller_accounts_subdomain_key
  ON public.reseller_accounts (lower(subdomain)) WHERE subdomain IS NOT NULL;
CREATE UNIQUE INDEX IF NOT EXISTS reseller_accounts_custom_domain_key
  ON public.reseller_accounts (lower(custom_domain)) WHERE custom_domain IS NOT NULL;

ALTER TABLE public.reseller_customers
  ADD COLUMN IF NOT EXISTS license_key text,
  ADD COLUMN IF NOT EXISTS license_status text NOT NULL DEFAULT 'active',
  ADD COLUMN IF NOT EXISTS license_expires_at timestamptz,
  ADD COLUMN IF NOT EXISTS features jsonb NOT NULL DEFAULT '{}'::jsonb;

CREATE UNIQUE INDEX IF NOT EXISTS reseller_customers_license_key_key
  ON public.reseller_customers (license_key) WHERE license_key IS NOT NULL;

CREATE OR REPLACE FUNCTION public.generate_license_key()
RETURNS text
LANGUAGE plpgsql
SET search_path = public
AS $$
DECLARE
  alphabet text := 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  block text;
  result text := 'SLC';
  i int;
  j int;
BEGIN
  FOR j IN 1..4 LOOP
    block := '';
    FOR i IN 1..4 LOOP
      block := block || substr(alphabet, 1 + floor(random()*length(alphabet))::int, 1);
    END LOOP;
    result := result || '-' || block;
  END LOOP;
  RETURN result;
END;
$$;

CREATE OR REPLACE FUNCTION public.ensure_reseller_customer_license()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  candidate text;
  exists_count int;
BEGIN
  IF NEW.license_key IS NULL OR NEW.license_key = '' THEN
    LOOP
      candidate := public.generate_license_key();
      SELECT count(*) INTO exists_count FROM public.reseller_customers WHERE license_key = candidate;
      EXIT WHEN exists_count = 0;
    END LOOP;
    NEW.license_key := candidate;
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_reseller_customers_license ON public.reseller_customers;
CREATE TRIGGER trg_reseller_customers_license
  BEFORE INSERT ON public.reseller_customers
  FOR EACH ROW EXECUTE FUNCTION public.ensure_reseller_customer_license();

UPDATE public.reseller_customers
SET license_key = public.generate_license_key()
WHERE license_key IS NULL;

-- Storage policies for reseller-logos bucket
DROP POLICY IF EXISTS "reseller-logos authenticated read" ON storage.objects;
CREATE POLICY "reseller-logos authenticated read"
  ON storage.objects FOR SELECT TO authenticated
  USING (bucket_id = 'reseller-logos');

DROP POLICY IF EXISTS "reseller-logos workspace insert" ON storage.objects;
CREATE POLICY "reseller-logos workspace insert"
  ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (
    bucket_id = 'reseller-logos'
    AND (
      public.is_super_admin(auth.uid())
      OR public.has_workspace_role(
        ((storage.foldername(name))[1])::uuid,
        auth.uid(),
        ARRAY['owner'::app_role,'admin'::app_role]
      )
    )
  );

DROP POLICY IF EXISTS "reseller-logos workspace update" ON storage.objects;
CREATE POLICY "reseller-logos workspace update"
  ON storage.objects FOR UPDATE TO authenticated
  USING (
    bucket_id = 'reseller-logos'
    AND (
      public.is_super_admin(auth.uid())
      OR public.has_workspace_role(
        ((storage.foldername(name))[1])::uuid,
        auth.uid(),
        ARRAY['owner'::app_role,'admin'::app_role]
      )
    )
  );

DROP POLICY IF EXISTS "reseller-logos workspace delete" ON storage.objects;
CREATE POLICY "reseller-logos workspace delete"
  ON storage.objects FOR DELETE TO authenticated
  USING (
    bucket_id = 'reseller-logos'
    AND (
      public.is_super_admin(auth.uid())
      OR public.has_workspace_role(
        ((storage.foldername(name))[1])::uuid,
        auth.uid(),
        ARRAY['owner'::app_role,'admin'::app_role]
      )
    )
  );
