CREATE OR REPLACE FUNCTION public.admin_delete_workspace(_workspace_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  r record;
BEGIN
  FOR r IN
    SELECT c.table_name
    FROM information_schema.columns c
    JOIN information_schema.tables t
      ON t.table_schema = c.table_schema AND t.table_name = c.table_name
    WHERE c.table_schema = 'public'
      AND c.column_name = 'workspace_id'
      AND t.table_type = 'BASE TABLE'
      AND c.table_name <> 'workspaces'
  LOOP
    EXECUTE format('DELETE FROM public.%I WHERE workspace_id = $1', r.table_name) USING _workspace_id;
  END LOOP;

  DELETE FROM public.workspaces WHERE id = _workspace_id;
END;
$$;

CREATE OR REPLACE FUNCTION public.admin_delete_user_data(_user_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  w record;
BEGIN
  -- Delete workspaces owned solely by this user
  FOR w IN SELECT id FROM public.workspaces WHERE owner_id = _user_id LOOP
    PERFORM public.admin_delete_workspace(w.id);
  END LOOP;

  DELETE FROM public.workspace_members WHERE user_id = _user_id;
  DELETE FROM public.profiles WHERE id = _user_id;
END;
$$;

REVOKE ALL ON FUNCTION public.admin_delete_workspace(uuid) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.admin_delete_user_data(uuid) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.admin_delete_workspace(uuid) TO service_role;
GRANT EXECUTE ON FUNCTION public.admin_delete_user_data(uuid) TO service_role;