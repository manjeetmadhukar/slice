
CREATE TABLE public.ai_credit_accounts (
  workspace_id uuid PRIMARY KEY REFERENCES public.workspaces(id) ON DELETE CASCADE,
  balance bigint NOT NULL DEFAULT 0,
  low_threshold integer NOT NULL DEFAULT 500,
  lifetime_added bigint NOT NULL DEFAULT 0,
  lifetime_used bigint NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.ai_credit_accounts TO authenticated;
GRANT ALL ON public.ai_credit_accounts TO service_role;
ALTER TABLE public.ai_credit_accounts ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Members view own workspace credit account"
  ON public.ai_credit_accounts FOR SELECT TO authenticated
  USING (public.is_workspace_member(workspace_id, auth.uid()) OR public.is_super_admin(auth.uid()));

CREATE TABLE public.ai_credit_ledger (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id uuid NOT NULL REFERENCES public.workspaces(id) ON DELETE CASCADE,
  delta bigint NOT NULL,
  entry_type text NOT NULL CHECK (entry_type IN ('usage','admin_add','admin_deduct','admin_reset','recharge')),
  feature text,
  model text,
  meta jsonb NOT NULL DEFAULT '{}'::jsonb,
  actor_user_id uuid,
  notes text,
  balance_after bigint NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX ai_credit_ledger_ws_created_idx ON public.ai_credit_ledger(workspace_id, created_at DESC);
GRANT SELECT ON public.ai_credit_ledger TO authenticated;
GRANT ALL ON public.ai_credit_ledger TO service_role;
ALTER TABLE public.ai_credit_ledger ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Members view own workspace credit ledger"
  ON public.ai_credit_ledger FOR SELECT TO authenticated
  USING (public.is_workspace_member(workspace_id, auth.uid()) OR public.is_super_admin(auth.uid()));

CREATE OR REPLACE FUNCTION public.consume_ai_credits(
  _workspace_id uuid, _amount bigint, _feature text, _model text, _meta jsonb DEFAULT '{}'::jsonb
) RETURNS TABLE(ok boolean, balance_after bigint)
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE current_balance bigint;
BEGIN
  IF _amount IS NULL OR _amount <= 0 THEN
    RAISE EXCEPTION 'invalid amount';
  END IF;
  INSERT INTO public.ai_credit_accounts(workspace_id) VALUES (_workspace_id)
    ON CONFLICT (workspace_id) DO NOTHING;
  SELECT balance INTO current_balance FROM public.ai_credit_accounts
    WHERE workspace_id = _workspace_id FOR UPDATE;
  IF current_balance < _amount THEN
    ok := false; balance_after := current_balance; RETURN NEXT; RETURN;
  END IF;
  UPDATE public.ai_credit_accounts
    SET balance = balance - _amount,
        lifetime_used = lifetime_used + _amount,
        updated_at = now()
    WHERE workspace_id = _workspace_id
    RETURNING balance INTO current_balance;
  INSERT INTO public.ai_credit_ledger(workspace_id, delta, entry_type, feature, model, meta, balance_after)
    VALUES (_workspace_id, -_amount, 'usage', _feature, _model, COALESCE(_meta,'{}'::jsonb), current_balance);
  ok := true; balance_after := current_balance; RETURN NEXT;
END$$;

CREATE OR REPLACE FUNCTION public.admin_adjust_ai_credits(
  _workspace_id uuid, _delta bigint, _entry_type text,
  _notes text DEFAULT NULL, _actor uuid DEFAULT NULL
) RETURNS bigint
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE current_balance bigint; eff_actor uuid := COALESCE(_actor, auth.uid());
BEGIN
  IF eff_actor IS NULL OR NOT public.is_super_admin(eff_actor) THEN
    RAISE EXCEPTION 'forbidden';
  END IF;
  IF _entry_type NOT IN ('admin_add','admin_deduct','admin_reset','recharge') THEN
    RAISE EXCEPTION 'invalid entry_type';
  END IF;
  INSERT INTO public.ai_credit_accounts(workspace_id) VALUES (_workspace_id)
    ON CONFLICT (workspace_id) DO NOTHING;
  IF _entry_type = 'admin_reset' THEN
    UPDATE public.ai_credit_accounts
      SET balance = 0, updated_at = now()
      WHERE workspace_id = _workspace_id
      RETURNING balance INTO current_balance;
    INSERT INTO public.ai_credit_ledger(workspace_id, delta, entry_type, actor_user_id, notes, balance_after)
      VALUES (_workspace_id, 0, 'admin_reset', eff_actor, _notes, current_balance);
    RETURN current_balance;
  END IF;
  UPDATE public.ai_credit_accounts
    SET balance = GREATEST(0::bigint, balance + _delta),
        lifetime_added = lifetime_added + GREATEST(0::bigint, _delta),
        updated_at = now()
    WHERE workspace_id = _workspace_id
    RETURNING balance INTO current_balance;
  INSERT INTO public.ai_credit_ledger(workspace_id, delta, entry_type, actor_user_id, notes, balance_after)
    VALUES (_workspace_id, _delta, _entry_type, eff_actor, _notes, current_balance);
  RETURN current_balance;
END$$;

GRANT EXECUTE ON FUNCTION public.admin_adjust_ai_credits(uuid, bigint, text, text, uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.consume_ai_credits(uuid, bigint, text, text, jsonb) TO service_role;
