CREATE UNIQUE INDEX IF NOT EXISTS ecom_orders_integration_external_unique
ON public.ecom_orders (integration_id, external_id)
WHERE integration_id IS NOT NULL AND external_id IS NOT NULL;

CREATE UNIQUE INDEX IF NOT EXISTS ecom_customers_integration_external_unique
ON public.ecom_customers (integration_id, external_id)
WHERE integration_id IS NOT NULL AND external_id IS NOT NULL;

CREATE UNIQUE INDEX IF NOT EXISTS store_integrations_workspace_provider_unique
ON public.store_integrations (workspace_id, provider);