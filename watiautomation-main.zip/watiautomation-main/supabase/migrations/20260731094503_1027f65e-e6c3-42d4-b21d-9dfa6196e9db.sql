UPDATE public.workspace_plans
SET features = COALESCE(features, '{}'::jsonb) || '{"interested_leads": true}'::jsonb
WHERE NOT (COALESCE(features, '{}'::jsonb) ? 'interested_leads');