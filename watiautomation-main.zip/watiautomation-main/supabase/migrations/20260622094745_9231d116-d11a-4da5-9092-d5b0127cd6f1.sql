-- Abandoned cart recovery: extend abandoned_carts and add click-tracking table.

-- 1) Extend abandoned_carts with provider, recovery token/url, and cart token
ALTER TABLE public.abandoned_carts
  ADD COLUMN IF NOT EXISTS provider text,
  ADD COLUMN IF NOT EXISTS cart_token text,
  ADD COLUMN IF NOT EXISTS recovery_token text,
  ADD COLUMN IF NOT EXISTS recovery_url text,
  ADD COLUMN IF NOT EXISTS provider_recovery_url text,
  ADD COLUMN IF NOT EXISTS recovery_expires_at timestamp with time zone,
  ADD COLUMN IF NOT EXISTS clicked_at timestamp with time zone,
  ADD COLUMN IF NOT EXISTS click_count integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS updated_at timestamp with time zone NOT NULL DEFAULT now();

CREATE UNIQUE INDEX IF NOT EXISTS uniq_abandoned_carts_recovery_token
  ON public.abandoned_carts (recovery_token) WHERE recovery_token IS NOT NULL;
CREATE UNIQUE INDEX IF NOT EXISTS uniq_abandoned_carts_integration_cart
  ON public.abandoned_carts (integration_id, cart_token) WHERE cart_token IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_abandoned_carts_phone
  ON public.abandoned_carts (workspace_id, customer_phone);

-- Updated_at trigger
DROP TRIGGER IF EXISTS trg_abandoned_carts_updated_at ON public.abandoned_carts;
CREATE TRIGGER trg_abandoned_carts_updated_at
  BEFORE UPDATE ON public.abandoned_carts
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- 2) Click tracking table for Slice short-link redirects
CREATE TABLE IF NOT EXISTS public.cart_recovery_clicks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id uuid NOT NULL,
  abandoned_cart_id uuid NOT NULL REFERENCES public.abandoned_carts(id) ON DELETE CASCADE,
  recovery_token text NOT NULL,
  ip text,
  user_agent text,
  referer text,
  clicked_at timestamp with time zone NOT NULL DEFAULT now()
);

GRANT SELECT ON public.cart_recovery_clicks TO authenticated;
GRANT ALL ON public.cart_recovery_clicks TO service_role;

ALTER TABLE public.cart_recovery_clicks ENABLE ROW LEVEL SECURITY;

CREATE POLICY "workspace members view cart recovery clicks"
  ON public.cart_recovery_clicks FOR SELECT
  USING (public.is_workspace_member(workspace_id, auth.uid()));

CREATE INDEX IF NOT EXISTS idx_cart_recovery_clicks_cart
  ON public.cart_recovery_clicks (abandoned_cart_id, clicked_at DESC);
CREATE INDEX IF NOT EXISTS idx_cart_recovery_clicks_ws
  ON public.cart_recovery_clicks (workspace_id, clicked_at DESC);