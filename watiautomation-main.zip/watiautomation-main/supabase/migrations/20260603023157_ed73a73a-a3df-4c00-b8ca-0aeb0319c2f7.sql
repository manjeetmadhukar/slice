
ALTER TABLE public.workspace_plans
  ADD COLUMN IF NOT EXISTS expires_at TIMESTAMPTZ;

UPDATE public.workspace_plans
SET expires_at = COALESCE(expires_at, updated_at + INTERVAL '30 days')
WHERE expires_at IS NULL;
