
-- =========================================================
-- 1. Hide sensitive columns via column-level grants
-- =========================================================

-- store_integrations: hide access_token, api_key, api_secret, webhook_secret
REVOKE SELECT ON public.store_integrations FROM authenticated;
GRANT SELECT (id, workspace_id, user_id, provider, store_url, status, last_sync_at, total_revenue, meta, created_at, updated_at)
  ON public.store_integrations TO authenticated;

-- whatsapp_accounts: hide access_token
REVOKE SELECT ON public.whatsapp_accounts FROM authenticated;
GRANT SELECT (id, workspace_id, connected_by, business_name, display_name, phone_number, phone_number_id, waba_id, quality_rating, messaging_tier, display_name_status, status, webhook_status, webhook_last_event_at, sync_status, last_synced_at, last_error, is_active, meta, connected_at, created_at, updated_at)
  ON public.whatsapp_accounts TO authenticated;

-- whatsapp_settings: hide access_token (waba_id kept readable for UI; non-secret identifier)
REVOKE SELECT ON public.whatsapp_settings FROM authenticated;
GRANT SELECT (user_id, phone_number_id, waba_id, business_phone, display_name, verified, updated_at, workspace_id)
  ON public.whatsapp_settings TO authenticated;

-- workspace_invitations: hide token
REVOKE SELECT ON public.workspace_invitations FROM authenticated;
GRANT SELECT (id, workspace_id, email, role, invited_by, accepted_at, expires_at, created_at)
  ON public.workspace_invitations TO authenticated;

-- payment_gateways: hide meta (may contain provider secrets)
REVOKE SELECT ON public.payment_gateways FROM authenticated;
GRANT SELECT (id, provider, display_name, is_enabled, key_id, created_at, updated_at)
  ON public.payment_gateways TO authenticated;

-- service_role keeps full access (used by server code)
GRANT ALL ON public.store_integrations TO service_role;
GRANT ALL ON public.whatsapp_accounts TO service_role;
GRANT ALL ON public.whatsapp_settings TO service_role;
GRANT ALL ON public.workspace_invitations TO service_role;
GRANT ALL ON public.payment_gateways TO service_role;

-- =========================================================
-- 2. Storage: chat-media bucket workspace-scoped policies
-- Files are stored under "{workspace_id}/..." (see whatsapp-webhook)
-- =========================================================

DROP POLICY IF EXISTS "chat-media authenticated delete" ON storage.objects;
DROP POLICY IF EXISTS "chat-media authenticated update" ON storage.objects;
DROP POLICY IF EXISTS "chat-media public read" ON storage.objects;
DROP POLICY IF EXISTS "chat-media authenticated upload" ON storage.objects;

CREATE POLICY "chat-media workspace upload"
  ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (
    bucket_id = 'chat-media'
    AND public.is_workspace_member(((storage.foldername(name))[1])::uuid, auth.uid())
  );

CREATE POLICY "chat-media workspace delete"
  ON storage.objects FOR DELETE TO authenticated
  USING (
    bucket_id = 'chat-media'
    AND public.is_workspace_member(((storage.foldername(name))[1])::uuid, auth.uid())
  );

CREATE POLICY "chat-media workspace update"
  ON storage.objects FOR UPDATE TO authenticated
  USING (
    bucket_id = 'chat-media'
    AND public.is_workspace_member(((storage.foldername(name))[1])::uuid, auth.uid())
  );

-- Files are served as public URLs (getPublicUrl) which bypasses RLS, but listing
-- via the storage API requires SELECT on storage.objects. Restrict listing to
-- workspace members; individual file fetches via the public CDN URL still work.
CREATE POLICY "chat-media workspace list"
  ON storage.objects FOR SELECT TO authenticated
  USING (
    bucket_id = 'chat-media'
    AND public.is_workspace_member(((storage.foldername(name))[1])::uuid, auth.uid())
  );

-- =========================================================
-- 3. Realtime: require authentication for channel subscriptions
-- =========================================================

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace
             WHERE n.nspname='realtime' AND c.relname='messages') THEN
    EXECUTE 'ALTER TABLE realtime.messages ENABLE ROW LEVEL SECURITY';
    EXECUTE 'DROP POLICY IF EXISTS "authenticated can use realtime" ON realtime.messages';
    EXECUTE $p$CREATE POLICY "authenticated can use realtime"
      ON realtime.messages FOR SELECT TO authenticated
      USING ((SELECT auth.role()) = 'authenticated')$p$;
  END IF;
END $$;
