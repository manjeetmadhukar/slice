
-- Profiles additions
ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS username text UNIQUE,
  ADD COLUMN IF NOT EXISTS created_by_admin boolean NOT NULL DEFAULT false;

-- Workspace member active flag
ALTER TABLE public.workspace_members
  ADD COLUMN IF NOT EXISTS is_active boolean NOT NULL DEFAULT true;

-- Member permissions table
CREATE TABLE IF NOT EXISTS public.member_permissions (
  workspace_id uuid NOT NULL REFERENCES public.workspaces(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  module text NOT NULL,
  can_view boolean NOT NULL DEFAULT false,
  can_create boolean NOT NULL DEFAULT false,
  can_edit boolean NOT NULL DEFAULT false,
  can_delete boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (workspace_id, user_id, module)
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.member_permissions TO authenticated;
GRANT ALL ON public.member_permissions TO service_role;

ALTER TABLE public.member_permissions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Members can read own permissions"
  ON public.member_permissions FOR SELECT TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Workspace admins can read permissions"
  ON public.member_permissions FOR SELECT TO authenticated
  USING (public.has_workspace_role(workspace_id, auth.uid(), ARRAY['owner','admin']::app_role[]));

CREATE POLICY "Workspace admins can insert permissions"
  ON public.member_permissions FOR INSERT TO authenticated
  WITH CHECK (public.has_workspace_role(workspace_id, auth.uid(), ARRAY['owner','admin']::app_role[]));

CREATE POLICY "Workspace admins can update permissions"
  ON public.member_permissions FOR UPDATE TO authenticated
  USING (public.has_workspace_role(workspace_id, auth.uid(), ARRAY['owner','admin']::app_role[]))
  WITH CHECK (public.has_workspace_role(workspace_id, auth.uid(), ARRAY['owner','admin']::app_role[]));

CREATE POLICY "Workspace admins can delete permissions"
  ON public.member_permissions FOR DELETE TO authenticated
  USING (public.has_workspace_role(workspace_id, auth.uid(), ARRAY['owner','admin']::app_role[]));

CREATE TRIGGER trg_member_permissions_updated
  BEFORE UPDATE ON public.member_permissions
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
