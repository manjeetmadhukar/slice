
-- 1. Flag plan templates as reseller tiers
ALTER TABLE public.plan_templates ADD COLUMN IF NOT EXISTS is_reseller boolean NOT NULL DEFAULT false;

-- 2. Reseller applications
CREATE TABLE public.reseller_applications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id uuid NOT NULL,
  applicant_id uuid NOT NULL,
  business_name text NOT NULL,
  brand_name text,
  contact_email text,
  contact_phone text,
  website text,
  country text,
  requested_plan_template_id uuid,
  notes text,
  status text NOT NULL DEFAULT 'pending',
  reviewed_by uuid,
  reviewed_at timestamptz,
  admin_notes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.reseller_applications TO authenticated;
GRANT ALL ON public.reseller_applications TO service_role;

ALTER TABLE public.reseller_applications ENABLE ROW LEVEL SECURITY;

CREATE POLICY "admins create reseller applications" ON public.reseller_applications
  FOR INSERT TO authenticated
  WITH CHECK (
    has_workspace_role(workspace_id, auth.uid(), ARRAY['owner'::app_role,'admin'::app_role])
    AND applicant_id = auth.uid()
    AND status = 'pending'
  );

CREATE POLICY "members view reseller applications" ON public.reseller_applications
  FOR SELECT TO authenticated
  USING (is_workspace_member(workspace_id, auth.uid()) OR is_super_admin(auth.uid()));

CREATE POLICY "applicant cancel own pending" ON public.reseller_applications
  FOR UPDATE TO authenticated
  USING (applicant_id = auth.uid() AND status = 'pending')
  WITH CHECK (applicant_id = auth.uid());

CREATE POLICY "super admins manage reseller applications" ON public.reseller_applications
  FOR ALL TO authenticated
  USING (is_super_admin(auth.uid()))
  WITH CHECK (is_super_admin(auth.uid()));

-- 3. Reseller accounts (approved resellers)
CREATE TABLE public.reseller_accounts (
  workspace_id uuid PRIMARY KEY,
  status text NOT NULL DEFAULT 'active',
  brand_name text NOT NULL,
  logo_url text,
  primary_color text DEFAULT '#3b82f6',
  support_email text,
  custom_domain text,
  plan_template_id uuid,
  commission_pct numeric NOT NULL DEFAULT 20,
  max_customers integer NOT NULL DEFAULT 10,
  allow_custom_domain boolean NOT NULL DEFAULT false,
  white_label boolean NOT NULL DEFAULT true,
  approved_by uuid,
  approved_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT ON public.reseller_accounts TO authenticated;
GRANT ALL ON public.reseller_accounts TO service_role;

ALTER TABLE public.reseller_accounts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "members view reseller account" ON public.reseller_accounts
  FOR SELECT TO authenticated
  USING (is_workspace_member(workspace_id, auth.uid()) OR is_super_admin(auth.uid()));

CREATE POLICY "owners update own branding" ON public.reseller_accounts
  FOR UPDATE TO authenticated
  USING (has_workspace_role(workspace_id, auth.uid(), ARRAY['owner'::app_role,'admin'::app_role]))
  WITH CHECK (has_workspace_role(workspace_id, auth.uid(), ARRAY['owner'::app_role,'admin'::app_role]));

CREATE POLICY "super admins manage reseller accounts" ON public.reseller_accounts
  FOR ALL TO authenticated
  USING (is_super_admin(auth.uid()))
  WITH CHECK (is_super_admin(auth.uid()));

-- 4. Reseller sub-customers
CREATE TABLE public.reseller_customers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  reseller_workspace_id uuid NOT NULL,
  customer_workspace_id uuid,
  customer_name text NOT NULL,
  customer_email text,
  customer_phone text,
  plan_template_id uuid,
  monthly_price numeric NOT NULL DEFAULT 0,
  currency text NOT NULL DEFAULT 'INR',
  commission_amount numeric NOT NULL DEFAULT 0,
  status text NOT NULL DEFAULT 'active',
  notes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.reseller_customers TO authenticated;
GRANT ALL ON public.reseller_customers TO service_role;

ALTER TABLE public.reseller_customers ENABLE ROW LEVEL SECURITY;

CREATE POLICY "reseller admins manage customers" ON public.reseller_customers
  FOR ALL TO authenticated
  USING (has_workspace_role(reseller_workspace_id, auth.uid(), ARRAY['owner'::app_role,'admin'::app_role]) OR is_super_admin(auth.uid()))
  WITH CHECK (has_workspace_role(reseller_workspace_id, auth.uid(), ARRAY['owner'::app_role,'admin'::app_role]) OR is_super_admin(auth.uid()));

CREATE POLICY "reseller members view customers" ON public.reseller_customers
  FOR SELECT TO authenticated
  USING (is_workspace_member(reseller_workspace_id, auth.uid()) OR is_super_admin(auth.uid()));

-- 5. Triggers for updated_at
CREATE TRIGGER trg_reseller_applications_updated_at BEFORE UPDATE ON public.reseller_applications
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER trg_reseller_accounts_updated_at BEFORE UPDATE ON public.reseller_accounts
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER trg_reseller_customers_updated_at BEFORE UPDATE ON public.reseller_customers
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- 6. Seed reseller plan templates
INSERT INTO public.plan_templates (name, description, is_reseller, is_active, price_monthly, price_yearly, currency, features, limits)
VALUES
  ('Reseller Starter', 'Resell to up to 10 customers with white-label branding.', true, true, 4999, 49990, 'INR',
    '{"inbox":true,"contacts":true,"campaigns":true,"templates":true,"reseller_program":true}'::jsonb,
    '{"reseller_max_customers":10,"team_members":3}'::jsonb),
  ('Reseller Pro', 'Up to 50 customers, custom domain and 25% margin.', true, true, 14999, 149990, 'INR',
    '{"inbox":true,"contacts":true,"campaigns":true,"templates":true,"automations":true,"bots":true,"reseller_program":true}'::jsonb,
    '{"reseller_max_customers":50,"team_members":10}'::jsonb),
  ('Reseller Enterprise', 'Unlimited customers, full white-label and 30% margin.', true, true, 39999, 399990, 'INR',
    '{"inbox":true,"contacts":true,"campaigns":true,"templates":true,"automations":true,"bots":true,"analytics":true,"integrations":true,"reseller_program":true}'::jsonb,
    '{"reseller_max_customers":-1,"team_members":-1}'::jsonb);
