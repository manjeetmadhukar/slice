GRANT SELECT ON public.store_integrations TO authenticated;
GRANT SELECT ON public.payment_gateways TO authenticated;