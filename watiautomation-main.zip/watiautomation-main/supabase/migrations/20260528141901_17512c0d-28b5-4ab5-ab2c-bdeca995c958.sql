
CREATE TABLE public.plan_requests (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  workspace_id UUID NOT NULL,
  requested_by UUID NOT NULL,
  plan_name TEXT NOT NULL DEFAULT 'Custom',
  features JSONB NOT NULL DEFAULT '{}'::jsonb,
  limits JSONB NOT NULL DEFAULT '{}'::jsonb,
  notes TEXT,
  status TEXT NOT NULL DEFAULT 'pending',
  admin_notes TEXT,
  reviewed_by UUID,
  reviewed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.plan_requests TO authenticated;
GRANT ALL ON public.plan_requests TO service_role;

ALTER TABLE public.plan_requests ENABLE ROW LEVEL SECURITY;

CREATE POLICY "members view plan requests"
  ON public.plan_requests FOR SELECT
  USING (public.is_workspace_member(workspace_id, auth.uid()) OR public.is_super_admin(auth.uid()));

CREATE POLICY "admins create plan requests"
  ON public.plan_requests FOR INSERT
  WITH CHECK (
    public.has_workspace_role(workspace_id, auth.uid(), ARRAY['owner'::app_role, 'admin'::app_role])
    AND requested_by = auth.uid()
    AND status = 'pending'
  );

CREATE POLICY "requester cancel own pending"
  ON public.plan_requests FOR UPDATE
  USING (requested_by = auth.uid() AND status = 'pending')
  WITH CHECK (requested_by = auth.uid());

CREATE POLICY "super admins manage plan requests"
  ON public.plan_requests FOR ALL
  USING (public.is_super_admin(auth.uid()))
  WITH CHECK (public.is_super_admin(auth.uid()));

CREATE TRIGGER trg_plan_requests_updated
  BEFORE UPDATE ON public.plan_requests
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE INDEX idx_plan_requests_workspace ON public.plan_requests(workspace_id);
CREATE INDEX idx_plan_requests_status ON public.plan_requests(status);
