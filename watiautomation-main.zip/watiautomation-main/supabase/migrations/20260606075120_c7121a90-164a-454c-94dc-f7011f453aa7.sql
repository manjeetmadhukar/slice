UPDATE public.messages m
SET wa_message_id = NULL
WHERE m.wa_message_id IS NOT NULL
  AND EXISTS (
    SELECT 1
    FROM public.messages keep
    WHERE keep.workspace_id = m.workspace_id
      AND keep.wa_message_id = m.wa_message_id
      AND keep.id::text < m.id::text
  );

UPDATE public.campaign_recipients cr
SET status = 'skipped_duplicate', error = 'Duplicate phone number in the same campaign'
WHERE cr.status IN ('pending', 'sending')
  AND EXISTS (
    SELECT 1
    FROM public.campaign_recipients keep
    WHERE keep.campaign_id = cr.campaign_id
      AND keep.status IN ('pending', 'sending')
      AND regexp_replace(coalesce(keep.phone, ''), '\D', '', 'g') = regexp_replace(coalesce(cr.phone, ''), '\D', '', 'g')
      AND keep.id::text < cr.id::text
  );

CREATE UNIQUE INDEX IF NOT EXISTS messages_workspace_wa_message_id_unique
  ON public.messages (workspace_id, wa_message_id)
  WHERE wa_message_id IS NOT NULL;

CREATE UNIQUE INDEX IF NOT EXISTS campaign_recipients_pending_phone_unique
  ON public.campaign_recipients (campaign_id, regexp_replace(coalesce(phone, ''), '\D', '', 'g'))
  WHERE status IN ('pending', 'sending');