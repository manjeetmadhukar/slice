DROP POLICY IF EXISTS "authenticated can use realtime" ON public.messages;
DROP POLICY IF EXISTS "members view whatsapp accounts" ON public.whatsapp_accounts;
DROP POLICY IF EXISTS "members view settings" ON public.whatsapp_settings;
DROP POLICY IF EXISTS "members view store integrations" ON public.store_integrations;
DROP POLICY IF EXISTS "ws members manage meta connections" ON public.meta_lead_connections;
DROP POLICY IF EXISTS "ws members manage meta pages" ON public.meta_lead_pages;

CREATE POLICY "members view whatsapp accounts without secrets"
ON public.whatsapp_accounts
FOR SELECT
TO authenticated
USING (has_workspace_role(workspace_id, auth.uid(), ARRAY['owner'::app_role, 'admin'::app_role]));

CREATE POLICY "members view settings without secrets"
ON public.whatsapp_settings
FOR SELECT
TO authenticated
USING (has_workspace_role(workspace_id, auth.uid(), ARRAY['owner'::app_role, 'admin'::app_role]));

CREATE POLICY "members view store integrations without secrets"
ON public.store_integrations
FOR SELECT
TO authenticated
USING (has_workspace_role(workspace_id, auth.uid(), ARRAY['owner'::app_role, 'admin'::app_role]));

CREATE POLICY "admins manage meta lead connections"
ON public.meta_lead_connections
FOR ALL
TO authenticated
USING (has_workspace_role(workspace_id, auth.uid(), ARRAY['owner'::app_role, 'admin'::app_role]))
WITH CHECK (has_workspace_role(workspace_id, auth.uid(), ARRAY['owner'::app_role, 'admin'::app_role]));

CREATE POLICY "admins manage meta lead pages"
ON public.meta_lead_pages
FOR ALL
TO authenticated
USING (has_workspace_role(workspace_id, auth.uid(), ARRAY['owner'::app_role, 'admin'::app_role]))
WITH CHECK (has_workspace_role(workspace_id, auth.uid(), ARRAY['owner'::app_role, 'admin'::app_role]));