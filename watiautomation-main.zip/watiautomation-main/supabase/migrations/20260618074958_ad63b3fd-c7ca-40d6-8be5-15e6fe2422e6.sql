
ALTER TABLE public.workspace_plans ADD COLUMN IF NOT EXISTS starts_at timestamptz;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS is_archived boolean NOT NULL DEFAULT false;
