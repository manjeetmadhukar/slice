
CREATE TYPE public.automation_type AS ENUM ('welcome', 'away', 'keyword', 'routing');

CREATE TABLE public.automations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id UUID NOT NULL,
  user_id UUID NOT NULL,
  name TEXT NOT NULL,
  type automation_type NOT NULL,
  enabled BOOLEAN NOT NULL DEFAULT true,
  keywords TEXT[] NOT NULL DEFAULT '{}',
  match_type TEXT NOT NULL DEFAULT 'contains',
  reply_text TEXT,
  template_id UUID,
  away_start TIME,
  away_end TIME,
  away_days INT[] NOT NULL DEFAULT '{0,1,2,3,4,5,6}',
  assign_to UUID,
  priority INT NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.automations ENABLE ROW LEVEL SECURITY;

CREATE POLICY "workspace members view automations" ON public.automations
  FOR SELECT USING (is_workspace_member(workspace_id, auth.uid()));

CREATE POLICY "agents+ insert automations" ON public.automations
  FOR INSERT WITH CHECK (has_workspace_role(workspace_id, auth.uid(), ARRAY['owner'::app_role,'admin'::app_role,'agent'::app_role]));

CREATE POLICY "agents+ update automations" ON public.automations
  FOR UPDATE USING (has_workspace_role(workspace_id, auth.uid(), ARRAY['owner'::app_role,'admin'::app_role,'agent'::app_role]));

CREATE POLICY "admins delete automations" ON public.automations
  FOR DELETE USING (has_workspace_role(workspace_id, auth.uid(), ARRAY['owner'::app_role,'admin'::app_role]));

CREATE INDEX idx_automations_workspace ON public.automations(workspace_id, enabled);

ALTER TABLE public.messages ADD COLUMN IF NOT EXISTS is_automated BOOLEAN NOT NULL DEFAULT false;
