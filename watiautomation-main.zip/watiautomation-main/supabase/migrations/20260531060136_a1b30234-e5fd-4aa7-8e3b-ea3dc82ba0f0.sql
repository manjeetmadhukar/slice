DROP INDEX IF EXISTS public.ecom_orders_integration_external_unique;
DROP INDEX IF EXISTS public.ecom_customers_integration_external_unique;

CREATE UNIQUE INDEX IF NOT EXISTS ecom_orders_integration_external_unique
ON public.ecom_orders (integration_id, external_id);

CREATE UNIQUE INDEX IF NOT EXISTS ecom_customers_integration_external_unique
ON public.ecom_customers (integration_id, external_id);