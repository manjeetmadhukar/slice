-- Custom fields on contacts
ALTER TABLE public.contacts
  ADD COLUMN IF NOT EXISTS custom_fields jsonb NOT NULL DEFAULT '{}'::jsonb;

-- Segments: saved filters
CREATE TABLE IF NOT EXISTS public.contact_segments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id uuid NOT NULL,
  user_id uuid NOT NULL,
  name text NOT NULL,
  description text,
  tags_any text[] NOT NULL DEFAULT '{}'::text[],
  search text,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.contact_segments ENABLE ROW LEVEL SECURITY;

CREATE POLICY "workspace members manage segments"
ON public.contact_segments
FOR ALL
USING (public.is_workspace_member(workspace_id, auth.uid()))
WITH CHECK (public.is_workspace_member(workspace_id, auth.uid()));

CREATE INDEX IF NOT EXISTS idx_contact_segments_workspace ON public.contact_segments(workspace_id);
CREATE INDEX IF NOT EXISTS idx_contacts_tags ON public.contacts USING gin(tags);