
-- 1. Role enum
CREATE TYPE public.app_role AS ENUM ('owner', 'admin', 'agent', 'viewer');

-- 2. Workspaces
CREATE TABLE public.workspaces (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  slug TEXT NOT NULL UNIQUE,
  owner_id UUID NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.workspaces ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.workspace_members (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id UUID NOT NULL REFERENCES public.workspaces(id) ON DELETE CASCADE,
  user_id UUID NOT NULL,
  role public.app_role NOT NULL DEFAULT 'agent',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (workspace_id, user_id)
);
ALTER TABLE public.workspace_members ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.workspace_invitations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id UUID NOT NULL REFERENCES public.workspaces(id) ON DELETE CASCADE,
  email TEXT NOT NULL,
  role public.app_role NOT NULL DEFAULT 'agent',
  token TEXT NOT NULL UNIQUE DEFAULT encode(gen_random_bytes(24), 'hex'),
  invited_by UUID NOT NULL,
  accepted_at TIMESTAMPTZ,
  expires_at TIMESTAMPTZ NOT NULL DEFAULT (now() + interval '7 days'),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.workspace_invitations ENABLE ROW LEVEL SECURITY;

-- 3. Security definer helpers (avoid recursive RLS)
CREATE OR REPLACE FUNCTION public.is_workspace_member(_workspace_id UUID, _user_id UUID)
RETURNS BOOLEAN LANGUAGE SQL STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.workspace_members
    WHERE workspace_id = _workspace_id AND user_id = _user_id
  );
$$;

CREATE OR REPLACE FUNCTION public.has_workspace_role(_workspace_id UUID, _user_id UUID, _roles public.app_role[])
RETURNS BOOLEAN LANGUAGE SQL STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.workspace_members
    WHERE workspace_id = _workspace_id AND user_id = _user_id AND role = ANY(_roles)
  );
$$;

CREATE OR REPLACE FUNCTION public.get_workspace_role(_workspace_id UUID, _user_id UUID)
RETURNS public.app_role LANGUAGE SQL STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT role FROM public.workspace_members
  WHERE workspace_id = _workspace_id AND user_id = _user_id LIMIT 1;
$$;

-- 4. Add workspace_id to existing data tables (nullable for now, backfill, then NOT NULL)
ALTER TABLE public.contacts ADD COLUMN workspace_id UUID REFERENCES public.workspaces(id) ON DELETE CASCADE;
ALTER TABLE public.templates ADD COLUMN workspace_id UUID REFERENCES public.workspaces(id) ON DELETE CASCADE;
ALTER TABLE public.campaigns ADD COLUMN workspace_id UUID REFERENCES public.workspaces(id) ON DELETE CASCADE;
ALTER TABLE public.campaign_recipients ADD COLUMN workspace_id UUID REFERENCES public.workspaces(id) ON DELETE CASCADE;
ALTER TABLE public.whatsapp_settings ADD COLUMN workspace_id UUID REFERENCES public.workspaces(id) ON DELETE CASCADE;

-- 5. Backfill: one workspace per existing user
DO $$
DECLARE
  u RECORD;
  new_ws UUID;
BEGIN
  FOR u IN SELECT id, email, full_name FROM public.profiles LOOP
    INSERT INTO public.workspaces (name, slug, owner_id)
    VALUES (
      COALESCE(u.full_name, split_part(u.email, '@', 1), 'My workspace'),
      lower(regexp_replace(COALESCE(u.full_name, split_part(u.email, '@', 1), 'workspace'), '[^a-z0-9]+', '-', 'gi')) || '-' || substr(u.id::text, 1, 6),
      u.id
    )
    RETURNING id INTO new_ws;

    INSERT INTO public.workspace_members (workspace_id, user_id, role) VALUES (new_ws, u.id, 'owner');

    UPDATE public.contacts SET workspace_id = new_ws WHERE user_id = u.id;
    UPDATE public.templates SET workspace_id = new_ws WHERE user_id = u.id;
    UPDATE public.campaigns SET workspace_id = new_ws WHERE user_id = u.id;
    UPDATE public.campaign_recipients SET workspace_id = new_ws WHERE user_id = u.id;
    UPDATE public.whatsapp_settings SET workspace_id = new_ws WHERE user_id = u.id;
  END LOOP;
END $$;

-- 6. Make workspace_id NOT NULL
ALTER TABLE public.contacts ALTER COLUMN workspace_id SET NOT NULL;
ALTER TABLE public.templates ALTER COLUMN workspace_id SET NOT NULL;
ALTER TABLE public.campaigns ALTER COLUMN workspace_id SET NOT NULL;
ALTER TABLE public.campaign_recipients ALTER COLUMN workspace_id SET NOT NULL;
ALTER TABLE public.whatsapp_settings ALTER COLUMN workspace_id SET NOT NULL;

-- whatsapp_settings: one per workspace, not per user
ALTER TABLE public.whatsapp_settings DROP CONSTRAINT IF EXISTS whatsapp_settings_pkey;
ALTER TABLE public.whatsapp_settings ADD CONSTRAINT whatsapp_settings_workspace_unique UNIQUE (workspace_id);

-- 7. Replace RLS policies (workspace-scoped)
-- workspaces
CREATE POLICY "members can view their workspaces" ON public.workspaces
  FOR SELECT USING (public.is_workspace_member(id, auth.uid()));
CREATE POLICY "authenticated users can create workspaces" ON public.workspaces
  FOR INSERT WITH CHECK (auth.uid() = owner_id);
CREATE POLICY "owners and admins can update workspace" ON public.workspaces
  FOR UPDATE USING (public.has_workspace_role(id, auth.uid(), ARRAY['owner','admin']::public.app_role[]));
CREATE POLICY "only owner can delete workspace" ON public.workspaces
  FOR DELETE USING (auth.uid() = owner_id);

-- workspace_members
CREATE POLICY "members can view co-members" ON public.workspace_members
  FOR SELECT USING (public.is_workspace_member(workspace_id, auth.uid()));
CREATE POLICY "owners/admins can add members" ON public.workspace_members
  FOR INSERT WITH CHECK (public.has_workspace_role(workspace_id, auth.uid(), ARRAY['owner','admin']::public.app_role[]));
CREATE POLICY "owners/admins can update members" ON public.workspace_members
  FOR UPDATE USING (public.has_workspace_role(workspace_id, auth.uid(), ARRAY['owner','admin']::public.app_role[]));
CREATE POLICY "owners/admins can remove members" ON public.workspace_members
  FOR DELETE USING (public.has_workspace_role(workspace_id, auth.uid(), ARRAY['owner','admin']::public.app_role[]));

-- workspace_invitations
CREATE POLICY "members view invites" ON public.workspace_invitations
  FOR SELECT USING (public.is_workspace_member(workspace_id, auth.uid()));
CREATE POLICY "admins create invites" ON public.workspace_invitations
  FOR INSERT WITH CHECK (public.has_workspace_role(workspace_id, auth.uid(), ARRAY['owner','admin']::public.app_role[]));
CREATE POLICY "admins delete invites" ON public.workspace_invitations
  FOR DELETE USING (public.has_workspace_role(workspace_id, auth.uid(), ARRAY['owner','admin']::public.app_role[]));

-- Drop old user-scoped policies and recreate workspace-scoped
DROP POLICY IF EXISTS "own contacts all" ON public.contacts;
CREATE POLICY "workspace members manage contacts" ON public.contacts
  FOR ALL USING (public.is_workspace_member(workspace_id, auth.uid()))
  WITH CHECK (public.is_workspace_member(workspace_id, auth.uid()));

DROP POLICY IF EXISTS "own templates all" ON public.templates;
CREATE POLICY "workspace members manage templates" ON public.templates
  FOR ALL USING (public.is_workspace_member(workspace_id, auth.uid()))
  WITH CHECK (public.is_workspace_member(workspace_id, auth.uid()));

DROP POLICY IF EXISTS "own campaigns all" ON public.campaigns;
CREATE POLICY "workspace members view campaigns" ON public.campaigns
  FOR SELECT USING (public.is_workspace_member(workspace_id, auth.uid()));
CREATE POLICY "agents+ create campaigns" ON public.campaigns
  FOR INSERT WITH CHECK (public.has_workspace_role(workspace_id, auth.uid(), ARRAY['owner','admin','agent']::public.app_role[]));
CREATE POLICY "agents+ update campaigns" ON public.campaigns
  FOR UPDATE USING (public.has_workspace_role(workspace_id, auth.uid(), ARRAY['owner','admin','agent']::public.app_role[]));
CREATE POLICY "admins delete campaigns" ON public.campaigns
  FOR DELETE USING (public.has_workspace_role(workspace_id, auth.uid(), ARRAY['owner','admin']::public.app_role[]));

DROP POLICY IF EXISTS "own recipients all" ON public.campaign_recipients;
CREATE POLICY "workspace members manage recipients" ON public.campaign_recipients
  FOR ALL USING (public.is_workspace_member(workspace_id, auth.uid()))
  WITH CHECK (public.is_workspace_member(workspace_id, auth.uid()));

DROP POLICY IF EXISTS "own settings all" ON public.whatsapp_settings;
CREATE POLICY "members view settings" ON public.whatsapp_settings
  FOR SELECT USING (public.is_workspace_member(workspace_id, auth.uid()));
CREATE POLICY "admins manage settings" ON public.whatsapp_settings
  FOR ALL USING (public.has_workspace_role(workspace_id, auth.uid(), ARRAY['owner','admin']::public.app_role[]))
  WITH CHECK (public.has_workspace_role(workspace_id, auth.uid(), ARRAY['owner','admin']::public.app_role[]));

-- 8. Update new-user trigger: also create personal workspace
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  new_ws UUID;
  base_name TEXT;
BEGIN
  INSERT INTO public.profiles (id, email, full_name)
  VALUES (new.id, new.email, COALESCE(new.raw_user_meta_data->>'full_name', new.email));

  base_name := COALESCE(new.raw_user_meta_data->>'full_name', split_part(new.email, '@', 1), 'Workspace');

  INSERT INTO public.workspaces (name, slug, owner_id)
  VALUES (
    base_name || '''s Workspace',
    lower(regexp_replace(base_name, '[^a-z0-9]+', '-', 'gi')) || '-' || substr(new.id::text, 1, 6),
    new.id
  )
  RETURNING id INTO new_ws;

  INSERT INTO public.workspace_members (workspace_id, user_id, role)
  VALUES (new_ws, new.id, 'owner');

  INSERT INTO public.whatsapp_settings (user_id, workspace_id) VALUES (new.id, new_ws);

  RETURN new;
END;
$$;

-- Ensure trigger exists
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();
