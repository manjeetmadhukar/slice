ALTER TABLE public.ai_assistant_settings
  ADD COLUMN IF NOT EXISTS system_prompt text NOT NULL DEFAULT '';