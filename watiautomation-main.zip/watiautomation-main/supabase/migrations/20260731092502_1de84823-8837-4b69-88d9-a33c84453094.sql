CREATE TABLE public.template_button_clicks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id uuid NOT NULL,
  contact_id uuid REFERENCES public.contacts(id) ON DELETE SET NULL,
  contact_name text,
  phone text NOT NULL,
  phone_normalized text,
  campaign_id uuid REFERENCES public.campaigns(id) ON DELETE SET NULL,
  template_name text,
  button_text text,
  button_payload text,
  button_type text NOT NULL DEFAULT 'quick_reply',
  wa_message_id text,
  context_wa_message_id text,
  conversation_id uuid,
  clicked_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT ON public.template_button_clicks TO authenticated;
GRANT ALL ON public.template_button_clicks TO service_role;

ALTER TABLE public.template_button_clicks ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Workspace members or super admins can view button clicks"
ON public.template_button_clicks FOR SELECT TO authenticated
USING (public.is_workspace_member(workspace_id, auth.uid()) OR public.is_super_admin(auth.uid()));

CREATE UNIQUE INDEX template_button_clicks_wa_msg_uniq
  ON public.template_button_clicks (workspace_id, wa_message_id)
  WHERE wa_message_id IS NOT NULL;
CREATE INDEX template_button_clicks_ws_time_idx ON public.template_button_clicks (workspace_id, clicked_at DESC);
CREATE INDEX template_button_clicks_campaign_idx ON public.template_button_clicks (campaign_id, clicked_at DESC);
CREATE INDEX template_button_clicks_template_idx ON public.template_button_clicks (workspace_id, template_name);
CREATE INDEX template_button_clicks_button_idx ON public.template_button_clicks (workspace_id, button_text);
CREATE INDEX template_button_clicks_phone_idx ON public.template_button_clicks (workspace_id, phone_normalized);