DROP POLICY IF EXISTS "authenticated can use realtime" ON realtime.messages;
DROP POLICY IF EXISTS "workspace members can use realtime" ON realtime.messages;

CREATE POLICY "workspace members can use realtime"
ON realtime.messages
FOR SELECT
TO authenticated
USING (
  topic ~ '^inbox-[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
  AND public.is_workspace_member(substring(topic from 7)::uuid, auth.uid())
);