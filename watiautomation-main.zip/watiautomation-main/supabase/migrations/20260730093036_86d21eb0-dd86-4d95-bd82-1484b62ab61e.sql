ALTER TABLE public.browse_events
ADD COLUMN IF NOT EXISTS visitor_key TEXT;

CREATE INDEX IF NOT EXISTS be_ws_visitor_idx
ON public.browse_events(workspace_id, visitor_key)
WHERE visitor_key IS NOT NULL;