
-- Connections (one per FB account per workspace)
CREATE TABLE public.meta_lead_connections (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id UUID NOT NULL REFERENCES public.workspaces(id) ON DELETE CASCADE,
  user_id UUID NOT NULL,
  fb_user_id TEXT NOT NULL,
  fb_user_name TEXT,
  long_lived_token TEXT NOT NULL,
  token_expires_at TIMESTAMPTZ,
  scope TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(workspace_id, fb_user_id)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.meta_lead_connections TO authenticated;
GRANT ALL ON public.meta_lead_connections TO service_role;
ALTER TABLE public.meta_lead_connections ENABLE ROW LEVEL SECURITY;
CREATE POLICY "ws members manage meta connections" ON public.meta_lead_connections
  FOR ALL TO authenticated
  USING (public.is_workspace_member(workspace_id, auth.uid()))
  WITH CHECK (public.is_workspace_member(workspace_id, auth.uid()));

-- Pages
CREATE TABLE public.meta_lead_pages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  connection_id UUID NOT NULL REFERENCES public.meta_lead_connections(id) ON DELETE CASCADE,
  workspace_id UUID NOT NULL,
  page_id TEXT NOT NULL,
  page_name TEXT,
  page_access_token TEXT NOT NULL,
  subscribed BOOLEAN NOT NULL DEFAULT false,
  business_name TEXT,
  category TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(workspace_id, page_id)
);
CREATE INDEX idx_meta_pages_page_id ON public.meta_lead_pages(page_id);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.meta_lead_pages TO authenticated;
GRANT ALL ON public.meta_lead_pages TO service_role;
ALTER TABLE public.meta_lead_pages ENABLE ROW LEVEL SECURITY;
CREATE POLICY "ws members manage meta pages" ON public.meta_lead_pages
  FOR ALL TO authenticated
  USING (public.is_workspace_member(workspace_id, auth.uid()))
  WITH CHECK (public.is_workspace_member(workspace_id, auth.uid()));

-- Forms with routing
CREATE TABLE public.meta_lead_forms (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id UUID NOT NULL,
  page_id TEXT NOT NULL,
  form_id TEXT NOT NULL,
  form_name TEXT,
  status TEXT,
  assigned_user_id UUID,
  assigned_agent_id UUID,
  assigned_agent_label TEXT,
  default_stage_id UUID,
  default_tags JSONB NOT NULL DEFAULT '[]'::jsonb,
  enabled BOOLEAN NOT NULL DEFAULT true,
  last_lead_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(workspace_id, form_id)
);
CREATE INDEX idx_meta_forms_form_id ON public.meta_lead_forms(form_id);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.meta_lead_forms TO authenticated;
GRANT ALL ON public.meta_lead_forms TO service_role;
ALTER TABLE public.meta_lead_forms ENABLE ROW LEVEL SECURITY;
CREATE POLICY "ws members manage meta forms" ON public.meta_lead_forms
  FOR ALL TO authenticated
  USING (public.is_workspace_member(workspace_id, auth.uid()))
  WITH CHECK (public.is_workspace_member(workspace_id, auth.uid()));

-- Custom agent roster
CREATE TABLE public.lead_agents (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id UUID NOT NULL REFERENCES public.workspaces(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  email TEXT,
  phone TEXT,
  active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.lead_agents TO authenticated;
GRANT ALL ON public.lead_agents TO service_role;
ALTER TABLE public.lead_agents ENABLE ROW LEVEL SECURITY;
CREATE POLICY "ws members manage lead agents" ON public.lead_agents
  FOR ALL TO authenticated
  USING (public.is_workspace_member(workspace_id, auth.uid()))
  WITH CHECK (public.is_workspace_member(workspace_id, auth.uid()));

-- Owner columns on deals + contacts
ALTER TABLE public.deals ADD COLUMN IF NOT EXISTS assigned_user_id UUID;
ALTER TABLE public.deals ADD COLUMN IF NOT EXISTS assigned_agent_id UUID;
ALTER TABLE public.deals ADD COLUMN IF NOT EXISTS assigned_agent_label TEXT;
ALTER TABLE public.contacts ADD COLUMN IF NOT EXISTS assigned_user_id UUID;
ALTER TABLE public.contacts ADD COLUMN IF NOT EXISTS assigned_agent_id UUID;
ALTER TABLE public.contacts ADD COLUMN IF NOT EXISTS assigned_agent_label TEXT;

-- updated_at triggers
CREATE TRIGGER set_meta_connections_updated_at BEFORE UPDATE ON public.meta_lead_connections
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER set_meta_pages_updated_at BEFORE UPDATE ON public.meta_lead_pages
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER set_meta_forms_updated_at BEFORE UPDATE ON public.meta_lead_forms
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
