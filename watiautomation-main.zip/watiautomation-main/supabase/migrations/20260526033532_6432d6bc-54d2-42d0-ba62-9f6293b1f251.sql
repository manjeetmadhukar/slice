
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER
LANGUAGE plpgsql
SET search_path = public
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

CREATE TABLE public.subscriptions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id UUID NOT NULL,
  vendor_id UUID NOT NULL,
  plan_id UUID NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',
  requested_by UUID NOT NULL,
  approved_by UUID,
  approved_at TIMESTAMPTZ,
  rejected_at TIMESTAMPTZ,
  cancelled_at TIMESTAMPTZ,
  notes TEXT,
  admin_notes TEXT,
  price_snapshot NUMERIC NOT NULL DEFAULT 0,
  currency TEXT NOT NULL DEFAULT 'USD',
  billing_interval TEXT NOT NULL DEFAULT 'monthly',
  plan_name_snapshot TEXT,
  vendor_name_snapshot TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_subscriptions_workspace ON public.subscriptions(workspace_id);
CREATE INDEX idx_subscriptions_status ON public.subscriptions(status);

ALTER TABLE public.subscriptions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "members view subscriptions"
ON public.subscriptions FOR SELECT
USING (is_workspace_member(workspace_id, auth.uid()));

CREATE POLICY "members request subscription"
ON public.subscriptions FOR INSERT
WITH CHECK (
  is_workspace_member(workspace_id, auth.uid())
  AND requested_by = auth.uid()
  AND status = 'pending'
);

CREATE POLICY "admins update subscriptions"
ON public.subscriptions FOR UPDATE
USING (has_workspace_role(workspace_id, auth.uid(), ARRAY['owner'::app_role, 'admin'::app_role]))
WITH CHECK (has_workspace_role(workspace_id, auth.uid(), ARRAY['owner'::app_role, 'admin'::app_role]));

CREATE POLICY "admins delete subscriptions"
ON public.subscriptions FOR DELETE
USING (has_workspace_role(workspace_id, auth.uid(), ARRAY['owner'::app_role, 'admin'::app_role]));

CREATE TRIGGER update_subscriptions_updated_at
BEFORE UPDATE ON public.subscriptions
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
