CREATE TABLE IF NOT EXISTS public.integration_debug_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id uuid NOT NULL,
  integration_id uuid,
  provider text NOT NULL DEFAULT 'woocommerce',
  direction text NOT NULL DEFAULT 'in',
  event text NOT NULL,
  status_code integer,
  ok boolean NOT NULL DEFAULT false,
  message text,
  payload jsonb NOT NULL DEFAULT '{}',
  response jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT ON public.integration_debug_logs TO authenticated;
GRANT ALL ON public.integration_debug_logs TO service_role;

ALTER TABLE public.integration_debug_logs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "workspace members view debug logs"
  ON public.integration_debug_logs FOR SELECT
  USING (is_workspace_member(workspace_id, auth.uid()));

CREATE INDEX IF NOT EXISTS idx_idl_ws_created
  ON public.integration_debug_logs(workspace_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_idl_integration_created
  ON public.integration_debug_logs(integration_id, created_at DESC);