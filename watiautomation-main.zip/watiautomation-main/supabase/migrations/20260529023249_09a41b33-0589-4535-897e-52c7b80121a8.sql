
-- 1) Pricing on plan_templates
ALTER TABLE public.plan_templates
  ADD COLUMN IF NOT EXISTS price_monthly numeric NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS price_yearly  numeric NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS currency      text    NOT NULL DEFAULT 'INR',
  ADD COLUMN IF NOT EXISTS gateway_ids   text[]  NOT NULL DEFAULT '{}'::text[];

-- 2) Snapshot pricing on workspace_plans
ALTER TABLE public.workspace_plans
  ADD COLUMN IF NOT EXISTS price_monthly    numeric NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS price_yearly     numeric NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS currency         text    NOT NULL DEFAULT 'INR',
  ADD COLUMN IF NOT EXISTS billing_interval text    NOT NULL DEFAULT 'monthly';

-- 3) Snapshot pricing on plan_requests
ALTER TABLE public.plan_requests
  ADD COLUMN IF NOT EXISTS price_monthly    numeric NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS price_yearly     numeric NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS currency         text    NOT NULL DEFAULT 'INR',
  ADD COLUMN IF NOT EXISTS billing_interval text    NOT NULL DEFAULT 'monthly';

-- 4) Payment gateway configuration (super-admin)
CREATE TABLE IF NOT EXISTS public.payment_gateways (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  provider    text NOT NULL UNIQUE, -- 'razorpay' | 'cashfree' | 'instamojo' | 'stripe'
  display_name text NOT NULL,
  is_enabled  boolean NOT NULL DEFAULT false,
  key_id      text,            -- publishable / merchant id (safe to expose)
  meta        jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at  timestamptz NOT NULL DEFAULT now(),
  updated_at  timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT ON public.payment_gateways TO authenticated;
GRANT ALL ON public.payment_gateways TO service_role;

ALTER TABLE public.payment_gateways ENABLE ROW LEVEL SECURITY;

CREATE POLICY "anyone authenticated can view enabled gateways"
ON public.payment_gateways FOR SELECT TO authenticated
USING (is_enabled = true OR public.is_super_admin(auth.uid()));

CREATE POLICY "super admins manage gateways"
ON public.payment_gateways FOR ALL TO authenticated
USING (public.is_super_admin(auth.uid()))
WITH CHECK (public.is_super_admin(auth.uid()));

-- Seed the four supported providers (disabled by default)
INSERT INTO public.payment_gateways (provider, display_name, is_enabled) VALUES
  ('razorpay',  'Razorpay',  false),
  ('cashfree',  'Cashfree',  false),
  ('instamojo', 'Instamojo', false),
  ('stripe',    'Stripe',    false)
ON CONFLICT (provider) DO NOTHING;

-- 5) Payment transactions
CREATE TABLE IF NOT EXISTS public.payment_transactions (
  id                 uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id       uuid NOT NULL,
  user_id            uuid NOT NULL,
  template_id        uuid,
  plan_name_snapshot text NOT NULL,
  provider           text NOT NULL,
  billing_interval   text NOT NULL DEFAULT 'monthly',
  amount             numeric NOT NULL DEFAULT 0,
  currency           text NOT NULL DEFAULT 'INR',
  status             text NOT NULL DEFAULT 'created', -- created | paid | failed | refunded
  order_id           text,
  payment_id         text,
  raw_event          jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at         timestamptz NOT NULL DEFAULT now(),
  updated_at         timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_pay_tx_workspace ON public.payment_transactions(workspace_id);
CREATE INDEX IF NOT EXISTS idx_pay_tx_order ON public.payment_transactions(provider, order_id);

GRANT SELECT, INSERT, UPDATE ON public.payment_transactions TO authenticated;
GRANT ALL ON public.payment_transactions TO service_role;

ALTER TABLE public.payment_transactions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "members view workspace transactions"
ON public.payment_transactions FOR SELECT TO authenticated
USING (public.is_workspace_member(workspace_id, auth.uid()) OR public.is_super_admin(auth.uid()));

CREATE POLICY "members create transactions"
ON public.payment_transactions FOR INSERT TO authenticated
WITH CHECK (public.is_workspace_member(workspace_id, auth.uid()) AND user_id = auth.uid());

-- updated_at triggers
DROP TRIGGER IF EXISTS trg_payment_gateways_updated ON public.payment_gateways;
CREATE TRIGGER trg_payment_gateways_updated
BEFORE UPDATE ON public.payment_gateways
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

DROP TRIGGER IF EXISTS trg_payment_transactions_updated ON public.payment_transactions;
CREATE TRIGGER trg_payment_transactions_updated
BEFORE UPDATE ON public.payment_transactions
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
