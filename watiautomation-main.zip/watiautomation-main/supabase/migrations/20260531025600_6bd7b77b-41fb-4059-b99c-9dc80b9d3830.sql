
-- =========================================
-- Landing Features (dynamic, admin-managed)
-- =========================================
CREATE TABLE public.landing_features (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  icon TEXT NOT NULL DEFAULT 'Sparkles',
  category TEXT NOT NULL DEFAULT 'General',
  position INTEGER NOT NULL DEFAULT 0,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.landing_features TO anon, authenticated;
GRANT ALL ON public.landing_features TO service_role;
ALTER TABLE public.landing_features ENABLE ROW LEVEL SECURITY;

CREATE POLICY "anyone reads active landing features"
ON public.landing_features FOR SELECT
USING (is_active = true OR public.is_super_admin(auth.uid()));

CREATE POLICY "super admins manage landing features"
ON public.landing_features FOR ALL
USING (public.is_super_admin(auth.uid()))
WITH CHECK (public.is_super_admin(auth.uid()));

CREATE TRIGGER landing_features_updated
BEFORE UPDATE ON public.landing_features
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- =========================================
-- Landing Testimonials
-- =========================================
CREATE TABLE public.landing_testimonials (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  company TEXT,
  role TEXT,
  photo_url TEXT,
  review TEXT NOT NULL,
  rating INTEGER NOT NULL DEFAULT 5,
  position INTEGER NOT NULL DEFAULT 0,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.landing_testimonials TO anon, authenticated;
GRANT ALL ON public.landing_testimonials TO service_role;
ALTER TABLE public.landing_testimonials ENABLE ROW LEVEL SECURITY;

CREATE POLICY "anyone reads active testimonials"
ON public.landing_testimonials FOR SELECT
USING (is_active = true OR public.is_super_admin(auth.uid()));

CREATE POLICY "super admins manage testimonials"
ON public.landing_testimonials FOR ALL
USING (public.is_super_admin(auth.uid()))
WITH CHECK (public.is_super_admin(auth.uid()));

CREATE TRIGGER landing_testimonials_updated
BEFORE UPDATE ON public.landing_testimonials
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- =========================================
-- Landing FAQs
-- =========================================
CREATE TABLE public.landing_faqs (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  question TEXT NOT NULL,
  answer TEXT NOT NULL,
  position INTEGER NOT NULL DEFAULT 0,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.landing_faqs TO anon, authenticated;
GRANT ALL ON public.landing_faqs TO service_role;
ALTER TABLE public.landing_faqs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "anyone reads active faqs"
ON public.landing_faqs FOR SELECT
USING (is_active = true OR public.is_super_admin(auth.uid()));

CREATE POLICY "super admins manage faqs"
ON public.landing_faqs FOR ALL
USING (public.is_super_admin(auth.uid()))
WITH CHECK (public.is_super_admin(auth.uid()));

CREATE TRIGGER landing_faqs_updated
BEFORE UPDATE ON public.landing_faqs
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- =========================================
-- Demo Requests
-- =========================================
CREATE TABLE public.demo_requests (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  full_name TEXT NOT NULL,
  email TEXT NOT NULL,
  phone TEXT,
  company TEXT,
  business_type TEXT,
  message TEXT,
  status TEXT NOT NULL DEFAULT 'new',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT INSERT ON public.demo_requests TO anon, authenticated;
GRANT ALL ON public.demo_requests TO service_role;
ALTER TABLE public.demo_requests ENABLE ROW LEVEL SECURITY;

CREATE POLICY "anyone submits demo requests"
ON public.demo_requests FOR INSERT
WITH CHECK (true);

CREATE POLICY "super admins read demo requests"
ON public.demo_requests FOR SELECT
USING (public.is_super_admin(auth.uid()));

CREATE POLICY "super admins update demo requests"
ON public.demo_requests FOR UPDATE
USING (public.is_super_admin(auth.uid()));

CREATE POLICY "super admins delete demo requests"
ON public.demo_requests FOR DELETE
USING (public.is_super_admin(auth.uid()));

-- =========================================
-- Trial fields on profiles
-- =========================================
ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS trial_started_at TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS trial_ends_at TIMESTAMPTZ;

-- Backfill trials for existing users so the dashboard countdown works
UPDATE public.profiles
SET trial_started_at = COALESCE(trial_started_at, created_at),
    trial_ends_at = COALESCE(trial_ends_at, created_at + INTERVAL '7 days')
WHERE trial_ends_at IS NULL;

-- Update the new-user trigger to set a 7-day trial on signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  new_ws UUID;
  base_name TEXT;
  is_first BOOLEAN;
BEGIN
  SELECT NOT EXISTS (SELECT 1 FROM public.profiles) INTO is_first;

  INSERT INTO public.profiles (id, email, full_name, is_super_admin, trial_started_at, trial_ends_at)
  VALUES (new.id, new.email, COALESCE(new.raw_user_meta_data->>'full_name', new.email), is_first, now(), now() + INTERVAL '7 days');

  base_name := COALESCE(new.raw_user_meta_data->>'full_name', split_part(new.email, '@', 1), 'Workspace');

  INSERT INTO public.workspaces (name, slug, owner_id)
  VALUES (
    base_name || '''s Workspace',
    lower(regexp_replace(base_name, '[^a-z0-9]+', '-', 'gi')) || '-' || substr(new.id::text, 1, 6),
    new.id
  )
  RETURNING id INTO new_ws;

  INSERT INTO public.workspace_members (workspace_id, user_id, role)
  VALUES (new_ws, new.id, 'owner');

  INSERT INTO public.whatsapp_settings (user_id, workspace_id) VALUES (new.id, new_ws);

  RETURN new;
END;
$function$;

-- =========================================
-- Seed initial landing features so the page isn't empty on first load
-- =========================================
INSERT INTO public.landing_features (name, description, icon, category, position) VALUES
('WhatsApp Business API', 'Official Meta WhatsApp Business Cloud API integration', 'MessageCircle', 'WhatsApp API', 1),
('Shared Team Inbox', 'Collaborate with your team on every conversation in real time', 'Inbox', 'WhatsApp API', 2),
('Template Messaging', 'Sync and send Meta-approved templates with variables', 'FileText', 'WhatsApp API', 3),
('Chatbot Builder', 'Visual drag-and-drop bot builder, no code required', 'Bot', 'Automation', 4),
('Auto Reply & Drip Campaigns', 'Trigger automated replies and time-based drip flows', 'Zap', 'Automation', 5),
('Workflow Automation', 'Build keyword and event-based automation workflows', 'Workflow', 'Automation', 6),
('Bulk Broadcast', 'Send personalized campaigns to thousands at once', 'Send', 'Marketing', 7),
('Audience Segmentation', 'Segment contacts by tags, behavior, and custom fields', 'Users', 'Marketing', 8),
('Click-to-WhatsApp Ads', 'Track conversions from Meta Click-to-WhatsApp ads', 'MousePointerClick', 'Marketing', 9),
('Lead & Pipeline Management', 'Track every lead through customizable sales stages', 'GitBranch', 'Sales', 10),
('Team Assignment', 'Auto-assign conversations and leads to the right agent', 'UserCheck', 'Sales', 11),
('Notes & Follow-ups', 'Never miss a follow-up with built-in reminders', 'BellRing', 'Sales', 12),
('Shopify & WooCommerce', 'Native integration with Shopify and WooCommerce stores', 'ShoppingBag', 'E-commerce', 13),
('Abandoned Cart Recovery', 'Recover lost revenue with automated cart reminders', 'ShoppingCart', 'E-commerce', 14),
('Order Notifications', 'Send order confirmation and shipping updates instantly', 'PackageCheck', 'E-commerce', 15),
('Contact Management', 'Centralized CRM with custom fields and tags', 'Contact', 'CRM', 16),
('Customer Segmentation', 'Group customers by lifecycle, spend, and behavior', 'Layers', 'CRM', 17),
('Campaign & Agent Reports', 'Real-time delivery, read, and agent performance reports', 'BarChart3', 'Analytics', 18),
('Performance Dashboard', 'Track KPIs and revenue impact at a glance', 'LineChart', 'Analytics', 19),
('Webhooks & Zapier', 'Connect Slice to 5000+ tools via webhooks and Zapier', 'Plug', 'Integrations', 20),
('Google Sheets Sync', 'Sync contacts and leads with Google Sheets in real time', 'Sheet', 'Integrations', 21),
('Open API Access', 'Build custom integrations with the Slice REST API', 'Code2', 'Integrations', 22);

INSERT INTO public.landing_faqs (question, answer, position) VALUES
('Is Slice an official WhatsApp Business API platform?', 'Yes. Slice uses the official Meta WhatsApp Business Cloud API. You connect your own Meta WhatsApp Business Account directly — no middlemen.', 1),
('How long is the free trial?', 'Every new account gets a 7-day free trial of the Basic plan with instant dashboard access. No credit card required.', 2),
('Can I send bulk broadcasts to my contacts?', 'Yes. Upload contacts via CSV or sync from your store, pick a Meta-approved template, and broadcast to thousands with real-time delivery tracking.', 3),
('Do you integrate with Shopify and WooCommerce?', 'Yes. We support Shopify, WooCommerce, and any custom store via webhooks. Recover abandoned carts and send order updates automatically.', 4),
('How is my data stored?', 'Your data is stored securely in an isolated workspace. Your Meta token and credentials never leave your private workspace.', 5),
('Can I cancel anytime?', 'Yes. Upgrade, downgrade, or cancel at any time from your dashboard. No long-term contracts.', 6);

INSERT INTO public.landing_testimonials (name, company, role, review, rating, position) VALUES
('Priya Sharma', 'Bloom Cosmetics', 'Founder', 'Slice helped us recover ₹4L in abandoned carts in the first month. The team inbox is a game-changer for our 6-agent support team.', 5, 1),
('Rohan Mehta', 'EduGrowth Academy', 'Marketing Head', 'We moved from manual broadcasts to fully automated drip campaigns. Our enrollment rate jumped 38% in two months.', 5, 2),
('Anita Desai', 'StyleHub India', 'Customer Success Lead', 'The Shopify integration just works. Order notifications and cart recovery run on autopilot now — exactly what we needed.', 5, 3);
